# CR7 — "Talent without work is nothing." · Final Report

A finished, verified, production-ready 3D scroll experience. Live preview running on **:5173**.
Source in `/home/user/cr7`.

## 1 · Source asset confirmation
- `Jersey.glb` cloned from `github.com/BlackSwordsman19/One`, served locally at `public/models/Jersey.glb`.
- **6,448,828 bytes** (exact). glTF 2.0 binary · `KHR_materials_specular` (0.6) · **0 baked animations**.
- 7 meshes / 3 embedded 2K PNG textures (`jersey_base`, `jersey_normal`, `jersey_orm`). Asset untouched.
- Runtime centroid via `Box3.setFromObject` → mandatory centering offset **(0, −0.37525, 0)** inside `JerseyRig`.

## 2 · Stack & renderer
- **Vite + TypeScript + modular Three.js (GLTFLoader) + GSAP + Lenis.** Single rAF loop. Self-hosted fonts; zero external runtime network dependency.
- Renderer: `ACESFilmicToneMapping`, exposure **1.12**, `SRGBColorSpace`, DPR clamped **[1, 2]**, antialias, `preserveDrawingBuffer` for reliable capture.
- Environment: procedural `RoomEnvironment` via `PMREMGenerator`, `environmentIntensity 0.40` (no external HDRI).
- PBR calibration: base→sRGB, normal/ORM→linear, `flipY=false` preserved, anisotropy = max(8, GPU max), `normalScale 0.9`.
- Scroll: Lenis smooth scroll → normalized `s` → `MathUtils.damp(λ=6.5)`; velocity `v` damped (λ=8). Pose via piecewise **Catmull-Rom** through the brief's keyframe table. Fully continuous & reversible (no IntersectionObserver one-shots).

## 3 · Six-act bidirectional choreography
- **Vertical wave:** desktop `JerseyRig.y` travels ≈ **−0.114 → +0.134 m** across the journey (1920×1080: −0.137 → +0.077 m); mobile rides the upper-48vh stage.
- **Rotation:** `rotY` sweeps **−0.28 → 3π (≈9.42 rad)** — front reveal → 180° dorsal spin → front → dorsal finale (1.5 turns), with `rotX/rotZ` tilts per the table.
- **Velocity reactivity:** `deltaY = clamp(−v·0.18, ±0.09)`, `deltaRotX = clamp(v·0.35, ±0.16)`, `deltaRotZ = clamp(−v·0.2, ±0.09)`; reverses instantly with scroll direction.
- **Idle levitation:** `sin(t·1.35)·0.016 m` Y + `cos(t·0.9)·0.025 rad` micro-yaw, blended in as `|v|→0`.
- **Ultraweave cloth:** non-destructive `onBeforeCompile` vertex wave masked by `h = clamp(1 − y/0.75)`; 2–3 mm at rest → 8–10 mm with velocity. Collar anchored, hem/cuffs ripple.
- **Lighting:** warm key + Atlantic-teal rim (carves the #047C80 collar off obsidian) + gold/crimson kick peaking in Acts IV/V + hemisphere fill; dust motes confined to z < −1.8.
- **Act VI:** drag-to-orbit 360° (verified Δyaw ≈ 1.6 rad) + Lenis "Back to Kickoff" reverse-scroll (verified return to s≈0).

## 4 · Palette & type
- Obsidian `#070709` · surface `#161821` · crimson `#BC0E28`/`#E01E37` · Atlantic teal `#047C80`/`#0BB5BA` · trophy gold `#D4AF37` · chalk `#F5F5F7` · steel `#9498A6`.
- **Bebas Neue** (display/quote/numerals) · **Plus Jakarta Sans** (body, ≤40ch, 1.65) · **JetBrains Mono** (telemetry/dates/coordinates).

## 5 · Headless WebGL verification (Playwright + SwiftShader)
DOWN `0→.2→.4→.6→.8→1`, UP `1→.8→.6→.4→.2→0`, plus a dense **0.02 sweep (51 stops)**, on **1440×900, 390×844, 768×1024, 1920×1080**. At every stop the jersey's world AABB is projected to screen px and compared against every visible UI rect.

| Viewport | UI overlaps | Frustum fails | Console errors | Failed requests | Hero pose returned |
|---|---|---|---|---|---|
| Desktop 1440×900 | **0** | **0** | 0 | 0 | ✅ exact |
| Mobile 390×844 | **0** | **0** | 0 | 0 | ✅ exact |
| Tablet 768×1024 | **0** | **0** | 0 | 0 | ✅ exact |
| Wide 1920×1080 | **0** | **0** | 0 | 0 | ✅ exact |

- **0 px² total UI occlusion** across all stops/viewports; frustum margins ≥16 px everywhere (desktop min top 86 / bottom 109 / sides 175 px). Minimum UI clearance: desktop 29 px · mobile 26 px · tablet 100 px · wide 143 px.
- **Exact bidirectional hero return** (`scripts/pose_return.mjs` → `verify/pose_return.log`): after reverse-scrolling from the finale, the rig returns to the hero pose with **0.000 mm / 0.000 mrad** delta on all four viewports, with monotonic reverse travel reaching the top.
- Quote `"Talent without work is nothing."` present **verbatim** in the DOM (display uppercased by design).
- GLB loads **locally, same-origin, 6,448,828 bytes**. Front crest/#7 and dorsal RONALDO 7 both render crisply.
- `npm run build` (tsc + vite) succeeds with **zero** TypeScript/bundler errors.

### Iterations & fixes
1. Mobile/tablet top-edge clipping + corner-HUD overlap → re-sized mobile frustum (`H 1.04→1.30`, centre lowered, wave attenuated) → 0 overlaps / 0 frustum.
2. SwiftShader screenshot deadlock → decoupled numeric assertions from captures; added pausable loop + `preserveDrawingBuffer` → reliable frames.
3. Counter window moved to `[0.75, 0.80]` so full verified records land while the ledger is visible.
4. Deterministic pose-return assertion (idle disabled + synchronous `snap` telemetry) → **0.000 mm exact** hero return on all viewports.
5. Mobile stage nudged down for ≥26 px HUD clearance (conservative AABB; actual silhouette gap larger).
6. Diagnosed a software-renderer-only effect: under SwiftShader's low FPS the `dt` clamp (0.05 s tab-switch safety) makes damped settling run in slow motion; on real 60 fps hardware `dt≈0.016` never hits the clamp and settling is ~0.7 s. Added a deterministic `snap` tool so pose assertions don't depend on renderer speed.

## 6 · Deliberate refinements
- **Live zero-occlusion guard:** panel opacity is multiplied by a smooth clearance gate computed from the projected jersey box every frame — UI yields *before* any overlap, in both directions, at any viewport (stronger than static safe-zones alone).
- Asymmetric split-stage that swaps sides per act; mobile upper-48vh / lower-52vh split.
- Perimeter-only HUD (CR7 // 07, act numeral, gold→crimson progress hairline).
- `prefers-reduced-motion` attenuates surge/ripple while preserving full scroll-scrubbed visibility.

## Artifacts
- `verify/final.log`, `verify/report.json` — full numeric occlusion/frustum/error results.
- `verify/pose_return.log` — exact bidirectional hero-return proof (0.000 mm, all viewports).
- `verify/interact.log` — orbit + replay interaction test.
- `verify/shots/` — desktop + mobile frames; `verify/contact_sheet.png` — visual overview.
- `WORKLOG.md`, `README.md`.
