import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const BASE = process.env.BASE_URL || 'http://localhost:5173';
const OUT = path.resolve('verify');
fs.mkdirSync(OUT, { recursive: true });

const ALL_VIEWPORTS = [
  { name: 'desktop', width: 1440, height: 900 },
  { name: 'mobile', width: 390, height: 844 },
  { name: 'tablet', width: 768, height: 1024 },
  { name: 'wide', width: 1920, height: 1080 },
];
const VIEWPORTS = process.env.VP ? ALL_VIEWPORTS.filter((v) => process.env.VP.split(',').includes(v.name)) : ALL_VIEWPORTS;
const STOPS = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0];
const UP_STOPS = [0.8, 0.6, 0.4, 0.2, 0.0];

const launchArgs = [
  '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
  '--ignore-gpu-blocklist', '--enable-webgl', '--disable-gpu-sandbox', '--no-sandbox',
];

function occlusionFn(box) {
  const els = Array.from(document.querySelectorAll('[data-ui], .hud, .replay'));
  const seen = new Set();
  const results = [];
  const effOpacity = (el) => { let o = 1, n = el; while (n && n !== document.body) { o *= parseFloat(getComputedStyle(n).opacity || '1'); n = n.parentElement; } return o; };
  const effVisible = (el) => { let n = el; while (n && n !== document.body) { const cs = getComputedStyle(n); if (cs.visibility === 'hidden' || cs.display === 'none') return false; n = n.parentElement; } return true; };
  for (const el of els) {
    if (seen.has(el)) continue; seen.add(el);
    if (!effVisible(el) || effOpacity(el) < 0.02) continue;
    const r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) continue;
    const ox = Math.max(0, Math.min(r.right, box.maxX) - Math.max(r.left, box.minX));
    const oy = Math.max(0, Math.min(r.bottom, box.maxY) - Math.max(r.top, box.minY));
    const area = ox * oy;
    const gapX = Math.max(box.minX - r.right, r.left - box.maxX);
    const gapY = Math.max(box.minY - r.bottom, r.top - box.maxY);
    const gap = Math.max(gapX, gapY);
    const sel = el.className && typeof el.className === 'string' ? el.tagName.toLowerCase() + '.' + el.className.trim().split(/\s+/).join('.') : el.tagName.toLowerCase();
    results.push({ sel, area: Math.round(area), gap: Math.round(gap), opacity: +effOpacity(el).toFixed(3) });
  }
  return results;
}

async function waitReady(page) {
  await page.waitForFunction(() => window.__CR7 && window.__CR7.ready, null, { timeout: 60000 });
  await page.waitForFunction(() => { const p = document.getElementById('preloader'); return p && (p.style.display === 'none' || parseFloat(getComputedStyle(p).opacity) < 0.05); }, null, { timeout: 60000 });
  await page.waitForTimeout(300);
}

async function settle(page, target, timeout = 4000) {
  const t0 = Date.now();
  let stable = 0;
  while (Date.now() - t0 < timeout) {
    const st = await page.evaluate(() => window.__CR7.state());
    // Require two consecutive stable reads so telemetry reflects the latest frame
    // (avoids reading a stale pre-setIdle / mid-deceleration frame).
    if (Math.abs(st.v) < 0.003 && Math.abs(st.s - target) < 0.003) { stable++; if (stable >= 2) return st; }
    else stable = 0;
    await page.waitForTimeout(70);
  }
  return page.evaluate(() => window.__CR7.state());
}

async function sample(page, vp, target) {
  const st = await settle(page, target);
  const box = st.box;
  const occ = await page.evaluate(occlusionFn, box);
  const overlaps = occ.filter((o) => o.area > 0);
  const frustum = {
    left: Math.round(box.minX), top: Math.round(box.minY),
    right: Math.round(vp.width - box.maxX), bottom: Math.round(vp.height - box.maxY),
    ok: box.minX >= 16 && box.maxX <= vp.width - 16 && box.minY >= 16 && box.maxY <= vp.height - 16,
  };
  return { target, s: +st.s.toFixed(4), v: +st.v.toFixed(4), act: st.act, rigPos: st.rigPos, rigRot: st.rigRot, box, frustum, overlaps, minGap: Math.min(...occ.map((o) => o.gap)), uiCount: occ.length };
}

const report = { base: BASE, viewports: [], quote: false, glb: null };
const browser = await chromium.launch({ headless: true, args: launchArgs });

for (const vp of VIEWPORTS) {
  const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const consoleErrors = [], failed = [];
  page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
  page.on('pageerror', (e) => consoleErrors.push('PAGEERROR: ' + e.message));
  page.on('requestfailed', (r) => failed.push(r.url() + ' :: ' + (r.failure()?.errorText || '')));
  page.on('response', (r) => { if (r.status() >= 400) failed.push(r.url() + ' :: HTTP ' + r.status()); });

  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 60000 });
  await waitReady(page);
  // Disable ambient idle levitation for deterministic, reproducible pose assertions.
  await page.evaluate(() => window.__CR7.setIdle(false));

  report.glb = await page.evaluate(() => { const e = performance.getEntriesByType('resource').find((r) => r.name.includes('Jersey.glb')); return e ? { name: e.name.split('/').pop(), size: e.encodedBodySize || e.transferSize, local: e.name.includes(location.host) } : null; });
  report.quote = await page.evaluate(() => { const q = document.querySelector('.quote'); return q ? q.textContent.trim() === 'Talent without work is nothing.' : false; });

  const vreport = { name: vp.name, width: vp.width, height: vp.height, down: [], up: [], dense: [], heroPose: null, returnPose: null, consoleErrors, failed };

  // DOWNWARD sweep (scroll to each stop, then settle + assert)
  await page.evaluate(() => window.__CR7.scrollTo(0, true));
  const hero = await sample(page, vp, 0.0);
  vreport.heroPose = { rigPos: hero.rigPos, rigRot: hero.rigRot };
  vreport.down.push(hero);
  for (let i = 1; i < STOPS.length; i++) {
    await page.evaluate((p) => window.__CR7.scrollTo(p, true), STOPS[i]);
    vreport.down.push(await sample(page, vp, STOPS[i]));
  }
  // UPWARD sweep via animated scroll to exercise reverse damping + velocity reactivity
  for (const target of UP_STOPS) { await page.evaluate((p) => window.__CR7.scrollTo(p, false), target); vreport.up.push(await sample(page, vp, target)); }
  // Measure the return-to-hero pose at a guaranteed rest state (idle disabled).
  await page.evaluate(() => window.__CR7.scrollTo(0, true));
  const rest = await sample(page, vp, 0.0);
  vreport.returnPose = { rigPos: rest.rigPos, rigRot: rest.rigRot };

  for (let p = 0; p <= 1.0001; p += 0.02) {
    const target = Math.min(1, +p.toFixed(3));
    await page.evaluate((t) => window.__CR7.scrollTo(t, true), target);
    const st = await settle(page, target, 1500);
    const occ = await page.evaluate(occlusionFn, st.box);
    const overlaps = occ.filter((o) => o.area > 0);
    const b = st.box;
    const ok = b.minX >= 16 && b.maxX <= vp.width - 16 && b.minY >= 16 && b.maxY <= vp.height - 16;
    vreport.dense.push({ target, overlaps, frustumOk: ok, box: { minX: Math.round(b.minX), minY: Math.round(b.minY), maxX: Math.round(b.maxX), maxY: Math.round(b.maxY) }, minGap: Math.min(...occ.map((o) => o.gap)) });
  }
  report.viewports.push(vreport);
  await ctx.close();
  console.log(`[${vp.name}] done`);
}
await browser.close();

let totalOverlaps = 0, frustumFails = 0;
for (const v of report.viewports) {
  for (const d of [...v.down, ...v.up]) { totalOverlaps += d.overlaps.length; if (!d.frustum.ok) frustumFails++; }
  for (const d of v.dense) { totalOverlaps += d.overlaps.length; if (!d.frustumOk) frustumFails++; }
}
report.summary = {
  totalOverlaps, frustumFails,
  consoleErrors: report.viewports.reduce((a, v) => a + v.consoleErrors.length, 0),
  failedRequests: report.viewports.reduce((a, v) => a + v.failed.length, 0),
  quoteVerbatim: report.quote,
};
fs.writeFileSync(path.join(OUT, 'report.json'), JSON.stringify(report, null, 2));
console.log('\nSUMMARY ' + JSON.stringify(report.summary));
console.log('GLB ' + JSON.stringify(report.glb));
for (const v of report.viewports) {
  const ov = [...v.down, ...v.up, ...v.dense].flatMap((d) => (d.overlaps || []).map((o) => ({ s: d.target, ...o })));
  const ff = [...v.down, ...v.up].filter((d) => !d.frustum.ok).map((d) => ({ s: d.target, f: d.frustum }));
  const dff = v.dense.filter((d) => !d.frustumOk).map((d) => ({ s: d.target, box: d.box }));
  const dp = Math.max(Math.abs(v.heroPose.rigPos.x - v.returnPose.rigPos.x), Math.abs(v.heroPose.rigPos.y - v.returnPose.rigPos.y));
  const dr = Math.max(Math.abs(v.heroPose.rigRot.x - v.returnPose.rigRot.x), Math.abs(v.heroPose.rigRot.y - v.returnPose.rigRot.y), Math.abs(v.heroPose.rigRot.z - v.returnPose.rigRot.z));
  const heroReturn = dp < 0.01 && dr < 0.01; // idle disabled -> exact choreography return
  console.log(`\n[${v.name}] overlaps=${ov.length} frustumFails=${ff.length + dff.length} consoleErrors=${v.consoleErrors.length} failed=${v.failed.length} heroPoseReturned=${heroReturn}`);
  if (ov.length) console.log('  OVERLAPS ' + JSON.stringify(ov.slice(0, 15)));
  if (ff.length) console.log('  FRUSTUM(stops) ' + JSON.stringify(ff));
  if (dff.length) console.log('  FRUSTUM(dense) ' + JSON.stringify(dff.slice(0, 15)));
  if (v.consoleErrors.length) console.log('  ERRORS ' + JSON.stringify(v.consoleErrors.slice(0, 8)));
  if (v.failed.length) console.log('  FAILED ' + JSON.stringify(v.failed.slice(0, 8)));
}
process.exit(totalOverlaps === 0 && frustumFails === 0 && report.summary.consoleErrors === 0 && report.summary.failedRequests === 0 && report.quote ? 0 : 1);
