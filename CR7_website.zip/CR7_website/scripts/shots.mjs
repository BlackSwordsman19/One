import { chromium } from 'playwright';
import fs from 'node:fs';
import path from 'node:path';

const BASE = process.env.BASE_URL || 'http://localhost:5173';
const OUT = path.resolve('verify/shots');
fs.mkdirSync(OUT, { recursive: true });
const VIEWPORTS = (process.env.VP || 'desktop,mobile').split(',').map((n) => ({
  desktop: { name: 'desktop', width: 1440, height: 900 },
  mobile: { name: 'mobile', width: 390, height: 844 },
  tablet: { name: 'tablet', width: 768, height: 1024 },
}[n]));
const STOPS = [0.0, 0.2, 0.4, 0.6, 0.8, 1.0];
const args = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'];

async function waitReady(page) {
  await page.waitForFunction(() => window.__CR7 && window.__CR7.ready, null, { timeout: 60000 });
  await page.waitForFunction(() => { const p = document.getElementById('preloader'); return p && (p.style.display === 'none' || parseFloat(getComputedStyle(p).opacity) < 0.05); }, null, { timeout: 60000 });
  await page.waitForTimeout(400);
}
async function settle(page, target) {
  const t0 = Date.now();
  while (Date.now() - t0 < 2600) {
    const st = await page.evaluate(() => window.__CR7.state());
    if (Math.abs(st.v) < 0.004 && Math.abs(st.s - target) < 0.004) return;
    await page.waitForTimeout(50);
  }
}

const browser = await chromium.launch({ headless: true, args });
for (const vp of VIEWPORTS) {
  const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  await page.goto(BASE, { waitUntil: 'networkidle', timeout: 60000 });
  await waitReady(page);
  for (const target of STOPS) {
    await page.evaluate((p) => window.__CR7.scrollTo(p, true), target);
    await settle(page, target);
    await page.waitForTimeout(200);
    await page.evaluate(() => window.__CR7.pause());
    await page.waitForTimeout(120);
    const file = `${vp.name}_s${String(target).replace('.', '_')}.png`;
    try {
      await page.screenshot({ path: path.join(OUT, file), timeout: 30000 });
      console.log('ok ' + file);
    } catch (e) { console.log('SKIP ' + file + ' ' + e.message.split('\n')[0]); }
    await page.evaluate(() => window.__CR7.resume());
  }
  await ctx.close();
}
await browser.close();
console.log('done');
