import { chromium } from 'playwright';
const BASE = 'http://localhost:5173';
const args = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'];
const b = await chromium.launch({ headless: true, args });
const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
const errs = [];
p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
p.on('pageerror', (e) => errs.push('PAGEERR ' + e.message));
await p.goto(BASE, { waitUntil: 'networkidle' });
await p.waitForFunction(() => window.__CR7 && window.__CR7.ready, null, { timeout: 60000 });
await p.waitForFunction(() => { const x = document.getElementById('preloader'); return x && (x.style.display === 'none' || parseFloat(getComputedStyle(x).opacity) < 0.05); }, null, { timeout: 60000 });

// Go to Act VI
await p.evaluate(() => window.__CR7.scrollTo(1, true));
await p.waitForTimeout(1500);
const before = await p.evaluate(() => window.__CR7.state());

// Drag horizontally across the canvas centre to orbit
await p.mouse.move(720, 450);
await p.mouse.down();
for (let i = 1; i <= 12; i++) { await p.mouse.move(720 + i * 18, 450); await p.waitForTimeout(16); }
await p.mouse.up();
await p.waitForTimeout(400);
const after = await p.evaluate(() => window.__CR7.state());
const orbitDelta = Math.abs(after.rigRot.y - before.rigRot.y);

// Click "Back to Kickoff" and poll until the reverse scroll settles at the top.
await p.click('#replay');
let returned;
const t0 = Date.now();
while (Date.now() - t0 < 7000) {
  returned = await p.evaluate(() => window.__CR7.state());
  if (returned.s < 0.02 && Math.abs(returned.v) < 0.01) break;
  await p.waitForTimeout(100);
}

console.log(JSON.stringify({
  actAtEnd: before.act,
  orbitYawBefore: +before.rigRot.y.toFixed(3),
  orbitYawAfter: +after.rigRot.y.toFixed(3),
  orbitDelta: +orbitDelta.toFixed(3),
  orbitWorks: orbitDelta > 0.3,
  replayReturnedS: +returned.s.toFixed(3),
  replayWorks: returned.s < 0.05,
  errors: errs,
}, null, 2));
await b.close();
process.exit(orbitDelta > 0.3 && returned.s < 0.05 && errs.length === 0 ? 0 : 1);
