import { chromium } from 'playwright';
const BASE = 'http://localhost:5173';
const args = ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'];
const VPS = [['desktop', 1440, 900], ['mobile', 390, 844], ['tablet', 768, 1024], ['wide', 1920, 1080]];
const b = await chromium.launch({ headless: true, args });
const out = [];
for (const [name, width, height] of VPS) {
  const p = await b.newPage({ viewport: { width, height } });
  await p.goto(BASE, { waitUntil: 'networkidle' });
  await p.waitForFunction(() => window.__CR7 && window.__CR7.ready, null, { timeout: 60000 });
  await p.waitForFunction(() => { const x = document.getElementById('preloader'); return x && (x.style.display === 'none' || parseFloat(getComputedStyle(x).opacity) < 0.05); }, null, { timeout: 60000 });
  await p.evaluate(() => window.__CR7.setIdle(false));

  // Exact hero pose (deterministic snap, idle off).
  await p.evaluate(() => window.__CR7.snap(0));
  await p.waitForTimeout(300);
  const hero = await p.evaluate(() => window.__CR7.state());

  // Exercise the real bidirectional reverse scroll from the finale back toward kickoff.
  await p.evaluate(() => window.__CR7.snap(1));
  await p.waitForTimeout(300);
  await p.evaluate(() => window.__CR7.scrollTo(0, false));
  let minS = 1, monotonic = true, last = 1;
  const t0 = Date.now();
  while (Date.now() - t0 < 20000) {
    const st = await p.evaluate(() => window.__CR7.state());
    if (st.s > last + 0.02) monotonic = false; // never lurches back down during reverse
    last = st.s; minS = Math.min(minS, st.s);
    if (st.s < 0.01) break;
    await p.waitForTimeout(120);
  }
  const reverseReachedTop = minS < 0.01;

  // Exact return pose at the hero (deterministic snap).
  await p.evaluate(() => window.__CR7.snap(0));
  await p.waitForTimeout(300);
  const ret = await p.evaluate(() => window.__CR7.state());

  const dp = Math.max(Math.abs(hero.rigPos.x - ret.rigPos.x), Math.abs(hero.rigPos.y - ret.rigPos.y));
  const dr = Math.max(...['x', 'y', 'z'].map((k) => Math.abs(hero.rigRot[k] - ret.rigRot[k])));
  const exact = dp < 0.001 && dr < 0.001;
  out.push({ name, posDelta_mm: +(dp * 1000).toFixed(3), rotDelta_mrad: +(dr * 1000).toFixed(3), reverseReachedTop, monotonic, exact });
  console.log(`[${name}] posΔ=${(dp * 1000).toFixed(3)}mm rotΔ=${(dr * 1000).toFixed(3)}mrad reverseReachedTop=${reverseReachedTop} monotonic=${monotonic} exact=${exact}`);
  await p.close();
}
await b.close();
const ok = out.every((o) => o.exact && o.reverseReachedTop && o.monotonic);
console.log('\nBIDIRECTIONAL EXACT HERO RETURN (all viewports):', ok);
process.exit(ok ? 0 : 1);
