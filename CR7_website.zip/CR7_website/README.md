# CR7 — Talent Without Work Is Nothing

A premium, scroll-driven 3D tribute to Cristiano Ronaldo, built around the authoritative
`Jersey.glb` (Portugal #7 home kit) as a continuously animated, **never-occluded** centerpiece.

> "Talent without work is nothing."

## Run

```bash
npm install
npm run dev        # http://localhost:5173  (binds 0.0.0.0)
npm run build      # tsc + vite production build → dist/
npm run preview    # serve the production build on :4173
```

The 3D model is served locally from `public/models/Jersey.glb` (6,448,828 bytes, cloned from
`github.com/BlackSwordsman19/One`). Fonts are self-hosted in `public/fonts`. **Zero external
runtime network dependencies.**

## Verify (headless WebGL)

```bash
npm run verify                 # programmatic occlusion + frustum + error sweep, 4 viewports
VP=mobile node scripts/verify.mjs   # filter viewports (desktop,mobile,tablet,wide)
VP=desktop,mobile node scripts/shots.mjs  # paused-render screenshot capture → verify/shots/
```

`verify.mjs` scrolls DOWN and UP through the six acts plus a dense 0.02 sweep, projects the
jersey's world-space AABB to screen pixels, and asserts **0 px² overlap** against every visible
UI element and **≥16 px** frustum clearance, with zero console/network errors. Results land in
`verify/report.json` and `verify/final.log`.

## Architecture

| Layer | File | Responsibility |
|---|---|---|
| Entry / loop | `src/main.ts` | single rAF, preloader, choreography assembly, debug API |
| 3D stage | `src/core/stage.ts` | renderer, frustum-safe camera solver, jersey rig, PBR calibration, wind shader, lights, dust |
| Choreography | `src/core/choreography.ts` | 6-act Catmull-Rom pose spline + act windows |
| Scroll | `src/core/scroll.ts` | Lenis + damped bidirectional `s`/`v` state |
| UI | `src/core/ui.ts` | panel opacity, **live zero-occlusion guard**, counters, drag-orbit, HUD |
| Styles | `src/style.css` | obsidian editorial palette, safe-zone layout, responsive |

### The zero-occlusion law
Every frame, the jersey's 8 AABB corners are transformed by `JerseyRig.matrixWorld` and projected
to screen pixels. Each editorial panel's opacity is multiplied by a smooth **clearance gate**
computed from the gap between its rect and that box — so UI gracefully yields *before* any pixel
of the jersey is covered, in both scroll directions, at every viewport.

### Bidirectional motion
`JerseyRig.position/rotation` are pure functions of damped scroll `s` (Catmull-Rom through the
brief's keyframe table) plus velocity-reactive surge/bank and idle levitation. Scrolling up plays
the exact choreography in reverse back to the hero pose. The Ultraweave cloth ripple is a
non-destructive `onBeforeCompile` vertex wave masked by local height.

### Palette
Obsidian `#070709` · Crimson `#BC0E28`/`#E01E37` · Atlantic teal `#047C80`/`#0BB5BA` ·
Trophy gold `#D4AF37` · Chalk `#F5F5F7` · Steel `#9498A6`.
Type: **Bebas Neue** (display) · **Plus Jakarta Sans** (body) · **JetBrains Mono** (telemetry).

## Controls
- Scroll / swipe — drive the six-act journey (down and up).
- Act VI — drag horizontally to orbit the jersey 360°.
- "Back to Kickoff" — smooth reverse-scroll to the hero.
- Respects `prefers-reduced-motion` (attenuates surge/ripple, keeps full scroll visibility).
