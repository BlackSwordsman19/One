import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import type { ScreenBox } from '../types';

export interface CameraSolution {
  z: number;
  H: number; // frustum half-height (m) at jersey plane
  W: number; // frustum half-width (m)
  baseY: number; // vertical offset to place jersey (mobile upper stage)
  yScale: number; // scale applied to choreography elevation
  xScale: number; // scale applied to choreography stage-x (0 on mobile)
  surgeScale: number;
  mobile: boolean;
}

const FOV = 35;
const TAN_HALF = Math.tan((FOV * Math.PI) / 360);

// Solve a frustum-safe camera for the current viewport.
export function solveCamera(width: number, height: number): CameraSolution {
  const aspect = width / height;
  const mobile = width < 1024;
  if (mobile) {
    // Jersey lives in the upper ~48vh; editorial owns the lower 52vh.
    // baseY = 0.5*H centres the jersey at 25vh; H sized for rotation + wave headroom
    // so the projected box clears the corner HUD (top) and the editorial band (bottom).
    const H = 1.3;
    const z = H / TAN_HALF;
    return { z, H, W: H * aspect, baseY: 0.44 * H, yScale: 0.18, xScale: 0, surgeScale: 0.2, mobile: true };
  }
  // Desktop: prominent side-stage jersey with >=10% headroom at peak excursion.
  const H = 0.78;
  const z = H / TAN_HALF;
  return { z, H, W: H * aspect, baseY: 0, yScale: 1, xScale: 1, surgeScale: 1, mobile: false };
}

interface WindShader {
  uniforms: Record<string, { value: number }>;
}

export class Stage {
  renderer: THREE.WebGLRenderer;
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  rig: THREE.Group; // JerseyRig — all scroll transforms applied here
  private centerGroup: THREE.Group;
  private half = new THREE.Vector3(0.3699, 0.37525, 0.134);
  private windShaders: WindShader[] = [];
  private keyLight: THREE.DirectionalLight;
  private rimLight: THREE.DirectionalLight;
  private kickLight: THREE.DirectionalLight;
  private fillLight: THREE.HemisphereLight;
  private dust: THREE.Points;
  private dustVel: Float32Array;
  private cam: CameraSolution;
  private pmrem: THREE.PMREMGenerator;
  private envRT: THREE.WebGLRenderTarget | null = null;
  private boxCorners: THREE.Vector3[] = [];
  ready = false;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.renderer.setPixelRatio(Math.min(2, Math.max(1, window.devicePixelRatio || 1)));

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(FOV, 1, 0.05, 60);
    this.cam = solveCamera(window.innerWidth, window.innerHeight);
    this.applyCamera();

    // Environment (procedural, no external HDRI)
    this.pmrem = new THREE.PMREMGenerator(this.renderer);
    const envScene = new RoomEnvironment();
    this.envRT = this.pmrem.fromScene(envScene, 0.04);
    this.scene.environment = this.envRT.texture;
    this.scene.environmentIntensity = 0.4;

    // Lights
    this.fillLight = new THREE.HemisphereLight(0x2a3038, 0x0a0608, 0.5);
    this.scene.add(this.fillLight);

    this.keyLight = new THREE.DirectionalLight(0xfff7ee, 2.4);
    this.keyLight.position.set(2.6, 2.2, 3.4);
    this.scene.add(this.keyLight);

    this.rimLight = new THREE.DirectionalLight(0x12b8be, 1.7);
    this.rimLight.position.set(-3.2, 2.6, -2.6);
    this.scene.add(this.rimLight);

    this.kickLight = new THREE.DirectionalLight(0xf3b95f, 0.8);
    this.kickLight.position.set(2.8, -1.6, -2.4);
    this.scene.add(this.kickLight);

    // Rig hierarchy: JerseyRig -> centerGroup(-centroid) -> JerseyAsset
    this.rig = new THREE.Group();
    this.rig.name = 'JerseyRig';
    this.centerGroup = new THREE.Group();
    this.rig.add(this.centerGroup);
    this.scene.add(this.rig);

    // Dust motes (deep background only, z < -1.8)
    const N = 220;
    const pos = new Float32Array(N * 3);
    this.dustVel = new Float32Array(N);
    for (let i = 0; i < N; i++) {
      pos[i * 3] = (Math.random() - 0.5) * 7;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 5;
      pos[i * 3 + 2] = -1.9 - Math.random() * 3.2;
      this.dustVel[i] = 0.02 + Math.random() * 0.05;
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x8a8f9c, size: 0.02, sizeAttenuation: true, transparent: true, opacity: 0.35,
      depthWrite: false, blending: THREE.AdditiveBlending,
    });
    this.dust = new THREE.Points(dustGeo, dustMat);
    this.scene.add(this.dust);

    for (let i = 0; i < 8; i++) this.boxCorners.push(new THREE.Vector3());
  }

  private applyCamera() {
    const w = window.innerWidth, h = window.innerHeight;
    this.cam = solveCamera(w, h);
    this.camera.aspect = w / h;
    this.camera.position.set(0, 0, this.cam.z);
    this.camera.lookAt(0, 0, 0);
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h, false);
    this.renderer.setPixelRatio(Math.min(2, Math.max(1, window.devicePixelRatio || 1)));
  }

  resize() { this.applyCamera(); }
  get camSolution() { return this.cam; }

  async load(onProgress: (p: number) => void): Promise<void> {
    const loader = new GLTFLoader();
    const TOTAL = 6448828;
    const gltf = await loader.loadAsync('./models/Jersey.glb', (e) => {
      const total = e.total || TOTAL;
      onProgress(Math.min(1, e.loaded / total));
    });
    const asset = gltf.scene;
    asset.name = 'JerseyAsset';

    // Compute true centroid + half extents from real geometry.
    const box = new THREE.Box3().setFromObject(asset);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    this.half.set(size.x / 2, size.y / 2, size.z / 2);
    // Mandatory pivot offset: mount inside centering group translated by -centroid.
    this.centerGroup.position.set(-center.x, -center.y, -center.z);

    const maxAniso = Math.max(8, this.renderer.capabilities.getMaxAnisotropy());
    asset.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.frustumCulled = false;
      const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const m of mats) this.calibrateMaterial(m as THREE.MeshStandardMaterial, maxAniso);
    });

    this.centerGroup.add(asset);
    this.ready = true;
  }

  private calibrateMaterial(mat: THREE.MeshStandardMaterial, aniso: number) {
    const anyMat = mat as unknown as Record<string, unknown>;
    const setColor = (tex: THREE.Texture | null, srgb: boolean) => {
      if (!tex) return;
      tex.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
      tex.flipY = false; // preserve glTF native orientation
      tex.anisotropy = aniso;
      tex.needsUpdate = true;
    };
    setColor(mat.map ?? null, true);
    setColor(mat.normalMap ?? null, false);
    setColor(mat.roughnessMap ?? null, false);
    setColor(mat.metalnessMap ?? null, false);
    setColor((anyMat.aoMap as THREE.Texture) ?? null, false);
    if (mat.normalMap) mat.normalScale.set(0.9, 0.9);
    mat.envMapIntensity = 0.55;
    mat.needsUpdate = true;
    this.injectWind(mat);
  }

  private injectWind(mat: THREE.MeshStandardMaterial) {
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.uTime = { value: 0 };
      shader.uniforms.uWind = { value: 0.003 };
      shader.vertexShader = 'uniform float uTime;\nuniform float uWind;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        float hgt = clamp(1.0 - position.y / 0.75, 0.0, 1.0);
        float w1 = sin(position.x * 21.0 + uTime * 2.3) * cos(position.y * 8.0 - uTime * 1.9);
        float w2 = sin(position.y * 15.0 + uTime * 3.1);
        float amp = uWind * hgt * hgt;
        transformed += normal * (w1 * amp);
        transformed.x += w2 * amp * 0.5;
        transformed.z += cos(position.x * 17.0 + uTime * 2.7) * amp * 0.4;`
      );
      this.windShaders.push(shader as unknown as WindShader);
    };
    mat.customProgramCacheKey = () => 'cr7wind';
  }

  // Per-frame lighting modulation across the 6 acts.
  updateLighting(s: number, act: number) {
    // Key stays strong; rim carves teal collar; kick peaks in Acts IV/V.
    const kickPeak = act === 4 ? 1.0 : act === 5 ? 0.85 : 0.35;
    const gold = act === 4 || act === 5;
    this.kickLight.intensity = 0.5 + kickPeak * 1.6;
    this.kickLight.color.setHex(gold ? 0xf3b95f : 0xd91e36);
    this.keyLight.intensity = 2.2 + 0.5 * Math.sin(s * Math.PI);
    this.rimLight.intensity = 1.5 + (act === 6 ? 0.7 : 0.2);
    this.fillLight.intensity = 0.45 + 0.1 * Math.sin(s * Math.PI * 2);
  }

  updateWind(time: number, velocity: number, reduced: boolean) {
    const base = reduced ? 0.0012 : 0.003;
    const surge = Math.min(Math.abs(velocity) * 0.02, reduced ? 0.002 : 0.007);
    const amp = base + surge;
    for (const sh of this.windShaders) {
      sh.uniforms.uTime.value = time;
      sh.uniforms.uWind.value = amp;
    }
  }

  updateDust(dt: number, velocity: number) {
    const attr = this.dust.geometry.getAttribute('position') as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    const drift = -velocity * 0.6; // opposite scroll velocity
    for (let i = 0; i < this.dustVel.length; i++) {
      arr[i * 3 + 1] += (this.dustVel[i] * 0.3 + drift) * dt;
      if (arr[i * 3 + 1] > 2.6) arr[i * 3 + 1] = -2.6;
      if (arr[i * 3 + 1] < -2.6) arr[i * 3 + 1] = 2.6;
    }
    attr.needsUpdate = true;
  }

  // Project the jersey's world-space AABB corners to screen pixels.
  screenBox(width: number, height: number): ScreenBox {
    const hx = this.half.x, hy = this.half.y, hz = this.half.z;
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    let idx = 0;
    for (let xi = -1; xi <= 1; xi += 2)
      for (let yi = -1; yi <= 1; yi += 2)
        for (let zi = -1; zi <= 1; zi += 2) {
          const c = this.boxCorners[idx++];
          c.set(xi * hx, yi * hy, zi * hz);
          c.applyMatrix4(this.rig.matrixWorld);
          c.project(this.camera);
          const px = (c.x * 0.5 + 0.5) * width;
          const py = (-c.y * 0.5 + 0.5) * height;
          minX = Math.min(minX, px); maxX = Math.max(maxX, px);
          minY = Math.min(minY, py); maxY = Math.max(maxY, py);
        }
    return { minX, minY, maxX, maxY };
  }

  render() { this.renderer.render(this.scene, this.camera); }

  async warmup(): Promise<void> {
    this.rig.updateMatrixWorld(true);
    if (this.renderer.compileAsync) await this.renderer.compileAsync(this.scene, this.camera);
    else this.renderer.compile(this.scene, this.camera);
    this.render();
  }

  dispose() {
    this.scene.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (mesh.isMesh) {
        mesh.geometry?.dispose();
        const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
        mats.forEach((m) => {
          const mm = m as THREE.MeshStandardMaterial;
          mm.map?.dispose(); mm.normalMap?.dispose(); mm.roughnessMap?.dispose(); mm.metalnessMap?.dispose();
          mm.dispose();
        });
      }
    });
    this.dust.geometry.dispose();
    (this.dust.material as THREE.Material).dispose();
    this.envRT?.dispose();
    this.pmrem.dispose();
    this.renderer.dispose();
  }
}
