import Lenis from 'lenis';
import * as THREE from 'three';
import type { ScrollState } from '../types';

export class ScrollEngine {
  lenis: Lenis;
  state: ScrollState = { s: 0, v: 0, raw: 0 };
  private prevS = 0;
  private reduced = false;
  private maxScroll = 1;

  constructor() {
    this.reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.lenis = new Lenis({
      duration: this.reduced ? 0.0 : 1.15,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: !this.reduced,
      syncTouch: false,
      touchMultiplier: 1.4,
    });
    this.measure();
    window.addEventListener('resize', () => this.measure());
  }

  private measure() {
    this.maxScroll = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  }

  // Called once per frame with dt in seconds.
  update(dt: number) {
    const raw = THREE.MathUtils.clamp(window.scrollY / this.maxScroll, 0, 1);
    this.state.raw = raw;
    const lambda = 6.5;
    const s = THREE.MathUtils.damp(this.state.s, raw, lambda, dt);
    const instV = dt > 0 ? (s - this.prevS) / dt : 0;
    // Damp velocity too, for silky inertia.
    this.state.v = THREE.MathUtils.damp(this.state.v, instV, 8, dt);
    this.state.s = s;
    this.prevS = s;
  }

  scrollToTop() {
    this.lenis.scrollTo(0, { duration: this.reduced ? 0 : 1.6 });
  }

  // Deterministic snap for verification: bypass damping lag (useful under low-FPS
  // software rendering where the dt clamp makes damped settling run in slow motion).
  snap(p: number) {
    const y = THREE.MathUtils.clamp(p, 0, 1) * this.maxScroll;
    this.lenis.scrollTo(y, { immediate: true });
    window.scrollTo(0, y);
    this.state.s = p; this.state.raw = p; this.state.v = 0;
    this.prevS = p;
  }

  get isReduced() { return this.reduced; }
  raf(time: number) { this.lenis.raf(time); }
  destroy() { this.lenis.destroy(); window.removeEventListener('resize', () => this.measure()); }
}
