import { actAt, clamp, smoothstep } from './choreography';
import type { ScreenBox } from '../types';

interface PanelMeta {
  el: HTMLElement;
  act: number;
  side: string;
  rects: DOMRect;
}

// Base opacity windows per act (inset so panels yield while the jersey crosses centre).
const WINDOWS: Record<number, [number, number, number, number]> = {
  // [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd]
  1: [-0.02, 0.0, 0.125, 0.165],
  2: [0.175, 0.215, 0.275, 0.315],
  3: [0.385, 0.425, 0.495, 0.535],
  4: [0.565, 0.605, 0.675, 0.715],
  5: [0.75, 0.79, 0.845, 0.878],
  6: [0.885, 0.925, 1.02, 1.06],
};

export class UIController {
  private panels: PanelMeta[] = [];
  private actNum: HTMLElement;
  private progressFill: HTMLElement;
  private counters: { el: HTMLElement; target: number; suffix: string }[] = [];
  private lastAct = 0;
  orbitYaw = 0;
  orbitPitch = 0;
  private dragging = false;
  private dragAxis: 'none' | 'orbit' | 'scroll' = 'none';
  private lastX = 0;
  private lastY = 0;
  private startX = 0;
  private startY = 0;
  private currentAct = 1;
  private onReplay: () => void;

  constructor(canvas: HTMLCanvasElement, onReplay: () => void) {
    this.onReplay = onReplay;
    document.querySelectorAll<HTMLElement>('[data-act]').forEach((el) => {
      this.panels.push({
        el,
        act: Number(el.dataset.act),
        side: el.dataset.side || 'left',
        rects: el.getBoundingClientRect(),
      });
    });
    this.actNum = document.getElementById('act-num')!;
    this.progressFill = document.getElementById('progress-fill')!;
    document.querySelectorAll<HTMLElement>('[data-count]').forEach((el) => {
      this.counters.push({ el, target: Number(el.dataset.count), suffix: el.dataset.suffix || '' });
    });
    document.getElementById('replay')!.addEventListener('click', () => this.onReplay());
    this.bindOrbit(canvas);
    window.addEventListener('resize', () => this.remeasure());
    // Re-measure once fonts settle.
    (document as Document & { fonts?: { ready: Promise<void> } }).fonts?.ready.then(() => this.remeasure());
  }

  private remeasure() {
    for (const p of this.panels) p.rects = p.el.getBoundingClientRect();
  }

  private bindOrbit(canvas: HTMLCanvasElement) {
    canvas.addEventListener('pointerdown', (e) => {
      if (this.currentAct !== 6) return;
      this.dragging = true;
      this.dragAxis = 'none';
      this.lastX = this.startX = e.clientX;
      this.lastY = this.startY = e.clientY;
    });
    window.addEventListener('pointermove', (e) => {
      if (!this.dragging || this.currentAct !== 6) return;
      const dx = e.clientX - this.lastX;
      const dy = e.clientY - this.lastY;
      if (this.dragAxis === 'none') {
        const tdx = e.clientX - this.startX;
        const tdy = e.clientY - this.startY;
        if (Math.abs(tdx) + Math.abs(tdy) > 6) {
          this.dragAxis = Math.abs(tdx) >= Math.abs(tdy) ? 'orbit' : 'scroll';
        }
      }
      if (this.dragAxis === 'orbit') {
        this.orbitYaw += dx * 0.008;
        this.orbitPitch = clamp(this.orbitPitch + dy * 0.004, -0.5, 0.5);
        if (e.cancelable) e.preventDefault();
      }
      this.lastX = e.clientX;
      this.lastY = e.clientY;
    });
    const end = () => { this.dragging = false; this.dragAxis = 'none'; };
    window.addEventListener('pointerup', end);
    window.addEventListener('pointercancel', end);
  }

  // Clearance between a panel rect and the jersey screen box (px). Positive = gap.
  private clearance(rect: DOMRect, box: ScreenBox, side: string): number {
    const vOverlap = rect.top < box.maxY && rect.bottom > box.minY;
    const hOverlap = rect.left < box.maxX && rect.right > box.minX;
    if (side === 'bottom') return rect.top - box.maxY;
    if (!vOverlap) return 1000; // separated vertically (mobile)
    if (side === 'left') return box.minX - rect.right;
    if (side === 'right') return rect.left - box.maxX;
    return hOverlap ? -1 : 1000;
  }

  update(s: number, box: ScreenBox, mobile: boolean) {
    const act = actAt(s);
    this.currentAct = act;
    if (act !== this.lastAct) {
      this.actNum.textContent = String(act).padStart(2, '0');
      this.lastAct = act;
    }
    this.progressFill.style.height = `${(s * 100).toFixed(2)}%`;

    for (const p of this.panels) {
      const w = WINDOWS[p.act];
      let base = smoothstep(w[0], w[1], s) * (1 - smoothstep(w[2], w[3], s));
      if (p.act === 1) base = 1 - smoothstep(w[2], w[3], s);
      if (p.act === 6) base = smoothstep(w[0], w[1], s);
      // Live zero-occlusion guard: yield to the jersey.
      const rect = p.el.getBoundingClientRect();
      const side = mobile ? 'bottom' : p.side;
      const gap = this.clearance(rect, box, side);
      const gate = smoothstep(18, 58, gap);
      const opacity = clamp(base * gate, 0, 1);
      p.el.style.opacity = opacity.toFixed(3);
      const ty = (1 - opacity) * 14;
      if (p.side === 'bottom') p.el.style.transform = `translate(-50%, ${ty}px)`;
      else if (!mobile) p.el.style.transform = `translateY(calc(-50% + ${ty}px))`;
      else p.el.style.transform = `translateY(${ty}px)`;
      const visible = opacity > 0.015;
      p.el.style.visibility = visible ? 'visible' : 'hidden';
      p.el.style.pointerEvents = 'none';
    }

    // Scrubbed, reversible achievement counters (Act V).
    const cp = clamp((s - 0.75) / (0.8 - 0.75), 0, 1);
    const eased = 1 - Math.pow(1 - cp, 3);
    for (const c of this.counters) {
      const val = Math.round(c.target * eased);
      c.el.textContent = `${val}${c.suffix}`;
    }

    // Decay orbit offsets when leaving Act VI so scroll choreography resumes cleanly.
    if (act !== 6 && !this.dragging) {
      this.orbitYaw *= 0.9;
      this.orbitPitch *= 0.9;
      if (Math.abs(this.orbitYaw) < 0.001) this.orbitYaw = 0;
      if (Math.abs(this.orbitPitch) < 0.001) this.orbitPitch = 0;
    }
  }

  get act() { return this.currentAct; }
}
