import type { Keyframe, Pose } from '../types';

// Authoritative 6-act choreography table (section 6C of the brief).
// x/y are normalized to frustum half-width / half-height at the jersey plane.
export const KEYFRAMES: Keyframe[] = [
  { s: 0.0, x: 0.26, y: -0.1, ry: -0.28, rx: 0.06, rz: -0.03 },
  { s: 0.12, x: 0.3, y: 0.14, ry: 0.18, rx: -0.04, rz: 0.02 },
  { s: 0.26, x: 0.42, y: -0.12, ry: 0.85, rx: 0.08, rz: -0.05 },
  { s: 0.44, x: -0.42, y: 0.15, ry: Math.PI - 0.25, rx: -0.06, rz: 0.04 },
  { s: 0.63, x: 0.4, y: 0.18, ry: 2 * Math.PI - 0.35, rx: -0.11, rz: -0.04 },
  { s: 0.8, x: -0.4, y: -0.13, ry: 2 * Math.PI + 0.42, rx: 0.07, rz: 0.03 },
  { s: 0.92, x: 0.0, y: 0.1, ry: 3 * Math.PI - 0.15, rx: -0.05, rz: 0.0 },
  { s: 1.0, x: 0.0, y: 0.08, ry: 3 * Math.PI, rx: 0.0, rz: 0.0 },
];

export const ACTS = [
  { id: 1, start: 0.0, end: 0.16 },
  { id: 2, start: 0.16, end: 0.34 },
  { id: 3, start: 0.34, end: 0.54 },
  { id: 4, start: 0.54, end: 0.72 },
  { id: 5, start: 0.72, end: 0.88 },
  { id: 6, start: 0.88, end: 1.0 },
];

export function actAt(s: number): number {
  for (const a of ACTS) if (s >= a.start && s < a.end) return a.id;
  return 6;
}

function catmull(p0: number, p1: number, p2: number, p3: number, t: number): number {
  const t2 = t * t;
  const t3 = t2 * t;
  return (
    0.5 *
    (2 * p1 +
      (-p0 + p2) * t +
      (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
      (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
}

// Piecewise Catmull-Rom across non-uniform keyframes; clamped at the ends.
export function samplePose(s: number): Pose {
  const k = KEYFRAMES;
  const n = k.length;
  const cs = Math.min(1, Math.max(0, s));
  let i = 0;
  while (i < n - 2 && cs > k[i + 1].s) i++;
  const a = k[i];
  const b = k[i + 1];
  const span = b.s - a.s || 1;
  const t = (cs - a.s) / span;
  const p0 = k[Math.max(0, i - 1)];
  const p3 = k[Math.min(n - 1, i + 2)];
  return {
    x: catmull(p0.x, a.x, b.x, p3.x, t),
    y: catmull(p0.y, a.y, b.y, p3.y, t),
    ry: catmull(p0.ry, a.ry, b.ry, p3.ry, t),
    rx: catmull(p0.rx, a.rx, b.rx, p3.rx, t),
    rz: catmull(p0.rz, a.rz, b.rz, p3.rz, t),
  };
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const smoothstep = (e0: number, e1: number, x: number) => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};
