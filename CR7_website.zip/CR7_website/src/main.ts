import './style.css';
import gsap from 'gsap';
import { Stage } from './core/stage';
import { ScrollEngine } from './core/scroll';
import { UIController } from './core/ui';
import { actAt, samplePose, clamp, smoothstep } from './core/choreography';
import type { FrameTelemetry } from './types';

const canvas = document.getElementById('stage') as HTMLCanvasElement;
const preloader = document.getElementById('preloader')!;
const preFill = document.getElementById('pre-fill')!;
const prePct = document.getElementById('pre-pct')!;

const stage = new Stage(canvas);
const scroll = new ScrollEngine();
const reduced = scroll.isReduced;
const ui = new UIController(canvas, () => scroll.scrollToTop());

// Velocity-reactive gains (section 6A).
const kY = 0.18, kP = 0.35, kR = 0.2;

let telemetry: FrameTelemetry = {
  s: 0, v: 0, rigPos: { x: 0, y: 0, z: 0 }, rigRot: { x: 0, y: 0, z: 0 },
  box: { minX: 0, minY: 0, maxX: 0, maxY: 0 }, act: 1, fps: 60,
};
let frames = 0, fpsAccum = 0, fps = 60;

function frame(time: number, dt: number) {
  scroll.raf(time);
  scroll.update(dt);
  const { s, v } = scroll.state;
  const pose = samplePose(s);
  const cam = stage.camSolution;
  const act = actAt(s);
  const t = time * 0.001;

  const surgeScale = cam.surgeScale * (reduced ? 0.3 : 1);
  const deltaY = clamp(-v * kY, -0.09, 0.09) * surgeScale;
  const deltaRX = clamp(v * kP, -0.16, 0.16) * surgeScale;
  const deltaRZ = clamp(-v * kR, -0.09, 0.09) * surgeScale;

  const idleW = (1 - clamp(Math.abs(v) / 0.12, 0, 1)) * (reduced ? 0.3 : 1) * (idleEnabled ? 1 : 0);
  const idleY = Math.sin(t * 1.35) * 0.016 * idleW;
  const idleYaw = Math.cos(t * 0.9) * 0.025 * idleW;

  const act6 = smoothstep(0.88, 0.94, s);
  const orbitY = ui.orbitYaw * act6;
  const orbitX = ui.orbitPitch * act6;

  const rig = stage.rig;
  rig.position.x = pose.x * cam.W * cam.xScale;
  rig.position.y = cam.baseY + pose.y * cam.H * cam.yScale + deltaY + idleY;
  rig.position.z = 0;
  rig.rotation.x = pose.rx + deltaRX + orbitX;
  rig.rotation.y = pose.ry + idleYaw + orbitY;
  rig.rotation.z = pose.rz + deltaRZ;
  rig.updateMatrixWorld(true);

  stage.updateLighting(s, act);
  stage.updateWind(t, v, reduced);
  stage.updateDust(dt, v);

  const w = window.innerWidth, h = window.innerHeight;
  const box = stage.screenBox(w, h);
  ui.update(s, box, cam.mobile);
  stage.render();

  frames++; fpsAccum += dt;
  if (fpsAccum >= 0.5) { fps = Math.round(frames / fpsAccum); frames = 0; fpsAccum = 0; }
  telemetry = {
    s, v,
    rigPos: { x: rig.position.x, y: rig.position.y, z: rig.position.z },
    rigRot: { x: rig.rotation.x, y: rig.rotation.y, z: rig.rotation.z },
    box, act, fps,
  };
}

let prev = performance.now();
let paused = false;
let idleEnabled = true;
function loop(time: number) {
  const dt = Math.min(0.05, Math.max(0.0001, (time - prev) / 1000));
  prev = time;
  if (!paused) frame(time, dt);
  requestAnimationFrame(loop);
}

async function boot() {
  try {
    await stage.load((p) => {
      const pct = Math.round(p * 100);
      preFill.style.width = `${pct}%`;
      prePct.textContent = `${pct}%`;
    });
    preFill.style.width = '100%';
    prePct.textContent = '100%';
    await stage.warmup();
    requestAnimationFrame(loop);
    // Fade the preloader only after the first real 3D frame is on screen.
    gsap.to(preloader, { opacity: 0, duration: 0.7, delay: 0.15, ease: 'power2.out', onComplete: () => {
      preloader.style.display = 'none';
    }});
    exposeDebug();
  } catch (err) {
    prePct.textContent = 'ERROR';
    console.error('[CR7] boot failed', err);
  }
}

function exposeDebug() {
  const api = {
    ready: true,
    state: () => telemetry,
    scrollTo: (p: number, immediate = false) => {
      const limit = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      const y = clamp(p, 0, 1) * limit;
      if (immediate) { scroll.lenis.scrollTo(y, { immediate: true }); window.scrollTo(0, y); }
      else scroll.lenis.scrollTo(y, { duration: 0.9 });
    },
    setOrbit: (yaw: number, pitch: number) => { ui.orbitYaw = yaw; ui.orbitPitch = pitch; },
    pause: () => { paused = true; },
    resume: () => { paused = false; prev = performance.now(); },
    setIdle: (b: boolean) => { idleEnabled = b; },
    snap: (p: number) => { scroll.snap(p); frame(performance.now(), 0.016); },
    assetInfo: () => ({ ready: stage.ready }),
  };
  (window as unknown as Record<string, unknown>).__CR7 = api;
}

window.addEventListener('resize', () => stage.resize());
window.addEventListener('beforeunload', () => { stage.dispose(); scroll.destroy(); });

boot();
