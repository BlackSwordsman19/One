export interface Keyframe {
  s: number;
  x: number; // stage X in frustum half-width units
  y: number; // elevation in frustum half-height units
  ry: number;
  rx: number;
  rz: number;
}

export interface Pose {
  x: number;
  y: number;
  ry: number;
  rx: number;
  rz: number;
}

export interface ScrollState {
  s: number; // damped normalized progress 0..1
  v: number; // damped signed velocity ds/dt
  raw: number; // raw normalized progress
}

export interface ScreenBox {
  minX: number;
  minY: number;
  maxX: number;
  maxY: number;
}

export interface FrameTelemetry {
  s: number;
  v: number;
  rigPos: { x: number; y: number; z: number };
  rigRot: { x: number; y: number; z: number };
  box: ScreenBox;
  act: number;
  fps: number;
}
