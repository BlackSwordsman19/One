import * as THREE from "three";
import { simplex2, fbm2, smoothstep, lerp, clamp01 } from "../src/lib/noise";
import { heightAt, slopeAt, riverX, WATER_LEVEL, WORLD_SIZE } from "../src/lib/terrain";
import { makePalette, sampleDaylight, clockTime, lux, elevation } from "../src/lib/daylight";

let fails = 0;
const ok = (cond: boolean, msg: string) => {
  if (!cond) {
    fails++;
    console.error("FAIL:", msg);
  } else console.log("ok:", msg);
};

// noise
ok(Math.abs(simplex2(1.23, 4.56)) <= 1.2, "simplex2 bounded");
ok(simplex2(3, 4) === simplex2(3, 4), "simplex2 deterministic");
ok(Math.abs(fbm2(9, 9, 4)) <= 1.2, "fbm2 bounded");
ok(smoothstep(0, 1, 0.5) === 0.5, "smoothstep midpoint");
ok(smoothstep(-20, -100, -60) > 0 && smoothstep(-20, -100, -60) < 1, "smoothstep reversed edges");
ok(lerp(2, 8, 0.25) === 3.5 && clamp01(4) === 1, "lerp/clamp");

// terrain
let min = Infinity, max = -Infinity, riverOk = true, rim = true;
for (let x = -WORLD_SIZE / 2; x <= WORLD_SIZE / 2; x += 4) {
  for (let z = -WORLD_SIZE / 2; z <= WORLD_SIZE / 2; z += 4) {
    const h = heightAt(x, z);
    if (!Number.isFinite(h)) { ok(false, `heightAt finite at ${x},${z}`); break; }
    min = Math.min(min, h); max = Math.max(max, h);
    const d = Math.abs(x - riverX(z));
    if (d < 2 && h > WATER_LEVEL + 0.4) riverOk = false; // river bed must sit below water
    // rim must enclose the valley, except where the river exits through its gorge
    if ((Math.abs(x) > 125 || z > 125) && d > 25 && h < 6) rim = false;
  }
}
console.log(`  terrain range: ${min.toFixed(1)} .. ${max.toFixed(1)} (water at ${WATER_LEVEL})`);
ok(riverOk, "river channel stays below water level along its centreline");
ok(rim, "enclosing rim rises at the map edges");
ok(max > 18, "headwall produces snow-capable peaks (>18)");
ok(min < WATER_LEVEL, "low spots dip under water (pools/river)");
ok(Number.isFinite(slopeAt(10, 20)), "slopeAt finite");

// tree-band availability (where the forest sampler may place trees)
let band = 0, samples = 0;
for (let x = -100; x <= 100; x += 5) {
  for (let z = -100; z <= 100; z += 5) {
    samples++;
    const h = heightAt(x, z);
    if (h > 1.75 && h < 11 && slopeAt(x, z) <= 1.1) band++;
  }
}
console.log(`  plantable cells: ${band}/${samples} (${((band / samples) * 100).toFixed(0)}%)`);
ok(band / samples > 0.12, "enough plantable terrain for a dense forest");

// daylight palette across the whole day
const pal = makePalette();
let cont = true;
for (let i = 0; i <= 200; i++) {
  const p = i / 200;
  sampleDaylight(p, pal);
  const cols = [pal.skyTop, pal.skyMid, pal.horizon, pal.fog, pal.sunColor, pal.hemiSky, pal.hemiGround, pal.cloudTint, pal.water, pal.lightColor];
  for (const c of cols) {
    if (!Number.isFinite(c.r + c.g + c.b)) { cont = false; }
  }
  if (![pal.fogNear, pal.fogFar, pal.sunInt, pal.hemiInt, pal.ambient, pal.stars, pal.fireflies, pal.cloudOpacity, pal.lightInt, pal.glow].every(Number.isFinite)) cont = false;
  if (pal.fogNear >= pal.fogFar) cont = false;
  if (pal.sunPos.lengthSq() < 1) cont = false;
}
ok(cont, "palette continuous and finite across p ∈ [0,1]");
sampleDaylight(0, pal);
const dawnFog = pal.fog.getHexString();
sampleDaylight(1, pal);
const nightStars = pal.stars;
const nightLight = pal.lightInt;
ok(pal.skyTop.getHexString() === "070d1f", `night sky top is deep indigo (#${pal.skyTop.getHexString()})`);
ok(nightStars === 1 && nightLight > 0.4, "night: stars full, moonlight on");
ok(dawnFog !== pal.fog.getHexString(), "fog colour shifts dawn → night");
ok(pal.lightPos.distanceTo(new THREE.Vector3(80, 95, -70)) < 0.01, "night light comes from the moon position");
sampleDaylight(0.45, pal);
ok(pal.sunInt > 2.4 && pal.stars === 0, "noon: sun at peak, no stars");

// HUD figures
ok(clockTime(0) === "05:12" && clockTime(1) === "23:41", `clock endpoints (${clockTime(0)} → ${clockTime(1)})`);
ok(parseFloat(lux(0.45).replace(/,/g, "")) > 25000 && parseFloat(lux(1)) < 1, "lux peaks at noon, near zero at night");
ok(parseInt(elevation(0, 30).replace(/,/g, "")) > 1900, "elevation figures plausible");

console.log(fails === 0 ? "\nALL PASS" : `\n${fails} FAILURES`);
process.exit(fails === 0 ? 0 : 1);
