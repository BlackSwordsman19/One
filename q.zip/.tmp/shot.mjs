import { chromium } from "playwright";
import { mkdirSync } from "node:fs";
import path from "node:path";

const root = path.resolve(process.cwd());
const out = path.join(root, ".tmp/shots");
mkdirSync(out, { recursive: true });

const browser = await chromium.launch({
  executablePath: "/home/user/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome",
  headless: true,
  args: ["--enable-unsafe-swiftshader", "--use-angle=swiftshader", "--no-sandbox"],
});
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

const errors = [];
page.on("console", (m) => {
  if (m.type() === "error") errors.push(`console: ${m.text()}`);
});
page.on("pageerror", (e) => errors.push(`pageerror: ${e.message}`));

await page.goto(`file://${root}/dist/index.html`, { waitUntil: "load" });
await page.waitForTimeout(6000); // let fonts, scene and dawn settle

const stops = [
  ["00-hero", 0],
  ["01-dawn", 0.14],
  ["02-forest", 0.34],
  ["03-river", 0.52],
  ["04-golden", 0.7],
  ["05-dusk", 0.84],
  ["06-night", 0.995],
];

for (const [name, frac] of stops) {
  await page.evaluate((f) => {
    const max = document.documentElement.scrollHeight - window.innerHeight;
    window.scrollTo(0, max * f);
  }, frac);
  await page.waitForTimeout(2600); // camera damping + palette lerp
  await page.screenshot({ path: path.join(out, `${name}.png`) });
}

// mobile check
await page.setViewportSize({ width: 390, height: 844 });
await page.evaluate(() => window.scrollTo(0, 0));
await page.waitForTimeout(1500);
await page.screenshot({ path: path.join(out, "07-mobile.png") });

console.log("ERRORS:", errors.length ? errors : "none");
await browser.close();
