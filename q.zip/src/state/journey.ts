/* Scroll state shared between the HTML journal and the 3-D scene.
   React only re-renders when the *chapter* changes; the canvas and the HUD
   read continuous values directly, with zero reconciliation per frame. */

import { useSyncExternalStore } from "react";
import { clamp01 } from "@/lib/noise";
import { clockTime, elevation, lux } from "@/lib/daylight";

type Listener = () => void;

export const REDUCED_MOTION =
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;

interface ChapterDef {
  id: string;
  numeral: string;
  label: string;
}

export const CHAPTERS: ChapterDef[] = [
  { id: "hour-0", numeral: "0", label: "Trailhead" },
  { id: "hour-1", numeral: "I", label: "First light" },
  { id: "hour-2", numeral: "II", label: "Canopy" },
  { id: "hour-3", numeral: "III", label: "The river" },
  { id: "hour-4", numeral: "IV", label: "Ridgeline" },
  { id: "hour-5", numeral: "V", label: "Starfall" },
];

class Journey {
  progress = 0; // raw scroll progress 0..1
  pointer = { x: 0, y: 0 }; // normalized -1..1, for camera parallax
  cameraY = 30; // last camera height, for the HUD elevation figure
  chapter = 0;

  private listeners = new Set<Listener>();
  private sectionTops: number[] = [];
  private docSpan = 1;
  private raf = 0;
  private inited = false;

  hud: {
    time?: HTMLElement | null;
    elev?: HTMLElement | null;
    lux?: HTMLElement | null;
    chip?: HTMLElement | null;
  } = {};

  subscribe = (fn: Listener) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };

  getSnapshot = () => this.chapter;

  init() {
    if (this.inited) return;
    this.inited = true;
    this.measure();
    this.onScroll();
    // fonts and the plate image reflow the document once they land
    window.addEventListener("load", () => this.measure());
    if (document.fonts?.ready) document.fonts.ready.then(() => this.measure());
    window.addEventListener("scroll", () => this.queue(), { passive: true });
    window.addEventListener("resize", () => {
      this.measure();
      this.queue();
    });
    window.addEventListener("pointermove", (e) => {
      this.pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
      this.pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
    }, { passive: true });
  }

  private measure() {
    this.sectionTops = CHAPTERS.map((c) => {
      const el = document.getElementById(c.id);
      return el ? el.offsetTop : 0;
    });
    this.docSpan = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
  }

  private queue() {
    if (this.raf) return;
    this.raf = requestAnimationFrame(() => {
      this.raf = 0;
      this.onScroll();
    });
  }

  private onScroll() {
    const y = window.scrollY;
    this.progress = clamp01(y / this.docSpan);

    const line = y + window.innerHeight * 0.45;
    let ch = 0;
    for (let i = 0; i < this.sectionTops.length; i++) {
      if (this.sectionTops[i] <= line) ch = i;
    }
    if (ch !== this.chapter) {
      this.chapter = ch;
      this.listeners.forEach((fn) => fn());
    }

    // HUD figures — direct DOM writes, no React in the loop.
    const t = clockTime(this.progress);
    if (this.hud.time) this.hud.time.textContent = t;
    if (this.hud.chip) this.hud.chip.textContent = `${t} in the valley`;
    if (this.hud.lux) this.hud.lux.textContent = `${lux(this.progress)} lx`;
    if (this.hud.elev) this.hud.elev.textContent = `${elevation(this.progress, this.cameraY)} m`;
  }

  goTo(i: number) {
    const el = document.getElementById(CHAPTERS[i].id);
    if (el) el.scrollIntoView({ behavior: REDUCED_MOTION ? "auto" : "smooth", block: "start" });
  }

  toTop() {
    window.scrollTo({ top: 0, behavior: REDUCED_MOTION ? "auto" : "smooth" });
  }
}

export const journey = new Journey();

export function useChapter(): number {
  return useSyncExternalStore(journey.subscribe, journey.getSnapshot);
}
