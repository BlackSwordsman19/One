import { useEffect } from "react";
import Experience from "@/three/Experience";
import Chrome from "@/components/Chrome";
import Sections from "@/components/Sections";
import { journey } from "@/state/journey";

export default function App() {
  useEffect(() => {
    journey.init();
  }, []);

  return (
    <>
      {/* the live valley, pinned behind the journal */}
      <div className="fixed inset-0 z-0" aria-hidden>
        <Experience />
      </div>

      {/* atmosphere over the canvas, under the text */}
      <div className="vignette" aria-hidden />

      <Chrome />

      <main className="relative z-10">
        <Sections />
      </main>

      {/* film grain — one print artefact for the whole page (hallmark texture §1) */}
      <div className="grain" aria-hidden />
    </>
  );
}
