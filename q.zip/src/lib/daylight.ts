/* One full day of weather, keyed by scroll progress p ∈ [0, 1]:
   0 dawn → ~0.25 morning → ~0.45 noon → ~0.68 golden hour → ~0.85 dusk → 1 night. */

import * as THREE from "three";
import { clamp01, lerp, smoothstep } from "./noise";

interface Key {
  at: number;
  skyTop: string;
  skyMid: string;
  horizon: string;
  fog: string;
  fogNear: number;
  fogFar: number;
  sunColor: string;
  sunPos: [number, number, number];
  sunInt: number;
  glow: number; // horizon halo strength in the sky shader
  hemiSky: string;
  hemiGround: string;
  hemiInt: number;
  ambient: number;
  stars: number;
  fireflies: number;
  cloudTint: string;
  cloudOpacity: number;
  water: string;
}

const KEYS: Key[] = [
  {
    at: 0.0,
    skyTop: "#3a4a72", skyMid: "#96656f", horizon: "#f0a05c",
    fog: "#c98f68", fogNear: 34, fogFar: 200,
    sunColor: "#ffd9a0", sunPos: [150, 24, -80], sunInt: 1.7, glow: 1.0,
    hemiSky: "#9aa7c9", hemiGround: "#3c4a3a", hemiInt: 0.55, ambient: 0.28,
    stars: 0.3, fireflies: 0.0, cloudTint: "#f2bb8d", cloudOpacity: 0.72,
    water: "#5d7d80",
  },
  {
    at: 0.2,
    skyTop: "#5d88b8", skyMid: "#9db8c9", horizon: "#e8e4c8",
    fog: "#c3d2c2", fogNear: 70, fogFar: 300,
    sunColor: "#fff0cc", sunPos: [95, 75, -45], sunInt: 2.3, glow: 0.45,
    hemiSky: "#bcd4e4", hemiGround: "#4a6a4a", hemiInt: 0.72, ambient: 0.3,
    stars: 0.0, fireflies: 0.0, cloudTint: "#ffffff", cloudOpacity: 0.85,
    water: "#6f9494",
  },
  {
    at: 0.45,
    skyTop: "#6aa0d0", skyMid: "#a8c4d4", horizon: "#eef0da",
    fog: "#cddccb", fogNear: 85, fogFar: 330,
    sunColor: "#fff6e0", sunPos: [30, 135, -12], sunInt: 2.7, glow: 0.3,
    hemiSky: "#c4dcea", hemiGround: "#527252", hemiInt: 0.8, ambient: 0.32,
    stars: 0.0, fireflies: 0.0, cloudTint: "#ffffff", cloudOpacity: 0.88,
    water: "#7ba3a0",
  },
  {
    at: 0.68,
    skyTop: "#4c5a86", skyMid: "#a97a6e", horizon: "#f2a45a",
    fog: "#c99468", fogNear: 55, fogFar: 260,
    sunColor: "#ffc26e", sunPos: [-105, 28, -60], sunInt: 1.9, glow: 0.95,
    hemiSky: "#a8a4c0", hemiGround: "#4c5a40", hemiInt: 0.62, ambient: 0.3,
    stars: 0.0, fireflies: 0.12, cloudTint: "#f3b688", cloudOpacity: 0.8,
    water: "#7d8a86",
  },
  {
    at: 0.85,
    skyTop: "#232a52", skyMid: "#6a4a66", horizon: "#c05a48",
    fog: "#5e4248", fogNear: 45, fogFar: 230,
    sunColor: "#ff8a4d", sunPos: [-145, 6, -70], sunInt: 0.9, glow: 1.1,
    hemiSky: "#5c6088", hemiGround: "#333c30", hemiInt: 0.5, ambient: 0.26,
    stars: 0.35, fireflies: 0.7, cloudTint: "#7a5462", cloudOpacity: 0.5,
    water: "#4c5a60",
  },
  {
    at: 1.0,
    skyTop: "#070d1f", skyMid: "#0e1a2e", horizon: "#14242e",
    fog: "#0a1418", fogNear: 38, fogFar: 220,
    sunColor: "#ff8a4d", sunPos: [-160, -30, -70], sunInt: 0.0, glow: 0.0,
    hemiSky: "#26324c", hemiGround: "#161c16", hemiInt: 0.42, ambient: 0.2,
    stars: 1.0, fireflies: 1.0, cloudTint: "#1c2836", cloudOpacity: 0.32,
    water: "#22303a",
  },
];

const MOON_POS = new THREE.Vector3(80, 95, -70);
const MOON_COLOR = new THREE.Color("#8fa7cc");
const MOON_INT = 0.55;

export interface Palette {
  skyTop: THREE.Color;
  skyMid: THREE.Color;
  horizon: THREE.Color;
  fog: THREE.Color;
  fogNear: number;
  fogFar: number;
  sunColor: THREE.Color;
  sunPos: THREE.Vector3;
  sunInt: number;
  glow: number;
  hemiSky: THREE.Color;
  hemiGround: THREE.Color;
  hemiInt: number;
  ambient: number;
  stars: number;
  fireflies: number;
  cloudTint: THREE.Color;
  cloudOpacity: number;
  water: THREE.Color;
  /** blended main light (sun by day, moon taking over at night) */
  lightPos: THREE.Vector3;
  lightColor: THREE.Color;
  lightInt: number;
  night: number;
}

const C = (hex: string) => new THREE.Color(hex);

// Pre-parsed key colours so per-frame sampling allocates nothing.
const PK = KEYS.map((k) => ({
  at: k.at,
  skyTop: C(k.skyTop), skyMid: C(k.skyMid), horizon: C(k.horizon), fog: C(k.fog),
  fogNear: k.fogNear, fogFar: k.fogFar,
  sunColor: C(k.sunColor), sunPos: new THREE.Vector3(...k.sunPos), sunInt: k.sunInt, glow: k.glow,
  hemiSky: C(k.hemiSky), hemiGround: C(k.hemiGround), hemiInt: k.hemiInt, ambient: k.ambient,
  stars: k.stars, fireflies: k.fireflies,
  cloudTint: C(k.cloudTint), cloudOpacity: k.cloudOpacity, water: C(k.water),
}));

export function makePalette(): Palette {
  return {
    skyTop: new THREE.Color(), skyMid: new THREE.Color(), horizon: new THREE.Color(),
    fog: new THREE.Color(), fogNear: 60, fogFar: 300,
    sunColor: new THREE.Color(), sunPos: new THREE.Vector3(), sunInt: 0, glow: 0,
    hemiSky: new THREE.Color(), hemiGround: new THREE.Color(), hemiInt: 0, ambient: 0,
    stars: 0, fireflies: 0, cloudTint: new THREE.Color(), cloudOpacity: 0, water: new THREE.Color(),
    lightPos: new THREE.Vector3(), lightColor: new THREE.Color(), lightInt: 0, night: 0,
  };
}

const mixC = (out: THREE.Color, a: THREE.Color, b: THREE.Color, t: number) => out.lerpColors(a, b, t);

export function sampleDaylight(p: number, out: Palette): Palette {
  const x = clamp01(p);
  let i = 0;
  while (i < PK.length - 2 && x > PK[i + 1].at) i++;
  const A = PK[i];
  const B = PK[i + 1];
  const t = smoothstep(A.at, B.at, x);

  mixC(out.skyTop, A.skyTop, B.skyTop, t);
  mixC(out.skyMid, A.skyMid, B.skyMid, t);
  mixC(out.horizon, A.horizon, B.horizon, t);
  mixC(out.fog, A.fog, B.fog, t);
  out.fogNear = lerp(A.fogNear, B.fogNear, t);
  out.fogFar = lerp(A.fogFar, B.fogFar, t);
  mixC(out.sunColor, A.sunColor, B.sunColor, t);
  out.sunPos.lerpVectors(A.sunPos, B.sunPos, t);
  out.sunInt = lerp(A.sunInt, B.sunInt, t);
  out.glow = lerp(A.glow, B.glow, t);
  mixC(out.hemiSky, A.hemiSky, B.hemiSky, t);
  mixC(out.hemiGround, A.hemiGround, B.hemiGround, t);
  out.hemiInt = lerp(A.hemiInt, B.hemiInt, t);
  out.ambient = lerp(A.ambient, B.ambient, t);
  out.stars = lerp(A.stars, B.stars, t);
  out.fireflies = lerp(A.fireflies, B.fireflies, t);
  mixC(out.cloudTint, A.cloudTint, B.cloudTint, t);
  out.cloudOpacity = lerp(A.cloudOpacity, B.cloudOpacity, t);
  mixC(out.water, A.water, B.water, t);

  const night = smoothstep(0.78, 0.95, x);
  out.night = night;
  out.lightPos.lerpVectors(out.sunPos, MOON_POS, night);
  out.lightColor.lerpColors(out.sunColor, MOON_COLOR, night);
  out.lightInt = Math.max(lerp(out.sunInt, MOON_INT, night), night * MOON_INT);

  return out;
}

/** Clock time for the HUD: 05:12 at the trailhead, 23:41 at starfall. */
export function clockTime(p: number): string {
  const minutes = Math.round(lerp(5 * 60 + 12, 23 * 60 + 41, clamp01(p)));
  const h = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export function lux(p: number): string {
  const x = clamp01(p);
  const v = x < 0.45 ? lerp(320, 31000, smoothstep(0, 0.45, x)) : lerp(31000, 0.2, smoothstep(0.45, 1, x));
  if (v >= 100) return Math.round(v).toLocaleString("en-US");
  if (v >= 1) return v.toFixed(1);
  return v.toFixed(2);
}

export function elevation(p: number, cameraY: number): string {
  const base = lerp(1805, 2650, clamp01(p));
  return Math.round(base + cameraY * 6).toLocaleString("en-US");
}
