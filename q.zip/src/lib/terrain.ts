/* The valley: one shared height function used by the mesh, the trees, the rocks
   and (indirectly) the camera path, so everything sits on the same ground. */

import { fbm2, simplex2, smoothstep, lerp } from "./noise";

export const WORLD_SIZE = 280;
export const WATER_LEVEL = 1.15;

/** River centreline — a double-sine meander running roughly along z. */
export function riverX(z: number): number {
  return Math.sin(z * 0.032) * 15 + Math.sin(z * 0.011 + 1.7) * 9;
}

export function heightAt(x: number, z: number): number {
  const rolling = fbm2(x * 0.016, z * 0.016, 4); // gentle meadow relief
  const ridgeMask = 0.3 + 0.7 * smoothstep(18, 72, Math.max(Math.abs(x) * 0.82, -z * 0.9, z * 0.55));
  const ridge = Math.pow(1 - Math.abs(simplex2(x * 0.011 + 31.7, z * 0.011 - 12.3)), 2.3) * 14 * ridgeMask;
  const peaks = smoothstep(-20, -100, z) * 30; // headwall of mountains at the far end
  const rim = smoothstep(78, 138, Math.max(Math.abs(x), z)) * 30; // enclosing ridges
  const hBase = -2.6 + (rolling + 1) * 4.6 + ridge + peaks + rim;
  // the river valley: blend the channel down to a guaranteed underwater bed,
  // however high the surrounding ground climbs (the gorge through the headwall)
  const d = Math.abs(x - riverX(z));
  const chan = Math.exp(-(d * d) / 210);
  return lerp(hBase, WATER_LEVEL - 1.05, Math.pow(chan, 1.25));
}

export function slopeAt(x: number, z: number): number {
  const e = 1.4;
  const dx = heightAt(x + e, z) - heightAt(x - e, z);
  const dz = heightAt(x, z + e) - heightAt(x, z - e);
  return Math.sqrt(dx * dx + dz * dz) / (2 * e);
}
