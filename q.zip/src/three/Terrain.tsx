/* The valley floor: one displaced plane, vertex-coloured by height, slope and
   a little noise so the bands never read as contour lines. */

import { useMemo } from "react";
import * as THREE from "three";
import { WORLD_SIZE, WATER_LEVEL, heightAt } from "@/lib/terrain";
import { simplex2, smoothstep } from "@/lib/noise";

const SAND = new THREE.Color("#7d7a58");
const SAND_WET = new THREE.Color("#5e6b52");
const GRASS_A = new THREE.Color("#4a744c");
const GRASS_B = new THREE.Color("#365c40");
const FOREST = new THREE.Color("#2b4c39");
const ROCK = new THREE.Color("#6f7268");
const SNOW = new THREE.Color("#e8ede4");
const BED = new THREE.Color("#32504a");

export default function Terrain() {
  const geometry = useMemo(() => {
    const SEG = 190;
    const geo = new THREE.PlaneGeometry(WORLD_SIZE, WORLD_SIZE, SEG, SEG);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      pos.setY(i, heightAt(x, z));
    }
    geo.computeVertexNormals();

    const colors = new Float32Array(pos.count * 3);
    const normal = geo.attributes.normal as THREE.BufferAttribute;
    const c = new THREE.Color();

    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = pos.getZ(i);
      const ny = normal.getY(i);
      const jitter = 0.9 + 0.2 * (simplex2(x * 0.13 + 7.7, z * 0.13 - 3.1) * 0.5 + 0.5);
      const speckle = 0.94 + 0.12 * (simplex2(x * 0.9, z * 0.9) * 0.5 + 0.5);

      if (y < WATER_LEVEL - 0.1) {
        c.copy(BED);
      } else if (y < WATER_LEVEL + 0.55) {
        c.lerpColors(SAND_WET, SAND, smoothstep(WATER_LEVEL - 0.1, WATER_LEVEL + 0.55, y));
      } else if (y < 6.2) {
        c.lerpColors(GRASS_A, GRASS_B, smoothstep(1.6, 6.2, y));
      } else if (y < 10) {
        c.lerpColors(GRASS_B, FOREST, smoothstep(6.2, 10, y));
      } else if (y < 16) {
        c.lerpColors(FOREST, ROCK, smoothstep(9.2, 15, y));
      } else {
        c.lerpColors(ROCK, SNOW, smoothstep(15, 19.5, y));
      }

      // steep faces shed their green and show rock
      const steep = smoothstep(0.52, 0.78, 1 - ny);
      if (y > 2.5 && steep > 0) c.lerp(ROCK, steep * 0.85);

      c.multiplyScalar(jitter * speckle);
      colors[i * 3] = c.r;
      colors[i * 3 + 1] = c.g;
      colors[i * 3 + 2] = c.b;
    }

    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return geo;
  }, []);

  return (
    <mesh geometry={geometry} receiveShadow>
      <meshStandardMaterial vertexColors roughness={1} metalness={0} />
    </mesh>
  );
}
