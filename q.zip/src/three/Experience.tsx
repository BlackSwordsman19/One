/* The whole valley in one Canvas: lights and fog are driven per-frame by the
   daylight palette, so dawn, noon, dusk and night are one continuous scroll. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { journey } from "@/state/journey";
import { makePalette, sampleDaylight } from "@/lib/daylight";
import Terrain from "./Terrain";
import Vegetation from "./Vegetation";
import Water from "./Water";
import SkyDome from "./SkyDome";
import Clouds from "./Clouds";
import Wildlife from "./Wildlife";
import CameraRig from "./CameraRig";

function LightRig() {
  const sunRef = useRef<THREE.DirectionalLight>(null);
  const hemiRef = useRef<THREE.HemisphereLight>(null);
  const ambRef = useRef<THREE.AmbientLight>(null);
  const scene = useThree((s) => s.scene);
  const pal = useMemo(() => makePalette(), []);
  const fog = useMemo(() => new THREE.Fog("#c98f68", 34, 200), []);

  useMemo(() => {
    scene.fog = fog;
  }, [scene, fog]);

  useFrame(() => {
    sampleDaylight(journey.progress, pal);
    if (sunRef.current) {
      sunRef.current.position.copy(pal.lightPos);
      sunRef.current.color.copy(pal.lightColor);
      sunRef.current.intensity = pal.lightInt;
    }
    if (hemiRef.current) {
      hemiRef.current.color.copy(pal.hemiSky);
      hemiRef.current.groundColor.copy(pal.hemiGround);
      hemiRef.current.intensity = pal.hemiInt;
    }
    if (ambRef.current) ambRef.current.intensity = pal.ambient;
    fog.color.copy(pal.fog);
    fog.near = pal.fogNear;
    fog.far = pal.fogFar;
  });

  return (
    <>
      <ambientLight ref={ambRef} intensity={0.3} color="#cfd8cf" />
      <hemisphereLight ref={hemiRef} intensity={0.6} />
      <directionalLight
        ref={sunRef}
        position={[150, 24, -80]}
        intensity={1.7}
        castShadow
        shadow-mapSize-width={1024}
        shadow-mapSize-height={1024}
        shadow-camera-left={-115}
        shadow-camera-right={115}
        shadow-camera-top={115}
        shadow-camera-bottom={-115}
        shadow-camera-near={10}
        shadow-camera-far={520}
        shadow-bias={-0.0006}
        shadow-normalBias={0.04}
      />
    </>
  );
}

export default function Experience() {
  return (
    <Canvas
      shadows
      dpr={[1, 1.75]}
      camera={{ fov: 55, near: 0.5, far: 950, position: [2, 30, 120] }}
      gl={{ antialias: true, powerPreference: "high-performance" }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
    >
      <LightRig />
      <SkyDome />
      <Clouds />
      <Terrain />
      <Vegetation />
      <Water />
      <Wildlife />
      <CameraRig />
    </Canvas>
  );
}
