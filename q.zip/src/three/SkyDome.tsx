/* Sky, stars, sun, moon and the horizon halo — all driven by one palette. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { journey } from "@/state/journey";
import { makePalette, sampleDaylight } from "@/lib/daylight";

const VERT = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = normalize(position);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;

const FRAG = /* glsl */ `
  uniform vec3 uTop;
  uniform vec3 uMid;
  uniform vec3 uHorizon;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform float uGlow;
  varying vec3 vDir;
  void main() {
    vec3 dir = normalize(vDir);
    float h = dir.y;
    vec3 col = mix(uHorizon, uMid, smoothstep(-0.04, 0.24, h));
    col = mix(col, uTop, smoothstep(0.16, 0.68, h));
    float s = max(dot(dir, normalize(uSunDir)), 0.0);
    col += uSunColor * (pow(s, 5.0) * 0.34 + pow(s, 60.0) * 0.5) * uGlow;
    col *= mix(0.5, 1.0, smoothstep(-0.28, 0.02, h));
    gl_FragColor = vec4(col, 1.0);
  }
`;

function glowTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.25, "rgba(255,255,255,0.6)");
  g.addColorStop(0.6, "rgba(255,255,255,0.14)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(canvas);
}

function starField(count: number): THREE.BufferGeometry {
  const arr = new Float32Array(count * 3);
  const v = new THREE.Vector3();
  for (let i = 0; i < count; i++) {
    do {
      v.set(Math.random() * 2 - 1, Math.random() * 2 - 1, Math.random() * 2 - 1);
    } while (v.lengthSq() > 1 || v.y < 0.04);
    v.normalize().multiplyScalar(370);
    arr[i * 3] = v.x;
    arr[i * 3 + 1] = v.y;
    arr[i * 3 + 2] = v.z;
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(arr, 3));
  return geo;
}

export default function SkyDome() {
  const matRef = useRef<THREE.ShaderMaterial>(null);
  const sunRef = useRef<THREE.Mesh>(null);
  const sunGlowRef = useRef<THREE.Sprite>(null);
  const moonRef = useRef<THREE.Group>(null);
  const starsRef = useRef<THREE.Points>(null);
  const starsBigRef = useRef<THREE.Points>(null);
  const starsGroupRef = useRef<THREE.Group>(null);

  const pal = useMemo(() => makePalette(), []);
  const tex = useMemo(() => glowTexture(), []);
  const stars = useMemo(() => starField(1100), []);
  const starsBig = useMemo(() => starField(140), []);

  const uniforms = useMemo(
    () => ({
      uTop: { value: new THREE.Color() },
      uMid: { value: new THREE.Color() },
      uHorizon: { value: new THREE.Color() },
      uSunDir: { value: new THREE.Vector3(0, 1, 0) },
      uSunColor: { value: new THREE.Color() },
      uGlow: { value: 0.5 },
    }),
    []
  );

  useFrame((_, dt) => {
    sampleDaylight(journey.progress, pal);

    uniforms.uTop.value.copy(pal.skyTop);
    uniforms.uMid.value.copy(pal.skyMid);
    uniforms.uHorizon.value.copy(pal.horizon);
    uniforms.uSunDir.value.copy(pal.sunPos).normalize();
    uniforms.uSunColor.value.copy(pal.sunColor);
    uniforms.uGlow.value = pal.glow;

    if (sunRef.current) {
      const dir = pal.sunPos.clone().normalize().multiplyScalar(380);
      sunRef.current.position.copy(dir);
      const sm = sunRef.current.material as THREE.MeshBasicMaterial;
      sm.color.copy(pal.sunColor);
      sm.opacity = THREE.MathUtils.clamp(pal.sunInt / 1.1, 0, 1);
      if (sunGlowRef.current) {
        sunGlowRef.current.position.copy(dir);
        sunGlowRef.current.material.color.copy(pal.sunColor);
        sunGlowRef.current.material.opacity = THREE.MathUtils.clamp(pal.sunInt / 1.6, 0, 0.85) * 0.9;
      }
    }

    if (moonRef.current) {
      const m = THREE.MathUtils.clamp((pal.night - 0.1) / 0.9, 0, 1);
      moonRef.current.visible = m > 0.01;
      moonRef.current.children.forEach((child) => {
        const mesh = child as THREE.Mesh;
        const mat = mesh.material as THREE.Material & { opacity: number };
        mat.opacity = m;
      });
      const s = moonRef.current.children[1] as THREE.Sprite | undefined;
      if (s) s.material.opacity = m * 0.4;
    }

    const twinkle = Math.sin(performance.now() * 0.0011) * 0.08;
    if (starsRef.current) (starsRef.current.material as THREE.PointsMaterial).opacity = THREE.MathUtils.clamp(pal.stars + twinkle * pal.stars, 0, 1);
    if (starsBigRef.current) (starsBigRef.current.material as THREE.PointsMaterial).opacity = THREE.MathUtils.clamp(pal.stars * 0.95, 0, 1);
    if (starsGroupRef.current) starsGroupRef.current.rotation.y += dt * 0.004;
  });

  return (
    <group>
      <mesh frustumCulled={false}>
        <sphereGeometry args={[420, 32, 20]} />
        <shaderMaterial ref={matRef} vertexShader={VERT} fragmentShader={FRAG} uniforms={uniforms} side={THREE.BackSide} depthWrite={false} />
      </mesh>

      {/* sun disc + halo */}
      <mesh ref={sunRef} frustumCulled={false}>
        <sphereGeometry args={[8, 20, 20]} />
        <meshBasicMaterial transparent depthWrite={false} fog={false} />
      </mesh>
      <sprite ref={sunGlowRef} scale={[150, 150, 1]} frustumCulled={false}>
        <spriteMaterial map={tex} transparent depthWrite={false} blending={THREE.AdditiveBlending} fog={false} />
      </sprite>

      {/* moon + cool halo, awake only at night */}
      <group ref={moonRef} position={[96, 130, -95]} visible={false}>
        <mesh frustumCulled={false}>
          <sphereGeometry args={[6, 20, 20]} />
          <meshBasicMaterial color="#e6ecf4" transparent opacity={0} depthWrite={false} fog={false} />
        </mesh>
        <sprite scale={[70, 70, 1]} frustumCulled={false}>
          <spriteMaterial map={tex} color="#aebfd8" transparent opacity={0} depthWrite={false} blending={THREE.AdditiveBlending} fog={false} />
        </sprite>
      </group>

      <group ref={starsGroupRef}>
        <points ref={starsRef} geometry={stars} frustumCulled={false}>
          <pointsMaterial color="#cdd8ec" size={1.5} sizeAttenuation={false} transparent opacity={0} depthWrite={false} fog={false} />
        </points>
        <points ref={starsBigRef} geometry={starsBig} frustumCulled={false}>
          <pointsMaterial color="#e8eef8" size={2.6} sizeAttenuation={false} transparent opacity={0} depthWrite={false} fog={false} />
        </points>
      </group>
    </group>
  );
}
