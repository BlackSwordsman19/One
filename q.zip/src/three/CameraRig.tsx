/* The walk itself: scroll position drives a camera along a spline through the
   valley — over the trailhead, down into the trees, across the river, up onto
   the ridge, out under the stars. Pointer adds a breath of parallax. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { journey, REDUCED_MOTION } from "@/state/journey";
import { clamp01 } from "@/lib/noise";
import { heightAt } from "@/lib/terrain";

const damp = (cur: number, target: number, lambda: number, dt: number) =>
  cur + (target - cur) * (1 - Math.exp(-lambda * dt));

export default function CameraRig() {
  const t = useRef(0);
  const px = useRef(0);
  const py = useRef(0);
  const vPos = useMemo(() => new THREE.Vector3(), []);
  const vTgt = useMemo(() => new THREE.Vector3(), []);

  const posCurve = useMemo(
    () =>
      new THREE.CatmullRomCurve3(
        [
          new THREE.Vector3(2, 44, 120),
          new THREE.Vector3(-16, 13, 84),
          new THREE.Vector3(13, 6.8, 56),
          new THREE.Vector3(15, 3.8, 30),
          new THREE.Vector3(-6, 3.3, 6),
          new THREE.Vector3(-15, 7.5, -24),
          new THREE.Vector3(-6, 30, -54),
          new THREE.Vector3(4, 48, -86),
        ],
        false,
        "catmullrom",
        0.35
      ),
    []
  );

  const tgtCurve = useMemo(
    () =>
      new THREE.CatmullRomCurve3(
        [
          new THREE.Vector3(0, 12, 58),
          new THREE.Vector3(9, 5, 48),
          new THREE.Vector3(13, 3.4, 28),
          new THREE.Vector3(-3, 2.7, 3),
          new THREE.Vector3(-13, 4.5, -26),
          new THREE.Vector3(-8, 11, -58),
          new THREE.Vector3(0, 24, -92),
          new THREE.Vector3(0, 36, -150),
        ],
        false,
        "catmullrom",
        0.35
      ),
    []
  );

  useFrame(({ camera, clock }, dt) => {
    const d = Math.min(dt, 0.05);
    t.current = damp(t.current, journey.progress, REDUCED_MOTION ? 14 : 3.1, d);
    const k = clamp01(t.current);

    posCurve.getPoint(k, vPos);
    tgtCurve.getPoint(k, vTgt);

    if (!REDUCED_MOTION) {
      vPos.y += Math.sin(clock.elapsedTime * 0.55) * 0.16; // walking bob
      px.current = damp(px.current, journey.pointer.x, 2.2, d);
      py.current = damp(py.current, journey.pointer.y, 2.2, d);
      vPos.x += px.current * 1.5;
      vPos.y += -py.current * 0.9;
      vTgt.x += px.current * 2.6;
      vTgt.y += -py.current * 1.4;
    }

    // never sink through the ground, however the spline and parallax combine
    const groundY = heightAt(vPos.x, vPos.z) + 1.3;
    if (vPos.y < groundY) vPos.y = groundY;

    camera.position.copy(vPos);
    camera.lookAt(vTgt);
    journey.cameraY = camera.position.y;
  });

  return null;
}
