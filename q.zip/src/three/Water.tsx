/* The river and its side pools: one wide plane at WATER_LEVEL with a gentle
   sine swell, tinted by the time of day. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { WORLD_SIZE, WATER_LEVEL } from "@/lib/terrain";
import { journey } from "@/state/journey";
import { makePalette, sampleDaylight } from "@/lib/daylight";

export default function Water() {
  const matRef = useRef<THREE.MeshStandardMaterial>(null);
  const geoRef = useRef<THREE.PlaneGeometry>(null);
  const pal = useMemo(() => makePalette(), []);
  const base = useRef<Float32Array | null>(null);

  useFrame(({ clock }) => {
    sampleDaylight(journey.progress, pal);
    if (matRef.current) {
      matRef.current.color.copy(pal.water);
      // fresnel-ish lift at dusk: roughness dips so the low sun streaks the water
      matRef.current.roughness = 0.32 - pal.glow * 0.18;
    }
    const geo = geoRef.current;
    if (geo) {
      if (!base.current) base.current = Float32Array.from((geo.attributes.position as THREE.BufferAttribute).array);
      const t = clock.elapsedTime;
      const posAttr = geo.attributes.position as THREE.BufferAttribute;
      const arr = posAttr.array as Float32Array;
      const src = base.current;
      for (let i = 0; i < posAttr.count; i++) {
        const x = src[i * 3];
        const y = src[i * 3 + 1];
        arr[i * 3 + 2] = Math.sin(x * 0.22 + t * 0.9) * 0.05 + Math.cos(y * 0.26 + t * 0.7) * 0.05;
      }
      posAttr.needsUpdate = true;
      geo.computeVertexNormals();
    }
  });

  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, WATER_LEVEL, 0]}>
      <planeGeometry ref={geoRef} args={[WORLD_SIZE, WORLD_SIZE, 56, 56]} />
      <meshStandardMaterial
        ref={matRef}
        color="#6f9494"
        transparent
        opacity={0.86}
        roughness={0.3}
        metalness={0.12}
      />
    </mesh>
  );
}
