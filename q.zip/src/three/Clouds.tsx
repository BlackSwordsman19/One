/* Slow cumulus: squashed icosahedra drifting on the wind, tinted by the hour —
   white at noon, peach at golden hour, slate after dark. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { journey } from "@/state/journey";
import { makePalette, sampleDaylight } from "@/lib/daylight";

interface Puff {
  group: THREE.Group;
  speed: number;
  origin: number;
}

export default function Clouds() {
  const pal = useMemo(() => makePalette(), []);

  const material = useMemo(
    () =>
      new THREE.MeshLambertMaterial({
        color: "#ffffff",
        transparent: true,
        opacity: 0.85,
        flatShading: true,
        depthWrite: false,
      }),
    []
  );

  const puffs = useMemo<Puff[]>(() => {
    const out: Puff[] = [];
    const rng = (a: number, b: number) => a + Math.random() * (b - a);
    for (let i = 0; i < 7; i++) {
      const g = new THREE.Group();
      const blobs = 4 + Math.floor(Math.random() * 3);
      for (let b = 0; b < blobs; b++) {
        const r = rng(3.5, 8);
        const m = new THREE.Mesh(new THREE.IcosahedronGeometry(r, 1), material);
        m.position.set(b * rng(4, 7.5) - blobs * 2.6, rng(-1, 1.6), rng(-2.5, 2.5));
        m.scale.y = 0.42;
        g.add(m);
      }
      g.position.set(rng(-120, 120), rng(34, 52), rng(-120, 60));
      out.push({ group: g, speed: rng(0.5, 1.3), origin: g.position.x });
    }
    return out;
  }, [material]);

  const cloudsRef = useRef<THREE.Group>(null);

  useFrame(({ clock }) => {
    sampleDaylight(journey.progress, pal);
    material.color.copy(pal.cloudTint);
    material.opacity = pal.cloudOpacity;
    const t = clock.elapsedTime;
    const span = 260;
    for (const p of puffs) {
      const x = p.origin + t * p.speed;
      p.group.position.x = ((x + span / 2) % span) - span / 2;
    }
    if (cloudsRef.current) cloudsRef.current.rotation.y = Math.sin(t * 0.01) * 0.02;
  });

  return (
    <group ref={cloudsRef}>
      {puffs.map((p, i) => (
        <primitive key={i} object={p.group} />
      ))}
    </group>
  );
}
