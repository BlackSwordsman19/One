/* Two populations: distant birds that wheel over the valley in daylight, and
   fireflies that wake through the forest as the light fails. */

import { useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { journey } from "@/state/journey";
import { makePalette, sampleDaylight } from "@/lib/daylight";
import { heightAt, riverX } from "@/lib/terrain";

/* ——— birds ——— */

interface Bird {
  phase: number;
  radius: number;
  speed: number;
  y: number;
  flap: number;
  wingL: THREE.Object3D;
  wingR: THREE.Object3D;
  group: THREE.Group;
}

function wingGeometry(): THREE.BufferGeometry {
  const geo = new THREE.BufferGeometry();
  geo.setAttribute(
    "position",
    new THREE.Float32BufferAttribute([0, 0, 0, 2.1, 0.3, -0.28, 1.7, 0.05, 0.62], 3)
  );
  geo.computeVertexNormals();
  return geo;
}

function buildFlock(material: THREE.Material) {
  const wingGeo = wingGeometry();
  const flock = new THREE.Group();
  const birds: Bird[] = [];
  for (let i = 0; i < 7; i++) {
    const g = new THREE.Group();
    const wingL = new THREE.Object3D();
    const wingR = new THREE.Object3D();
    const mL = new THREE.Mesh(wingGeo, material);
    const mR = new THREE.Mesh(wingGeo, material);
    mL.scale.x = -1; // mirror the silhouette
    wingL.add(mL);
    wingR.add(mR);
    g.add(wingL, wingR);
    flock.add(g);
    birds.push({
      phase: (i / 7) * Math.PI * 2,
      radius: 48 + i * 6,
      speed: 0.055 + i * 0.004,
      y: 34 + i * 1.6,
      flap: 5.2 + i * 0.4,
      wingL,
      wingR,
      group: g,
    });
  }
  return { flock, birds };
}

function Birds() {
  const material = useMemo(
    () => new THREE.MeshBasicMaterial({ color: "#12180f", side: THREE.DoubleSide, transparent: true, opacity: 0.9 }),
    []
  );
  const { flock, birds } = useMemo(() => buildFlock(material), [material]);
  const pal = useMemo(() => makePalette(), []);

  useFrame(({ clock }) => {
    sampleDaylight(journey.progress, pal);
    // visible from first light to late afternoon, then the flock roosts
    const inDay = THREE.MathUtils.clamp(pal.sunInt / 1.2, 0, 1);
    const roost = 1 - THREE.MathUtils.smoothstep(journey.progress, 0.62, 0.74);
    const vis = inDay * roost * 0.9;
    material.opacity = vis;
    flock.visible = vis > 0.02;
    if (!flock.visible) return;

    const t = clock.elapsedTime;
    const cx = -8;
    const cz = -5;
    for (const b of birds) {
      const a = t * b.speed + b.phase;
      b.group.position.set(
        cx + Math.cos(a) * b.radius,
        b.y + Math.sin(t * 0.9 + b.phase * 3) * 1.6,
        cz + Math.sin(a) * b.radius * 0.62
      );
      b.group.rotation.y = -a + Math.PI / 2;
      b.group.rotation.z = 0.24;
      const f = Math.sin(t * b.flap + b.phase) * 0.62;
      b.wingL.rotation.z = f;
      b.wingR.rotation.z = -f;
    }
  });

  return <primitive object={flock} />;
}

/* ——— fireflies ——— */

const FIREFLY_COUNT = 240;

function fireflyTexture(): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, "rgba(255,255,255,1)");
  g.addColorStop(0.4, "rgba(255,255,255,0.5)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  return new THREE.CanvasTexture(canvas);
}

function Fireflies() {
  const pointsRef = useRef<THREE.Points>(null);
  const pal = useMemo(() => makePalette(), []);
  const tex = useMemo(() => fireflyTexture(), []);

  const { geometry, basePos, phases, speeds } = useMemo(() => {
    const positions = new Float32Array(FIREFLY_COUNT * 3);
    const base = new Float32Array(FIREFLY_COUNT * 3);
    const ph = new Float32Array(FIREFLY_COUNT);
    const sp = new Float32Array(FIREFLY_COUNT);
    let placed = 0;
    let guard = 0;
    while (placed < FIREFLY_COUNT && guard < 6000) {
      guard++;
      const x = (Math.random() * 2 - 1) * 95;
      const z = (Math.random() * 2 - 1) * 95;
      const h = heightAt(x, z);
      if (h < 1.5 || h > 9 || Math.abs(x - riverX(z)) < 5) continue;
      base[placed * 3] = x;
      base[placed * 3 + 1] = h + 0.6 + Math.random() * 3.2;
      base[placed * 3 + 2] = z;
      positions[placed * 3] = x;
      positions[placed * 3 + 1] = base[placed * 3 + 1];
      positions[placed * 3 + 2] = z;
      ph[placed] = Math.random() * Math.PI * 2;
      sp[placed] = 0.4 + Math.random() * 0.8;
      placed++;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return { geometry: geo, basePos: base, phases: ph, speeds: sp };
  }, []);

  useFrame(({ clock }) => {
    sampleDaylight(journey.progress, pal);
    const pts = pointsRef.current;
    if (!pts) return;
    const mat = pts.material as THREE.PointsMaterial;
    mat.opacity = pal.fireflies * 0.95;
    pts.visible = mat.opacity > 0.02;
    if (!pts.visible) return;
    const t = clock.elapsedTime;
    const attr = pts.geometry.attributes.position as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    for (let i = 0; i < FIREFLY_COUNT; i++) {
      const p = phases[i];
      const s = speeds[i];
      arr[i * 3] = basePos[i * 3] + Math.sin(t * s + p) * 1.3;
      arr[i * 3 + 1] = basePos[i * 3 + 1] + Math.sin(t * s * 1.4 + p * 2.1) * 0.7;
      arr[i * 3 + 2] = basePos[i * 3 + 2] + Math.cos(t * s * 0.8 + p) * 1.3;
    }
    attr.needsUpdate = true;
  });

  return (
    <points ref={pointsRef} geometry={geometry} frustumCulled={false}>
      <pointsMaterial
        map={tex}
        color="#ffd977"
        size={0.55}
        sizeAttenuation
        transparent
        opacity={0}
        depthWrite={false}
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

export default function Wildlife() {
  return (
    <group>
      <Birds />
      <Fireflies />
    </group>
  );
}
