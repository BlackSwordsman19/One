/* Instanced forest + boulders. ~700 pines and larches from two draw calls.
   Larches are flagged per-instance and turn gold as the day slides into dusk —
   the same moment the journal calls "the larches hold the last light". */

import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { heightAt, slopeAt, riverX } from "@/lib/terrain";
import { smoothstep } from "@/lib/noise";
import { journey } from "@/state/journey";

interface Placement {
  x: number;
  y: number;
  z: number;
  scale: number;
  rot: number;
  larch: boolean;
}

function placeTrees(target: number): Placement[] {
  const out: Placement[] = [];
  let guard = 0;
  // deterministic-ish scatter with Math.random is fine here (layout is computed once)
  while (out.length < target && guard < 9000) {
    guard++;
    const x = (Math.random() * 2 - 1) * 104;
    const z = (Math.random() * 2 - 1) * 104;
    const h = heightAt(x, z);
    if (h < 1.75 || h > 11) continue;
    if (slopeAt(x, z) > 1.1) continue;
    if (Math.abs(x - riverX(z)) < 6.5) continue;
    const scale = 0.75 + Math.random() * 0.95 + Math.max(0, 8.5 - h) * 0.07;
    out.push({
      x,
      y: h - 0.22,
      z,
      scale,
      rot: Math.random() * Math.PI * 2,
      larch: Math.random() < 0.24 && h < 6.5,
    });
  }
  return out;
}

const PINE_LO = new THREE.Color("#24503a");
const PINE_HI = new THREE.Color("#3f7050");
const LARCH_GREEN = new THREE.Color("#4c7a45");
const LARCH_GOLD = new THREE.Color("#d9a13f");

const ROCK_LO = new THREE.Color("#5f6359");
const ROCK_HI = new THREE.Color("#83867b");

export default function Vegetation() {
  const canopyRef = useRef<THREE.InstancedMesh>(null);
  const trunkRef = useRef<THREE.InstancedMesh>(null);
  const rockRef = useRef<THREE.InstancedMesh>(null);

  const placements = useMemo(() => placeTrees(680), []);

  const rocks = useMemo(() => {
    const out: { x: number; y: number; z: number; s: number; rx: number; ry: number; rz: number; shade: number }[] = [];
    let guard = 0;
    while (out.length < 150 && guard < 4000) {
      guard++;
      const x = (Math.random() * 2 - 1) * 110;
      const z = (Math.random() * 2 - 1) * 110;
      const h = heightAt(x, z);
      if (h < 0.6 || h > 22) continue;
      out.push({
        x,
        y: h - 0.18,
        z,
        s: 0.35 + Math.random() * Math.random() * 2.3,
        rx: Math.random() * Math.PI,
        ry: Math.random() * Math.PI,
        rz: Math.random() * Math.PI,
        shade: Math.random(),
      });
    }
    return out;
  }, []);

  const canopyGeo = useMemo(() => {
    const c1 = new THREE.ConeGeometry(1.55, 2.6, 7);
    c1.translate(0, 2.9, 0);
    const c2 = new THREE.ConeGeometry(1.15, 2.2, 7);
    c2.translate(0, 4.3, 0);
    const c3 = new THREE.ConeGeometry(0.72, 1.8, 7);
    c3.translate(0, 5.6, 0);
    const merged = mergeGeometries([c1, c2, c3]);
    merged.computeBoundingSphere();
    return merged;
  }, []);

  const trunkGeo = useMemo(() => {
    const g = new THREE.CylinderGeometry(0.13, 0.24, 2.6, 6);
    g.translate(0, 1.1, 0);
    return g;
  }, []);

  const rockGeo = useMemo(() => new THREE.DodecahedronGeometry(0.7, 0), []);

  const dummy = useMemo(() => new THREE.Object3D(), []);
  const color = useMemo(() => new THREE.Color(), []);
  const baseColors = useRef<THREE.Color[]>([]);

  useLayoutEffect(() => {
    const canopy = canopyRef.current;
    const trunk = trunkRef.current;
    const rock = rockRef.current;
    if (!canopy || !trunk || !rock) return;

    const bases: THREE.Color[] = [];
    placements.forEach((p, i) => {
      dummy.position.set(p.x, p.y, p.z);
      dummy.rotation.set(0, p.rot, 0);
      dummy.scale.setScalar(p.scale);
      dummy.updateMatrix();
      canopy.setMatrixAt(i, dummy.matrix);
      trunk.setMatrixAt(i, dummy.matrix);

      if (p.larch) {
        color.copy(LARCH_GREEN);
      } else {
        color.lerpColors(PINE_LO, PINE_HI, Math.random());
      }
      color.multiplyScalar(0.88 + Math.random() * 0.24);
      bases.push(color.clone());
      canopy.setColorAt(i, color);
    });
    baseColors.current = bases;
    canopy.instanceMatrix.needsUpdate = true;
    trunk.instanceMatrix.needsUpdate = true;
    if (canopy.instanceColor) canopy.instanceColor.needsUpdate = true;

    rocks.forEach((r, i) => {
      dummy.position.set(r.x, r.y, r.z);
      dummy.rotation.set(r.rx, r.ry, r.rz);
      dummy.scale.set(r.s, r.s * (0.7 + Math.random() * 0.5), r.s);
      dummy.updateMatrix();
      rock.setMatrixAt(i, dummy.matrix);
      color.lerpColors(ROCK_LO, ROCK_HI, r.shade);
      rock.setColorAt(i, color);
    });
    rock.instanceMatrix.needsUpdate = true;
    if (rock.instanceColor) rock.instanceColor.needsUpdate = true;
  }, [placements, rocks, dummy, color]);

  // the larches turn: instance colours drift green → gold between p 0.55 and 0.85
  useFrame(() => {
    const canopy = canopyRef.current;
    if (!canopy || baseColors.current.length === 0) return;
    const burn = smoothstep(0.55, 0.85, journey.progress);
    const dim = 1 - smoothstep(0.88, 1, journey.progress) * 0.35;
    if (burn <= 0.001 && canopy.userData.done) return;
    placements.forEach((p, i) => {
      if (!p.larch) return;
      color.copy(baseColors.current[i]).lerp(LARCH_GOLD, burn).multiplyScalar(dim);
      canopy.setColorAt(i, color);
    });
    if (canopy.instanceColor) canopy.instanceColor.needsUpdate = true;
    canopy.userData.done = burn <= 0.001;
  });

  const n = placements.length;
  return (
    <group>
      <instancedMesh ref={canopyRef} args={[canopyGeo, undefined, n]} castShadow frustumCulled={false}>
        <meshLambertMaterial />
      </instancedMesh>
      <instancedMesh ref={trunkRef} args={[trunkGeo, undefined, n]} castShadow frustumCulled={false}>
        <meshStandardMaterial color="#4a3a2b" roughness={1} />
      </instancedMesh>
      <instancedMesh ref={rockRef} args={[rockGeo, undefined, rocks.length]} castShadow frustumCulled={false}>
        <meshLambertMaterial />
      </instancedMesh>
    </group>
  );
}

