/* The fixed furniture: progress line, wordmark, chapter rail and the field
   HUD whose figures are written straight to the DOM on scroll. */

import { useEffect, useRef } from "react";
import { CHAPTERS, journey, useChapter } from "@/state/journey";
import { cn } from "@/utils/cn";

function ProgressBar() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      if (ref.current) ref.current.style.transform = `scaleX(${journey.progress})`;
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className="fixed inset-x-0 top-0 z-50 h-[2px] bg-pine/60" aria-hidden>
      <div ref={ref} className="h-full origin-left bg-gold" style={{ transform: "scaleX(0)" }} />
    </div>
  );
}

function TopBar() {
  const chipRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    journey.hud.chip = chipRef.current;
  }, []);

  return (
    <header className="pointer-events-none fixed inset-x-0 top-0 z-40 flex items-center justify-between px-5 py-4 md:px-9">
      <a href="#hour-0" onClick={(e) => { e.preventDefault(); journey.toTop(); }} className="pointer-events-auto font-display display-wonk text-[1.35rem] leading-none text-paper/95 italic">
        Verdant Atlas
      </a>
      <span ref={chipRef} className="hidden rounded-full border border-paper/15 bg-night/45 px-4 py-1.5 font-figure text-[0.72rem] text-mist sm:block">
        05:12 in the valley
      </span>
    </header>
  );
}

function ChapterRail() {
  const chapter = useChapter();
  return (
    <nav aria-label="Chapters" className="fixed right-5 top-1/2 z-40 hidden -translate-y-1/2 flex-col items-end gap-3.5 md:flex lg:right-8">
      {CHAPTERS.map((c, i) => {
        const active = i === chapter;
        return (
          <button
            key={c.id}
            type="button"
            onClick={() => journey.goTo(i)}
            aria-current={active ? "true" : undefined}
            className="group flex items-center gap-3"
          >
            <span
              className={cn(
                "font-body text-[0.78rem] lowercase transition-opacity duration-300",
                active ? "text-paper opacity-100" : "text-mist opacity-0 group-hover:opacity-70 group-focus-visible:opacity-70"
              )}
            >
              {c.label}
            </span>
            <span
              className={cn(
                "font-figure text-[0.8rem] duration-300 [transition-property:color]",
                active ? "text-gold" : "text-paper/40 group-hover:text-paper/80"
              )}
            >
              {c.numeral}
            </span>
            <span
              className={cn(
                "h-px w-8 origin-right transition-transform duration-500",
                active ? "scale-x-100 bg-gold" : "scale-x-[0.42] bg-paper/25 group-hover:bg-paper/60"
              )}
            />
          </button>
        );
      })}
    </nav>
  );
}

function Hud() {
  const timeRef = useRef<HTMLSpanElement>(null);
  const elevRef = useRef<HTMLSpanElement>(null);
  const luxRef = useRef<HTMLSpanElement>(null);
  const chapter = useChapter();

  useEffect(() => {
    journey.hud.time = timeRef.current;
    journey.hud.elev = elevRef.current;
    journey.hud.lux = luxRef.current;
  }, []);

  return (
    <div className="pointer-events-none fixed bottom-5 left-5 z-40 hidden font-figure text-[0.7rem] leading-[1.9] text-mist/90 sm:block md:bottom-7 md:left-9">
      <div className="mb-1 h-px w-16 bg-paper/25" aria-hidden />
      <div>
        time&ensp;<span ref={timeRef} className="text-paper/90">05:12</span>
      </div>
      <div>
        elev&ensp;<span ref={elevRef} className="text-paper/90">2,041 m</span>
      </div>
      <div>
        light&ensp;<span ref={luxRef} className="text-paper/90">320 lx</span>
      </div>
      <div>
        ch&ensp;<span className="text-gold">{CHAPTERS[chapter].numeral}</span>
        <span className="text-paper/50">&thinsp;/&thinsp;V</span>
      </div>
    </div>
  );
}

export default function Chrome() {
  return (
    <>
      <ProgressBar />
      <TopBar />
      <ChapterRail />
      <Hud />
    </>
  );
}
