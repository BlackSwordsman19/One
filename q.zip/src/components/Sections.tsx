/* The field journal itself: six hours of one valley, laid over the live scene. */

import { CSSProperties, ReactNode, useState } from "react";
import plate from "@/assets/plate.jpg";
import Reveal, { MaskedTitle } from "./Reveal";
import { journey } from "@/state/journey";
import { cn } from "@/utils/cn";

function Kicker({ children }: { children: ReactNode }) {
  return <p className="font-body text-[0.95rem] text-mist">{children}</p>;
}

function Fig({ children }: { children: ReactNode }) {
  return <span className="font-figure text-[0.85rem] text-paper/85">{children}</span>;
}

function GhostNumeral({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      aria-hidden
      className={cn(
        "pointer-events-none absolute select-none font-display display-wonk leading-none text-paper/[0.05]",
        className
      )}
    >
      {children}
    </span>
  );
}

const d = (ms: number) => ({ "--d": `${ms}ms` }) as CSSProperties;

/* ——— 0 · trailhead ——— */

function Trailhead() {
  return (
    <section id="hour-0" className="relative flex min-h-svh flex-col justify-end px-5 pb-[12vh] md:px-9">
      <div className="mx-auto w-full max-w-[1200px]">
        <Reveal>
          <Kicker>
            <Fig>46°31′ N, 9°50′ E</Fig>, the Engadine at <Fig>1,805 m</Fig>, one full day
          </Kicker>
        </Reveal>
        <Reveal delay={90} className="mt-4">
          <h1 className="font-display display-wonk text-[clamp(3.4rem,11.5vw,9.5rem)] leading-[0.94] tracking-[-0.025em] font-[600] text-paper">
            <span className="mask-line"><span>The valley</span></span>
            <span className="mask-line"><span style={d(120)}>keeps its</span></span>
            <span className="mask-line"><span style={d(240)}>own time.</span></span>
          </h1>
        </Reveal>
        <Reveal delay={420} className="mt-7 max-w-xl">
          <p className="text-[1.05rem] leading-relaxed text-mist">
            Scroll to walk a single alpine valley from first light to starfall. Every ridge, tree
            and firefly on this page is live geometry, not footage, not photographs.
          </p>
        </Reveal>
      </div>
      <div className="absolute bottom-8 right-7 flex flex-col items-center gap-3 md:right-12" aria-hidden>
        <span className="font-figure text-[0.68rem] text-mist">scroll</span>
        <span className="cue-line block h-16 w-px">
          <i />
        </span>
      </div>
    </section>
  );
}

/* ——— I · first light ——— */

function FirstLight() {
  const figures = [
    { v: "−3.5 °C", label: "on the meadow at dawn, while the ridge above sits at +2.1 °C", off: "" },
    { v: "212", label: "bird species logged in the valley since records began in 1911", off: "md:mt-12" },
    { v: "12 min", label: "of alpenglow on the headwall, on a dry morning", off: "md:mt-24" },
  ];
  return (
    <section id="hour-1" className="relative flex min-h-[115svh] items-center px-5 py-24 md:px-9">
      <GhostNumeral className="-left-[3vw] top-[14%] text-[26vw]">I</GhostNumeral>
      <div className="mx-auto w-full max-w-[1200px]">
        <div className="max-w-[34rem]">
          <Reveal>
            <Kicker>Chapter I: first light, <Fig>05:12</Fig></Kicker>
          </Reveal>
          <MaskedTitle className="mt-4" lines={["Dawn climbs", "the slope on foot."]} />
          <Reveal delay={200} className="scrim -mx-7 mt-7 px-7 py-5">
            <p className="text-[1.02rem] leading-relaxed text-mist">
              Before the sun clears <em className="text-paper/90">Piz Rosatsch</em> it sends a
              deputy: alpenglow, a few minutes of rose on the highest snow while the valley floor
              still sits in a lake of cold air. The mist you are scrolling through is real
              weather, an inversion layer, and it burns off from the top down.
            </p>
          </Reveal>
        </div>
        <Reveal delay={140} className="mt-16">
          <div className="grid max-w-3xl grid-cols-1 gap-9 sm:grid-cols-3 sm:gap-8">
            {figures.map((f) => (
              <div key={f.v} className={f.off}>
                <div className="font-display text-[clamp(2rem,4vw,3.3rem)] leading-none font-[540] text-paper tabular-nums">
                  {f.v}
                </div>
                <p className="mt-2.5 max-w-[15.5rem] text-[0.85rem] leading-snug text-mist">{f.label}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ——— II · canopy ——— */

const SPECIES = [
  { name: "Swiss stone pine", latin: "Pinus cembra", note: "The elder: a metre a decade, a thousand years if spared. Its seeds are cached by nutcrackers, who never return for one in five." },
  { name: "European larch", latin: "Larix decidua", note: "The only conifer here that lets go, dropping every needle each October, and for three weeks it turns this valley to gold." },
  { name: "Norway spruce", latin: "Picea abies", note: "The dark metronome of the slope. One Swedish clone has resprouted the same roots since 9550 BC." },
  { name: "Mountain ash", latin: "Sorbus aucuparia", note: "Sets the hillside alight in September; a single tree can feed a whole passing thrush migration." },
  { name: "Bilberry", latin: "Vaccinium myrtillus", note: "Bear, grouse and walker all eat at the same low table." },
  { name: "Lady fern", latin: "Athyrium filix-femina", note: "Unfurls by pure geometry: a logarithmic spiral, like a breaking wave or a galaxy." },
];

function Canopy() {
  const [open, setOpen] = useState(-1);
  return (
    <section id="hour-2" className="relative flex min-h-[130svh] items-center px-5 py-24 md:px-9">
      <GhostNumeral className="-right-[2vw] top-[8%] text-[24vw]">II</GhostNumeral>
      <div className="mx-auto w-full max-w-[1200px]">
        <div className="ml-auto max-w-[34rem]">
          <Reveal>
            <Kicker>Chapter II: under the canopy, <Fig>11:40</Fig></Kicker>
          </Reveal>
          <MaskedTitle className="mt-4" lines={["A forest is a slow", "conversation."]} />
          <Reveal delay={200} className="scrim -mx-7 mt-7 px-7 py-5">
            <p className="text-[1.02rem] leading-relaxed text-mist">
              One gram of this soil holds up to a kilometre of fungal thread, and the trees trade
              sugar and warnings through it. Six residents of the valley, in order of how long
              they have been here. Open a name to read its entry.
            </p>
          </Reveal>
        </div>

        <Reveal delay={120} className="mt-16 max-w-3xl">
          <ul className="border-t border-paper/15">
            {SPECIES.map((s, i) => {
              const expanded = open === i;
              return (
                <li key={s.latin} className="border-b border-paper/15">
                  <button
                    type="button"
                    className="species-row grid w-full grid-cols-[auto_1fr] items-baseline gap-x-5 py-5 text-left md:grid-cols-[auto_1fr_auto]"
                    aria-expanded={expanded}
                    onClick={() => setOpen(expanded ? -1 : i)}
                  >
                    <span className="idx font-figure text-[0.8rem] text-mist">{String(i + 1).padStart(2, "0")}</span>
                    <span className="name font-display text-[clamp(1.45rem,3vw,2.1rem)] leading-tight font-[520] text-paper">
                      {s.name}
                      <span className="latin ml-3 font-body text-[0.95rem] italic text-mist">{s.latin}</span>
                    </span>
                    <span className="note col-span-2 mt-2 hidden max-w-[16rem] text-[0.82rem] leading-snug text-mist md:col-span-1 md:mt-0 md:block md:text-right">
                      {s.note}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
          <p className="mt-6 text-[0.85rem] text-mist/80">
            And watch the scene itself: the larches in it turn gold as you scroll towards dusk.
          </p>
        </Reveal>
      </div>
    </section>
  );
}

/* ——— III · the river ——— */

const RIVER_BARS = [
  { label: "Suspended load, glacial flour", value: 68 },
  { label: "Channel shaded by canopy", value: 83 },
  { label: "Flow from snow and ice, June", value: 41 },
];

function River() {
  return (
    <section id="hour-3" className="relative flex min-h-[120svh] items-center px-5 py-24 md:px-9">
      <GhostNumeral className="-left-[4vw] bottom-[10%] text-[24vw]">III</GhostNumeral>
      <div className="mx-auto grid w-full max-w-[1150px] items-center gap-14 md:grid-cols-[1.25fr_1fr]">
        <div>
          <Reveal>
            <Kicker>Chapter III: the river's memory, <Fig>15:05</Fig></Kicker>
          </Reveal>
          <MaskedTitle className="mt-4" lines={["Water remembers", "every mountain", "it has been."]} />
          <Reveal delay={220} className="scrim -mx-7 mt-8 px-7 py-5">
            <blockquote className="border-l-2 border-gold/70 pl-5 font-body text-[1.22rem] italic leading-relaxed text-paper/90">
              “The Inn leaves this valley carrying some 4,000 tonnes of dissolved rock a year,
              and still runs clear enough to count pebbles at four metres.”
              <footer className="mt-3 font-figure text-[0.72rem] not-italic text-mist">
                field notebook, 14 August
              </footer>
            </blockquote>
          </Reveal>
        </div>
        <Reveal delay={160}>
          <div className="flex flex-col gap-8">
            {RIVER_BARS.map((b, i) => (
              <div key={b.label}>
                <div className="mb-2.5 flex items-baseline justify-between gap-6">
                  <span className="text-[0.88rem] text-mist">{b.label}</span>
                  <span className="font-figure text-[0.8rem] text-paper tabular-nums">{b.value}%</span>
                </div>
                <div className="h-[3px] w-full bg-paper/12">
                  <div className="bar-fill h-full bg-gold" style={{ width: `${b.value}%`, ...d(i * 160) }} />
                </div>
              </div>
            ))}
            <p className="text-[0.82rem] leading-snug text-mist/75">
              Figures from a single August survey; the river revises them with every storm.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ——— IV · ridgeline ——— */

function Ridgeline() {
  return (
    <section id="hour-4" className="relative flex min-h-[125svh] items-center px-5 py-24 md:px-9">
      <GhostNumeral className="-right-[3vw] top-[16%] text-[24vw]">IV</GhostNumeral>
      <div className="mx-auto grid w-full max-w-[1150px] items-center gap-16 md:grid-cols-2">
        <div>
          <Reveal>
            <Kicker>Chapter IV: the ridgeline, <Fig>19:58</Fig></Kicker>
          </Reveal>
          <MaskedTitle className="mt-4" lines={["Dusk is the valley", "exhaling."]} />
          <Reveal delay={200} className="scrim -mx-7 mt-7 px-7 py-5">
            <p className="text-[1.02rem] leading-relaxed text-mist">
              Cool air begins to pour downhill: the katabatic wind, the valley's evening breath.
              Chamois move up onto the ledges as the walkers go down, and the larches take the
              last twenty minutes of light and hold it. Keep scrolling: below this paragraph, the
              day is turning.
            </p>
          </Reveal>
        </div>
        <Reveal delay={150} className="justify-self-center">
          <figure className="plate w-[min(88vw,25rem)] p-5 pb-4">
            <span className="tape -top-3 left-8 -rotate-6" aria-hidden />
            <span className="tape -top-3 right-10 rotate-3" aria-hidden />
            <img
              src={plate}
              alt="Botanical plate of a Swiss stone pine branch and a golden larch sprig"
              className="relative z-[1] w-full"
              width={800}
              height={1000}
            />
            <figcaption className="relative z-[1] mt-3.5 font-figure text-[0.68rem] leading-snug text-sheetink/80">
              Plate XII: Pinus cembra and Larix decidua, pressed at 1,980 m
            </figcaption>
          </figure>
        </Reveal>
      </div>
    </section>
  );
}

/* ——— V · starfall ——— */

function Starfall() {
  return (
    <section id="hour-5" className="relative flex min-h-[150svh] flex-col px-5 pt-24 md:px-9">
      <GhostNumeral className="right-[6vw] top-[6%] text-[24vw]">V</GhostNumeral>
      <div className="mx-auto flex w-full max-w-[1200px] flex-1 flex-col justify-center">
        <div className="max-w-[34rem]">
          <Reveal>
            <Kicker>Chapter V: starfall, <Fig>23:41</Fig></Kicker>
          </Reveal>
          <MaskedTitle className="mt-4" lines={["The dark is", "habitat too."]} />
          <Reveal delay={200} className="scrim -mx-7 mt-7 px-7 py-5">
            <p className="text-[1.02rem] leading-relaxed text-mist">
              Bats over the water, an owl in the spruces, and above them one of the Alps' last
              genuinely dark skies. Walk quietly, and leave the torch off: the fireflies are
              already on.
            </p>
          </Reveal>
        </div>
        <Reveal delay={120} className="mt-24 md:mt-32">
          <p className="max-w-2xl font-display display-wonk text-[clamp(2rem,4.6vw,3.8rem)] leading-[1.06] font-[520] italic text-paper/92">
            The valley will keep its own time, with or without you.
          </p>
        </Reveal>
        <Reveal delay={240} className="mt-11 mb-24">
          <button type="button" className="pill" onClick={() => journey.toTop()}>
            Walk the day again
          </button>
        </Reveal>
      </div>
      <footer className="mx-auto w-full max-w-[1200px] border-t border-paper/12 pb-9 pt-6">
        <div className="flex flex-wrap items-center gap-x-10 gap-y-3 text-[0.8rem] text-mist">
          <span className="font-display display-wonk text-[1rem] italic text-paper/90">Verdant Atlas</span>
          <span>a scroll-driven field journal</span>
          <span>set in Fraunces and Spectral, figures in IBM Plex Mono</span>
          <span>every ridge, tree and firefly is live three.js geometry</span>
          <span className="font-figure text-[0.72rem]">46°31′ N, 9°50′ E</span>
          <span className="text-mist/70">no cookies, no trackers, only moss</span>
        </div>
      </footer>
    </section>
  );
}

export default function Sections() {
  return (
    <>
      <Trailhead />
      <FirstLight />
      <Canopy />
      <River />
      <Ridgeline />
      <Starfall />
    </>
  );
}
