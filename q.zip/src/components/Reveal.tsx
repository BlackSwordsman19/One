import { CSSProperties, ReactNode, useEffect, useRef } from "react";
import { cn } from "@/utils/cn";

interface RevealProps {
  children: ReactNode;
  className?: string;
  /** transition delay in ms */
  delay?: number;
  threshold?: number;
}

/** Fades content in once it enters the viewport (transform + opacity only). */
export default function Reveal({ children, className, delay = 0, threshold = 0.2 }: RevealProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            el.classList.add("is-in");
            io.disconnect();
          }
        }
      },
      { threshold, rootMargin: "0px 0px -8% 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);

  return (
    <div ref={ref} className={cn("reveal", className)} style={{ "--d": `${delay}ms` } as CSSProperties}>
      {children}
    </div>
  );
}

/** A display heading whose lines rise out of a mask, one after another. */
export function MaskedTitle({ lines, className, sizeClass }: { lines: string[]; className?: string; sizeClass?: string }) {
  return (
    <Reveal className={className}>
      <h2 className={cn("font-display display-wonk text-paper", sizeClass ?? "text-[clamp(2.6rem,6vw,5.2rem)] leading-[1.03] tracking-[-0.02em] font-[560]")}>
        {lines.map((line, i) => (
          <span key={line} className="mask-line">
            <span style={{ "--d": `${i * 110}ms` } as CSSProperties}>{line}</span>
          </span>
        ))}
      </h2>
    </Reveal>
  );
}
