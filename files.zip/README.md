# Lights Out: a 3D scroll-driven Formula 1 page

## Run it
Serve the folder over HTTP. It will not work from `file://` because it uses ES modules and an import map.

    python3 -m http.server 8000      # then open http://localhost:8000

## Files
- `index.html`: the only entry point.
- `css/styles.css`: all styles.
- `js/main.js`: scroll controller, nav, lap map, start lights, 3D fallback. It never imports three.js, so a failed CDN cannot break the page.
- `js/scene.js`: renderer, lights, scroll-to-pose mapping, auto-framing.
- `js/car.js`: the car, built in code (lofted bodywork plus simple shapes).
- `verify/`: the overlap check and a local mirror server used during testing (see below).

## External dependencies (loaded from the internet)
- three.js 0.186.1 (MIT) from cdn.jsdelivr.net, set in the import map in `index.html`.
- Barlow Condensed and Inter (SIL Open Font License) from Google Fonts.

## Imagery and licences
- No photographs. The car, start-light gantry, circuit map, kerb strip, pit-lane lights and grain are original code and vector art, so nothing needs attribution.
- The car is a generic Formula 1 style car, not a specific team's car, and uses no logos.
- If you add photos later, credit them here.

## How the car stays clear
- The car's canvas lives in its own grid cell (`.stage`). Text, nav and the lap map live in other cells, so they cannot overlap it.
- The camera is re-fitted every frame so the car always fills 84 to 90 percent of its cell and never leaves it.
- The story text is swapped in a pinned panel by scroll progress. It never scrolls through the car's area.

## Accessibility and motion
- Reduced motion: lights stay static, text switches without sliding, and the car holds one pose per chapter.
- If WebGL, the model or the CDN fails, an SVG illustration of the car is shown and the story still works.
- Landmarks, skip link, keyboard-reachable chapter links, text contrast of 5:1 or higher.

## Re-running the checks
Add `?debug` to the URL to expose `window.__f1` (car screen bounds, draw-call counts, `jump(p)`).
`verify/check.js` samples 21 scroll positions and reports car bounds and any element overlapping the car's cell.
`verify/serve.py` serves the page with the pinned CDN files mirrored locally (`npm i three@0.186.1 @fontsource/barlow-condensed @fontsource/inter` inside `verify/` first).
