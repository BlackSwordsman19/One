// Scroll controller, UI and fallback. It never imports three.js directly, so a failed CDN cannot break the page.
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
const root = document.documentElement, stage = $('#stage'), panels = $$('.panel'), jumps = $$('[data-go]'), navLinks = $$('nav a');
const lapText = $('#lapText'), road = $('#road'), done = $('#done'), dot = $('#dot'), ids = ['intro', 'aero', 'power', 'finish'];
root.classList.remove('no-js');

const mq = matchMedia('(prefers-reduced-motion: reduce)');
let reduced = mq.matches;
mq.addEventListener('change', e => { reduced = e.matches; kick(); });

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const maxScroll = () => Math.max(1, root.scrollHeight - innerHeight);
const snap = p => (Math.min(3, Math.floor(p * 4)) + .5) / 4;   // reduced motion: hold each chapter's pose
const len = road.getTotalLength();
done.style.strokeDasharray = len;

let target = 0, cur = 0, raf = 0, last = 0, scene = null, chapter = -1, ready = false, go = false;

function paint(p) {
  const s = p * 4;
  panels.forEach((el, i) => {
    let d = s - (i + .5);
    if ((i === 0 && d < 0) || (i === 3 && d > 0)) d = 0;   // first and last panel stay visible at the ends
    const o = reduced ? +(Math.abs(d) < .5) : clamp((.5 - Math.abs(d)) / .12);
    el.style.setProperty('--o', o.toFixed(2));
    el.style.setProperty('--y', reduced ? 0 : (-clamp(d, -.5, .5)).toFixed(2));   // slides up as you scroll down, never leaves its slot
  });
  const k = Math.min(3, Math.floor(s));
  if (k !== chapter) {
    chapter = k;
    panels.forEach((el, i) => { el.classList.toggle('on', i === k); $$('a', el).forEach(a => (a.tabIndex = i === k ? 0 : -1)); });
    navLinks.forEach((a, i) => (i === k ? a.setAttribute('aria-current', 'step') : a.removeAttribute('aria-current')));
    lapText.textContent = `Lap ${k + 1} of 4`;
  }
  done.style.strokeDashoffset = len * (1 - p);
  const pt = road.getPointAtLength(p * len);
  dot.setAttribute('cx', pt.x); dot.setAttribute('cy', pt.y);
}

function frame(t) {
  const dt = Math.max(.001, Math.min(.25, (t - last) / 1e3)); last = t;
  cur = reduced ? target : cur + (target - cur) * (1 - Math.exp(-dt * 7));
  if (Math.abs(target - cur) < 1e-4) cur = target;
  paint(cur);
  if (scene) scene.update(reduced ? snap(cur) : cur);
  raf = cur === target ? 0 : requestAnimationFrame(frame);
}
const kick = () => { if (!raf) { last = performance.now(); raf = requestAnimationFrame(frame); } };
const readScroll = () => { target = clamp(scrollY / maxScroll()); kick(); };
addEventListener('scroll', readScroll, { passive: true });
addEventListener('resize', readScroll);

// Chapter links scroll to the middle of a chapter, where its copy is fully visible.
const ch = i => (i === 0 ? 0 : ((i + .5) / 4) * maxScroll());
function goTo(i, smooth = true) {
  scrollTo({ top: ch(i), behavior: smooth && !reduced ? 'smooth' : 'auto' });
  history.replaceState(null, '', '#' + ids[i]);
}
jumps.forEach(a => a.addEventListener('click', e => { e.preventDefault(); goTo(+a.dataset.go); }));

// One orchestrated moment: five lights, then lights out, then the car appears.
// The lamps are timed by CSS animation (one more every 0.3 s, all out at 2.3 s), so a busy main thread cannot squash the sequence.
const gantry = $('.gantry'), show = () => stage.classList.toggle('show', ready && go);
let out = 0;
function lightsOut() { clearTimeout(out); gantry.classList.add('out'); go = true; show(); }
if (reduced) lightsOut();
else { out = setTimeout(lightsOut, 2300); addEventListener('scroll', lightsOut, { once: true, passive: true }); }

async function boot() {
  const fail = e => { console.warn('3D view unavailable, showing the illustration instead.', e); root.classList.add('no-3d'); ready = true; stage.classList.add('ready'); show(); };
  const timer = setTimeout(() => fail('timeout'), 15000);
  try {
    const { createScene } = await import('./scene.js');
    const s = await createScene($('#gl'), stage);
    if (root.classList.contains('no-3d')) return;
    clearTimeout(timer); scene = s; ready = true; stage.classList.add('ready'); show(); kick();
    if (/[?&]debug/.test(location.search)) window.__f1 = { bbox: () => s.bbox(), info: () => s.info(), jump(p) { scrollTo(0, p * maxScroll()); target = cur = clamp(p); frame(performance.now()); } };
  } catch (e) { clearTimeout(timer); fail(e); }
}

const start = ids.indexOf(location.hash.slice(1));
target = cur = clamp(scrollY / maxScroll()); paint(cur);
if (start > 0) addEventListener('load', () => { goTo(start, false); setTimeout(() => goTo(start, false), 150); });   // beat the browser's own anchor jump
boot();
