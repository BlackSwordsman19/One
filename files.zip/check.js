(() => {
  const st = document.getElementById('stage'), S = st.getBoundingClientRect(), cv = document.getElementById('gl').getBoundingClientRect(), out = [];
  for (let i = 0; i <= 20; i++) {
    const p = i / 20; __f1.jump(p);
    const b = __f1.bbox();
    const hits = [...document.querySelectorAll('.rig *')].filter(e => e !== st && !st.contains(e)).filter(e => {
      const cs = getComputedStyle(e); let eo = 1; for (let n = e; n && n !== document.body; n = n.parentElement) eo *= +getComputedStyle(n).opacity; if (cs.display === 'none' || cs.visibility === 'hidden' || eo < .02) return false;
      const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0 && r.left < S.right && r.right > S.left && r.top < S.bottom && r.bottom > S.top;
    }).map(e => e.tagName + '.' + e.className);
    const x0 = cv.left + (b.x0 + 1) / 2 * cv.width, x1 = cv.left + (b.x1 + 1) / 2 * cv.width, y0 = cv.top + (1 - b.y1) / 2 * cv.height, y1 = cv.top + (1 - b.y0) / 2 * cv.height;
    let covered = 0;
    for (let a = 0; a <= 6; a++) for (let c = 0; c <= 6; c++) { const el = document.elementFromPoint(x0 + (x1 - x0) * a / 6, y0 + (y1 - y0) * c / 6); if (el && el.id !== 'gl') covered++; }
    const cp = document.querySelector('.copy').getBoundingClientRect(), vis = [...document.querySelectorAll('.panel')].find(e => +getComputedStyle(e).opacity > .9), pr = vis && vis.getBoundingClientRect(), fits = !pr || (pr.top >= cp.top - 1 && pr.bottom <= cp.bottom + 1 && pr.left >= cp.left - 1 && pr.right <= cp.right + 1);
    out.push([+p.toFixed(2), +b.x0.toFixed(2), +b.x1.toFixed(2), +b.y0.toFixed(2), +b.y1.toFixed(2), hits.length, covered, hits[0] || '', fits ? 1 : 0]);
  }
  const inside = out.every(r => r[1] >= -1 && r[2] <= 1 && r[3] >= -1 && r[4] <= 1);
  const worst = Math.max(...out.map(r => Math.max(Math.abs(r[1]), Math.abs(r[2]), Math.abs(r[3]), Math.abs(r[4]))));
  return JSON.stringify({ vp: [innerWidth, innerHeight], stage: [S.left | 0, S.top | 0, S.width | 0, S.height | 0], carInsideStage: inside, worstNdc: +worst.toFixed(3), overlapRows: out.filter(r => r[5] || r[6]).length, textFits: out.every(r => r[8]), badFit: out.filter(r => !r[8]).map(r => r[0]), info: __f1.info(), rows: out.map(r => r.join(',')) });
})()
