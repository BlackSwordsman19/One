// Procedural Formula 1 style car: lofted bodywork plus simple primitives. Original geometry, no external model, no licence to track.
// Axes: nose points to +Z, up is +Y, units are metres.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

const { Mesh, Group, BoxGeometry: Box, CylinderGeometry: Cyl, MeshStandardMaterial: Std, MeshPhysicalMaterial: Phys, Vector3: V3 } = THREE;
const PI = Math.PI;

function livery() {                                   // red paint, white centre stripe, race number roundel
  const c = document.createElement('canvas'); c.width = 512; c.height = 2048;
  const g = c.getContext('2d'), zy = z => (1 - (z + 2.3) / 5.2) * 2048;
  g.fillStyle = '#d70d00'; g.fillRect(0, 0, 512, 2048);
  g.fillStyle = '#111'; g.fillRect(210, zy(2.25), 92, zy(-1.6) - zy(2.25));
  g.fillStyle = '#f5f5f3'; g.fillRect(220, zy(2.25), 72, zy(-1.6) - zy(2.25));
  g.save(); g.translate(256, zy(1.9)); g.scale(1, .69);
  g.fillStyle = '#f5f5f3'; g.beginPath(); g.arc(0, 0, 50, 0, 2 * PI); g.fill();
  g.fillStyle = '#111'; g.font = '800 64px "Barlow Condensed","Arial Narrow",sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('07', 0, 4);
  g.restore();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t;
}

const cr = (a, b, c, d, u) => .5 * (2 * b + (c - a) * u + (2 * a - 5 * b + 4 * c - d) * u * u + (3 * b - a - 3 * c + d) * u ** 3);
function spline(v, u) {                               // smooth curve through evenly spaced values, u from 0 to 1
  const n = v.length - 1, f = Math.min(n - 1e-9, u * n), i = Math.floor(f), g = k => v[Math.max(0, Math.min(n, k))];
  return cr(g(i - 1), g(i), g(i + 1), g(i + 2), f - i);
}
// Loft a smooth body through cross-sections [z, centreX, halfWidth, top, bottom, squareness], listed rear to front.
function loft(st, sx, mat) {
  const [Z, CX, WD, T, B, E] = [0, 1, 2, 3, 4, 5].map(k => st.map(s => s[k]));
  const M = 44, N = 40, pos = [], uv = [], idx = [];
  for (let j = 0; j < M; j++) {
    const u = j / (M - 1), z = spline(Z, u), cx = sx * spline(CX, u), w = spline(WD, u), t = spline(T, u), b = spline(B, u), e = spline(E, u), yc = (t + b) / 2, h = (t - b) / 2;
    for (let k = 0; k < N; k++) {
      const a = (k / N) * 2 * PI, c = Math.cos(a), s = Math.sin(a);
      const x = cx + w * Math.sign(c) * Math.abs(c) ** (2 / e), y = yc + h * Math.sign(s) * Math.abs(s) ** (2 / e);
      pos.push(x, y, z); uv.push(.5 + x / .9, (z + 2.3) / 5.2);
    }
  }
  for (let j = 0; j < M - 1; j++) for (let k = 0; k < N; k++) {
    const a = j * N + k, b = j * N + ((k + 1) % N), c = a + N, d = b + N;
    sx > 0 ? idx.push(a, b, c, b, d, c) : idx.push(a, c, b, b, c, d);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  g.setIndex(idx); g.computeVertexNormals();
  return new Mesh(g, mat);
}

export function buildCar() {
  const paint = new Phys({ map: livery(), roughness: .32, metalness: .2, clearcoat: 1, clearcoatRoughness: .05 });
  const red = new Std({ color: 0xd70d00, roughness: .4, metalness: .2 });
  const carbon = new Std({ color: 0x15171b, roughness: .5, metalness: .55 });
  const dark = new Std({ color: 0x050506, roughness: .6 });
  const metal = new Std({ color: 0xb4bac0, roughness: .28, metalness: 1 });
  const rubber = new Std({ color: 0x0c0c0d, roughness: .95 });
  const rainMat = new Std({ color: 0x300000, emissive: 0xff1200, emissiveIntensity: 1 });
  const root = new Group(), inner = new Group(); root.add(inner);
  const add = (geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0, parent = inner) => { const m = new Mesh(geo, mat); m.position.set(x, y, z); m.rotation.set(rx, ry, rz); parent.add(m); return m; };
  const arm = (a, b, r = .012) => {                    // suspension arm between two points
    const A = new V3(...a), D = new V3(...b).sub(A), m = new Mesh(new Cyl(r, r, D.length(), 6), metal);
    m.position.copy(A).addScaledVector(D, .5); m.quaternion.setFromUnitVectors(new V3(0, 1, 0), D.normalize()); inner.add(m);
  };

  // Monocoque, cockpit surround and engine cover in one smooth piece.
  inner.add(loft([[-2.25, 0, .015, .28, .2, 2], [-1.5, 0, .14, .42, .16, 2.4], [-.9, 0, .25, .66, .14, 2.5], [-.3, 0, .33, .74, .12, 2.6], [.3, 0, .34, .62, .1, 2.6], [.9, 0, .27, .5, .1, 2.4], [1.6, 0, .17, .33, .14, 2.2], [2.3, 0, .1, .27, .15, 2.1], [2.62, 0, .015, .22, .17, 2]], 1, paint));
  for (const s of [-1, 1]) {                           // sidepods with a dark inlet
    inner.add(loft([[-1.55, .3, .12, .26, .12, 2.2], [-1, .4, .2, .34, .1, 2.4], [-.4, .46, .26, .46, .09, 2.5], [.2, .46, .27, .5, .09, 2.6], [.62, .42, .2, .44, .11, 2.4]], s, paint));
    const inlet = add(new THREE.CircleGeometry(1, 24), dark, s * .42, .275, .622); inlet.scale.set(.19, .15, 1);
  }
  // Floor, diffuser and turning vanes.
  const half = [[.6, 1.05], [.83, .55], [.83, -1], [.57, -1.3], [.57, -2.1]], sh = new THREE.Shape();
  [...half.map(([x, z]) => [x, -z]), [0, 2.15], ...[...half].reverse().map(([x, z]) => [-x, -z])].forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  const fg = new THREE.ExtrudeGeometry(sh, { depth: .04, bevelEnabled: false }); fg.rotateX(-PI / 2); add(fg, carbon, 0, .06, 0);
  add(new Box(1.02, .03, .6), carbon, 0, .15, -2, .3);
  for (const s of [-1, 1]) {
    add(new Box(.012, .14, .55), carbon, s * .2, .15, -2, .3);
    [[.38, .95], [.5, .85], [.62, .75]].forEach(([x, z]) => add(new Box(.012, .14, .32), carbon, s * x, .16, z, 0, s * -.25, 0));
  }
  // Cockpit: helmet, halo, airbox, shark fin, mirrors.
  add(new THREE.SphereGeometry(.135, 24, 16), new Std({ color: 0xf5f5f3, roughness: .25 }), 0, .68, .08);
  add(new THREE.SphereGeometry(.139, 24, 8, PI / 2 - .85, 1.7, 1, .65), dark, 0, .68, .08);
  const curve = pts => new THREE.CatmullRomCurve3(pts.map(p => new V3(...p)));
  for (const s of [-1, 1]) add(new THREE.TubeGeometry(curve([[s * .27, .6, -.12], [s * .29, .8, .08], [s * .2, .88, .4], [s * .05, .8, .62]]), 24, .017, 8), metal);
  add(new THREE.TubeGeometry(curve([[0, .8, .62], [0, .66, .7], [0, .56, .74]]), 8, .02, 8), metal);
  add(new RoundedBoxGeometry(.19, .16, .32, 3, .05), red, 0, .78, -.32);
  add(new Box(.12, .08, .02), dark, 0, .8, -.162);
  const fin = new THREE.Shape(); [[-.25, .7], [-.3, .82], [-1, .8], [-1.76, .42], [-1.76, .34], [-1, .58]].forEach(([z, y], i) => (i ? fin.lineTo(z, y) : fin.moveTo(z, y)));
  const fgm = new THREE.ExtrudeGeometry(fin, { depth: .02, bevelEnabled: false }); fgm.rotateY(-PI / 2); fgm.translate(.01, 0, 0); add(fgm, red);
  for (const s of [-1, 1]) { add(new Box(.15, .07, .045), carbon, s * .4, .62, .78, 0, s * .15, 0); arm([s * .22, .56, .72], [s * .36, .62, .78], .008); }

  // Front wing: three stacked elements and end plates.
  const fw = new Group(); fw.position.set(0, 0, 2.55); inner.add(fw);
  [[.06, .1, .32, .06], [.105, -.06, .26, .22], [.155, -.2, .22, .36]].forEach(([y, z, c, r]) => add(new Box(1.95, .014, c), y > .15 ? red : carbon, 0, y, z, r, 0, 0, fw));
  for (const s of [-1, 1]) { add(new Box(.016, .2, .62), carbon, s * .98, .12, -.05, 0, 0, s * .06, fw); add(new Box(.02, .16, .3), carbon, s * .07, .15, -.05, 0, 0, 0, fw); }
  // Rear wing with a rain light that glows brighter as the story builds.
  const rw = new Group(); rw.position.set(0, 0, -2.4); inner.add(rw);
  add(new Box(1, .016, .32), carbon, 0, .78, 0, .15, 0, 0, rw);
  add(new Box(1, .014, .24), red, 0, .9, -.09, .45, 0, 0, rw);
  add(new Box(.9, .012, .2), carbon, 0, .24, -.02, .2, 0, 0, rw);
  add(new Box(.05, .56, .08), carbon, 0, .52, .17, 0, 0, 0, rw);
  const rain = add(new Box(.1, .06, .02), rainMat, 0, .46, .12, 0, 0, 0, rw);
  for (const s of [-1, 1]) add(new Box(.016, .46, .5), carbon, s * .51, .7, -.03, 0, 0, 0, rw);

  // Wheels: black tyre, coloured sidewall ring, dark cover with six slots (so the spin is visible) and a metal nut.
  const wheels = [];
  const wheel = (x, z, r, w) => {
    const g = new Group(); g.position.set(x, r, z); inner.add(g); wheels.push(g);
    add(new Cyl(r, r, w, 40), rubber, 0, 0, 0, 0, 0, PI / 2, g);
    for (const f of [-1, 1]) {
      const face = new Group(); face.position.x = f * (w / 2 + .002); face.rotation.y = f * PI / 2; g.add(face);
      add(new THREE.RingGeometry(r * .72, r * .8, 48), red, 0, 0, 0, 0, 0, 0, face);
      add(new THREE.CircleGeometry(r * .62, 32), carbon, 0, 0, .004, 0, 0, 0, face);
      for (let k = 0; k < 6; k++) { const a = (k * PI) / 3; add(new Box(.025, r * .26, .004), dark, Math.cos(a) * r * .4, Math.sin(a) * r * .4, .008, 0, 0, a - PI / 2, face); }
      add(new Cyl(.03, .03, .02, 12), metal, 0, 0, .01, PI / 2, 0, 0, face);
    }
  };
  for (const s of [-1, 1]) {
    wheel(s * .8, 1.65, .34, .3); wheel(s * .8, -1.75, .36, .39);
    arm([s * .14, .3, 1.5], [s * .66, .36, 1.65]); arm([s * .14, .16, 1.8], [s * .66, .3, 1.65]); arm([s * .66, .34, 1.65], [s * .2, .5, 1.25]);
    arm([s * .12, .32, -1.55], [s * .66, .38, -1.75]); arm([s * .07, .18, -1.95], [s * .66, .3, -1.75]); arm([s * .66, .34, -1.75], [s * .2, .45, -1.35]);
  }
  // Soft contact shadow that turns with the car.
  const sc = document.createElement('canvas'); sc.width = sc.height = 128;
  const sg = sc.getContext('2d'), gr = sg.createRadialGradient(64, 64, 4, 64, 64, 64);
  gr.addColorStop(0, 'rgba(0,0,0,.8)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); sg.fillStyle = gr; sg.fillRect(0, 0, 128, 128);
  const shadow = new Mesh(new THREE.PlaneGeometry(3.4, 7.4), new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(sc), transparent: true, depthWrite: false }));
  shadow.rotation.x = -PI / 2; shadow.position.y = .004; shadow.userData.skip = true; root.add(shadow);
  return { root, inner, wheels, rain };
}
