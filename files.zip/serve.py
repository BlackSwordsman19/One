# Dev-only server: serves ../site and mirrors the pinned CDN files locally (sandbox blocks CDNs).
import http.server, socketserver, os, re, sys
ROOT = os.path.abspath('..'); NM = os.path.abspath('node_modules')
CDN = 'https://cdn.jsdelivr.net/npm/three@0.186.1/'
FONTS = ('Barlow Condensed', 'Inter')
def fonts_css():
    out = []
    for fam, slug, specs in (('Barlow Condensed','barlow-condensed',[(500,'normal'),(600,'normal'),(700,'normal'),(800,'normal'),(700,'italic'),(800,'italic')]),
                             ('Inter','inter',[(400,'normal'),(500,'normal'),(600,'normal')])):
        for w, st in specs:
            out.append("@font-face{font-family:'%s';font-style:%s;font-weight:%d;font-display:swap;src:url(/vendor/fontsource/%s/files/%s-latin-%d-%s.woff2) format('woff2')}" % (fam, st, w, slug, slug, w, st))
    return '\n'.join(out)
class H(http.server.SimpleHTTPRequestHandler):
    def translate_path(self, path):
        p = path.split('?')[0].split('#')[0]
        if p.startswith('/vendor/three/'): return os.path.join(NM, 'three', p[len('/vendor/three/'):])
        if p.startswith('/vendor/fontsource/'): return os.path.join(NM, '@fontsource', p[len('/vendor/fontsource/'):])
        return os.path.join(ROOT, p.lstrip('/') or 'index.html') if p != '/' else os.path.join(ROOT, 'index.html')
    def do_GET(self):
        p = self.path.split('?')[0]
        if p == '/vendor/fonts.css':
            b = fonts_css().encode(); self.send_response(200); self.send_header('Content-Type','text/css'); self.send_header('Content-Length',str(len(b))); self.end_headers(); self.wfile.write(b); return
        if p in ('/', '/index.html') or p.endswith('.html'):
            fp = self.translate_path(self.path)
            if os.path.isfile(fp):
                s = open(fp, encoding='utf-8').read().replace(CDN, '/vendor/three/')
                s = re.sub(r'<link[^>]+fonts\.googleapis\.com/css2[^>]*>', '<link rel="stylesheet" href="/vendor/fonts.css">', s)
                b = s.encode(); self.send_response(200); self.send_header('Content-Type','text/html; charset=utf-8'); self.send_header('Content-Length',str(len(b))); self.send_header('Cache-Control','no-store'); self.end_headers(); self.wfile.write(b); return
        return super().do_GET()
    def end_headers(self):
        self.send_header('Cache-Control','no-store'); super().end_headers()
    def log_message(self, *a): pass
socketserver.TCPServer.allow_reuse_address = True
with socketserver.ThreadingTCPServer(('127.0.0.1', 8123), H) as s: s.serve_forever()
