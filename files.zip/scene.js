// Renderer, lights and the scroll-to-pose mapping. Poses hold briefly at each chapter, then ease to the next.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { buildCar } from './car.js';

const FOV = 28, PI = Math.PI, sin = Math.sin, cos = Math.cos;
// yaw: 0 = nose toward camera, PI/2 = side profile, PI = tail toward camera.
// cx, cy: where the car sits inside its stage (-1 to 1). fill: how much of the stage it fills.
const POSES = [
  { yaw: .55, y: .45, elev: .10, cx: .06, cy: -.03, fill: .84, red: .5 },        // intro: front three-quarter
  { yaw: PI / 2, y: .42, elev: .20, cx: 0, cy: .02, fill: .85, red: .3 },       // aero: side profile
  { yaw: PI - .6, y: .45, elev: .12, cx: .05, cy: -.02, fill: .86, red: 1 },      // power: rear three-quarter
  { yaw: 2 * PI - .5, y: .45, elev: .06, cx: 0, cy: -.04, fill: .88, red: .7 },   // finish: front three-quarter, other side
];
const mix = (a, b, t) => a + (b - a) * t, clamp = (v, a, b) => Math.min(b, Math.max(a, v));

function sample(p) {
  const s = clamp(p * 4 - .5, 0, 3), i = Math.min(2, Math.floor(s)), u = clamp((s - i - .2) / .6, 0, 1), t = u * u * (3 - 2 * u), a = POSES[i], b = POSES[i + 1], o = {};
  for (const k in a) o[k] = mix(a[k], b[k], t);
  return o;
}

export async function createScene(canvas, stage) {
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = .92;
  canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); document.documentElement.classList.add('no-3d'); });

  const scene = new THREE.Scene(), cam = new THREE.PerspectiveCamera(FOV, 1, .5, 80);
  scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), .04).texture;
  scene.environmentIntensity = .55;
  const key = new THREE.DirectionalLight(0xffffff, 1.9), rim = new THREE.DirectionalLight(0xff2b1c, 2);
  key.position.set(4, 6, 6); rim.position.set(-6, 3, -5);
  scene.add(key, rim);

  const car = buildCar(); scene.add(car.root);
  const box = new THREE.Box3().setFromObject(car.inner), size = box.getSize(new THREE.Vector3()), mid = box.getCenter(new THREE.Vector3());
  car.inner.position.set(-mid.x, 0, -mid.z);            // pivot on the car's centre so it turns in place
  const L = size.z, W = size.x, H = size.y, v = new THREE.Vector3(), pts = [];
  car.root.updateMatrixWorld(true);
  car.root.traverse(m => {                              // corners of every part's box, kept to measure the car on screen
    if (!m.isMesh || m.userData.skip) return;
    m.geometry.computeBoundingBox();
    const b = m.geometry.boundingBox;
    for (let i = 0; i < 8; i++) { v.set(i & 1 ? b.max.x : b.min.x, i & 2 ? b.max.y : b.min.y, i & 4 ? b.max.z : b.min.z).applyMatrix4(m.matrixWorld); pts.push(v.x, v.y, v.z); }
  });
  function bounds(yaw) {                                // the car's extent in screen units (-1 to 1)
    const c = cos(yaw), s = sin(yaw); let x0 = 9, x1 = -9, y0 = 9, y1 = -9;
    for (let i = 0; i < pts.length; i += 3) {
      v.set(pts[i] * c + pts[i + 2] * s, pts[i + 1], pts[i + 2] * c - pts[i] * s).project(cam);
      if (v.x < x0) x0 = v.x; if (v.x > x1) x1 = v.x; if (v.y < y0) y0 = v.y; if (v.y > y1) y1 = v.y;
    }
    return { x0, x1, y0, y1 };
  }

  let p = 0;
  function render(np = p) {
    p = np;
    const o = sample(p), tan = Math.tan((FOV * PI) / 360), c = Math.abs(cos(o.yaw)), s = Math.abs(sin(o.yaw));
    const depth = L * c + W * s, halfW = (L * s + W * c) / 2, halfH = (H * cos(o.elev) + depth * sin(o.elev)) / 2;
    let d = Math.max(halfW / (tan * cam.aspect * .8), halfH / (tan * .8)) + depth / 2, sx = 0, sy = 0;
    car.root.rotation.y = o.yaw;
    for (let i = 0; i < 3; i++) {                       // place, measure, correct: centre the car and fill the stage by the pose's amount
      cam.position.set(sx, o.y + sy + d * sin(o.elev), d * cos(o.elev)); cam.lookAt(sx, o.y + sy, 0); cam.updateMatrixWorld();
      if (i === 2) break;
      const b = bounds(o.yaw), k = o.fill / Math.max((b.x1 - b.x0) / 2, (b.y1 - b.y0) / 2);
      sx += ((b.x0 + b.x1) / 2 - o.cx) * d * tan * cam.aspect; sy += ((b.y0 + b.y1) / 2 - o.cy) * d * tan;
      d = Math.max(depth / 2 + 3.2, depth / 2 + (d - depth / 2) / k);
    }
    car.wheels.forEach(w => (w.rotation.x = p * 12 * PI));
    car.rain.material.emissiveIntensity = .5 + 1.5 * o.red; rim.intensity = .8 + 2.6 * o.red;
    renderer.render(scene, cam);
  }

  const bbox = () => bounds(car.root.rotation.y);       // used by the overlap check
  const info = () => ({ calls: renderer.info.render.calls, triangles: renderer.info.render.triangles, geometries: renderer.info.memory.geometries });
  const resize = () => {
    const w = stage.clientWidth, h = stage.clientHeight;
    if (!w || !h) return;
    renderer.setSize(w, h, false); cam.aspect = w / h; cam.updateProjectionMatrix(); render();
  };
  new ResizeObserver(resize).observe(stage); resize();
  return { update: render, bbox, info };
}
