# Kamish's Wrath — work log

Tools: Python 3.11, numpy, Pillow, Blender 5.0.1 (headless `bpy` pip module,
plus Debian X/GL runtime libraries installed to make it import), Node 20/Vite.

1. Read the 720x1499 reference; adopted its landmark proportions per dagger.
2. Built a procedural bmesh toolkit: ear-clipped concave solids, prisms,
   zero-thickness single-edge blade lofts, curved fang outlines, instanced
   chevron grip scales, packed per-face UV islands.
3. Iteration 1: pipeline/export validated; guards too small, blades too narrow,
   studio light was clipping the coral to white.
4. Iteration 2: larger guards, wider blades, softer neutral lighting.
5. Iteration 3: guard widths corrected from landmarks (A ~0.09 m, B ~0.13 m);
   grip wrap rebuilt as real overlapping chevron plates.
6. Iteration 4: atlas UV rows were vertically mirrored (faces sampling empty
   texels); fixed. Restored wider blades and calmer guard masses.
7. Iteration 5: simplified the ivory skull, removed crossing spikes, enlarged
   pommels, darkened the engraved emissive strokes to the specified palette.
8. Iteration 6: exact per-dagger overall length normalised to 0.6105 m;
   exported GLB (tangents, embedded textures), re-imported it and audited nodes,
   materials, image links, UVs, triangle count, cameras and lights.
9. Final: plain download page, HTTP byte-for-byte download verification.

Render audit: four neutral studio views (front, back, side, 3/4) in `renders/`.
