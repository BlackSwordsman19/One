"""Small procedural mesh toolkit used to build Kamish's Wrath.

Everything is authored as sharp, triangulated solids.  Parts are accumulated in
a Builder (welded positions, per-face material slots) and handed to Blender as
one mesh object per named part.  UVs are packed per material cell with at least
4 px of padding so the embedded PBR atlas is valid.
"""
from __future__ import annotations

import math
from collections import defaultdict

_UV_CURSOR: dict[str, int] = defaultdict(int)

V = tuple[float, float, float]


def v_add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def v_sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def v_mul(a, s):
    return (a[0] * s, a[1] * s, a[2] * s)


def v_cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def v_len(a):
    return math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2])


def poly_area2(poly):
    return 0.5 * sum(
        poly[i][0] * poly[(i + 1) % len(poly)][1]
        - poly[(i + 1) % len(poly)][0] * poly[i][1]
        for i in range(len(poly))
    )


def _point_in_tri(p, a, b, c, eps=1e-12):
    def sign(p1, p2, p3):
        return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])

    d1 = sign(p, a, b)
    d2 = sign(p, b, c)
    d3 = sign(p, c, a)
    has_neg = (d1 < -eps) or (d2 < -eps) or (d3 < -eps)
    has_pos = (d1 > eps) or (d2 > eps) or (d3 > eps)
    return not (has_neg and has_pos)


def triangulate_polygon(poly):
    """Ear-clip a simple (possibly concave) polygon in 2-D. Returns CCW tris."""
    pts = [tuple(float(v) for v in p[:2]) for p in poly]
    if poly_area2(pts) < 0:
        pts = list(reversed(pts))
    n = len(pts)
    idx = list(range(n))
    tris = []
    guard = 0
    while len(idx) > 3 and guard < 10000:
        guard += 1
        ear_found = False
        m = len(idx)
        for k in range(m):
            i0, i1, i2 = idx[(k - 1) % m], idx[k], idx[(k + 1) % m]
            a, b, c = pts[i0], pts[i1], pts[i2]
            cross = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
            if cross <= 1e-14:
                continue
            if any(
                _point_in_tri(pts[j], a, b, c)
                for j in idx
                if j not in (i0, i1, i2)
            ):
                continue
            tris.append((i0, i1, i2))
            idx.pop(k)
            ear_found = True
            break
        if not ear_found:
            break
    if len(idx) == 3:
        tris.append((idx[0], idx[1], idx[2]))
    elif len(idx) > 3:
        for k in range(1, len(idx) - 1):
            tris.append((idx[0], idx[k], idx[k + 1]))
    return tris


def lerp(a, b, t):
    return a + (b - a) * t


def resample_profile(points, n):
    """Linear resample of a 2-D polyline to n points."""
    seg = []
    total = 0.0
    for i in range(len(points) - 1):
        d = math.dist(points[i], points[i + 1])
        seg.append((total, total + d))
        total += d
    out = []
    for i in range(n):
        t = total * i / (n - 1)
        for j, (s0, s1) in enumerate(seg):
            if t <= s1 + 1e-12:
                u = 0 if s1 == s0 else (t - s0) / (s1 - s0)
                out.append(
                    (
                        lerp(points[j][0], points[j + 1][0], u),
                        lerp(points[j][1], points[j + 1][1], u),
                    )
                )
                break
    return out


class Builder:
    """Accumulates triangles with material names, then creates a Blender mesh."""

    def __init__(self, name):
        self.name = name
        self.verts: list[V] = []
        self.faces: list[tuple[int, int, int]] = []
        self.face_mats: list[str] = []
        self._lookup: dict[tuple[int, int, int], int] = {}
        self.materials: list[str] = []

    def _vert(self, p):
        key = (round(p[0], 7), round(p[1], 7), round(p[2], 7))
        got = self._lookup.get(key)
        if got is None:
            got = len(self.verts)
            self._lookup[key] = got
            self.verts.append((float(p[0]), float(p[1]), float(p[2])))
        return got

    def tri(self, a, b, c, mat):
        if v_len(v_cross(v_sub(b, a), v_sub(c, a))) < 1e-14:
            return
        self.faces.append((self._vert(a), self._vert(b), self._vert(c)))
        self.face_mats.append(mat)
        if mat not in self.materials:
            self.materials.append(mat)

    def quad(self, a, b, c, d, mat):
        self.tri(a, b, c, mat)
        self.tri(a, c, d, mat)

    def poly(self, pts, mat):
        for i, j, k in triangulate_polygon(pts):
            self.tri(pts[i], pts[j], pts[k], mat)

    def prism(self, outline, y_front, y_back, mat, front=None):
        """Extrude a closed XZ polygon between two Y planes."""
        front = front or mat
        fpts = [(x, y_front, z) for x, z in outline]
        bpts = [(x, y_back, z) for x, z in outline]
        tris = triangulate_polygon(outline)
        for i, j, k in tris:
            self.tri(fpts[i], fpts[j], fpts[k], front)
            self.tri(bpts[i], bpts[j], bpts[k], mat)
        n = len(outline)
        for i in range(n):
            j = (i + 1) % n
            self.quad(fpts[i], bpts[i], bpts[j], fpts[j], mat)
        return fpts, bpts

    def plate(self, outline, y, thickness, mat):
        return self.prism(outline, y - thickness * 0.5, y + thickness * 0.5, mat)

    def loft(self, rings, mat, cap_start=True, apex=None, cap_end=True):
        n = len(rings[0])
        for r0, r1 in zip(rings, rings[1:]):
            for i in range(n):
                j = (i + 1) % n
                self.quad(r0[i], r1[i], r1[j], r0[j], mat)
        if cap_start:
            self.poly(list(rings[0]), mat)
        if apex is not None:
            last = rings[-1]
            for i in range(n):
                self.tri(last[i], last[(i + 1) % n], apex, mat)
        elif cap_end:
            self.poly(list(rings[-1]), mat)

    def pyramid(self, base, apex, mat, base_mat=None):
        for i in range(len(base)):
            self.tri(base[i], base[(i + 1) % len(base)], apex, mat)
        for i, j, k in triangulate_polygon([(p[0], p[2]) for p in base]):
            self.tri(base[i], base[k], base[j], base_mat or mat)

    def ribbon(self, points_xz, width, y, thickness, mat):
        """Closed prismatic ribbon following an XZ polyline (engraved linework)."""
        hw = width * 0.5
        for i in range(len(points_xz) - 1):
            x0, z0 = points_xz[i]
            x1, z1 = points_xz[i + 1]
            dx, dz = x1 - x0, z1 - z0
            ln = math.hypot(dx, dz) or 1.0
            nx, nz = -dz / ln * hw, dx / ln * hw
            quad = [
                (x0 + nx, z0 + nz),
                (x1 + nx, z1 + nz),
                (x1 - nx, z1 - nz),
                (x0 - nx, z0 - nz),
            ]
            self.prism(quad, y - thickness * 0.5, y + thickness * 0.5, mat)

    def cylinder(self, z0, z1, r0, r1, sides, mat, rows=5, cap=True, twist=0.0):
        rings = []
        for r in range(rows + 1):
            t = r / rows
            z = lerp(z0, z1, t)
            rad = lerp(r0, r1, t)
            ring = []
            for i in range(sides):
                a = 2 * math.pi * i / sides + twist * t
                ring.append((math.cos(a) * rad, math.sin(a) * rad, z))
            rings.append(ring)
        self.loft(rings, mat, cap_start=cap, cap_end=cap)

    def scale(self, angle, z_top, radius, height, arc, raise_amt, mat, z_axis=0.0):
        """One overlapping fish-scale chevron: a real pentagonal plate with a
        V-notch top, raised proud of the grip and tapering to a sharp point."""

        def cp(a, z, rad):
            return (math.cos(a) * rad, math.sin(a) * rad, z + z_axis)

        outline = [
            (-arc * 0.50, 0.00),
            (-arc * 0.24, -0.14),
            (0.0, 0.00),
            (arc * 0.24, -0.14),
            (arc * 0.50, 0.00),
            (arc * 0.26, -0.58),
            (0.0, -1.00),
            (-arc * 0.26, -0.58),
        ]
        outer = [cp(angle + a, z_top + t * height, radius + raise_amt) for a, t in outline]
        inner = [cp(angle + a, z_top + t * height, radius - 0.0006) for a, t in outline]
        self.poly(outer, mat)
        self.poly(list(reversed(inner)), mat)
        n = len(outline)
        for i in range(n):
            j = (i + 1) % n
            self.quad(inner[i], inner[j], outer[j], outer[i], mat)

    def finish(self, uv_regions: dict[str, list[tuple[float, float]]], atlas_cols=4, atlas_rows=4):
        """Create a mesh object; per-face UVs packed inside per-material atlas cells.

        uv_regions maps each material name to one or two (col,row) atlas cells.
        Every triangle receives its own padded sub-cell, so UVs never overlap.
        """
        import bpy
        import bmesh

        mesh = bpy.data.meshes.new(self.name)
        mesh.from_pydata(self.verts, [], self.faces)
        mesh.update()

        mats = []
        for m in self.materials:
            mat = bpy.data.materials.get(m)
            if mat is None:
                raise RuntimeError(f"material missing: {m}")
            mats.append(mat)
            mesh.materials.append(mat)
        slot = {m: i for i, m in enumerate(self.materials)}
        for p, fm in zip(mesh.polygons, self.face_mats):
            p.material_index = slot[fm]
            p.use_smooth = False

        bm = bmesh.new()
        bm.from_mesh(mesh)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.to_mesh(mesh)
        bm.free()

        uv = mesh.uv_layers.new(name="UVMap")
        # Global, overlap-free allocation: every face of every mesh gets its own
        # padded sub-cell inside its material region.  32x32 sub-cells per 512 px
        # region => 16 px cells and >= 4 px gutters at 2048 px.
        cells = 56
        per_region = cells * cells
        for poly, fm in zip(mesh.polygons, self.face_mats):
            regions = uv_regions[fm]
            k = _UV_CURSOR[fm]
            _UV_CURSOR[fm] += 1
            region_i = k // per_region
            if region_i >= len(regions):
                raise RuntimeError(
                    f"UV atlas overflow: material {fm} needs region {region_i + 1}; "
                    f"faces={k + 1}, regions={len(regions)}"
                )
            local = k % per_region
            cx, cy = local % cells, local // cells
            col, row = regions[region_i]
            u0 = col / atlas_cols
            v0 = (atlas_rows - 1 - row) / atlas_rows
            cw = 1.0 / (atlas_cols * cells)
            ch = 1.0 / (atlas_rows * cells)
            tri = ((0.28, 0.28), (0.72, 0.28), (0.50, 0.72))
            for lid, uv_c in zip(mesh.polygons[poly.index].loop_indices, tri):
                uv.data[lid].uv = (u0 + (cx + uv_c[0]) * cw, v0 + (cy + uv_c[1]) * ch)
        obj = bpy.data.objects.new(self.name, mesh)
        bpy.context.collection.objects.link(obj)
        return obj


def catmull_rom(points, samples):
    """Smooth a small list of control points into a polyline."""
    if len(points) < 3:
        return resample_profile(points, samples)
    ext = [points[0]] + list(points) + [points[-1]]
    out = []
    for i in range(len(points) - 1):
        p0, p1, p2, p3 = ext[i], ext[i + 1], ext[i + 2], ext[i + 3]
        n = samples // (len(points) - 1)
        for j in range(n):
            t = j / n
            t2, t3 = t * t, t * t * t
            x = 0.5 * (
                2 * p1[0]
                + (-p0[0] + p2[0]) * t
                + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2
                + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3
            )
            z = 0.5 * (
                2 * p1[1]
                + (-p0[1] + p2[1]) * t
                + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2
                + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3
            )
            out.append((x, z))
    out.append(points[-1])
    return out
