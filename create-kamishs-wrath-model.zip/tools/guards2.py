"""Final guard geometry for Kamish's Wrath (iteration 6).

Design language taken from the artwork, not from any third-party 3D asset:
  A: a single near-black organic shield hugging the blade heel, with two thin
     talon wings that follow the blade, two long prongs beside the grip, a few
     crisp chips and a raised plate carrying the emissive dragon-tiger mask.
  B: one coherent ivory dragon-skull mass with a heavy brow, deep eye socket,
     a jaw that steps down into a fang fan, blunt horns and one large smooth
     coral hook sweeping away from the blade.
Everything is flat shaded; all tips/notches are single welded vertices.
"""
from __future__ import annotations

import math

from daggers import fang
from meshkit import Builder


def _shell(b, outline, depth, mat, y0=-0.0125, y1=0.0125, back_scale=0.86,
           back_offset=0.145):
    """Main mass + a slightly smaller rear layer for real thickness."""
    b.prism(outline, y0, y1, mat)
    rear = [(x * back_scale, back_offset + (z - back_offset) * 0.90) for x, z in outline]
    b.prism(rear, y1 - 0.002, y1 + depth, mat)


# ------------------------------------------------------------------ DAGGER A
def guard_A():
    b = Builder("Guard")
    black = "M_Guard_Black"
    red = "M_Guard_BlackEmissive"

    # smooth, scalloped obsidian shield (broad mid, flared jaw, chipped crown)
    shield = [
        (-0.026, 0.024), (-0.036, 0.042), (-0.031, 0.062), (-0.043, 0.076),
        (-0.034, 0.096), (-0.045, 0.110), (-0.036, 0.128), (-0.046, 0.144),
        (-0.036, 0.160), (-0.044, 0.178), (-0.032, 0.190), (-0.038, 0.212),
        (-0.026, 0.220), (-0.030, 0.242), (-0.017, 0.236), (-0.016, 0.264),
        (-0.014, 0.226), (0.000, 0.252), (0.006, 0.218), (0.019, 0.238),
        (0.017, 0.208), (0.030, 0.222), (0.028, 0.200), (0.040, 0.207),
        (0.032, 0.190), (0.043, 0.176), (0.033, 0.160), (0.043, 0.143),
        (0.031, 0.131), (0.039, 0.112), (0.026, 0.104), (0.032, 0.080),
        (0.017, 0.084), (0.022, 0.055), (0.008, 0.064), (0.012, 0.032),
        (0.000, 0.052), (-0.010, 0.026), (-0.016, 0.056), (-0.027, 0.046),
    ]
    _shell(b, shield, 0.0095, black, -0.0125, 0.0125, 0.84, 0.135)

    # broad raised faceplate for the engraving
    face = [
        (-0.026, 0.230), (-0.012, 0.242), (0.000, 0.226), (0.013, 0.239),
        (0.025, 0.222), (0.029, 0.198), (0.020, 0.182), (0.030, 0.166),
        (0.019, 0.152), (0.026, 0.132), (0.012, 0.126), (0.016, 0.098),
        (0.002, 0.106), (-0.004, 0.080), (-0.016, 0.096), (-0.027, 0.086),
        (-0.025, 0.112), (-0.036, 0.124), (-0.027, 0.140), (-0.037, 0.156),
        (-0.026, 0.172), (-0.033, 0.192), (-0.023, 0.206), (-0.029, 0.224),
    ]
    b.prism(face, -0.0200, -0.0080, black)
    ridge = [(-0.003, 0.224), (0.007, 0.226), (0.012, 0.186), (0.005, 0.150),
             (0.008, 0.112), (-0.001, 0.098), (-0.008, 0.128), (-0.006, 0.168),
             (-0.010, 0.200)]
    b.prism(ridge, -0.0246, -0.0188, black)

    # two thin talon wings that follow the blade (not crossing it)
    fang(b, (-0.026, 0.238), (-0.045, 0.342), 0.017, 0.013, black,
         yf=-0.0175, yb=0.0110, relief=False)
    fang(b, (-0.033, 0.206), (-0.047, 0.288), 0.013, 0.010, black,
         yf=-0.0160, yb=0.0105, relief=False)
    fang(b, (0.024, 0.230), (0.036, 0.310), 0.014, -0.010, black,
         yf=-0.0168, yb=0.0105, relief=False)
    # long jaw prongs running down beside the grip
    fang(b, (-0.033, 0.070), (-0.037, -0.014), 0.016, 0.004, black,
         yf=-0.0180, yb=0.0098, relief=False)
    fang(b, (0.031, 0.066), (0.034, -0.008), 0.013, -0.003, black,
         yf=-0.0172, yb=0.0098, relief=False)
    # a couple of crisp outward chips only
    fang(b, (-0.044, 0.168), (-0.054, 0.178), 0.011, 0.002, black,
         yf=-0.0118, yb=0.0090, relief=False)
    fang(b, (0.041, 0.150), (0.051, 0.160), 0.010, -0.002, black,
         yf=-0.0116, yb=0.0090, relief=False)

    b.cylinder(0.054, 0.080, 0.0158, 0.0138, 8, black, rows=2)

    # ---- emissive engraved dragon-tiger mask (front of the faceplate) ----
    y = -0.0216
    strokes = [
        # brows sweeping to the crown
        [(-0.029, 0.204), (-0.019, 0.216), (-0.008, 0.206), (0.001, 0.197)],
        [(0.030, 0.206), (0.020, 0.217), (0.009, 0.207), (0.001, 0.198)],
        # eyes (sharp angular lids)
        [(-0.023, 0.187), (-0.014, 0.193), (-0.005, 0.186), (-0.014, 0.179)],
        [(0.024, 0.188), (0.015, 0.194), (0.006, 0.186), (0.015, 0.180)],
        # crown jewel
        [(0.001, 0.217), (-0.0040, 0.223), (0.001, 0.229), (0.0060, 0.223), (0.001, 0.217)],
        # nose bridge
        [(0.001, 0.198), (0.004, 0.176), (-0.001, 0.158), (0.002, 0.142)],
        # whisker curls
        [(-0.001, 0.159), (-0.012, 0.150), (-0.023, 0.156), (-0.030, 0.146)],
        [(0.003, 0.159), (0.014, 0.150), (0.025, 0.155), (0.031, 0.145)],
        # jaw fangs
        [(-0.014, 0.139), (-0.020, 0.129), (-0.012, 0.122)],
        [(0.016, 0.139), (0.021, 0.128), (0.013, 0.121)],
        # temple curls
        [(-0.033, 0.214), (-0.040, 0.206), (-0.035, 0.196)],
        [(0.034, 0.215), (0.041, 0.206), (0.036, 0.195)],
        # lower jaw contour
        [(-0.021, 0.114), (-0.012, 0.106), (-0.002, 0.111)],
        [(0.022, 0.113), (0.013, 0.105), (0.003, 0.110)],
    ]
    for pts in strokes:
        b.ribbon(pts, 0.0012, y, 0.0010, red)
    return b


# ------------------------------------------------------------------ DAGGER B
def guard_B():
    b = Builder("Guard")
    ivory = "M_Guard_Ivory"
    coral = "M_Blade_Coral"
    black = "M_Guard_Black"

    # one coherent skull mass, cream bone plates, chipped jaw toward the blade
    skull = [
        (-0.024, 0.302), (-0.010, 0.314), (0.004, 0.300), (0.019, 0.311),
        (0.032, 0.292), (0.028, 0.270), (0.041, 0.256), (0.033, 0.234),
        (0.044, 0.220), (0.032, 0.200), (0.040, 0.180), (0.027, 0.172),
        (0.032, 0.146), (0.018, 0.152), (0.023, 0.122), (0.009, 0.132),
        (0.012, 0.100), (-0.001, 0.114), (-0.002, 0.080), (-0.013, 0.096),
        (-0.019, 0.066), (-0.028, 0.086), (-0.036, 0.070), (-0.038, 0.100),
        (-0.049, 0.094), (-0.045, 0.122), (-0.056, 0.128), (-0.047, 0.152),
        (-0.057, 0.164), (-0.046, 0.184), (-0.056, 0.198), (-0.044, 0.214),
        (-0.052, 0.232), (-0.039, 0.242), (-0.045, 0.264), (-0.033, 0.272),
        (-0.036, 0.292),
    ]
    _shell(b, skull, 0.0115, ivory, -0.0205, 0.0205, 0.88, 0.170)

    # raised brow / cheek plate with a sharp centre V
    plate = [
        (-0.040, 0.266), (-0.021, 0.281), (-0.002, 0.264), (0.016, 0.276),
        (0.030, 0.258), (0.024, 0.236), (0.033, 0.220), (0.021, 0.204),
        (0.027, 0.182), (0.014, 0.176), (0.015, 0.150), (0.001, 0.160),
        (-0.009, 0.134), (-0.021, 0.158), (-0.033, 0.150), (-0.031, 0.176),
        (-0.042, 0.190), (-0.033, 0.206), (-0.043, 0.222), (-0.034, 0.238),
        (-0.042, 0.252),
    ]
    b.prism(plate, -0.0335, -0.0170, ivory)
    snout = [
        (-0.012, 0.200), (0.012, 0.198), (0.017, 0.160), (0.008, 0.126),
        (0.000, 0.100), (-0.008, 0.130), (-0.014, 0.160),
    ]
    b.prism(snout, -0.0405, -0.0315, ivory)

    # deep eye socket with a hard bony rim
    cx, cz = -0.020, 0.224
    outer, inner = 0.0150, 0.0058
    for i in range(9):
        a0 = 2 * math.pi * i / 9
        a1 = 2 * math.pi * (i + 1) / 9
        p = [
            (cx + math.cos(a0) * outer, cz + math.sin(a0) * outer * 0.88),
            (cx + math.cos(a1) * outer, cz + math.sin(a1) * outer * 0.88),
            (cx + math.cos(a1) * inner, cz + math.sin(a1) * inner * 0.88),
            (cx + math.cos(a0) * inner, cz + math.sin(a0) * inner * 0.88),
        ]
        b.prism(p, -0.0450, -0.0300, ivory)
    socket = [(cx + math.cos(2 * math.pi * i / 12) * 0.0068,
               cz + math.sin(2 * math.pi * i / 12) * 0.0054) for i in range(12)]
    b.prism(socket, -0.0340, -0.0040, black)

    # blunt horns: one up-left, one down-right
    fang(b, (-0.030, 0.280), (-0.072, 0.296), 0.034, -0.008, ivory,
         yf=-0.0235, yb=0.0095, relief=False)
    fang(b, (0.032, 0.196), (0.074, 0.170), 0.034, -0.010, ivory,
         yf=-0.0285, yb=0.0105, relief=False)

    # jaw fan: four large bone fangs toward the blade, layered in depth
    fangs = [
        (-0.026, 0.118, 0.046, 0.032),
        (-0.005, 0.108, 0.054, 0.033),
        (0.016, 0.122, 0.038, 0.026),
    ]
    for i, (fx, fz, drop, fw) in enumerate(fangs):
        fang(b, (fx, fz), (fx + 0.005, fz - drop), fw, 0.005, ivory,
             yf=-0.0262 - i * 0.0012, yb=0.0130, relief=False)
    # small coral crest and one large smooth coral hook
    crest = [
        (-0.014, 0.250), (0.000, 0.266), (0.014, 0.250), (0.010, 0.228),
        (-0.001, 0.216), (-0.010, 0.232),
    ]
    b.prism(crest, -0.0420, -0.0300, coral)
    fin = [
        (-0.042, 0.134), (-0.066, 0.148), (-0.090, 0.142), (-0.110, 0.122),
        (-0.130, 0.094), (-0.144, 0.056), (-0.126, 0.066), (-0.114, 0.038),
        (-0.104, 0.070), (-0.086, 0.060), (-0.076, 0.090), (-0.056, 0.084),
    ]
    b.prism(fin, -0.0145, 0.0145, coral)
    b.prism([(x * 0.64 - 0.004, 0.096 + (z - 0.096) * 0.80) for x, z in fin],
            -0.0210, -0.0125, coral)

    b.cylinder(0.030, 0.058, 0.0198, 0.0174, 8, ivory, rows=2)
    return b
