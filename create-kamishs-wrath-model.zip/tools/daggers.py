"""Geometry for the two Kamish's Wrath daggers.

Local space for each dagger: grip centre at origin, +Z toward the tip, -Y
toward the viewer.  Proportions are taken from the reference landmarks, with
the guard overlapping the heel of the blade exactly as it does in the artwork.

    Dagger A (slim, black guard) : 0.611 m, guard z 0.02..0.29
    Dagger B (thick, ivory guard): 0.612 m, guard z 0.03..0.31

Cutting edges are true zero-thickness triangle strips; every horn, fang and
notch terminates in a single welded vertex and is flat shaded.
"""
from __future__ import annotations

import math

from meshkit import Builder, lerp


def interp_profile(profile, s):
    if s <= profile[0][0]:
        return profile[0][1]
    for (s0, v0), (s1, v1) in zip(profile, profile[1:]):
        if s <= s1:
            t = (s - s0) / max(1e-9, s1 - s0)
            return lerp(v0, v1, t)
    return profile[-1][1]


def _bez2(p0, p1, p2, t):
    u = 1 - t
    return (u * u * p0[0] + 2 * u * t * p1[0] + t * t * p2[0],
            u * u * p0[1] + 2 * u * t * p1[1] + t * t * p2[1])


def fang_outline(base, tip, width, bow=0.0, n=7):
    bx, bz = base
    tx, tz = tip
    dx, dz = tx - bx, tz - bz
    ln = math.hypot(dx, dz) or 1.0
    nx, nz = -dz / ln, dx / ln
    mid = ((bx + tx) * 0.5 + nx * bow, (bz + tz) * 0.5 + nz * bow)
    left, right = [], []
    for i in range(n):
        t = i / n
        cx, cz = _bez2(base, mid, tip, t)
        w = width * 0.5 * (1.0 - t) ** 0.82
        left.append((cx + nx * w, cz + nz * w))
        right.append((cx - nx * w, cz - nz * w))
    return left + [tip] + list(reversed(right))


def fang(b, base, tip, width, bow, mat, yf=-0.020, yb=0.010, relief=True, relief_scale=0.60):
    outline = fang_outline(base, tip, width, bow)
    b.prism(outline, yf, yb, mat)
    if relief:
        cx = sum(p[0] for p in outline) / len(outline)
        cz = sum(p[1] for p in outline) / len(outline)
        inner = [(cx + (x - cx) * relief_scale, cz + (z - cz) * 0.9) for x, z in outline]
        b.prism(inner, yf - 0.0050, yf - 0.0008, mat)


def blade_ring(z, xc, w, t, edge_extra=0.0, spine_extra=0.0):
    """Sharp single-edged cross-section; the cutting edge is one vertex line."""
    edge = xc - w * 0.46 - edge_extra
    spine = xc + w * 0.54 + spine_extra
    ridge = xc + w * 0.02
    return [
        (edge, 0.0, z),
        (ridge, -t * 0.50, z),
        (spine, -t * 0.26, z),
        (spine, t * 0.26, z),
        (ridge, t * 0.50, z),
    ]


def face_plate_teeth(x0, x1, z0, z1, teeth, sign=1):
    """Rectangular face plate with a straight top and a saw-tooth lower edge."""
    pts = [(x0, z1), (x1, z1), (x1, z0)]
    n = teeth
    for i in range(n):
        zt = z1 - (z1 - z0) * (i + 1) / (n + 1)
        pts.append((x1 - (x1 - x0) * (i + 0.5) / n, zt + sign * 0.0))
        pts.append((x1 - (x1 - x0) * (i + 1) / n, z0 + (z1 - z0) * 0.10))
    return pts


# ================================================================== DAGGER A ==
A_ROOT, A_TIP = 0.020, 0.4865
A_GRIP_TOP, A_GRIP_BOT = 0.0705, -0.0705
A_POMMEL_BOT = -0.1245


def blade_A():
    """Long, slim, strongly recurved coral blade with a wavy spine near the
    heel and a forward needling tip."""
    b = Builder("Blade")
    mat = "M_Blade_Coral"
    wp = [(0, 0.055), (0.12, 0.053), (0.26, 0.049), (0.40, 0.044),
          (0.54, 0.037), (0.66, 0.031), (0.78, 0.023), (0.88, 0.014),
          (0.95, 0.006), (1, 0.0)]
    tp = [(0, 0.0105), (0.28, 0.0092), (0.55, 0.0070), (0.78, 0.0044),
          (0.92, 0.0020), (1, 0.0004)]
    # forward sweep: the tip ends ~0.07 m to the right of the heel
    xc_prof = [(0, -0.010), (0.20, -0.012), (0.40, 0.000), (0.58, 0.020),
               (0.76, 0.048), (0.90, 0.068), (1, 0.076)]
    rings = []
    N = 38
    for i in range(N):
        s = i / (N - 1)
        z = lerp(A_ROOT, A_TIP, s)
        xc = interp_profile(xc_prof, s)
        w = interp_profile(wp, s)
        t = interp_profile(tp, s)
        # stepped notches on the spine, forward spur and heel scallops on the edge
        sp = {0.55: 0.0055, 0.59: 0.0010, 0.63: 0.0045, 0.67: 0.0010,
              0.72: 0.0032, 0.77: 0.0010, 0.82: 0.0020}.get(round(s, 2), 0.0)
        es = {0.38: 0.0050, 0.45: 0.0010, 0.52: 0.0028}.get(round(s, 2), 0.0)
        rings.append(blade_ring(z, xc, w, t, es, sp))
    apex = (rings[-1][0][0] + 0.0008, 0.0, A_TIP)
    b.loft(rings, mat, cap_start=True, apex=apex, cap_end=False)
    return b


def guard_A():
    """One compact near-black organic mass, ~26 cm tall, wrapping the blade heel
    and splitting into talons around the grip.  Two blade-hugging wings, a
    raised carved skull face and emissive dragon-tiger linework."""
    b = Builder("Guard")
    black = "M_Guard_Black"
    red = "M_Guard_BlackEmissive"

    outline = [
        (-0.012, 0.020), (-0.031, -0.020), (-0.032, 0.045), (-0.049, 0.050),
        (-0.042, 0.080), (-0.058, 0.088), (-0.045, 0.108), (-0.060, 0.122),
        (-0.044, 0.140), (-0.057, 0.158), (-0.041, 0.172), (-0.053, 0.190),
        (-0.035, 0.198), (-0.045, 0.220), (-0.028, 0.226), (-0.032, 0.250),
        (-0.016, 0.248), (-0.017, 0.284), (-0.002, 0.264), (0.016, 0.288),
        (0.024, 0.252), (0.038, 0.260), (0.031, 0.232), (0.046, 0.226),
        (0.034, 0.202), (0.052, 0.194), (0.039, 0.174), (0.056, 0.160),
        (0.042, 0.142), (0.052, 0.124), (0.037, 0.114), (0.047, 0.094),
        (0.031, 0.090), (0.037, 0.060), (0.020, 0.064), (0.029, 0.024),
        (0.012, 0.052), (0.004, 0.016), (-0.004, 0.052),
    ]
    b.prism(outline, -0.0130, 0.0130, black)
    back = [(x * 0.80, 0.14 + (z - 0.14) * 0.88) for x, z in outline]
    b.prism(back, 0.0105, 0.0205, black)

    # broad central faceted growth, widest beside the blade heel
    face = [
        (-0.030, 0.268), (-0.016, 0.278), (-0.005, 0.260), (0.009, 0.276),
        (0.024, 0.262), (0.030, 0.234), (0.040, 0.220), (0.031, 0.198),
        (0.042, 0.180), (0.030, 0.162), (0.037, 0.140), (0.024, 0.132),
        (0.028, 0.104), (0.012, 0.104), (0.008, 0.078), (-0.006, 0.094),
        (-0.018, 0.076), (-0.026, 0.100), (-0.039, 0.108), (-0.032, 0.132),
        (-0.045, 0.146), (-0.034, 0.164), (-0.043, 0.184), (-0.032, 0.202),
        (-0.041, 0.220), (-0.032, 0.234), (-0.037, 0.252),
    ]
    b.prism(face, -0.0205, -0.0080, black)
    # crisp centre crease catching a faceted highlight
    crest = [(-0.006, 0.260), (0.006, 0.262), (0.012, 0.200), (0.004, 0.150),
             (-0.004, 0.104), (-0.010, 0.152), (-0.012, 0.204)]
    b.prism(crest, -0.0245, -0.0190, black)

    # long blade-hugging wings
    fang(b, (-0.019, 0.250), (-0.034, 0.340), 0.021, 0.008, black,
         yf=-0.0200, yb=0.0120)
    fang(b, (0.017, 0.248), (0.031, 0.326), 0.018, -0.006, black,
         yf=-0.0190, yb=0.0120)
    fang(b, (-0.026, 0.226), (-0.028, 0.286), 0.011, 0.004, black,
         yf=-0.0160, yb=0.0110, relief=False)
    # jaw talons framing the grip
    fang(b, (-0.032, 0.056), (-0.038, -0.018), 0.017, 0.004, black,
         yf=-0.0195, yb=0.0100)
    fang(b, (0.031, 0.058), (0.036, -0.010), 0.015, -0.004, black,
         yf=-0.0185, yb=0.0100)
    # outer side horns
    fang(b, (-0.047, 0.120), (-0.069, 0.132), 0.015, 0.003, black,
         yf=-0.0140, yb=0.0090, relief=False)
    fang(b, (0.045, 0.150), (0.067, 0.160), 0.014, -0.003, black,
         yf=-0.0135, yb=0.0090, relief=False)
    fang(b, (-0.044, 0.192), (-0.062, 0.208), 0.011, 0.002, black,
         yf=-0.0130, yb=0.0090, relief=False)

    b.cylinder(0.048, 0.082, 0.0175, 0.0150, 8, black, rows=2)

    # engraved emissive dragon / tiger mask on the raised face plate
    y = -0.0222
    strokes = [
        [(-0.024, 0.242), (-0.017, 0.252), (-0.008, 0.244)],
        [(0.026, 0.244), (0.018, 0.252), (0.009, 0.245)],
        [(-0.022, 0.228), (-0.014, 0.233), (-0.006, 0.227), (-0.013, 0.221)],
        [(0.024, 0.229), (0.016, 0.234), (0.008, 0.226), (0.015, 0.220)],
        [(0.001, 0.257), (-0.004, 0.263), (0.001, 0.269), (0.006, 0.263), (0.001, 0.257)],
        [(0.001, 0.244), (0.004, 0.222), (-0.001, 0.204), (0.003, 0.190)],
        [(-0.001, 0.206), (-0.012, 0.198), (-0.023, 0.204), (-0.030, 0.194)],
        [(0.004, 0.206), (0.015, 0.198), (0.026, 0.203), (0.032, 0.192)],
        [(-0.014, 0.186), (-0.019, 0.177), (-0.011, 0.171)],
        [(0.015, 0.186), (0.020, 0.176), (0.012, 0.170)],
        [(-0.030, 0.215), (-0.037, 0.207), (-0.032, 0.196)],
        [(0.030, 0.216), (0.038, 0.206), (0.033, 0.195)],
        [(-0.024, 0.158), (-0.014, 0.151), (-0.002, 0.156)],
        [(0.025, 0.156), (0.015, 0.149), (0.003, 0.154)],
    ]
    for pts in strokes:
        b.ribbon(pts, 0.00125, y, 0.0012, red)
    b.pyramid(
        [(-0.0025, y - 0.0003, 0.190), (0.0025, y - 0.0003, 0.190),
         (0.0025, y - 0.0003, 0.196), (-0.0025, y - 0.0003, 0.196)],
        (0.000, y - 0.0030, 0.194), red,
    )
    return b


def grip_A():
    b = Builder("Grip")
    mat = "M_Grip_BlueGrey"
    z0, z1, r0, r1 = A_GRIP_BOT, A_GRIP_TOP, 0.0122, 0.0138
    b.cylinder(z0, z1, r0, r1, 10, mat, rows=6, cap=True)

    def rad(z):
        return lerp(r0, r1, (z - z0) / (z1 - z0))

    for phase, twist in ((0.0, 0.30), (math.pi / 5, -0.30)):
        for row in range(6):
            zt = lerp(z0 + 0.004, z1 + 0.006, row / 5)
            for col in range(5):
                a = 2 * math.pi * (col + phase) / 5 + row * twist
                b.scale(a, zt, rad(zt) + 0.0003, 0.0300, 0.92, 0.0022, mat)
    return b


def pommel_A():
    b = Builder("Pommel")
    black = "M_Guard_Black"
    coral = "M_Pommel_Coral"
    b.cylinder(-0.0790, -0.0660, 0.0130, 0.0118, 9, black, rows=1)
    flame = [
        (-0.0125, -0.0690), (0.0125, -0.0690), (0.0200, -0.0830), (0.0105, -0.0935),
        (0.0165, -0.1045), (0.0060, -0.0990), (0.0035, -0.1270), (-0.0045, -0.1035),
        (-0.0110, -0.1215), (-0.0130, -0.0985), (-0.0205, -0.1095), (-0.0195, -0.0925),
        (-0.0205, -0.0815),
    ]
    b.prism(flame, -0.0065, 0.0065, coral)
    inner = [
        (-0.0065, -0.0710), (0.0065, -0.0710), (0.0100, -0.0830), (0.0035, -0.0920),
        (0.0050, -0.1030), (0.0000, -0.0965), (-0.0045, -0.1075), (-0.0060, -0.0920),
        (-0.0095, -0.0825),
    ]
    b.prism(inner, -0.0090, -0.0050, coral)
    leaf = [(-0.0150, -0.0820), (-0.0230, -0.0900), (-0.0200, -0.1000), (-0.0130, -0.0930)]
    b.prism(leaf, -0.0040, 0.0040, coral)
    return b


# ================================================================== DAGGER B ==
B_ROOT, B_TIP = 0.020, 0.5430
B_GRIP_TOP, B_GRIP_BOT = 0.048, -0.048
B_POMMEL_BOT = -0.0690


def blade_B():
    """Broader, thicker blade: deep spine wave rising into a backward hook then
    a long forward sweep to the needle point."""
    b = Builder("Blade")
    mat = "M_Blade_Coral"
    wp = [(0, 0.096), (0.18, 0.094), (0.34, 0.088), (0.50, 0.079),
          (0.62, 0.068), (0.74, 0.054), (0.85, 0.036), (0.94, 0.017), (1, 0.0)]
    tp = [(0, 0.0225), (0.26, 0.0200), (0.52, 0.0160), (0.76, 0.0095),
          (0.92, 0.0040), (1, 0.0007)]
    xc_prof = [(0, 0.000), (0.25, -0.008), (0.45, -0.010), (0.65, -0.006),
               (0.82, 0.000), (0.95, 0.004), (1, 0.005)]
    rings = []
    N = 36
    for i in range(N):
        s = i / (N - 1)
        z = lerp(B_ROOT, B_TIP, s)
        xc = interp_profile(xc_prof, s)
        w = interp_profile(wp, s)
        t = interp_profile(tp, s)
        sp = 0.0
        if 0.18 < s < 0.44:
            sp = 0.0135 * math.sin((s - 0.18) / 0.26 * math.pi) ** 0.7
        elif 0.44 < s < 0.62:
            sp = -0.0045 * math.sin((s - 0.44) / 0.18 * math.pi)
        es = {0.52: 0.0045, 0.58: 0.0012, 0.64: 0.0028}.get(round(s, 2), 0.0)
        rings.append(blade_ring(z, xc, w, t, es, sp))
    apex = (rings[-1][0][0] - 0.0010, 0.0, B_TIP)
    b.loft(rings, mat, cap_start=True, apex=apex, cap_end=False)

    # razor fin row on the spine immediately above the guard
    for s, out, h in ((0.53, 0.026, 0.026), (0.58, 0.031, 0.030),
                      (0.63, 0.025, 0.025), (0.68, 0.019, 0.021)):
        z = lerp(B_ROOT, B_TIP, s)
        xc = interp_profile(xc_prof, s)
        w = interp_profile(wp, s)
        sp = 0.0
        if 0.18 < s < 0.44:
            sp = 0.0135 * math.sin((s - 0.18) / 0.26 * math.pi) ** 0.7
        elif 0.44 < s < 0.62:
            sp = -0.0045 * math.sin((s - 0.44) / 0.18 * math.pi)
        spine = xc + w * 0.54 + sp
        b.pyramid(
            [(spine - 0.004, -0.0040, z - 0.007), (spine + 0.005, -0.0015, z - 0.002),
             (spine + 0.005, 0.0015, z - 0.002), (spine - 0.004, 0.0040, z - 0.007)],
            (spine + out, 0.0, z + h), mat,
        )
    return b


def guard_B():
    """Very large ivory-cream dragon-skull guard, ~28 cm tall: chunky brow,
    recessed eye socket, blunt horns, layered jaw fangs and a separate coral
    fin/hook.  Canon calls the metal gold; the reference artwork paints it
    ivory, which is what this asset reproduces."""
    b = Builder("Guard")
    ivory = "M_Guard_Ivory"
    coral = "M_Blade_Coral"
    black = "M_Guard_Black"

    outline = [
        (-0.013, 0.310), (-0.033, 0.300), (-0.030, 0.272), (-0.051, 0.280),
        (-0.045, 0.256), (-0.064, 0.250), (-0.051, 0.226), (-0.066, 0.210),
        (-0.049, 0.192), (-0.062, 0.174), (-0.045, 0.158), (-0.058, 0.142),
        (-0.039, 0.134), (-0.054, 0.112), (-0.035, 0.108), (-0.047, 0.080),
        (-0.027, 0.086), (-0.035, 0.044), (-0.017, 0.066), (-0.013, 0.026),
        (-0.002, 0.048), (0.008, 0.018), (0.015, 0.048), (0.026, 0.022),
        (0.028, 0.056), (0.044, 0.040), (0.036, 0.074), (0.052, 0.070),
        (0.041, 0.100), (0.058, 0.108), (0.044, 0.132), (0.061, 0.148),
        (0.046, 0.170), (0.063, 0.186), (0.048, 0.210), (0.062, 0.228),
        (0.048, 0.246), (0.040, 0.272), (0.022, 0.262), (0.020, 0.300),
        (0.001, 0.284),
    ]
    b.prism(outline, -0.0200, 0.0200, ivory)
    back = [(x * 0.84, 0.16 + (z - 0.16) * 0.90) for x, z in outline]
    b.prism(back, 0.0170, 0.0310, ivory)

    # heavy frontal brow plate, sharp V between the brows
    brow = [
        (-0.042, 0.272), (-0.020, 0.290), (0.000, 0.268), (0.020, 0.288),
        (0.042, 0.270), (0.034, 0.244), (0.012, 0.256), (0.000, 0.240),
        (-0.014, 0.256), (-0.033, 0.244),
    ]
    b.prism(brow, -0.0350, -0.0180, ivory)
    # cheek / jaw flange, larger on one side for the dragon skull read
    cheek = [
        (0.002, 0.238), (0.028, 0.252), (0.049, 0.236), (0.055, 0.206),
        (0.042, 0.192), (0.050, 0.168), (0.036, 0.150), (0.040, 0.124),
        (0.024, 0.136), (0.018, 0.108), (0.006, 0.134), (-0.006, 0.112),
        (-0.013, 0.148), (-0.024, 0.162), (-0.019, 0.190), (-0.008, 0.208),
    ]
    b.prism(cheek, -0.0360, -0.0185, ivory)
    bridge = [
        (-0.014, 0.238), (0.012, 0.238), (0.020, 0.200), (0.014, 0.158),
        (0.004, 0.120), (-0.004, 0.158), (-0.011, 0.198),
    ]
    b.prism(bridge, -0.0400, -0.0340, ivory)

    # recessed eye socket with a sharp bony rim
    cx, cz = -0.025, 0.206
    outer, inner = 0.0200, 0.0085
    for i in range(9):
        a0 = 2 * math.pi * i / 9
        a1 = 2 * math.pi * (i + 1) / 9
        p = [
            (cx + math.cos(a0) * outer, cz + math.sin(a0) * outer * 0.82),
            (cx + math.cos(a1) * outer, cz + math.sin(a1) * outer * 0.82),
            (cx + math.cos(a1) * inner, cz + math.sin(a1) * inner * 0.82),
            (cx + math.cos(a0) * inner, cz + math.sin(a0) * inner * 0.82),
        ]
        b.prism(p, -0.0460, -0.0300, ivory)
    socket = [(cx + math.cos(2 * math.pi * i / 12) * 0.0100,
               cz + math.sin(2 * math.pi * i / 12) * 0.0080) for i in range(12)]
    b.prism(socket, -0.0340, -0.0040, black)
    # brow shadow above the socket
    b.prism([(-0.048, 0.222), (-0.030, 0.230), (-0.020, 0.222), (-0.040, 0.216)],
            -0.0380, -0.0260, ivory)

    # large overlapping fangs along the lower jaw
    fangs = [
        (-0.036, 0.084, 0.050, 0.026),
        (-0.014, 0.074, 0.058, 0.027),
        (0.008, 0.080, 0.050, 0.025),
        (0.030, 0.092, 0.042, 0.023),
        (0.044, 0.062, 0.038, 0.019),
        (-0.026, 0.118, 0.034, 0.020),
    ]
    for fx, fz, drop, fw in fangs:
        fang(b, (fx, fz), (fx + 0.004, fz - drop), fw, 0.0, ivory,
             yf=-0.0270, yb=0.0140, relief=True, relief_scale=0.56)
    # blunt forward-swept horns
    fang(b, (-0.048, 0.262), (-0.080, 0.286), 0.030, -0.005, ivory,
         yf=-0.0250, yb=0.0090)
    fang(b, (0.042, 0.258), (0.073, 0.272), 0.026, 0.004, ivory,
         yf=-0.0235, yb=0.0090)

    # ivory blade climbing over the guard toward the grip
    shaft = [
        (-0.016, 0.094), (0.014, 0.094), (0.018, 0.062), (0.011, 0.020),
        (0.002, -0.030), (-0.006, 0.020), (-0.012, 0.060),
    ]
    b.prism(shaft, -0.0210, 0.0110, ivory)
    b.prism([(x * 0.55 + 0.003, 0.040 + (z - 0.040) * 0.85) for x, z in shaft],
            -0.0280, -0.0200, ivory)

    # coral crest between the bone plates and near the blade
    crest = [
        (-0.020, 0.170), (-0.002, 0.198), (0.022, 0.184), (0.031, 0.152),
        (0.017, 0.128), (0.001, 0.150), (-0.011, 0.122), (-0.025, 0.138),
    ]
    b.prism(crest, -0.041, -0.024, coral)
    b.prism([(-0.007, 0.196), (0.007, 0.205), (0.000, 0.222), (-0.011, 0.207)],
            -0.030, -0.014, coral)

    # separate coral fin/hook sweeping away from the skull
    fin = [
        (-0.030, 0.150), (-0.061, 0.166), (-0.094, 0.148), (-0.112, 0.108),
        (-0.094, 0.106), (-0.078, 0.074), (-0.070, 0.108), (-0.050, 0.098),
        (-0.044, 0.130),
    ]
    b.prism(fin, -0.016, 0.016, coral)
    b.prism([(x * 0.64 - 0.003, 0.115 + (z - 0.115) * 0.76) for x, z in fin],
            -0.023, -0.014, coral)
    fin_r = [
        (0.030, 0.120), (0.059, 0.138), (0.080, 0.118), (0.066, 0.090),
        (0.051, 0.100), (0.041, 0.076),
    ]
    b.prism(fin_r, -0.014, 0.014, coral)
    # coral blade lip emerging beside the upper jaw
    lip = [
        (0.019, 0.268), (0.039, 0.282), (0.033, 0.252), (0.048, 0.234),
        (0.026, 0.236), (0.020, 0.214),
    ]
    b.prism(lip, -0.027, -0.014, coral)

    b.cylinder(0.034, 0.064, 0.0210, 0.0185, 8, ivory, rows=2)
    return b


def grip_B():
    b = Builder("Grip")
    mat = "M_Grip_PurpleGrey"
    z0, z1, r0, r1 = B_GRIP_BOT, B_GRIP_TOP, 0.0150, 0.0170
    b.cylinder(z0, z1, r0, r1, 10, mat, rows=5, cap=True)

    def rad(z):
        return lerp(r0, r1, (z - z0) / (z1 - z0))

    for phase, twist in ((0.0, 0.30), (math.pi / 5, -0.30)):
        for row in range(4):
            zt = lerp(z0 + 0.004, z1 + 0.006, row / 3)
            for col in range(5):
                a = 2 * math.pi * (col + phase) / 5 + row * twist
                b.scale(a, zt, rad(zt) + 0.0003, 0.0280, 0.92, 0.0020, mat)
    return b


def pommel_B():
    b = Builder("Pommel")
    black = "M_Guard_Black"
    coral = "M_Pommel_Coral"
    b.cylinder(-0.0570, -0.0470, 0.0140, 0.0128, 9, black, rows=1)
    cap = [
        (-0.0115, -0.0490), (0.0115, -0.0490), (0.0140, -0.0570),
        (0.0185, -0.0660), (0.0310, -0.0635), (0.0230, -0.0710),
        (0.0100, -0.0735), (0.0035, -0.0820), (-0.0060, -0.0735),
        (-0.0140, -0.0660), (-0.0100, -0.0540),
    ]
    b.prism(cap, -0.0075, 0.0075, coral)
    inner = [
        (-0.0050, -0.0515), (0.0050, -0.0515), (0.0065, -0.0620), (0.0015, -0.0700),
        (-0.0045, -0.0665), (-0.0075, -0.0580),
    ]
    b.prism(inner, -0.0100, -0.0055, coral)
    return b


# ================================================================== assemble ==
def build_local_parts():
    # guards refined in guards2.py (imported locally to avoid a circular import)
    from guards2 import guard_A as guard_A2, guard_B as guard_B2

    return {
        "A": {"Blade": blade_A(), "Guard": guard_A2(), "Grip": grip_A(), "Pommel": pommel_A()},
        "B": {"Blade": blade_B(), "Guard": guard_B2(), "Grip": grip_B(), "Pommel": pommel_B()},
    }
