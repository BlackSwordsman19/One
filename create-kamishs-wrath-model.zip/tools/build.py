"""Build, materialise, export, render and audit Kamish's Wrath.

Run with: python3 tools/build.py
Output:   Kamishs_Wrath.glb  +  neutral studio renders in renders/
"""
from __future__ import annotations

import json
import math
import os
import sys

import bpy
from mathutils import Vector

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from daggers import build_local_parts  # noqa: E402
from textures import P, REGIONS, make_textures  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GLB_PATH = os.path.join(ROOT, "Kamishs_Wrath.glb")
RENDER_DIR = os.path.join(ROOT, "renders")


def srgb_to_linear(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_lin(h):
    h = h.lstrip("#")
    vals = [int(h[i : i + 2], 16) / 255.0 for i in (0, 2, 4)]
    return tuple(srgb_to_linear(v) for v in vals) + (1.0,)


def make_materials(texture_paths):
    imgs = {}
    for k, path in texture_paths.items():
        img = bpy.data.images.load(path, check_existing=True)
        img.name = "KW_" + k
        img.colorspace_settings.name = "sRGB" if k == "base" else "Non-Color"
        imgs[k] = img

    materials = {}
    for name, hexcol in P.items():
        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        nt = mat.node_tree
        nt.nodes.clear()
        out = nt.nodes.new("ShaderNodeOutputMaterial")
        out.location = (620, 0)
        bsdf = nt.nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (300, 0)
        nt.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])

        base = nt.nodes.new("ShaderNodeTexImage")
        base.image = imgs["base"]
        base.interpolation = "Linear"
        base.location = (-420, 240)
        nt.links.new(base.outputs["Color"], bsdf.inputs["Base Color"])

        orm_tex = nt.nodes.new("ShaderNodeTexImage")
        orm_tex.image = imgs["orm"]
        orm_tex.interpolation = "Linear"
        orm_tex.location = (-420, -20)
        sep = nt.nodes.new("ShaderNodeSeparateColor")
        sep.mode = "RGB"
        sep.location = (-120, -20)
        nt.links.new(orm_tex.outputs["Color"], sep.inputs["Color"])
        nt.links.new(sep.outputs["Green"], bsdf.inputs["Roughness"])
        nt.links.new(sep.outputs["Blue"], bsdf.inputs["Metallic"])

        nrm_tex = nt.nodes.new("ShaderNodeTexImage")
        nrm_tex.image = imgs["normal"]
        nrm_tex.interpolation = "Linear"
        nrm_tex.location = (-420, -300)
        nmap = nt.nodes.new("ShaderNodeNormalMap")
        nmap.location = (-120, -300)
        nmap.inputs["Strength"].default_value = 0.35
        nt.links.new(nrm_tex.outputs["Color"], nmap.inputs["Color"])
        nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])

        rough, metal = {
            "M_Blade_Coral": (0.30, 0.85),
            "M_Guard_Black": (0.45, 0.70),
            "M_Guard_BlackEmissive": (0.60, 0.00),
            "M_Guard_Ivory": (0.40, 0.80),
            "M_Grip_BlueGrey": (0.50, 0.80),
            "M_Grip_PurpleGrey": (0.50, 0.80),
            "M_Pommel_Coral": (0.55, 0.60),
        }[name]
        bsdf.inputs["Roughness"].default_value = rough
        bsdf.inputs["Metallic"].default_value = metal
        bsdf.inputs["Base Color"].default_value = hex_lin(hexcol)
        mat.diffuse_color = hex_lin(hexcol)
        mat.metallic = metal
        mat.roughness = rough

        if name == "M_Guard_BlackEmissive":
            col = hex_lin(hexcol)
            if "Emission Color" in bsdf.inputs:
                bsdf.inputs["Emission Color"].default_value = col
            elif "Emission" in bsdf.inputs:
                bsdf.inputs["Emission"].default_value = col
            bsdf.inputs["Emission Strength"].default_value = 0.6
            mat.diffuse_color = col
        materials[name] = mat
    return materials


def make_empty(name, parent=None, location=(0, 0, 0), rotation=(0, 0, 0)):
    ob = bpy.data.objects.new(name, None)
    ob.empty_display_type = "PLAIN_AXES"
    ob.empty_display_size = 0.05
    bpy.context.collection.objects.link(ob)
    if parent:
        ob.parent = parent
    ob.location = location
    ob.rotation_euler = rotation
    return ob


def main():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    os.makedirs(RENDER_DIR, exist_ok=True)
    tex = make_textures(os.path.join(ROOT, "textures"))
    make_materials(tex)

    parts = build_local_parts()
    # normalise each dagger to exactly 0.6105 m along local Z, about the grip centre
    for key, group in parts.items():
        zmin = min(v[2] for bd in group.values() for v in bd.verts)
        zmax = max(v[2] for bd in group.values() for v in bd.verts)
        factor = 0.6105 / (zmax - zmin)
        for bd in group.values():
            bd.verts = [(x * factor, y * factor, z * factor) for x, y, z in bd.verts]
        print("SCALE", key, "extent_before", zmax - zmin, "factor", factor)
    root = make_empty("KamishsWrath")
    daggers = {
        "A": make_empty(
            "KW_Dagger_A_BlackGuard", root,
            location=(-0.075, 0.0, -0.181), rotation=(0.0, math.radians(-8.0), 0.0),
        ),
        "B": make_empty(
            "KW_Dagger_B_GoldGuard", root,
            location=(0.085, 0.0, 0.231), rotation=(0.0, math.radians(172.0), 0.0),
        ),
    }

    objects = {}
    for key, part_builders in parts.items():
        objects[key] = {}
        for part_name, builder in part_builders.items():
            blender_name = part_name if key == "A" else part_name + "_B"
            builder.name = blender_name
            ob = builder.finish(REGIONS)
            ob.parent = daggers[key]
            ob.location = (0, 0, 0)
            ob.rotation_euler = (0, 0, 0)
            ob.scale = (1, 1, 1)
            objects[key][part_name] = ob

    bpy.context.view_layer.update()

    # centre the pair's bounding box exactly on the origin
    mn = Vector((1e9, 1e9, 1e9))
    mx = Vector((-1e9, -1e9, -1e9))
    for key in objects:
        for ob in objects[key].values():
            for v in ob.data.vertices:
                w = ob.matrix_world @ v.co
                for i in range(3):
                    mn[i] = min(mn[i], w[i])
                    mx[i] = max(mx[i], w[i])
    center = (mn + mx) * 0.5
    for key in daggers:
        daggers[key].location.x -= center.x
        daggers[key].location.z -= center.z
    bpy.context.view_layer.update()

    counts = {}
    for key in objects:
        for part_name, ob in objects[key].items():
            counts[f"{key}_{part_name}"] = {
                "verts": len(ob.data.vertices),
                "tris": len(ob.data.polygons),
                "materials": [m.name for m in ob.data.materials],
            }
    total_verts = sum(c["verts"] for c in counts.values())
    total_tris = sum(c["tris"] for c in counts.values())
    print("COUNTS", json.dumps(counts, indent=1))
    print("TOTAL", total_verts, "verts", total_tris, "tris")

    # export only the weapon hierarchy
    bpy.ops.object.select_all(action="DESELECT")
    for ob in [root] + list(daggers.values()) + [o for d in objects.values() for o in d.values()]:
        ob.select_set(True)
    bpy.context.view_layer.objects.active = root
    bpy.ops.export_scene.gltf(
        filepath=GLB_PATH,
        export_format="GLB",
        use_selection=True,
        export_apply=True,
        export_yup=True,
        export_texcoords=True,
        export_normals=True,
        export_tangents=True,
        export_materials="EXPORT",
        export_image_format="AUTO",
        export_cameras=False,
        export_lights=False,
        export_extras=False,
        export_animations=False,
    )
    patch_glb(GLB_PATH)
    print("EXPORTED", GLB_PATH, os.path.getsize(GLB_PATH))

    report = {
        "counts": counts,
        "total_verts_blender": total_verts,
        "total_tris": total_tris,
        "bbox_min": list(mn),
        "bbox_max": list(mx),
        "objects": {
            key: {name: {"type": "MESH", "parent": daggers[key].name} for name in objects[key]}
            for key in objects
        },
        "placement": {
            "A": {"location": list(daggers["A"].location), "rotation_y_deg": -8.0},
            "B": {"location": list(daggers["B"].location), "rotation_y_deg": 172.0},
        },
    }
    with open(os.path.join(ROOT, "tools", "build_report.json"), "w") as f:
        json.dump(report, f, indent=2)

    render_views()
    verify_export()


def patch_glb(path):
    """Rename duplicated part nodes to the exact required mesh names and audit
    the glTF JSON.  Node names may repeat in glTF; indices stay unique."""
    import struct

    with open(path, "rb") as f:
        data = f.read()
    magic, version, length = struct.unpack_from("<III", data, 0)
    assert magic == 0x46546C67 and version == 2
    off = 12
    chunks = []
    while off < length:
        clen, ctype = struct.unpack_from("<II", data, off)
        payload = data[off + 8 : off + 8 + clen]
        chunks.append((ctype, payload))
        off += 8 + clen
    js = json.loads(chunks[0][1].decode("utf-8"))
    for node in js.get("nodes", []):
        name = node.get("name", "")
        if name.endswith("_B"):
            node["name"] = name[:-2]
    for mesh in js.get("meshes", []):
        name = mesh.get("name", "")
        if name.endswith("_B"):
            mesh["name"] = name[:-2]
    if "cameras" in js:
        del js["cameras"]
    js.pop("extensions", None) if js.get("extensions", {}).get("KHR_lights_punctual") else None
    new_json = json.dumps(js, separators=(",", ":")).encode("utf-8")
    pad = (4 - len(new_json) % 4) % 4
    new_json += b" " * pad
    out = [(0x4E4F534A, new_json)]
    for ctype, payload in chunks[1:]:
        out.append((ctype, payload))
    total = 12 + sum(8 + len(p) for _, p in out)
    with open(path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total))
        for ctype, payload in out:
            f.write(struct.pack("<II", len(payload), ctype))
            f.write(payload)
    audit = {
        "nodes": [n.get("name") for n in js.get("nodes", [])],
        "meshes": [m.get("name") for m in js.get("meshes", [])],
        "materials": [m.get("name") for m in js.get("materials", [])],
        "images": [{"name": i.get("name"), "mime": i.get("mimeType"), "uri": i.get("uri")}
                   for i in js.get("images", [])],
        "textures": len(js.get("textures", [])),
        "cameras": len(js.get("cameras", [])),
        "extensions_used": js.get("extensionsUsed", []),
    }
    with open(os.path.join(ROOT, "tools", "glb_audit.json"), "w") as f:
        json.dump(audit, f, indent=2)
    print("GLB JSON", json.dumps(audit, indent=1))


def look_at(ob, target):
    d = Vector(target) - ob.location
    ob.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()


def render_views():
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.device = "CPU"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = True
    scene.render.resolution_x = 620
    scene.render.resolution_y = 940
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.resolution_percentage = 100
    scene.render.film_transparent = False
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "None"
    scene.view_settings.exposure = -0.15

    world = bpy.data.worlds.new("NeutralStudio")
    world.use_nodes = True
    bg = world.node_tree.nodes["Background"]
    bg.inputs[0].default_value = (0.34, 0.34, 0.35, 1.0)
    bg.inputs[1].default_value = 1.0
    scene.world = world

    def area(name, loc, energy, size):
        data = bpy.data.lights.new(name, "AREA")
        data.energy = energy
        data.shape = "DISK"
        data.size = size
        data.color = (1.0, 1.0, 1.0)
        ob = bpy.data.objects.new(name, data)
        bpy.context.collection.objects.link(ob)
        ob.location = loc
        look_at(ob, (0, 0, 0))
        return ob

    area("Key_Neutral", (-1.4, -2.0, 1.9), 95, 3.2)
    area("Fill_Neutral", (1.8, -1.3, 0.2), 40, 2.6)
    area("Rim_Neutral", (0.2, 2.0, 1.2), 55, 2.4)

    cam_data = bpy.data.cameras.new("AuditCam")
    cam = bpy.data.objects.new("AuditCam", cam_data)
    bpy.context.collection.objects.link(cam)
    scene.camera = cam

    views = {
        "front": ((0.0, -3.0, 0.0), "ORTHO"),
        "back": ((0.0, 3.0, 0.0), "ORTHO"),
        "side": ((3.0, 0.0, 0.0), "ORTHO"),
        "three_quarter": ((-1.35, -2.1, 0.62), "PERSP"),
    }
    for name, (loc, kind) in views.items():
        cam.location = loc
        look_at(cam, (0.0, 0.0, 0.0))
        cam.data.type = kind
        if kind == "ORTHO":
            cam.data.ortho_scale = 0.74
        else:
            cam.data.lens = 72
        scene.render.filepath = os.path.join(RENDER_DIR, name + ".png")
        print("RENDERING", name)
        bpy.ops.render.render(write_still=True)
    print("RENDERS COMPLETE")


def verify_export():
    """Re-import the exported GLB into an empty scene and check the spec."""
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=GLB_PATH)
    objects = list(bpy.context.scene.objects)
    meshes = [o for o in objects if o.type == "MESH"]
    cameras = [o for o in objects if o.type == "CAMERA"]
    lights = [o for o in objects if o.type == "LIGHT"]
    roots = [o for o in objects if o.parent is None]
    missing = []
    for ob in meshes:
        if not ob.data.uv_layers:
            missing.append(ob.name + ":no UV")
        for m in ob.data.materials:
            if m and m.use_nodes:
                for n in m.node_tree.nodes:
                    if n.type == "TEX_IMAGE" and n.image is None:
                        missing.append(f"{ob.name}:{m.name}:missing image")
    for ob in meshes:
        ob.data.calc_loop_triangles()
    report = {
        "reimport_objects": sorted(o.name for o in objects),
        "mesh_objects": [o.name for o in meshes],
        "mesh_count": len(meshes),
        "cameras": len(cameras),
        "lights": len(lights),
        "root_objects": [o.name for o in roots],
        "materials": sorted({m.name for o in meshes for m in o.data.materials if m}),
        "images": sorted({i.name for i in bpy.data.images if i.name != "Render Result"}),
        "missing_textures_or_uvs": missing,
        "vertices_reimported": sum(len(o.data.vertices) for o in meshes),
        "triangles_reimported": sum(len(o.data.loop_triangles) for o in meshes),
        "glb_bytes": os.path.getsize(GLB_PATH),
    }
    with open(os.path.join(ROOT, "tools", "verify_report.json"), "w") as f:
        json.dump(report, f, indent=2)
    print("VERIFY", json.dumps(report, indent=1))
    return report


if __name__ == "__main__":
    main()
