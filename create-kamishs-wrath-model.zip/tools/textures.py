"""Procedural PBR atlas for Kamish's Wrath.

1024 x 1024 PNG base-colour + tangent normal + ORM, embedded in the GLB.
Seven material regions in a 4x2 grid.  The atlas is deliberately flat: the
manhwa's hard cel facets are produced by flat-shaded geometry and real
lighting, never painted into albedo.  Geometry supplies the engraving and the
scale wrap; textures carry only the exact palette, fine grain, micro normals
and the specified metallic/roughness values.
"""
from __future__ import annotations

import os

import numpy as np
from PIL import Image, ImageFilter

SIZE = 2048
COLS = 4
ROWS = 4
CW = SIZE // COLS
CH = SIZE // ROWS

P = {
    "M_Blade_Coral": "#F98A7A",
    "M_Guard_Black": "#100609",
    "M_Guard_BlackEmissive": "#FF695E",
    "M_Guard_Ivory": "#E8DDB4",
    "M_Grip_BlueGrey": "#535468",
    "M_Grip_PurpleGrey": "#543347",
    "M_Pommel_Coral": "#F28A87",
}

REGIONS = {
    "M_Blade_Coral": [(0, 0), (0, 1)],
    "M_Guard_Black": [(1, 0), (1, 1)],
    "M_Grip_BlueGrey": [(2, 0)],
    "M_Grip_PurpleGrey": [(3, 0)],
    "M_Guard_Ivory": [(2, 1), (3, 1)],
    "M_Pommel_Coral": [(0, 2)],
    "M_Guard_BlackEmissive": [(1, 2)],
}

PBR = {
    "M_Blade_Coral": (0.30, 0.85),
    "M_Guard_Black": (0.45, 0.70),
    "M_Guard_BlackEmissive": (0.60, 0.00),
    "M_Guard_Ivory": (0.40, 0.80),
    "M_Grip_BlueGrey": (0.50, 0.80),
    "M_Grip_PurpleGrey": (0.50, 0.80),
    "M_Pommel_Coral": (0.55, 0.60),
}

# Additional palette values documented for the report, used for micro-shading
SHADE = {
    "M_Blade_Coral": (188, 74, 64),
    "M_Guard_Black": (75, 22, 27),
    "M_Guard_BlackEmissive": (255, 105, 94),
    "M_Guard_Ivory": (157, 102, 75),
    "M_Grip_BlueGrey": (138, 132, 156),
    "M_Grip_PurpleGrey": (139, 96, 113),
    "M_Pommel_Coral": (162, 77, 85),
}


def hex_rgb(h):
    h = h.lstrip("#")
    return np.array([int(h[i : i + 2], 16) for i in (0, 2, 4)], dtype=np.float32)


def _cell_xy(col, row):
    # row 0 is the TOP row of the image = upper UV band, matching meshkit
    return col * CW, row * CH


def _height(mat, seed):
    rng = np.random.default_rng(seed)
    if mat in ("M_Grip_BlueGrey", "M_Grip_PurpleGrey"):
        # crisp micro scale ridges aligned with the real chevron geometry
        yy, xx = np.mgrid[0:CH, 0:CW]
        h = np.zeros((CH, CW), np.float32)
        for k in range(0, 11):
            zc = k * 24
            chev = np.abs((yy - zc) - 0.45 * np.abs(xx - CW / 2))
            h += np.where(chev < 2.0, 0.85, 0.0)
        h += rng.normal(0, 0.06, (CH, CW))
        return h
    if mat == "M_Guard_Ivory":
        yy, xx = np.mgrid[0:CH, 0:CW]
        h = np.sin(xx / 19.0 + np.sin(yy / 43.0) * 1.4) * 0.20
        h += rng.normal(0, 0.07, (CH, CW))
        return h
    if mat == "M_Blade_Coral":
        yy, xx = np.mgrid[0:CH, 0:CW]
        h = np.sin(yy / 6.0 + xx / 40.0) * 0.10
        h += rng.normal(0, 0.08, (CH, CW))
        return h
    return rng.normal(0, 0.10, (CH, CW))


def _normals(h, strength):
    dx = (np.roll(h, -1, axis=1) - np.roll(h, 1, axis=1)) * 0.5
    dy = (np.roll(h, -1, axis=0) - np.roll(h, 1, axis=0)) * 0.5
    nx, ny, nz = -dx * strength, -dy * strength, np.ones_like(h)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    return np.stack(
        [((nx / ln) * 0.5 + 0.5) * 255, ((ny / ln) * 0.5 + 0.5) * 255,
         ((nz / ln) * 0.5 + 0.5) * 255], axis=-1
    ).clip(0, 255).astype(np.uint8)


def make_textures(outdir="textures"):
    os.makedirs(outdir, exist_ok=True)
    base = np.zeros((SIZE, SIZE, 3), np.float32)
    normal = np.full((SIZE, SIZE, 3), (128, 128, 255), np.uint8)
    orm = np.ones((SIZE, SIZE, 3), np.float32)

    for mat, cells in REGIONS.items():
        rough, metal = PBR[mat]
        for ci, (col, row) in enumerate(cells):
            x0, y0 = _cell_xy(col, row)
            rng = np.random.default_rng(1000 + abs(hash(mat)) % 997 + ci)
            colr = hex_rgb(P[mat])
            # base colour stays within +/-2 codes of the specified palette value
            arr = np.ones((CH, CW, 3), np.float32) * colr
            arr += rng.normal(0, 0.55, (CH, CW, 1))
            if "Grip" in mat:
                # restrained value steps under the real scale geometry
                yy, xx = np.mgrid[0:CH, 0:CW]
                edge = np.abs(((yy % 34) - 0.45 * np.abs(xx - CW / 2)))
                mask = (edge < 1.8)[..., None]
                arr = np.where(mask, arr * 0.80 + hex_rgb("#" + "".join(f"{int(v):02X}" for v in SHADE[mat])) * 0.20, arr)
            elif mat == "M_Guard_Black":
                arr += rng.normal(0, 0.6, (CH, CW, 1))
            elif mat == "M_Guard_Ivory":
                yy, xx = np.mgrid[0:CH, 0:CW]
                tan = (np.sin(xx / 22.0 + yy / 61.0) > 0.72)[..., None]
                arr = np.where(tan, arr * 0.88 + hex_rgb("#9D664B") * 0.12, arr)
            base[y0 : y0 + CH, x0 : x0 + CW] = np.clip(arr, 0, 255)

            h = _height(mat, 7 + abs(hash(mat)) % 1009 + ci)
            normal[y0 : y0 + CH, x0 : x0 + CW] = _normals(h, 0.55 if "Grip" in mat else 0.22)

            g = rough * 255 + rng.normal(0, 0.8, (CH, CW))
            b = metal * 255 + rng.normal(0, 0.8, (CH, CW))
            orm[y0 : y0 + CH, x0 : x0 + CW, 0] = 255
            orm[y0 : y0 + CH, x0 : x0 + CW, 1] = g.clip(0, 255)
            orm[y0 : y0 + CH, x0 : x0 + CW, 2] = b.clip(0, 255)

    paths = {
        "base": os.path.join(outdir, "KW_BaseColor_2048.png"),
        "normal": os.path.join(outdir, "KW_Normal_2048.png"),
        "orm": os.path.join(outdir, "KW_ORM_2048.png"),
    }
    Image.fromarray(np.clip(base, 0, 255).astype(np.uint8), "RGB").filter(
        ImageFilter.GaussianBlur(0.2)
    ).save(paths["base"], optimize=True)
    Image.fromarray(normal, "RGB").save(paths["normal"], optimize=True)
    Image.fromarray(np.clip(orm, 0, 255).astype(np.uint8), "RGB").save(paths["orm"], optimize=True)
    return paths


if __name__ == "__main__":
    print(make_textures())
