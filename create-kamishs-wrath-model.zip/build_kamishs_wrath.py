# =============================================================================
#  KAMISH'S WRATH  —  procedural build pipeline (Blender 3.6 / 4.x)
#  Run inside Blender:   blender -b -P build_kamishs_wrath.py
#  Produces:             Kamishs_Wrath.glb  (+ 4 neutral verification renders)
#
#  Source of truth: the attached manhwa artwork (720x1499 px).
#  LEFT  dagger = A : slimmer blade, BLACK guard, blue-grey grip   (blade up)
#  RIGHT dagger = B : thicker blade, IVORY/GOLD guard, purple grip (blade down)
#
#  Scale decision: 0.61 m overall per dagger (official-replica scale).
# =============================================================================

import bpy, bmesh, math, os, sys
import numpy as np
from mathutils import Vector, Matrix

OUT_DIR   = os.path.dirname(os.path.abspath(__file__)) if "__file__" in globals() else os.getcwd()
GLB_PATH  = os.path.join(OUT_DIR, "Kamishs_Wrath.glb")

# -----------------------------------------------------------------------------
# 0. CLEAN SCENE
# -----------------------------------------------------------------------------
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete()
for block_list in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.objects):
    for b in list(block_list):
        if b.users == 0:
            block_list.remove(b)

# px -> metres for dagger A  (1382 px overall == 0.61 m)
S_A = 0.61 / 1382.0

def P(px, py, ox=207.0, oy=1190.0, s=S_A):
    """artwork px -> dagger-local (x, z); +Z from pommel toward tip."""
    return ((px - ox) * s, (oy - py) * s)

# -----------------------------------------------------------------------------
# 1. MATERIALS  (section 7 palette, exact)
# -----------------------------------------------------------------------------
def hexc(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) / 255.0 for i in (0, 2, 4)) + (1.0,)

def srgb_to_lin(c):
    return tuple((x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4) for x in c[:3]) + (c[3],)

MAT_SPEC = {
    "M_Blade_Coral":        ("F98A7A", 0.85, 0.30, None),
    "M_Guard_Black":        ("100609", 0.70, 0.45, None),
    "M_Guard_BlackEmissive":("FF695E", 0.00, 0.60, 0.6),
    "M_Guard_Ivory":        ("E8DDB4", 0.80, 0.40, None),
    "M_Grip_BlueGrey":      ("535468", 0.80, 0.50, None),
    "M_Grip_PurpleGrey":    ("543347", 0.80, 0.50, None),
    "M_Pommel_Coral":       ("F28A87", 0.60, 0.55, None),
}
materials = {}
for name, (hx, met, rough, emis) in MAT_SPEC.items():
    m = bpy.data.materials.new(name)
    m.use_nodes = True
    bsdf = m.node_tree.nodes["Principled BSDF"]
    lin = srgb_to_lin(hexc(hx))
    bsdf.inputs["Base Color"].default_value = lin
    bsdf.inputs["Metallic"].default_value = met
    bsdf.inputs["Roughness"].default_value = rough
    if emis is not None:
        bsdf.inputs["Emission Color"].default_value = srgb_to_lin(hexc(hx))
        bsdf.inputs["Emission Strength"].default_value = emis
    materials[name] = m

# -----------------------------------------------------------------------------
# 2. PROCEDURAL TEXTURE SET  (1024, numpy -> embedded)
#    Flat cel-shaded look: near-white base with subtle value steps + fine noise
#    so per-material baseColorFactor carries the exact palette.
# -----------------------------------------------------------------------------
TEX_RES = 1024
rng = np.random.default_rng(7)

def make_textures():
    n = TEX_RES
    # subtle large-scale cel value steps + fine surface noise
    base = np.ones((n, n, 3), dtype=np.float32)
    yy, xx = np.mgrid[0:n, 0:n].astype(np.float32) / n
    steps = (np.floor((xx * 6 + yy * 3) * 2.0) % 3) * 0.012
    noise = rng.normal(0, 0.010, (n, n, 3)).astype(np.float32)
    base = np.clip(base - steps[..., None] + noise, 0.0, 1.0)

    # ORM: occlusion=1, roughness mid, metallic 0 (factors live on the BSDF)
    orm = np.ones((n, n, 3), dtype=np.float32)
    orm[..., 1] = 0.5

    # normal: gentle noise bumps, mostly flat (cel look)
    h = rng.normal(0, 1.0, (n, n)).astype(np.float32)
    h = (h + np.roll(h, 1, 0) + np.roll(h, 1, 1)) / 3.0
    gx, gy = np.gradient(h)
    nrm = np.stack([-gx * 0.35, -gy * 0.35, np.ones_like(h)], -1)
    nrm /= np.linalg.norm(nrm, axis=-1, keepdims=True)
    nrm = (nrm * 0.5 + 0.5)

    imgs = {}
    for key, arr, srgb in (("BaseColor", base, True), ("ORM", orm, False), ("Normal", nrm, False)):
        img = bpy.data.images.new(f"KW_{key}", n, n, alpha=False, float_buffer=False)
        if key == "Normal":
            img.colorspace_settings.name = 'Non-Color'
        elif key == "ORM":
            img.colorspace_settings.name = 'Non-Color'
        rgba = np.ones((n, n, 4), dtype=np.float32)
        rgba[..., :3] = arr
        img.pixels.foreach_set(rgba.ravel())
        img.pack()
        imgs[key] = img
    return imgs

TEX = make_textures()

def wire_textures(mat):
    """Attach basecolor(multiply)/normal/ORM to a material's BSDF."""
    if mat.name not in ("M_Blade_Coral", "M_Guard_Black", "M_Guard_Ivory",
                        "M_Grip_BlueGrey", "M_Grip_PurpleGrey", "M_Pommel_Coral"):
        return
    nt = mat.node_tree
    bsdf = nt.nodes["Principled BSDF"]
    out = next(n for n in nt.nodes if n.type == 'OUTPUT_MATERIAL')
    texco = nt.nodes.new('ShaderNodeTexCoord'); texco.location = (-1100, 0)
    bc = nt.nodes.new('ShaderNodeTexImage'); bc.image = TEX["BaseColor"]; bc.location = (-800, 300)
    nt.links.new(texco.outputs["UV"], bc.inputs["Vector"])
    nt.links.new(bc.outputs["Color"], bsdf.inputs["Base Color"])
    orm = nt.nodes.new('ShaderNodeTexImage'); orm.image = TEX["ORM"]; orm.location = (-800, 0)
    nt.links.new(texco.outputs["UV"], orm.inputs["Vector"])
    sep = nt.nodes.new('ShaderNodeSeparateColor'); sep.location = (-520, 0)
    nt.links.new(orm.outputs["Color"], sep.inputs["Color"])
    nt.links.new(sep.outputs["Green"], bsdf.inputs["Roughness"])
    nt.links.new(sep.outputs["Blue"], bsdf.inputs["Metallic"])
    nm = nt.nodes.new('ShaderNodeTexImage'); nm.image = TEX["Normal"]; nm.location = (-800, -320)
    nt.links.new(texco.outputs["UV"], nm.inputs["Vector"])
    nmap = nt.nodes.new('ShaderNodeNormalMap'); nmap.location = (-520, -320)
    nt.links.new(nm.outputs["Color"], nmap.inputs["Color"])
    nt.links.new(nmap.outputs["Normal"], bsdf.inputs["Normal"])

for m in materials.values():
    wire_textures(m)

# -----------------------------------------------------------------------------
# 3. MESH HELPERS
# -----------------------------------------------------------------------------
def new_obj(name, bm, mat):
    me = bpy.data.meshes.new(name)
    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    bm.to_mesh(me)
    bm.free()
    me.materials.append(mat)
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    return ob

def bridge_sections(bm, rings, close_tip=True):
    """rings: list of lists of verts (same count), bridged with quads."""
    for a, b in zip(rings[:-1], rings[1:]):
        for i in range(len(a)):
            j = (i + 1) % len(a)
            bm.faces.new((a[i], a[j], b[j], b[i]))
    if close_tip:
        bm.faces.new(rings[-1])

def resample(pts, n):
    """resample polyline [(x,z)...] by arc length to n points."""
    pts = [Vector((p[0], 0, p[1])) for p in pts]
    lens = [0.0] + [ (pts[i+1]-pts[i]).length for i in range(len(pts)-1) ]
    cum = np.cumsum(lens)
    total = cum[-1]
    out = []
    for t in np.linspace(0, total, n):
        k = int(np.searchsorted(cum, t, side='right') - 1)
        k = min(k, len(pts) - 2)
        f = 0.0 if cum[k+1] == cum[k] else (t - cum[k]) / (cum[k+1] - cum[k])
        out.append(pts[k].lerp(pts[k+1], f))
    return out

# -----------------------------------------------------------------------------
# 4. BLADES  — zero-thickness cutting edge, faceted spine ridge
#    section ring (4 verts): edge(y=0) -> mid-ridge(+y) -> spine(+y thin) -> spine-back(y=0)
# -----------------------------------------------------------------------------
def build_blade(name, spine_px, edge_px, t_max, mat, nsec=14, ox=207.0, oy=1190.0, s=S_A,
                spur=None, fin_spikes=False):
    spine = resample([P(x, y, ox, oy, s) for x, y in spine_px], nsec)
    edge  = resample([P(x, y, ox, oy, s) for x, y in edge_px],  nsec)
    bm = bmesh.new()
    rings = []
    z_tip = spine[-1].z
    z_heel = spine[0].z
    for i in range(nsec):
        e, sp = edge[i], spine[i]
        f = (z_heel - e.z) / max(1e-6, (z_heel - z_tip))     # 0 at heel -> 1 at tip
        t = t_max * (1.0 - f) ** 1.4 + t_max * 0.04
        if i == nsec - 1:
            v = bm.verts.new((e.x, 0, e.z))                  # needle tip, single vert
            rings.append([v, v, v, v])
            continue
        ve = bm.verts.new((e.x, 0.0, e.z))                   # TRUE zero-thickness edge
        vm = bm.verts.new(((e.x + sp.x) * 0.5 + 0.002, t * 0.75, e.z))
        vs = bm.verts.new((sp.x, t * 0.28, e.z))             # spine ridge
        vb = bm.verts.new((sp.x, 0.0, e.z))                  # flat back facet
        rings.append([ve, vm, vs, vb])
    bridge_sections(bm, rings)
    bm.faces.new(rings[0])                                   # heel cap
    ob = new_obj(name, bm, mat)
    if spur:                                                 # small forward spur on edge
        sx, sz = P(*spur, ox, oy, s)
        bm2 = bmesh.new()
        a = bm2.verts.new((sx, 0, sz - 0.012))
        b = bm2.verts.new((sx - 0.014, 0, sz))
        c = bm2.verts.new((sx, 0, sz + 0.010))
        d = bm2.verts.new((sx - 0.006, 0.004, sz - 0.002))
        bm2.faces.new((a, b, d)); bm2.faces.new((b, c, d)); bm2.faces.new((a, d, c))
        new_obj(name + "_spur", bm2, mat)
    if fin_spikes:                                           # jagged fin row above guard (B)
        for k, zz in enumerate(np.linspace(z_heel + 0.02, z_heel + 0.10, 4)):
            xx = np.interp(zz, [p.z for p in spine], [p.x for p in spine])
            bm3 = bmesh.new()
            a = bm3.verts.new((xx + 0.004, 0.004, zz))
            b = bm3.verts.new((xx - 0.016, 0.004, zz + 0.020))
            c = bm3.verts.new((xx - 0.002, 0.004, zz + 0.034))
            d = bm3.verts.new((xx - 0.004, 0.010, zz + 0.014))
            bm3.faces.new((a, b, d)); bm3.faces.new((b, c, d)); bm3.faces.new((a, d, c))
            new_obj(f"{name}_fin{k}", bm3, mat)
    return ob

# ---- Dagger A blade landmarks (refined from artwork) ----
A_SPINE = [(338,88),(352,140),(340,190),(300,230),(250,330),(215,430),(198,470),(205,505),(195,520),(185,590)]
A_EDGE  = [(338,88),(300,120),(255,190),(215,270),(185,360),(172,420),(160,455),(168,470),(160,490)]

# ---- Dagger B blade (own origin at its grip centre ~ (475,320)) ----
S_B = S_A
B_SPINE = [(410,470),(375,560),(370,650),(390,720),(400,800),(395,900),(390,1000),(380,1100),(385,1200),(470,1345)]
B_EDGE  = [(560,900),(555,1000),(520,1100),(490,1200),(470,1345)]
# extend B edge up to heel so resample pairs cleanly
B_EDGE  = [(540,760),(552,830),(560,900),(555,1000),(520,1100),(490,1200),(470,1345)]
B_SPINE = [(430,455),(410,470),(375,560),(370,650),(390,720),(400,800),(395,900),(390,1000),(380,1100),(385,1200),(470,1345)]

def PB(px, py):
    return ((px - 475.0) * S_B, (320.0 - py) * S_B)   # B local: +Z toward pommel-up pre-flip

# Build B in its own frame then flip (blade down in final scene)
def build_blade_B():
    spine = resample([PB(x, y) for x, y in B_SPINE], 16)
    edge  = resample([PB(x, y) for x, y in B_EDGE], 16)
    # pair by z
    bm = bmesh.new()
    rings = []
    t_max = 0.016
    zs = [ (s.z + e.z) * 0.5 for s, e in zip(spine, edge) ]
    for i in range(16):
        sp = spine[i]; e = edge[i]
        f = i / 15.0
        t = t_max * (1.0 - abs(f - 0.15)) ** 1.2 + 0.002
        if i == 15:
            v = bm.verts.new((e.x, 0, e.z)); rings.append([v, v, v, v]); continue
        ve = bm.verts.new((e.x, 0.0, e.z))
        vm = bm.verts.new(((e.x + sp.x) * 0.5, t * 0.8, e.z))
        vs = bm.verts.new((sp.x, t * 0.3, e.z))
        vb = bm.verts.new((sp.x, 0.0, e.z))
        rings.append([ve, vm, vs, vb])
    bridge_sections(bm, rings)
    bm.faces.new(rings[0])
    return new_obj("Blade_B", bm, materials["M_Blade_Coral"])

# -----------------------------------------------------------------------------
# 5. GUARDS — unions of sharp solids
# -----------------------------------------------------------------------------
def prism_from_outline(name, pts_xz, y0, y1, mat, taper_top=1.0):
    """extrude a 2D outline (x,z) between y0..y1, tapering the top face."""
    bm = bmesh.new()
    lo = [bm.verts.new((x, y0, z)) for x, z in pts_xz]
    cx = sum(p[0] for p in pts_xz) / len(pts_xz); cz = sum(p[1] for p in pts_xz) / len(pts_xz)
    hi = [bm.verts.new((cx + (x - cx) * taper_top, y1, cz + (z - cz) * taper_top)) for x, z in pts_xz]
    bm.faces.new(lo)
    bm.faces.new(list(reversed(hi)))
    for i in range(len(lo)):
        j = (i + 1) % len(lo)
        bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
    return new_obj(name, bm, mat)

def talon(name, base, tip, width, mat, y=0.008):
    """sharp tapered wing hugging the blade."""
    bm = bmesh.new()
    bx, bz = base; tx, tz = tip
    nx, nz = -(tz - bz), (tx - bx)
    l = math.hypot(nx, nz) or 1.0
    nx, nz = nx / l * width, nz / l * width
    a = bm.verts.new((bx + nx, -y, bz + nz)); b = bm.verts.new((bx - nx, -y, bz - nz))
    c = bm.verts.new((bx - nx, y, bz - nz));  d = bm.verts.new((bx + nx, y, bz + nz))
    e = bm.verts.new((tx, 0, tz))
    bm.faces.new((a, b, c, d)); bm.faces.new((a, d, e)); bm.faces.new((b, a, e))
    bm.faces.new((d, c, e)); bm.faces.new((c, b, e))
    return new_obj(name, bm, mat)

def build_guard_A():
    # irregular scalloped black mass (artwork extent x85..280 y530..1105), concave chips
    outline = [P(x, y) for x, y in [
        (150,1095),(110,1040),(88,960),(105,900),(92,840),(118,780),(100,720),
        (135,660),(128,600),(165,545),(205,532),(248,555),(272,610),(255,668),
        (278,730),(258,795),(276,860),(250,925),(262,990),(232,1050),(195,1098)]]
    objs = [prism_from_outline("Guard_A", outline, -0.011, 0.011, materials["M_Guard_Black"], 0.85)]
    # two long tapering talons bleeding forward along lower third of blade
    objs.append(talon("Guard_A_talonL", P(150, 640), P(178, 300), 0.010, materials["M_Guard_Black"]))
    objs.append(talon("Guard_A_talonR", P(255, 650), P(230, 330), 0.010, materials["M_Guard_Black"]))
    # red engraved dragon-mask linework: thin emissive strips on +Y face
    mask = [  # (browL, browR, eye, nose, whisker1, whisker2)
        ((150,905),(175,880)), ((215,880),(240,905)), ((178,862),(205,852)),
        ((192,845),(196,800)), ((160,815),(130,790)), ((230,815),(258,792))]
    for k, (p0, p1) in enumerate(mask):
        a = P(*p0); b = P(*p1)
        bm = bmesh.new()
        dx, dz = b[0]-a[0], b[1]-a[1]; l = math.hypot(dx, dz) or 1
        wx, wz = -dz/l*0.0035, dx/l*0.0035
        v = [bm.verts.new((a[0]+wx, 0.0115, a[1]+wz)), bm.verts.new((a[0]-wx, 0.0115, a[1]-wz)),
             bm.verts.new((b[0]-wx, 0.0115, b[1]-wz)), bm.verts.new((b[0]+wx, 0.0115, b[1]+wz))]
        bm.faces.new(v)
        objs.append(new_obj(f"Guard_A_mask{k}", bm, materials["M_Guard_BlackEmissive"]))
    return objs

def build_guard_B():
    # chunky ivory skull mass (x355..600 y430..950), saw-tooth fang bottom
    outline = [PB(x, y) for x, y in [
        (400,470),(365,520),(358,600),(372,660),(360,720),(378,780),(368,840),
        (392,880),(382,915),(405,905),(415,935),(432,908),(448,940),(466,910),
        (486,942),(505,912),(524,938),(540,905),(560,860),(585,800),(596,720),
        (588,640),(596,560),(575,500),(540,455),(500,438),(455,442)]]
    objs = [prism_from_outline("Guard_B", outline, -0.016, 0.016, materials["M_Guard_Ivory"], 0.80)]
    # blunt forward-swept horns + cheek lobes
    objs.append(talon("Guard_B_hornL", PB(392, 560), PB(330, 500), 0.014, materials["M_Guard_Ivory"], 0.012))
    objs.append(talon("Guard_B_hornR", PB(575, 560), PB(640, 510), 0.014, materials["M_Guard_Ivory"], 0.012))
    # hollow eye-socket recess: shallow inset dark prism on the face
    eye = [PB(x, y) for x, y in [(455,560),(435,585),(445,615),(478,618),(492,588),(478,562)]]
    objs.append(prism_from_outline("Guard_B_eye", eye, 0.016, 0.020, materials["M_Guard_Black"], 0.7))
    # separate RED fin/hook sweeping up-right
    fin = [PB(x, y) for x, y in [(560,520),(600,478),(640,455),(618,505),(585,545)]]
    objs.append(prism_from_outline("Guard_B_fin", fin, -0.006, 0.006, materials["M_Pommel_Coral"], 0.4))
    return objs

# -----------------------------------------------------------------------------
# 6. GRIPS — real overlapping chevron scale geometry, two opposing spirals
# -----------------------------------------------------------------------------
def build_grip(name, length, r0, r1, mat, rows=9, around=7):
    objs = []
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=8, radius1=r0, radius2=r1, depth=length)
    objs.append(new_obj(name + "_core", bm, mat))
    for row in range(rows):
        z = -length/2 + length * (row + 0.5) / rows
        r = np.interp(z, [-length/2, length/2], [r0, r1])
        for k in range(around):
            side = 1 if k % 2 == 0 else -1                      # opposing spirals
            ang = k * 2*math.pi/around + side * row * 0.35
            cx, cy = math.cos(ang) * r, math.sin(ang) * r
            bm = bmesh.new()
            w, h = 2*math.pi*r/around*0.62, length/rows*0.75
            # chevron scale: 5-vert fan pointing toward pommel, lifted outward
            pts = [(0,-h*0.5,0),(-w*0.5,-h*0.15,0),(0,h*0.55,0.004),(w*0.5,-h*0.15,0),(0,-h*0.05,0.005)]
            verts = []
            rot = Matrix.Rotation(ang + math.pi/2, 4, 'Z') @ Matrix.Rotation(-0.5*side, 4, 'X')
            for px, py, pz in pts:
                co = rot @ Vector((px, py, pz))
                verts.append(bm.verts.new((cx + co.x, cy + co.y, z + co.z)))
            bm.faces.new((verts[0], verts[1], verts[4]))
            bm.faces.new((verts[1], verts[2], verts[4]))
            bm.faces.new((verts[2], verts[3], verts[4]))
            bm.faces.new((verts[3], verts[0], verts[4]))
            objs.append(new_obj(f"{name}_s{row}_{k}", bm, mat))
    return objs

# -----------------------------------------------------------------------------
# 7. POMMELS
# -----------------------------------------------------------------------------
def build_pommel_A():
    bm = bmesh.new()
    bmesh.ops.create_icosphere(bm, subdivisions=1, radius=0.016)
    for v in bm.verts:
        v.co.z *= 1.5; v.co.x *= 0.8
        if v.co.z > 0.012: v.co.x *= 0.3          # soft split-tip flame
    ob = new_obj("Pommel_A", bm, materials["M_Pommel_Coral"])
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=5, radius1=0.005, radius2=0.0, depth=0.018)
    for v in bm.verts: v.co.z += 0.026; v.co.x -= 0.004
    ob2 = new_obj("Pommel_A_tip", bm, materials["M_Pommel_Coral"])
    return [ob, ob2]

def build_pommel_B():
    bm = bmesh.new()
    bmesh.ops.create_cone(bm, cap_ends=True, segments=6, radius1=0.014, radius2=0.008, depth=0.02)
    ob = new_obj("Pommel_B", bm, materials["M_Pommel_Coral"])
    bm = bmesh.new()   # tiny sideways hook claw
    a = bm.verts.new((0.010, 0, 0.004)); b = bm.verts.new((0.024, 0, 0.010))
    c = bm.verts.new((0.020, 0, -0.004)); d = bm.verts.new((0.012, 0.005, 0))
    bm.faces.new((a, b, d)); bm.faces.new((b, c, d)); bm.faces.new((a, d, c))
    ob2 = new_obj("Pommel_B_claw", bm, materials["M_Pommel_Coral"])
    return [ob, ob2]

# -----------------------------------------------------------------------------
# 8. ASSEMBLE
# -----------------------------------------------------------------------------
def join(objs, name):
    bpy.ops.object.select_all(action='DESELECT')
    for o in objs: o.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    bpy.ops.object.join()
    ob = bpy.context.active_object
    ob.name = name; ob.data.name = name
    return ob

root = bpy.data.objects.new("KamishsWrath", None)
bpy.context.collection.objects.link(root)

# ---- Dagger A ----
bladeA = build_blade("Blade", A_SPINE, A_EDGE, 0.010, materials["M_Blade_Coral"], spur=(160, 455))
spurA = [o for o in bpy.data.objects if o.name == "Blade_spur"]
bladeA = join([bladeA] + spurA, "Blade") if spurA else bladeA
guardA = join(build_guard_A(), "Guard")
gripA  = join(build_grip("Grip", 0.150, 0.013, 0.011, materials["M_Grip_BlueGrey"]), "Grip")
pomA   = join(build_pommel_A(), "Pommel")
gripA.location.z = -0.075 - 0.075 + 0.0   # grip sits below heel
# position parts in A-local frame (origin at grip centre, +Z to tip)
heel_z = P(185, 590)[1]                    # ~0.265
grip_c = P(207, 1190)[1]                   # 0
bladeA.location.z = 0; guardA.location.z = 0
gripA.location = (0, 0, -0.105)
pomA.location  = (0, 0, -0.195)

empA = bpy.data.objects.new("KW_Dagger_A_BlackGuard", None)
bpy.context.collection.objects.link(empA)
for o in (bladeA, guardA, gripA, pomA):
    o.parent = empA
empA.parent = root
empA.location = (-0.10, 0, 0.02)
empA.rotation_euler = (0, math.radians(10), 0)   # ~10 deg tilt, blade up

# ---- Dagger B ----
bladeB = build_blade_B()
spikes = [o for o in bpy.data.objects if o.name.startswith("Blade_B_fin")]
guardB = join(build_guard_B(), "Guard")
gripB  = join(build_grip("GripB", 0.115, 0.012, 0.010, materials["M_Grip_PurpleGrey"], rows=7), "Grip")
pomB   = join(build_pommel_B(), "Pommel")
bladeB = join([bladeB] + spikes, "Blade") if spikes else bladeB
# B local origin at its grip centre; grip/pommel above heel in artwork frame
gripB.location = (PB(475, 320)[0], 0, PB(475, 320)[1])
pomB.location  = (PB(478, 210)[0], 0, PB(478, 210)[1])
bladeB.name = "Blade"; guardB.name = "Guard"; gripB.name = "Grip"; pomB.name = "Pommel"

empB = bpy.data.objects.new("KW_Dagger_B_GoldGuard", None)
bpy.context.collection.objects.link(empB)
for o in (bladeB, guardB, gripB, pomB):
    o.parent = empB
empB.parent = root
# blade DOWN as in artwork: flip 180 about X, opposite tilt
empB.location = (0.10, 0, -0.01)
empB.rotation_euler = (math.radians(180), math.radians(-10), 0)

# -----------------------------------------------------------------------------
# 9. UVs + APPLY TRANSFORMS + TRIANGULATE (already triangulated per-part)
# -----------------------------------------------------------------------------
mesh_objs = [o for o in bpy.data.objects if o.type == 'MESH']
bpy.ops.object.select_all(action='DESELECT')
for o in mesh_objs:
    o.select_set(True)
bpy.context.view_layer.objects.active = mesh_objs[0]
bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

for o in mesh_objs:
    bpy.ops.object.select_all(action='DESELECT')
    o.select_set(True); bpy.context.view_layer.objects.active = o
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.02)
    bpy.ops.object.mode_set(mode='OBJECT')

# -----------------------------------------------------------------------------
# 10. EXPORT  (Y-up, applied, triangulated, embedded, no cameras/lights)
# -----------------------------------------------------------------------------
bpy.ops.object.select_all(action='DESELECT')
root.select_set(True)
for o in bpy.data.objects:
    if o.parent == root or o in (empA, empB) or o.type == 'MESH':
        o.select_set(True)

bpy.ops.export_scene.gltf(
    filepath=GLB_PATH, export_format='GLB', use_selection=True,
    export_yup=True, export_apply=True, export_materials='EXPORT',
    export_image_format='AUTO', export_tangents=True)

print("EXPORTED:", GLB_PATH, os.path.getsize(GLB_PATH), "bytes")

# -----------------------------------------------------------------------------
# 11. VERIFY — re-import, stats, 4 neutral renders
# -----------------------------------------------------------------------------
try:
    bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete()
    bpy.ops.import_scene.gltf(filepath=GLB_PATH)
    tot_v = tot_t = 0
    for o in bpy.data.objects:
        if o.type == 'MESH':
            tot_v += len(o.data.vertices)
            tot_t += sum(len(p.vertices) - 2 for p in o.data.polygons)
    print(f"VERIFY verts={tot_v} tris={tot_t}")
    print("VERIFY nodes:", [o.name for o in bpy.data.objects if o.parent is None or o.type == 'EMPTY'])
    print("VERIFY mats:", sorted({m.name for o in bpy.data.objects if o.type=='MESH' for m in o.data.materials}))

    world = bpy.data.worlds.new("Studio"); bpy.context.scene.world = world
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (0.22, 0.22, 0.22, 1)
    sun = bpy.data.lights.new("Sun", 'SUN'); sun.energy = 3.0
    so = bpy.data.objects.new("Sun", sun); bpy.context.collection.objects.link(so)
    so.rotation_euler = (math.radians(55), 0, math.radians(30))
    bpy.context.scene.render.engine = 'BLENDER_WORKBENCH'
    bpy.context.scene.render.resolution_x = 640
    bpy.context.scene.render.resolution_y = 900
    for i, rot in enumerate([(math.radians(90),0,0),(math.radians(90),0,math.pi),
                             (math.radians(90),0,math.pi/2),(math.radians(70),0,math.radians(35))]):
        cam_d = bpy.data.cameras.new("Cam"); co = bpy.data.objects.new("Cam", cam_d)
        bpy.context.collection.objects.link(co)
        co.rotation_euler = rot; co.location = (0, -1.4, 0.05)
        if i == 3: co.location = (-0.9, -1.0, 0.35)
        bpy.context.scene.camera = co
        bpy.context.scene.render.filepath = os.path.join(OUT_DIR, f"verify_{i}.png")
        bpy.ops.render.render(write_still=True)
        bpy.data.objects.remove(co)
    print("VERIFY renders written")
except Exception as e:
    print("VERIFY skipped:", e)

print("DONE")
