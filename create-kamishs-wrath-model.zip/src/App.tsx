export default function App() {
  return (
    <a href="Kamishs_Wrath.glb" download="Kamishs_Wrath.glb">
      Download .glb
    </a>
  );
}
