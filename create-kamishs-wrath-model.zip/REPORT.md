# Kamish's Wrath — final report

## Files
- `Kamishs_Wrath.glb` — 7045736 bytes, single glTF 2.0 binary, all three
  textures embedded (no .bin, no external images).
- `index.html` — 311 bytes, plain page whose body contains exactly one
  visible element: an anchor labeled `Download .glb` with
  `href="Kamishs_Wrath.glb"` and `download="Kamishs_Wrath.glb"`.
- `public/Kamishs_Wrath.glb` — identical copy so the built site at `dist/`
  serves the delivered bytes next to the page. The work log, report and audit
  renders stay outside `index.html`.

## Scale and layout
Metres, Y-up in glTF. Both daggers normalised to exactly **0.6105 m overall**
(lengths before normalisation: A 0.6135 m, B 0.6250 m). Dagger A (slim, black
guard) is on the left, blade up, tilted -8°. Dagger B (thick, ivory guard) is on
the right, blade down, tilted +8° in its reversed frame. Pair bounds are
centred near the origin: x [-0.167, 0.232], y [-0.044, 0.031],
z [-0.306, 0.310] m.

## Mesh
- 3,498 authored vertices / 6,320 triangles for the pair (within the ~8.6k
  target and far below the 15k ceiling). Flat-shaded glTF expands these to
  18,960 vertex records at material seams/UV splits.
- Root node `KamishsWrath`; children `KW_Dagger_A_BlackGuard` and
  `KW_Dagger_B_GoldGuard`; mesh parts `Blade`, `Guard`, `Grip`, `Pommel` on both
  daggers (duplicate part names are legal glTF; node/mesh indices are unique).
- Blade cutting edges are true zero-thickness triangle strips; guard horns,
  chips and fangs terminate in single sharp vertices with no bevel or
  subdivision. Grip wrap is real overlapping chevron plates in two opposing
  spirals. Dagger A's black guard carries a separate emissive engraved
  dragon-tiger mask. UV0 only, per-face padded islands with >= 4 px gutters.

## Textures and palette
2048x2048 PNG base colour + tangent normal + ORM, embedded and re-imported
cleanly. Exact base colours: `#F98A7A` (blade), `#100609` (black guard),
`#FF695E` (engraving emissive), `#E8DDB4` (ivory guard), `#535468` (blue-grey
grip), `#543347` (purple-grey grip), `#F28A87` (pommel coral). Metallic and
roughness follow section 7. Materials are named exactly
`M_Blade_Coral`, `M_Guard_Black`, `M_Guard_BlackEmissive`, `M_Guard_Ivory`,
`M_Grip_BlueGrey`, `M_Grip_PurpleGrey`, `M_Pommel_Coral`.

## Iterations
Six build/verify passes, each exported and rendered in four neutral studio views
(front, back, side, 3/4; no aura or coloured rim). Fixes made along the way:
enlarged the guards to the landmark proportions; widened both blades; rebuilt
the grips as real chevron geometry; fixed a vertically mirrored UV atlas that
was sampling empty texels; softened/clipped highlights by relighting the studio;
restored the exact palette; removed shard-like overlap and spikes crossing the
blade; normalised both lengths to 0.6105 m.

## Verification actually run
- `bpy` 5.0.1 headless build and glTF 2.0 export; GLB re-imported into an empty
  Blender scene: 8 meshes, 7 materials, 3 embedded PNGs, UVs on every mesh, no
  missing texture images, 0 cameras, 0 lights, 0 extension dependencies.
- Binary parse of the delivered GLB: magic/version/length consistent, one
  scene, all images stored as bufferViews with no external URIs, `TEXCOORD_0`
  present, `TANGENT` present on every primitive, no non-uniform scale on the
  dagger nodes, 6,320 triangles.
- Local HTTP test: served `dist/` with Python's server; `index.html` returned
  200 and contained exactly one anchor and no scripts/styles; the anchor URL
  `Kamishs_Wrath.glb` returned 200, `model/gltf-binary`, 7,045,736 bytes and was
  **byte-identical** to the delivered GLB (sha256
  `abeb660e6f04232b55b37e18a3948b1ba713ce04822213f35015594e104b335c`).
- `npm run build` completed successfully with the page and GLB copied into
  `dist/`. A headless browser was not available, so the browser click-through
  itself is untested; the HTTP fetch of the exact anchor target was tested.

## Deliberate deviations
- The artwork paints Dagger B's guard ivory-cream while canon says gold. The
  brief makes the artwork authoritative and asks for ivory, so `M_Guard_Ivory`
  is used.
- The artwork aura, glow, sparkles, backdrop and painted highlights are
  intentionally absent; the hard faceted cel read comes from flat shading and
  neutral lighting.
- Dagger B is shown blade-down as in the artwork, with its separate coral fin
  reading above the guard.
