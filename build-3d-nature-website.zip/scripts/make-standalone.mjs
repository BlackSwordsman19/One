/**
 * Builds the single-file Understory site.
 * TypeScript + JSX are compiled to plain JS at build time, then assembled with the
 * stylesheet into one index.html. React, ReactDOM and three.js come from public CDNs.
 */
import fs from "node:fs";
import path from "node:path";
import ts from "typescript";

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), "utf8");

const SOURCES = [
  "src/data/content.ts",
  "src/hooks/useScroll.ts",
  "src/hooks/useForestSound.ts",
  "src/components/Header.tsx",
  "src/components/DepthRail.tsx",
  "src/components/Descent.tsx",
  "src/components/StorySections.tsx",
  "src/components/VisitFooter.tsx",
  "src/scene/RedwoodScene.tsx",
  "src/App.tsx",
];

const CDN = {
  react: "https://unpkg.com/react@18.3.1/umd/react.production.min.js",
  reactDom: "https://unpkg.com/react-dom@18.3.1/umd/react-dom.production.min.js",
  three: "https://cdn.jsdelivr.net/npm/three@0.152.2/build/three.min.js",
};

const PHOTOS = {
  "/images/redwood-fog.jpg":
    "https://images.pexels.com/photos/29909713/pexels-photo-29909713.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1400&w=2100",
  "/images/canopy-up.jpg":
    "https://images.pexels.com/photos/31359373/pexels-photo-31359373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1300&w=1000",
  "/images/forest-path.jpg":
    "https://images.pexels.com/photos/32148867/pexels-photo-32148867.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1500",
  "/images/moss-fern.jpg":
    "https://images.pexels.com/photos/39660507/pexels-photo-39660507.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600",
  "/images/grove-path.jpg":
    "https://images.pexels.com/photos/8146960/pexels-photo-8146960.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=1500",
};

function replacePhotos(text) {
  let output = text;
  for (const [local, remote] of Object.entries(PHOTOS)) {
    output = output.split(local).join(remote);
  }
  return output;
}

function transpile(file) {
  const source = read(file);
  const result = ts.transpileModule(source, {
    fileName: file,
    reportDiagnostics: true,
    compilerOptions: {
      jsx: ts.JsxEmit.React,
      target: ts.ScriptTarget.ES2020,
      module: ts.ModuleKind.ESNext,
      esModuleInterop: false,
      removeComments: false,
      newLine: ts.NewLineKind.LineFeed,
    },
  });
  const errors = (result.diagnostics || []).filter((d) => d.category === ts.DiagnosticCategory.Error);
  if (errors.length) {
    const message = ts.formatDiagnostics(errors, {
      getCanonicalFileName: (f) => f,
      getCurrentDirectory: () => root,
      getNewLine: () => "\n",
    });
    throw new Error(`Could not compile ${file}:\n${message}`);
  }
  let code = result.outputText;
  code = code.replace(/^\s*import\s+[\s\S]*?from\s+["'][^"']+["'];?\s*$/gm, "");
  code = code.replace(/^\s*import\s+["'][^"']+["'];?\s*$/gm, "");
  code = code.replace(/\bexport\s+default\s+function\s+/g, "function ");
  code = code.replace(/\bexport\s+default\s+/g, "");
  code = code.replace(/\bexport\s+(function|const|let|var|class)\s+/g, "$1 ");
  code = code.replace(/\/\/# sourceMappingURL=.*$/gm, "");
  if (/^\s*(import|export)\b/m.test(code)) {
    throw new Error(`Unhandled module syntax left in ${file}`);
  }
  return replacePhotos(code).trim();
}

const polyfills = `
/* ——— shared globals from the CDN builds ——— */
const { useCallback, useEffect, useRef, useState } = React;

/* three r152: turn on physical light units to match modern three defaults */
THREE.ColorManagement.enabled = true;

/* The one addon the scene needs: merge the three frond planes into one geometry. */
function mergeGeometries(geometries) {
  const parts = geometries.map((geometry) => (geometry.index ? geometry.toNonIndexed() : geometry));
  const merged = new THREE.BufferGeometry();
  ["position", "normal", "uv"].forEach((name) => {
    const first = parts[0].getAttribute(name);
    if (!first) return;
    const arrays = parts.map((geometry) => Array.from(geometry.getAttribute(name).array));
    const total = arrays.reduce((sum, array) => sum + array.length, 0);
    const data = new Float32Array(total);
    let offset = 0;
    arrays.forEach((array) => {
      data.set(array, offset);
      offset += array.length;
    });
    merged.setAttribute(name, new THREE.BufferAttribute(data, first.itemSize));
  });
  return merged;
}
`;

let appCode = [polyfills, ...SOURCES.map(transpile)].join("\n\n/* ——————————————————— */\n\n");
appCode = appCode.replace(
  "renderer.setPixelRatio(",
  "if ('useLegacyLights' in renderer) renderer.useLegacyLights = false;\n    renderer.setPixelRatio(",
);

const css = replacePhotos(read("src/index.css"))
  .replace(/^@import\s+["']tailwindcss["'];?/m, "")
  .trim();

const reset = `
*, *::before, *::after { box-sizing: border-box; border: 0 solid; }
html { -webkit-text-size-adjust: 100%; }
body { margin: 0; }
h1, h2, h3, h4, h5, h6 { font-size: inherit; font-weight: inherit; }
ol, ul, menu { margin: 0; padding: 0; list-style: none; }
img, svg, video, canvas { display: block; vertical-align: middle; }
img, video { max-width: 100%; height: auto; }
button, input, select, textarea { margin: 0; padding: 0; border: 0; background: transparent; color: inherit; font: inherit; }
button { cursor: pointer; background-image: none; }
`;

const favicon =
  "data:image/svg+xml," +
  encodeURIComponent(
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="14" fill="#0d1711"/><path d="M32 53V22" stroke="#d8e6a8" stroke-width="3.5" stroke-linecap="round"/><path d="M32 33 15 20M32 33l17-13M32 42 19 32M32 42l13-10" stroke="#d8e6a8" stroke-width="3" stroke-linecap="round"/><path d="M32 22c-7-2-11-8-11-14 7 1 11 6 11 14Zm0 0c7-2 11-8 11-14-7 1-11 6-11 14Z" fill="#d8e6a8"/></svg>`,
  );

const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta
      name="description"
      content="Understory is a vertical field guide to the coast redwood: a scroll from the weather in its crown to the fungal network beneath the forest floor."
    />
    <meta name="theme-color" content="#0d1711" />
    <meta property="og:title" content="Understory — a vertical field guide to the coast redwood" />
    <meta
      property="og:description"
      content="A scroll-driven descent through the world's tallest living thing, from the fog in its crown to the roots beneath the grove."
    />
    <meta property="og:image" content="${PHOTOS["/images/redwood-fog.jpg"]}" />
    <link rel="icon" href="${favicon}" type="image/svg+xml" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,300..800&family=DM+Mono:wght@300;400;500&family=Hanken+Grotesk:ital,wght@0,300..800;1,300..800&display=swap"
      rel="stylesheet"
    />
    <title>Understory — a vertical field guide to the coast redwood</title>
    <style>
${reset}
${css}
    </style>
  </head>
  <body>
    <a class="skip-link" href="#main">Skip to the field guide</a>
    <div id="root"></div>
    <noscript>
      <div style="max-width: 620px; margin: 15vh auto; padding: 0 24px; color: #f1eddc; background: #0b1510; font-family: Georgia, serif; line-height: 1.6">
        <h1 style="font-size: 2rem; margin-bottom: 12px">Understory</h1>
        <p>
          A vertical field guide to the coast redwood. This page needs JavaScript for its 3D
          descent, but the places are real: Redwood National and State Parks, Humboldt Redwoods,
          Muir Woods and Big Basin. The forest is best visited in person.
        </p>
      </div>
    </noscript>

    <script src="${CDN.react}" crossorigin></script>
    <script src="${CDN.reactDom}" crossorigin></script>
    <script src="${CDN.three}"></script>
    <script>
${appCode}

/* ——— mount ——— */
(function () {
  const renderer = ReactDOM.createRoot(document.getElementById("root"));
  renderer.render(React.createElement(App));
})();
    </script>
  </body>
</html>
`;

fs.mkdirSync(path.join(root, "standalone"), { recursive: true });
fs.writeFileSync(path.join(root, "standalone/index.html"), html);
console.log(
  `standalone/index.html written · ${(Buffer.byteLength(html) / 1024).toFixed(1)} kB · ${SOURCES.length} source files`,
);
