import { useEffect, useRef, useState, type RefObject } from "react";
import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";

type RedwoodSceneProps = {
  progressRef: RefObject<number>;
  reducedMotion: boolean;
};

const HERO_PALETTE = {
  top: "#c6c6a5",
  horizon: "#ddd2ad",
  bottom: "#2b4030",
  fog: "#aeb9a2",
  sun: "#ffe5ad",
};

const FLOOR_PALETTE = {
  top: "#193a31",
  horizon: "#6f8976",
  bottom: "#0a1510",
  fog: "#506b5c",
  sun: "#f6d9a2",
};

type Keyframe = {
  p: number;
  pos: [number, number, number];
  look: [number, number, number];
  fog: number;
  exposure: number;
  sun: number;
};

const CAMERA_PATH: Keyframe[] = [
  { p: 0, pos: [2.8, 47, 38], look: [-1, 34, -28], fog: 0.0095, exposure: 1.02, sun: 1 },
  { p: 0.18, pos: [-2.4, 39.5, 27], look: [1, 31, -28], fog: 0.011, exposure: 0.98, sun: 0.9 },
  { p: 0.4, pos: [2.4, 29.5, 16], look: [-2, 23, -30], fog: 0.0135, exposure: 0.94, sun: 0.68 },
  { p: 0.62, pos: [-2.1, 19.5, 7], look: [1.5, 13, -30], fog: 0.017, exposure: 0.89, sun: 0.46 },
  { p: 0.82, pos: [1.5, 8.5, -1], look: [-2, 9, -28], fog: 0.021, exposure: 0.84, sun: 0.3 },
  { p: 1, pos: [0.2, 2.15, 6], look: [0, 7.5, -24], fog: 0.024, exposure: 0.8, sun: 0.2 },
];

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function canvasTexture(
  width: number,
  height: number,
  draw: (ctx: CanvasRenderingContext2D) => void,
  colorSpace = true,
) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (ctx) draw(ctx);
  const texture = new THREE.CanvasTexture(canvas);
  if (colorSpace) texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

function makeBarkTexture() {
  const random = mulberry32(42);
  const texture = canvasTexture(256, 1024, (ctx) => {
    ctx.fillStyle = "#4a3626";
    ctx.fillRect(0, 0, 256, 1024);
    for (let i = 0; i < 330; i += 1) {
      const x = random() * 256;
      const y = random() * 1024;
      const width = 0.65 + random() * 3.2;
      const length = 36 + random() * 330;
      const warm = random();
      ctx.strokeStyle =
        warm > 0.78
          ? `rgba(139, 96, 58, ${0.16 + random() * 0.22})`
          : warm > 0.4
            ? `rgba(29, 20, 15, ${0.18 + random() * 0.3})`
            : `rgba(94, 61, 40, ${0.12 + random() * 0.22})`;
      ctx.lineWidth = width;
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.bezierCurveTo(x + random() * 5 - 2.5, y + length * 0.33, x + random() * 8 - 4, y + length * 0.66, x + random() * 5 - 2.5, y + length);
      ctx.stroke();
    }
    for (let i = 0; i < 42; i += 1) {
      const x = random() * 256;
      ctx.strokeStyle = `rgba(189, 144, 91, ${0.05 + random() * 0.1})`;
      ctx.lineWidth = 0.6 + random();
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x + random() * 12 - 6, 1024);
      ctx.stroke();
    }
  });
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set(1.6, 3.2);
  return texture;
}

function makeSoftTexture(inner = "rgba(255,255,255,0.7)", outer = "rgba(255,255,255,0)") {
  return canvasTexture(256, 256, (ctx) => {
    const gradient = ctx.createRadialGradient(128, 128, 2, 128, 128, 128);
    gradient.addColorStop(0, inner);
    gradient.addColorStop(0.38, inner.replace(/[\d.]+\)$/, "0.32)"));
    gradient.addColorStop(1, outer);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 256, 256);
  });
}

function makeDotTexture() {
  return canvasTexture(64, 64, (ctx) => {
    const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    gradient.addColorStop(0, "rgba(255,245,205,1)");
    gradient.addColorStop(0.28, "rgba(255,238,181,0.9)");
    gradient.addColorStop(1, "rgba(255,231,160,0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 64, 64);
  });
}

function makeFernTexture() {
  return canvasTexture(256, 256, (ctx) => {
    ctx.clearRect(0, 0, 256, 256);
    ctx.lineCap = "round";
    const stems = 8;
    for (let s = 0; s < stems; s += 1) {
      const angle = -Math.PI / 2 + (s - (stems - 1) / 2) * 0.3;
      const length = 96 + (s % 3) * 22;
      const originX = 128;
      const originY = 254;
      const tipX = originX + Math.cos(angle) * length;
      const tipY = originY + Math.sin(angle) * length;
      const cx = originX + Math.cos(angle) * length * 0.5 - (s - stems / 2) * 6;
      const cy = originY + Math.sin(angle) * length * 0.5;
      ctx.strokeStyle = "rgba(169, 199, 147, 0.95)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(originX, originY);
      ctx.quadraticCurveTo(cx, cy + 14, tipX, tipY);
      ctx.stroke();
      for (let leaflet = 1; leaflet < 21; leaflet += 1) {
        const t = leaflet / 22;
        const x = originX + (cx - originX) * 2 * t * (1 - t) + (tipX - originX) * t * t;
        const y = originY + (cy + 14 - originY) * 2 * t * (1 - t) + (tipY - originY) * t * t;
        const width = Math.sin(t * Math.PI) * 12 + 1.5;
        for (const side of [-1, 1]) {
          const leafAngle = angle + side * (1.3 - t * 0.35);
          const mx = x + Math.cos(leafAngle) * width * 0.6;
          const my = y + Math.sin(leafAngle) * width * 0.6;
          const ex = x + Math.cos(leafAngle - 0.2) * width;
          const ey = y + Math.sin(leafAngle - 0.2) * width;
          ctx.fillStyle = t > 0.8 ? "rgba(177, 204, 152, 0.85)" : "rgba(133, 168, 118, 0.9)";
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.quadraticCurveTo(mx - 2, my - 2, ex, ey);
          ctx.quadraticCurveTo(mx + 2, my + 2, x, y);
          ctx.fill();
        }
      }
    }
  });
}

function makeLightShaftTexture() {
  return canvasTexture(256, 512, (ctx) => {
    const vertical = ctx.createLinearGradient(0, 0, 0, 512);
    vertical.addColorStop(0, "rgba(255,236,184,0.68)");
    vertical.addColorStop(0.48, "rgba(255,236,184,0.24)");
    vertical.addColorStop(1, "rgba(255,236,184,0)");
    ctx.fillStyle = vertical;
    ctx.fillRect(0, 0, 256, 512);
    ctx.globalCompositeOperation = "destination-in";
    const horizontal = ctx.createLinearGradient(0, 0, 256, 0);
    horizontal.addColorStop(0, "rgba(255,255,255,0)");
    horizontal.addColorStop(0.4, "rgba(255,255,255,0.75)");
    horizontal.addColorStop(0.5, "rgba(255,255,255,1)");
    horizontal.addColorStop(0.6, "rgba(255,255,255,0.75)");
    horizontal.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = horizontal;
    ctx.fillRect(0, 0, 256, 512);
  });
}

const CAMERA_PATH_MOBILE: Keyframe[] = [
  { p: 0, pos: [1.1, 44, 46], look: [-2.4, 35, -26], fog: 0.011, exposure: 1.02, sun: 1 },
  { p: 0.18, pos: [-1.6, 36.5, 34], look: [1.6, 29.5, -26], fog: 0.0125, exposure: 0.98, sun: 0.9 },
  { p: 0.4, pos: [1.6, 26.5, 21], look: [-1.8, 21, -26], fog: 0.0145, exposure: 0.94, sun: 0.68 },
  { p: 0.62, pos: [-1.5, 16.5, 10], look: [1.4, 12.5, -27], fog: 0.018, exposure: 0.89, sun: 0.46 },
  { p: 0.82, pos: [1.1, 7.4, 1.5], look: [-1.6, 8.4, -26], fog: 0.022, exposure: 0.84, sun: 0.3 },
  { p: 1, pos: [0.1, 2.1, 8], look: [0, 7.2, -22], fog: 0.025, exposure: 0.8, sun: 0.2 },
];

function sampleCamera(path: Keyframe[], progress: number) {
  const clamped = Math.min(1, Math.max(0, progress));
  let a = path[0];
  let b = path[path.length - 1];
  for (let i = 0; i < path.length - 1; i += 1) {
    if (clamped >= path[i].p && clamped <= path[i + 1].p) {
      a = path[i];
      b = path[i + 1];
      break;
    }
  }
  const t = b.p === a.p ? 0 : (clamped - a.p) / (b.p - a.p);
  const eased = t * t * (3 - 2 * t);
  const position = new THREE.Vector3(...a.pos).lerp(new THREE.Vector3(...b.pos), eased);
  const look = new THREE.Vector3(...a.look).lerp(new THREE.Vector3(...b.look), eased);
  return {
    position,
    look,
    fog: THREE.MathUtils.lerp(a.fog, b.fog, t),
    exposure: THREE.MathUtils.lerp(a.exposure, b.exposure, t),
    sun: THREE.MathUtils.lerp(a.sun, b.sun, t),
  };
}

export default function RedwoodScene({ progressRef, reducedMotion }: RedwoodSceneProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [ready, setReady] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: false,
        powerPreference: "high-performance",
      });
    } catch {
      setFailed(true);
      return;
    }

    const compact = window.innerWidth < 760;
    const lowPower = (navigator.hardwareConcurrency ?? 8) <= 4;
    const quality = compact || lowPower ? 0.6 : 1;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(compact ? 54 : 47, 1, 0.1, 480);
    const cameraPath = compact ? CAMERA_PATH_MOBILE : CAMERA_PATH;
    const clock = new THREE.Clock();
    const pointer = { x: 0, y: 0 };
    const current = { x: 0, y: 0 };
    let smoothProgress = progressRef.current ?? 0;
    let hasPainted = false;

    scene.fog = new THREE.FogExp2(HERO_PALETTE.fog, 0.01);

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, compact ? 1.4 : 1.8));
    renderer.setSize(window.innerWidth, window.innerHeight, false);

    // Sky dome, painted per frame toward the floor palette.
    const skyMaterial = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
      uniforms: {
        uTop: { value: new THREE.Color(HERO_PALETTE.top) },
        uHorizon: { value: new THREE.Color(HERO_PALETTE.horizon) },
        uBottom: { value: new THREE.Color(HERO_PALETTE.bottom) },
      },
      vertexShader: `
        varying vec3 vLocal;
        void main() {
          vLocal = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 uTop;
        uniform vec3 uHorizon;
        uniform vec3 uBottom;
        varying vec3 vLocal;
        void main() {
          float h = clamp(vLocal.y / 150.0 * 0.5 + 0.5, 0.0, 1.0);
          vec3 col = mix(uBottom, uHorizon, smoothstep(0.34, 0.56, h));
          col = mix(col, uTop, smoothstep(0.52, 0.92, h));
          float haze = smoothstep(0.3, 0.68, h) * 0.08;
          gl_FragColor = vec4(col + haze, 1.0);
        }
      `,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(160, 28, 20), skyMaterial);
    scene.add(sky);

    // Sun glow behind the grove.
    const sunTexture = makeSoftTexture("rgba(255,244,204,0.95)");
    const sunMaterial = new THREE.SpriteMaterial({
      map: sunTexture,
      color: HERO_PALETTE.sun,
      transparent: true,
      opacity: 0.8,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: false,
    });
    const sunSprite = new THREE.Sprite(sunMaterial);
    sunSprite.position.set(-46, 72, -94);
    sunSprite.scale.set(78, 78, 1);
    scene.add(sunSprite);

    const hemi = new THREE.HemisphereLight(0xc5d0b6, 0x1a2517, 1.5);
    scene.add(hemi);
    const key = new THREE.DirectionalLight(0xffe5b4, 3);
    key.position.set(-30, 62, 14);
    scene.add(key);
    const cool = new THREE.DirectionalLight(0x8aab97, 1.4);
    cool.position.set(24, 16, -38);
    scene.add(cool);

    const barkTexture = makeBarkTexture();
    const barkMaterial = new THREE.MeshStandardMaterial({
      color: 0xb0987f,
      map: barkTexture,
      bumpMap: barkTexture,
      bumpScale: 0.24,
      roughness: 0.97,
      metalness: 0,
    });
    const foliageMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.92,
      metalness: 0,
      flatShading: true,
    });
    const mossMaterial = new THREE.MeshStandardMaterial({
      color: 0x597344,
      roughness: 1,
      flatShading: true,
    });

    const random = mulberry32(712);
    type Tree = { x: number; z: number; r: number; h: number; sway: number };
    const trees: Tree[] = [
      { x: -7.4, z: 15, r: 1.65, h: 70, sway: 0.4 },
      { x: 8.2, z: 0, r: 1.22, h: 62, sway: 1.9 },
      { x: -10.5, z: -13, r: 1.1, h: 57, sway: 3.1 },
      { x: 6.8, z: -33, r: 1.5, h: 66, sway: 5.2 },
      { x: -15, z: -33, r: 1.3, h: 60, sway: 2.4 },
    ];
    const totalTrees = Math.round(44 * (quality > 0.7 ? 1 : 0.72));
    while (trees.length < totalTrees) {
      const angle = random() * Math.PI * 2;
      const distance = 11 + Math.pow(random(), 0.68) * 66;
      let x = Math.cos(angle) * distance;
      let z = Math.sin(angle) * distance - 12;
      if (z > 39) z -= 24;
      if (Math.abs(x) < 6 && z > -21 && z < 35) x += x < 0 ? -5.5 : 5.5;
      trees.push({
        x,
        z,
        r: 0.32 + random() * 1.12,
        h: 36 + random() * 33,
        sway: random() * Math.PI * 2,
      });
    }

    const trunkGeometry = new THREE.CylinderGeometry(0.68, 1.24, 1, compact ? 9 : 14, 8);
    trunkGeometry.translate(0, 0.5, 0);
    {
      const position = trunkGeometry.getAttribute("position") as THREE.BufferAttribute;
      for (let i = 0; i < position.count; i += 1) {
        const x = position.getX(i);
        const y = position.getY(i);
        const angle = Math.atan2(position.getZ(i), x);
        const ridge = 1 + Math.sin(angle * 7 + y * 4.2) * 0.035 + Math.sin(angle * 13) * 0.018;
        position.setX(i, x * ridge);
        position.setZ(i, position.getZ(i) * ridge);
      }
      trunkGeometry.computeVertexNormals();
    }
    const trunks = new THREE.InstancedMesh(trunkGeometry, barkMaterial, trees.length);
    const barkShades = ["#87705a", "#7d6652", "#947d63", "#6e5c4a", "#9d8567"];
    const dummy = new THREE.Object3D();
    trees.forEach((tree, index) => {
      dummy.position.set(tree.x, 0, tree.z);
      dummy.rotation.set(0, tree.sway, 0);
      dummy.scale.set(tree.r, tree.h, tree.r);
      dummy.updateMatrix();
      trunks.setMatrixAt(index, dummy.matrix);
      trunks.setColorAt(index, new THREE.Color(barkShades[index % barkShades.length]));
    });
    trunks.instanceMatrix.needsUpdate = true;
    if (trunks.instanceColor) trunks.instanceColor.needsUpdate = true;
    scene.add(trunks);

    // Root flares and fallen timber.
    const flareGeometry = new THREE.CylinderGeometry(0.24, 1.2, 1, 9, 2, true);
    flareGeometry.translate(0, 0.5, 0);
    const flares = new THREE.InstancedMesh(flareGeometry, barkMaterial, trees.length * 2);
    trees.forEach((tree, index) => {
      const count = tree.r > 0.9 ? 2 : 1;
      for (let i = 0; i < count; i += 1) {
        dummy.position.set(tree.x + (random() - 0.5) * tree.r * 1.4, 0, tree.z + (random() - 0.5) * tree.r * 1.4);
        dummy.rotation.set((random() - 0.5) * 0.1, random() * Math.PI, (random() - 0.5) * 0.1);
        dummy.scale.set(tree.r * (1.6 + random()), 1.2 + random() * 1.4, tree.r * (1.6 + random()));
        dummy.updateMatrix();
        flares.setMatrixAt(index * 2 + i, dummy.matrix);
      }
    });
    flares.instanceMatrix.needsUpdate = true;
    scene.add(flares);

    const logMaterial = new THREE.MeshStandardMaterial({
      color: 0x5e4a36,
      map: barkTexture,
      bumpMap: barkTexture,
      bumpScale: 0.3,
      roughness: 1,
    });
    const logGeometry = new THREE.CylinderGeometry(1.05, 1.25, 1, 11, 4);
    const logs = new THREE.InstancedMesh(logGeometry, logMaterial, 4);
    const logData = [
      { x: 4.6, z: -5.2, len: 15, rot: 1.2, y: 0.9 },
      { x: -8.5, z: -20, len: 12, rot: 2.4, y: 0.75 },
      { x: 12.5, z: -34, len: 17, rot: 0.6, y: 0.72 },
      { x: -16, z: 10, len: 10, rot: 2.1, y: 0.65 },
    ];
    logData.forEach((log, index) => {
      dummy.position.set(log.x, log.y, log.z);
      dummy.rotation.set(Math.PI / 2, 0, log.rot);
      dummy.scale.set(1, log.len, 1.05);
      dummy.updateMatrix();
      logs.setMatrixAt(index, dummy.matrix);
    });
    logs.instanceMatrix.needsUpdate = true;
    scene.add(logs);

    const mossGeometry = new THREE.IcosahedronGeometry(1, 1);
    const mossPatches = new THREE.InstancedMesh(mossGeometry, mossMaterial, 72);
    const mossColors = ["#68804a", "#597242", "#7a8e53", "#4e693f"];
    for (let i = 0; i < 72; i += 1) {
      const logIndex = i % 4;
      const log = logData[logIndex];
      const along = (random() - 0.5) * log.len;
      dummy.position.set(
        log.x + Math.cos(log.rot) * along + (random() - 0.5) * 0.6,
        log.y + 0.7 + random() * 0.3,
        log.z - Math.sin(log.rot) * along,
      );
      dummy.rotation.set(random(), random() * 3, random());
      dummy.scale.set(0.4 + random() * 0.75, 0.2 + random() * 0.25, 0.35 + random() * 0.6);
      dummy.updateMatrix();
      mossPatches.setMatrixAt(i, dummy.matrix);
      mossPatches.setColorAt(i, new THREE.Color(mossColors[i % mossColors.length]));
    }
    mossPatches.instanceMatrix.needsUpdate = true;
    scene.add(mossPatches);

    // The crown: low-poly foliage masses with per-instance colour.
    const foliageGeometry = new THREE.IcosahedronGeometry(1, 1);
    const foliageCount = Math.round(1500 * quality);
    const foliage = new THREE.InstancedMesh(foliageGeometry, foliageMaterial, foliageCount);
    const foliageColors = ["#2e4a34", "#38573a", "#446445", "#263f2f", "#506d46", "#1f3529"];
    let foliageIndex = 0;
    for (const tree of trees) {
      const clusters = 14 + Math.floor(random() * 11);
      const crownRadius = Math.max(2.2, tree.r * 3.8 + 1.7);
      for (let c = 0; c < clusters && foliageIndex < foliageCount; c += 1) {
        const t = random();
        const angle = random() * Math.PI * 2;
        const spread = (0.3 + random() * 0.78) * crownRadius * (1 - t * 0.34);
        const cx = tree.x + Math.cos(angle) * spread;
        const cz = tree.z + Math.sin(angle) * spread;
        const cy = tree.h * (0.52 + t * 0.45) + (random() - 0.5) * 3.4;
        const size = 0.85 + random() * 1.65 + tree.r * 0.42;
        dummy.position.set(cx, cy, cz);
        dummy.rotation.set(random() * 2, random() * 6, random() * 2);
        dummy.scale.set(size * 1.2, size * 0.62, size * 1.05);
        dummy.updateMatrix();
        foliage.setMatrixAt(foliageIndex, dummy.matrix);
        foliage.setColorAt(foliageIndex, new THREE.Color(foliageColors[(foliageIndex * 7) % foliageColors.length]));
        foliageIndex += 1;
      }
    }
    foliage.count = foliageIndex;
    foliage.instanceMatrix.needsUpdate = true;
    if (foliage.instanceColor) foliage.instanceColor.needsUpdate = true;
    scene.add(foliage);

    // A far wall of trunks and crowns closes the horizon under the haze.
    const distantMaterial = new THREE.MeshBasicMaterial({ color: 0x52614f, fog: true });
    const distantGeometry = new THREE.CylinderGeometry(0.9, 1.5, 1, 6, 1);
    distantGeometry.translate(0, 0.5, 0);
    const distantTrees = new THREE.InstancedMesh(distantGeometry, distantMaterial, compact ? 110 : 170);
    for (let i = 0; i < distantTrees.count; i += 1) {
      const angle = random() * Math.PI * 2;
      const radius = 58 + random() * 96;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius - 18;
      const height = 38 + random() * 48;
      dummy.position.set(x, 0, z);
      dummy.rotation.set(0, random() * 6, 0);
      dummy.scale.set(2.6 + random() * 3.2, height, 2.6 + random() * 3.2);
      dummy.updateMatrix();
      distantTrees.setMatrixAt(i, dummy.matrix);
    }
    distantTrees.instanceMatrix.needsUpdate = true;
    scene.add(distantTrees);

    // Low understory foliage makes the floor a place rather than a plane.
    const shrubGeometry = new THREE.IcosahedronGeometry(1, 1);
    const shrubMaterial = new THREE.MeshStandardMaterial({
      color: 0x5e7b48,
      roughness: 1,
      flatShading: true,
    });
    const shrubs = new THREE.InstancedMesh(shrubGeometry, shrubMaterial, compact ? 130 : 210);
    for (let i = 0; i < shrubs.count; i += 1) {
      const angle = random() * Math.PI * 2;
      const radius = 5 + Math.pow(random(), 0.6) * 33;
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius + 3;
      const scale = 0.55 + random() * 2.2;
      dummy.position.set(x, 0.25 + random() * 0.7, z);
      dummy.rotation.set(random(), random() * 6, random());
      dummy.scale.set(scale * 1.35, scale, scale);
      dummy.updateMatrix();
      shrubs.setMatrixAt(i, dummy.matrix);
    }
    shrubs.instanceMatrix.needsUpdate = true;
    scene.add(shrubs);

    // Branch silhouettes in the middle storey.
    const branchGeometry = new THREE.CylinderGeometry(0.055, 0.13, 1, 5, 1);
    branchGeometry.translate(0, 0.5, 0);
    const branches = new THREE.InstancedMesh(branchGeometry, barkMaterial, 130);
    const branchUp = new THREE.Vector3(0, 1, 0);
    const branchDir = new THREE.Vector3();
    let branchIndex = 0;
    for (const tree of trees) {
      if (tree.h < 48) continue;
      for (let b = 0; b < 3 && branchIndex < 130; b += 1) {
        const height = tree.h * (0.44 + random() * 0.4);
        const angle = random() * Math.PI * 2;
        const length = 2.4 + random() * 3.8;
        branchDir.set(Math.cos(angle), 0.38 + random() * 0.3, Math.sin(angle)).normalize();
        dummy.position.set(tree.x, height, tree.z);
        dummy.quaternion.setFromUnitVectors(branchUp, branchDir);
        dummy.scale.set(tree.r * 0.8 + 0.3, length, tree.r * 0.8 + 0.3);
        dummy.updateMatrix();
        branches.setMatrixAt(branchIndex, dummy.matrix);
        branchIndex += 1;
      }
    }
    branches.count = branchIndex;
    branches.instanceMatrix.needsUpdate = true;
    scene.add(branches);

    // Forest floor, gently rolled, with moss patches.
    const groundGeometry = new THREE.PlaneGeometry(560, 560, 110, 110);
    groundGeometry.rotateX(-Math.PI / 2);
    const groundPositions = groundGeometry.getAttribute("position") as THREE.BufferAttribute;
    const groundColors: number[] = [];
    const lowColor = new THREE.Color("#263120");
    const highColor = new THREE.Color("#455232");
    for (let i = 0; i < groundPositions.count; i += 1) {
      const x = groundPositions.getX(i);
      const z = groundPositions.getZ(i);
      const radius = Math.hypot(x, z);
      const rise = Math.pow(Math.max(0, radius - 42) / 90, 1.7) * 22;
      const height =
        Math.sin(x * 0.11) * Math.cos(z * 0.09) * 0.55 +
        Math.sin(x * 0.31 + z * 0.22) * 0.18 +
        Math.cos(z * 0.13) * 0.35 +
        rise;
      groundPositions.setY(i, height);
      const blend = THREE.MathUtils.clamp((height + 0.7) / 2.4, 0, 1);
      const color = lowColor.clone().lerp(highColor, blend * 0.75);
      groundColors.push(color.r, color.g, color.b);
    }
    groundGeometry.setAttribute("color", new THREE.Float32BufferAttribute(groundColors, 3));
    groundGeometry.computeVertexNormals();
    const ground = new THREE.Mesh(
      groundGeometry,
      new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 1, metalness: 0 }),
    );
    ground.position.y = -0.04;
    scene.add(ground);

    // Ferns: crossed planes with a drawn frond, instanced across the floor.
    const fernTexture = makeFernTexture();
    const fernMaterial = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: fernTexture,
      alphaTest: 0.32,
      transparent: false,
      side: THREE.DoubleSide,
      roughness: 1,
    });
    const fernPlane = new THREE.PlaneGeometry(1, 1);
    fernPlane.translate(0, 0.5, 0);
    const fernGeometry = mergeGeometries([
      fernPlane.clone(),
      fernPlane.clone().rotateY(Math.PI / 2),
      fernPlane.clone().rotateY(Math.PI / 4),
    ]) as THREE.BufferGeometry;
    const fernCount = Math.round(760 * quality);
    const ferns = new THREE.InstancedMesh(fernGeometry, fernMaterial, fernCount);
    const fernColors = ["#4d7048", "#3d5f3d", "#5b7b4a", "#345739", "#678254"];
    for (let i = 0; i < fernCount; i += 1) {
      let x: number;
      let z: number;
      if (i < fernCount * 0.42) {
        const angle = random() * Math.PI * 2;
        const radius = 1 + Math.pow(random(), 0.7) * 17;
        x = Math.cos(angle) * radius;
        z = 4 + Math.sin(angle) * radius - random() * 16;
      } else {
        x = (random() - 0.5) * 74;
        z = (random() - 0.5) * 78 - 8;
      }
      const scale = 1.05 + random() * 3.4;
      dummy.position.set(x, 0.03, z);
      dummy.rotation.set(0, random() * Math.PI * 2, 0);
      dummy.scale.set(scale, scale * (0.7 + random() * 0.55), scale);
      dummy.updateMatrix();
      ferns.setMatrixAt(i, dummy.matrix);
      ferns.setColorAt(i, new THREE.Color(fernColors[(i * 3) % fernColors.length]));
    }
    ferns.instanceMatrix.needsUpdate = true;
    if (ferns.instanceColor) ferns.instanceColor.needsUpdate = true;
    scene.add(ferns);

    // Air: drifting mist sheets, pollen and a few shafts of light.
    const mistTexture = makeSoftTexture("rgba(240,246,225,0.5)");
    const mists: THREE.Sprite[] = [];
    for (let i = 0; i < (compact ? 7 : 12); i += 1) {
      const material = new THREE.SpriteMaterial({
        map: mistTexture,
        color: i % 2 ? "#dbe4cf" : "#c6d3c0",
        transparent: true,
        opacity: 0.17 + random() * 0.14,
        depthWrite: false,
        fog: true,
      });
      const sprite = new THREE.Sprite(material);
      sprite.position.set((random() - 0.5) * 74, 1.5 + random() * 34, -58 + random() * 70);
      const width = 30 + random() * 42;
      sprite.scale.set(width, width * (0.28 + random() * 0.2), 1);
      sprite.userData.baseX = sprite.position.x;
      sprite.userData.speed = 0.08 + random() * 0.14;
      sprite.userData.offset = random() * 10;
      mists.push(sprite);
      scene.add(sprite);
    }

    const moteTexture = makeDotTexture();
    const moteCount = Math.round(560 * quality);
    const motePositions = new Float32Array(moteCount * 3);
    const moteSeeds = new Float32Array(moteCount);
    for (let i = 0; i < moteCount; i += 1) {
      motePositions[i * 3] = (random() - 0.5) * 48;
      motePositions[i * 3 + 1] = random() * 44;
      motePositions[i * 3 + 2] = (random() - 0.5) * 68 - 10;
      moteSeeds[i] = random() * 10;
    }
    const moteGeometry = new THREE.BufferGeometry();
    moteGeometry.setAttribute("position", new THREE.BufferAttribute(motePositions, 3));
    const moteMaterial = new THREE.PointsMaterial({
      map: moteTexture,
      color: 0xffe9b4,
      size: 0.22,
      sizeAttenuation: true,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      fog: true,
    });
    const motes = new THREE.Points(moteGeometry, moteMaterial);
    scene.add(motes);

    const lightTexture = makeLightShaftTexture();
    const shaftMaterial = new THREE.MeshBasicMaterial({
      map: lightTexture,
      color: 0xffe8b6,
      transparent: true,
      opacity: 0.2,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      side: THREE.DoubleSide,
      fog: true,
    });
    const shafts: THREE.Mesh[] = [];
    const shaftData = [
      { x: -7, y: 31, z: -5, w: 12, h: 52, rz: 0.16, rx: -0.02 },
      { x: 4, y: 33, z: -20, w: 7, h: 45, rz: -0.13, rx: 0.06 },
      { x: -19, y: 34, z: 2, w: 17, h: 58, rz: 0.1, rx: -0.07 },
      { x: 13, y: 30, z: -35, w: 9, h: 40, rz: 0.2, rx: 0.04 },
    ];
    shaftData.forEach((data, index) => {
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(data.w, data.h), shaftMaterial.clone());
      mesh.material.opacity = 0.1 + index * 0.03;
      mesh.position.set(data.x, data.y, data.z);
      mesh.rotation.set(data.rx, 0, data.rz);
      shafts.push(mesh);
      scene.add(mesh);
    });

    // Floating birds, distant punctuation.
    const onPointerMove = (event: PointerEvent) => {
      pointer.x = (event.clientX / window.innerWidth) * 2 - 1;
      pointer.y = (event.clientY / window.innerHeight) * 2 - 1;
    };
    const onPointerLeave = () => {
      pointer.x = 0;
      pointer.y = 0;
    };
    window.addEventListener("pointermove", onPointerMove, { passive: true });
    document.documentElement.addEventListener("pointerleave", onPointerLeave);

    const resize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, width < 760 ? 1.4 : 1.8));
      renderer.setSize(width, height, false);
    };
    window.addEventListener("resize", resize);

    const heroTop = new THREE.Color(HERO_PALETTE.top);
    const floorTop = new THREE.Color(FLOOR_PALETTE.top);
    const heroHorizon = new THREE.Color(HERO_PALETTE.horizon);
    const floorHorizon = new THREE.Color(FLOOR_PALETTE.horizon);
    const heroBottom = new THREE.Color(HERO_PALETTE.bottom);
    const floorBottom = new THREE.Color(FLOOR_PALETTE.bottom);
    const heroFog = new THREE.Color(HERO_PALETTE.fog);
    const floorFog = new THREE.Color(FLOOR_PALETTE.fog);
    const workingColor = new THREE.Color();
    const currentTarget = new THREE.Vector3();
    const currentPosition = new THREE.Vector3();

    const render = () => {
      const dt = Math.min(clock.getDelta(), 0.05);
      const elapsed = clock.elapsedTime;
      const targetProgress = Math.min(1, Math.max(0, progressRef.current ?? 0));
      smoothProgress = reducedMotion
        ? targetProgress
        : THREE.MathUtils.damp(smoothProgress, targetProgress, 4.4, dt);
      const frame = sampleCamera(cameraPath, smoothProgress);

      current.x = reducedMotion ? 0 : THREE.MathUtils.damp(current.x, pointer.x, 2.6, dt);
      current.y = reducedMotion ? 0 : THREE.MathUtils.damp(current.y, pointer.y, 2.6, dt);
      const floatX = reducedMotion ? 0 : Math.sin(elapsed * 0.18) * 0.20;
      const floatY = reducedMotion ? 0 : Math.cos(elapsed * 0.22) * 0.16;
      currentPosition.copy(frame.position);
      currentPosition.x += floatX + current.x * 1.25;
      currentPosition.y += floatY - current.y * 0.55;
      camera.position.copy(currentPosition);
      currentTarget.copy(frame.look);
      currentTarget.x += current.x * 0.7;
      currentTarget.y -= current.y * 0.35;
      camera.lookAt(currentTarget);

      workingColor.copy(heroTop).lerp(floorTop, smoothProgress);
      skyMaterial.uniforms.uTop.value.copy(workingColor);
      workingColor.copy(heroHorizon).lerp(floorHorizon, smoothProgress);
      skyMaterial.uniforms.uHorizon.value.copy(workingColor);
      workingColor.copy(heroBottom).lerp(floorBottom, smoothProgress);
      skyMaterial.uniforms.uBottom.value.copy(workingColor);
      workingColor.copy(heroFog).lerp(floorFog, smoothProgress);
      (scene.fog as THREE.FogExp2).color.copy(workingColor);
      (scene.fog as THREE.FogExp2).density = frame.fog;
      renderer.toneMappingExposure = frame.exposure;
      sunMaterial.opacity = 0.8 * frame.sun;

      if (!reducedMotion) {
        mists.forEach((mist) => {
          mist.position.x =
            (mist.userData.baseX as number) +
            Math.sin(elapsed * (mist.userData.speed as number) + (mist.userData.offset as number)) * 4.5;
        });
        const positions = moteGeometry.getAttribute("position") as THREE.BufferAttribute;
        for (let i = 0; i < moteCount; i += 1) {
          const base = positions.getY(i);
          const seed = moteSeeds[i];
          positions.setY(i, 0.2 + ((base + elapsed * (0.12 + (seed % 1) * 0.15)) % 44));
          positions.setX(i, positions.getX(i) + Math.sin(elapsed * 0.12 + seed) * 0.0018);
        }
        positions.needsUpdate = true;
        motes.material.opacity = 0.42 + smoothProgress * 0.25;
        shafts.forEach((shaft, index) => {
          (shaft.material as THREE.MeshBasicMaterial).opacity =
            (0.09 + index * 0.025) * (0.72 + Math.sin(elapsed * 0.32 + index) * 0.24);
        });
      }

      sky.position.copy(camera.position);
      renderer.render(scene, camera);
      if (!hasPainted) {
        hasPainted = true;
        setReady(true);
      }
    };

    renderer.setAnimationLoop(render);
    resize();
    render();

    const onContextLost = (event: Event) => {
      event.preventDefault();
      setFailed(true);
    };
    canvas.addEventListener("webglcontextlost", onContextLost);

    return () => {
      renderer.setAnimationLoop(null);
      window.removeEventListener("pointermove", onPointerMove);
      document.documentElement.removeEventListener("pointerleave", onPointerLeave);
      window.removeEventListener("resize", resize);
      canvas.removeEventListener("webglcontextlost", onContextLost);
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Points || object instanceof THREE.Line) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => {
            if (material instanceof THREE.Material) material.dispose();
          });
        }
      });
      barkTexture.dispose();
      fernTexture.dispose();
      sunTexture.dispose();
      mistTexture.dispose();
      moteTexture.dispose();
      lightTexture.dispose();
      sunMaterial.dispose();
      renderer.dispose();
    };
  }, [progressRef, reducedMotion]);

  return (
    <div className="scene" aria-hidden="true">
      <div className="scene__poster" />
      <canvas ref={canvasRef} className={`scene__canvas${ready ? " is-ready" : ""}`} />
      <div className="scene__grain" />
      <div className="scene__vignette" />
      {failed ? (
        <div className="scene__status">
          Still view · move through the grove by scrolling the story
        </div>
      ) : null}
    </div>
  );
}
