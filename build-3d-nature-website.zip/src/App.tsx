import { useRef } from "react";
import Header from "./components/Header";
import DepthRail from "./components/DepthRail";
import { Descent, Hero } from "./components/Descent";
import { Anatomy, FogSection, RemainsSection, RootsSection } from "./components/StorySections";
import { Footer, Visit } from "./components/VisitFooter";
import { useReducedMotion, useReveal, useSceneProgress } from "./hooks/useScroll";
import { useForestSound } from "./hooks/useForestSound";
import RedwoodScene from "./scene/RedwoodScene";

export default function App() {
  const sceneTrackRef = useRef<HTMLDivElement>(null);
  const progressRef = useSceneProgress(sceneTrackRef);
  const reducedMotion = useReducedMotion();
  const sound = useForestSound();
  useReveal();

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to the field guide
      </a>
      <RedwoodScene progressRef={progressRef} reducedMotion={reducedMotion} />
      <Header sound={sound} />
      <DepthRail />
      <main id="main">
        <div id="scene-track" className="scene-track" ref={sceneTrackRef}>
          <Hero />
          <Descent />
        </div>
        <Anatomy />
        <FogSection />
        <RootsSection />
        <RemainsSection />
        <Visit sound={sound} />
      </main>
      <Footer />
    </>
  );
}
