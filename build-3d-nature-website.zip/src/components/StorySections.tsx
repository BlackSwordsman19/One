import { useState } from "react";
import { treeLayers } from "../data/content";

const branchLevels = Array.from({ length: 15 }, (_, i) => {
  const t = i / 14;
  const y = 88 + i * 28;
  const len = 18 + t * 88 - (i % 2) * 5;
  const dir = i % 2 === 0 ? -1 : 1;
  const clumpCount = i < 4 ? 2 : i < 9 ? 3 : 2;
  const clumps = Array.from({ length: clumpCount }, (_, c) => {
    const at = len * (0.36 + c * 0.32);
    const shrink = 1 - t * 0.45;
    return {
      at,
      rise: 3 + (c % 2) * 3,
      rx: (14 + (c === 1 ? 9 : 0)) * shrink,
      ry: (7 + (c === 1 ? 3 : 0)) * shrink,
    };
  });
  return { y, len, dir, width: 3.2 - t * 1.9, droop: 7 + t * 12, clumps };
});

function TreeGlyph({ active }: { active: string }) {
  const index = Math.max(0, treeLayers.findIndex((layer) => layer.id === active));
  const selected = treeLayers[index];
  return (
    <div className="tree-figure">
      <div className="tree-figure__scale" aria-hidden="true">
        <span>116 m</span>
        <span>0 m</span>
      </div>
      <div
        className="tree-figure__band"
        style={{ top: `${selected.top}%`, height: `${selected.height}%` }}
        aria-hidden="true"
      />
      <svg
        className="tree-figure__svg"
        viewBox="0 0 400 640"
        fill="none"
        role="img"
        aria-label={`A section drawing of a coast redwood with the ${selected.band.toLowerCase()} highlighted`}
      >
        <defs>
          <linearGradient id="bark-wash" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--bark-light)" />
            <stop offset="42%" stopColor="var(--bark)" />
            <stop offset="100%" stopColor="var(--bark-dark)" />
          </linearGradient>
          <linearGradient id="crown-fade" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--crown-light)" />
            <stop offset="100%" stopColor="var(--crown-deep)" />
          </linearGradient>
          <pattern id="soil-hatch" width="16" height="16" patternUnits="userSpaceOnUse">
            <path d="M0 16 16 0" stroke="var(--line-strong)" strokeWidth="0.5" />
          </pattern>
        </defs>

        <g stroke="var(--line)" strokeWidth="0.7" strokeDasharray="1 7" opacity="0.8">
          {[36, 128, 240, 356, 500, 584].map((y) => (
            <path key={y} d={`M26 ${y}H376`} />
          ))}
        </g>
        <g fill="var(--ink-faint)" fontFamily="var(--font-mono)" fontSize="8">
          <text x="4" y="31">116</text>
          <text x="4" y="123">94</text>
          <text x="4" y="235">62</text>
          <text x="4" y="351">22</text>
          <text x="6" y="579">0</text>
        </g>

        <path d="M22 584h356v48H22Z" fill="url(#soil-hatch)" opacity="0.36" />
        <path d="M22 584h356" stroke="var(--accent-dim)" strokeWidth="1" />
        <g stroke="var(--root)" strokeLinecap="round" fill="none">
          <path d="M174 584c-14 10-39 8-57 19-18 6-44 5-59 13" strokeWidth="4.4" />
          <path d="M226 584c14 10 39 8 57 19 18 6 44 5 59 13" strokeWidth="4.8" />
          <path d="M160 586c-18 5-37 15-52 26M240 586c18 5 37 15 51 26" strokeWidth="2.3" opacity="0.8" />
          <path d="M112 609c-14 3-23 9-33 14M288 609c14 3 23 9 33 14" strokeWidth="1.3" opacity="0.6" />
          <path d="M114 592c-3-8 3-14 10-16M285 592c3-8-3-14-10-16" strokeWidth="1" opacity="0.7" />
        </g>
        <g stroke="var(--fungus)" strokeWidth="0.8" opacity="0.66">
          <path d="M88 603c7-6 16-6 22-1M297 601c-6-5-14-5-19 0M139 616c5-4 11-4 15 0M254 616c-4-3-10-3-13 1" />
          <circle cx="100" cy="594" r="1.8" />
          <circle cx="303" cy="592" r="1.6" />
          <circle cx="250" cy="605" r="1.4" />
        </g>

        <g strokeLinecap="round">
          {branchLevels.map((branch) => (
            <g key={branch.y}>
              <path
                d={`M200 ${branch.y} C${200 + branch.dir * branch.len * 0.28} ${branch.y - 3}, ${200 + branch.dir * branch.len * 0.72} ${branch.y + branch.droop * 0.5}, ${200 + branch.dir * branch.len} ${branch.y + branch.droop}`}
                stroke="var(--bark-light)"
                strokeWidth={branch.width}
                opacity="0.88"
              />
              {branch.clumps.map((clump, clumpIndex) => (
                <g key={clumpIndex} opacity={0.82 + clumpIndex * 0.05}>
                  <ellipse
                    cx={200 + branch.dir * clump.at}
                    cy={branch.y + branch.droop * (clump.at / branch.len) - clump.rise}
                    rx={clump.rx}
                    ry={clump.ry}
                    fill="url(#crown-fade)"
                    transform={`rotate(${branch.dir * -6} ${200 + branch.dir * clump.at} ${branch.y})`}
                  />
                  <ellipse
                    cx={200 + branch.dir * clump.at - 4}
                    cy={branch.y + branch.droop * (clump.at / branch.len) - clump.rise - clump.ry * 0.5}
                    rx={clump.rx * 0.58}
                    ry={clump.ry * 0.55}
                    fill="var(--crown-light)"
                    opacity="0.28"
                  />
                </g>
              ))}
            </g>
          ))}
        </g>

        <path
          d="M194 40c3-5 7-7 11-2 4 7 5 33 6 66 1 48 3 108 5 170 2 81 3 176 4 310 0 13-37 13-37 0 0-134 1-229 3-310 1-62 1-122 1-170 1-33 3-59 7-64Z"
          fill="url(#bark-wash)"
          stroke="var(--bark-dark)"
          strokeWidth="1"
        />
        <path d="M200 54c1 58 2 127 3 199 1 92 1 206 1 331" stroke="var(--bark-ridge)" strokeWidth="1.4" opacity="0.55" />
        <path d="M210 130c0 60-1 129-2 203-1 91-1 176 0 251" stroke="var(--bark-light)" strokeWidth="0.7" opacity="0.35" />
        <path d="M182 540c-4 12-13 27-19 44M218 540c3 12 12 27 18 44" stroke="var(--bark-dark)" strokeWidth="1.2" opacity="0.7" />
        <g stroke="var(--bark-dark)" strokeWidth="0.6" opacity="0.34">
          <path d="M189 176c-3 18-1 35-2 53M196 298c-2 22-1 39 0 58M210 418c2 21 1 44 2 65M205 222c1 29 0 60 1 88M201 478c-1 17 0 32 1 46" />
        </g>

        <g fill="var(--crown-fade)">
          <ellipse cx="200" cy="26" rx="11" ry="20" />
          <ellipse cx="193" cy="48" rx="18" ry="13" opacity="0.92" />
          <ellipse cx="207" cy="58" rx="19" ry="12" opacity="0.9" />
          <ellipse cx="200" cy="76" rx="28" ry="14" opacity="0.9" />
          <ellipse cx="178" cy="94" rx="27" ry="12" opacity="0.8" />
          <ellipse cx="224" cy="98" rx="24" ry="11" opacity="0.82" />
        </g>
        <g fill="var(--crown-light)" opacity="0.36">
          <ellipse cx="197" cy="20" rx="4" ry="9" />
          <ellipse cx="192" cy="60" rx="6" ry="7" />
          <ellipse cx="178" cy="88" rx="8" ry="5" />
        </g>

        <g stroke="var(--root)" strokeWidth="1.1" strokeLinecap="round" fill="none" opacity="0.75">
          {[46, 74, 100, 130, 262, 294, 320, 348].map((x, i) => (
            <g key={x}>
              <path d={`M${x} 584c0-9 ${i % 2 === 0 ? -5 : 5}-13 ${i % 2 === 0 ? -10 : 10}-16`} />
              <path d={`M${x} 584c0-8 ${i % 2 === 0 ? 4 : -4}-12 ${i % 2 === 0 ? 8 : -8}-15`} />
            </g>
          ))}
        </g>
        <g fill="var(--fungus)" opacity="0.6">
          <circle cx="58" cy="578" r="1.6" />
          <circle cx="116" cy="576" r="1.2" />
          <circle cx="330" cy="577" r="1.5" />
        </g>
      </svg>
    </div>
  );
}

export function Anatomy() {
  const [active, setActive] = useState("canopy");
  const index = Math.max(0, treeLayers.findIndex((layer) => layer.id === active));
  const selected = treeLayers[index];
  const go = (direction: number) => {
    const next = (index + direction + treeLayers.length) % treeLayers.length;
    setActive(treeLayers[next].id);
  };

  return (
    <section id="anatomy" className="sheet sheet--anatomy">
      <div className="shell">
        <div className="section-intro section-intro--split">
          <h2>
            A hundred metres,
            <br />
            read from the ground up.
          </h2>
          <div>
            <p>
              An old-growth redwood is not one habitat but a stack of them. Each height has its own
              light, moisture and weather. Choose a layer to look closer.
            </p>
            <p className="section-intro__hint">
              Select any band on the tree <span aria-hidden="true">↘</span>
            </p>
          </div>
        </div>

        <div className="anatomy-grid">
          <div className="tree-stage">
            <TreeGlyph active={active} />
            <div className="tree-bands">
              {treeLayers.map((layer, layerIndex) => (
                <button
                  key={layer.id}
                  type="button"
                  className={`tree-band${layer.id === active ? " is-active" : ""}${layerIndex % 2 === 0 ? " tree-band--left" : " tree-band--right"}`}
                  style={{ top: `${layer.top + layer.height / 2}%` }}
                  onClick={() => setActive(layer.id)}
                  aria-pressed={layer.id === active}
                  aria-controls="layer-detail"
                >
                  <span className="tree-band__line" aria-hidden="true" />
                  <span className="tree-band__node" aria-hidden="true" />
                  <span className="tree-band__label">
                    <strong>{layer.band}</strong>
                    <span>{layer.metres}</span>
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="layer-panel" id="layer-detail">
            <div className="layer-panel__top" key={selected.id}>
              <p className="layer-panel__index">
                Layer {String(index + 1).padStart(2, "0")} <i /> {selected.metres}
              </p>
              <h3>{selected.title}</h3>
              <p className="layer-panel__body">{selected.body}</p>
              <div className="layer-panel__fact">
                <span>Field note</span>
                <p>{selected.fact}</p>
              </div>
            </div>
            <div className="layer-panel__controls">
              <button type="button" onClick={() => go(-1)} aria-label="Previous layer">
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M19 12H5m6-6-6 6 6 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                <span>Previous</span>
              </button>
              <span aria-hidden="true" className="layer-panel__dashes">
                {treeLayers.map((layer) => (
                  <i key={layer.id} className={layer.id === active ? "is-active" : ""} />
                ))}
              </span>
              <button type="button" onClick={() => go(1)} aria-label="Next layer">
                <span>Next</span>
                <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <path d="M5 12h14m-6-6 6 6-6 6" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </button>
            </div>
          </div>
        </div>

        <p className="source-line">
          A reading of <i>Sequoia sempervirens</i>, based on the National Park Service and Save the
          Redwoods League. <a href="#sources">Full sources</a>.
        </p>
      </div>
    </section>
  );
}

export function FogSection() {
  const drops = Array.from({ length: 16 }, (_, i) => i);
  return (
    <section id="water" className="fog-section" aria-labelledby="fog-title">
      <div className="fog-section__media">
        <img
          src="/images/redwood-fog.jpg"
          alt="Mist drifting between the trunks of a redwood grove"
          loading="lazy"
        />
      </div>
      <div className="fog-section__scrim" aria-hidden="true" />
      <div className="fog-section__drops" aria-hidden="true">
        {drops.map((drop) => (
          <i
            key={drop}
            style={{
              left: `${7 + drop * 5.7}%`,
              animationDelay: `${(drop % 8) * 1.6}s`,
              animationDuration: `${10 + (drop % 5) * 2.5}s`,
              opacity: 0.15 + (drop % 4) * 0.08,
            }}
          />
        ))}
      </div>
      <div className="shell fog-section__inner">
        <div className="fog-section__copy" data-reveal>
          <h2 id="fog-title">
            The forest
            <br />
            drinks from
            <br />
            the sky.
          </h2>
          <p className="fog-section__kicker">Summer, Pacific coast</p>
          <p className="fog-section__lede">
            For months each year, a cold fog rolls in from the Pacific and settles in the canopy.
            Redwood needles comb it out of the air. What the crown does not use falls, cool and
            slow, onto the forest floor.
          </p>
          <div className="water-ledger" aria-label="Fog can provide up to 40 percent of a redwood's annual water">
            <div className="water-ledger__number">
              <strong>40</strong>
              <span>%</span>
            </div>
            <div className="water-ledger__detail">
              <p>of a redwood&rsquo;s yearly water can arrive as fog</p>
              <div className="water-ledger__bar" aria-hidden="true">
                <span />
                <i />
              </div>
              <div className="water-ledger__keys">
                <span>Fog</span>
                <span>Rain &amp; soil</span>
              </div>
            </div>
          </div>
          <p className="fog-section__source">
            National Park Service estimates up to 40 percent. Fog also waters the understory and
            keeps the forest cool.
          </p>
        </div>
        <p className="fog-section__credit">
          Mist in the grove, Pacific Northwest
          <span>Photo: Ambient Vista, Pexels</span>
        </p>
      </div>
    </section>
  );
}

export function RootsSection() {
  return (
    <section id="roots" className="sheet sheet--roots">
      <div className="shell">
        <div className="section-intro section-intro--split section-intro--roots">
          <h2>
            The tree
            <br />
            below the tree.
          </h2>
          <div>
            <p>
              A coast redwood holds its height above the ground with a wide, shallow root plate. The
              roots reach outward, not down, and meet the roots of the trees beside it. The grove
              leans on itself.
            </p>
            <p className="section-intro__hint">The lower third of this page is a shared foundation.</p>
          </div>
        </div>

        <div className="root-figure" data-reveal>
          <svg viewBox="0 0 1200 470" fill="none" role="img" aria-label="Diagram of a redwood's shallow, wide root system and the fungal threads around it">
            <defs>
              <linearGradient id="soil-fade" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="var(--soil-top)" />
                <stop offset="100%" stopColor="var(--soil-deep)" />
              </linearGradient>
              <pattern id="fine-soil" width="9" height="9" patternUnits="userSpaceOnUse">
                <circle cx="2" cy="2" r="0.7" fill="var(--root-faint)" />
                <circle cx="7" cy="6" r="0.4" fill="var(--root-faint)" />
              </pattern>
            </defs>
            <g>
              <path d="M0 124h1200v346H0Z" fill="url(#soil-fade)" />
              <path d="M0 124h1200v346H0Z" fill="url(#fine-soil)" opacity="0.9" />
              <path d="M0 124h1200" stroke="var(--accent-dim)" strokeWidth="1" opacity="0.5" />
              {Array.from({ length: 24 }, (_, i) => (
                <path
                  key={i}
                  d={`M${i * 54 + 14} 124v${i % 3 === 0 ? 12 : 7}`}
                  stroke="var(--root-faint)"
                  strokeWidth="0.8"
                />
              ))}
            </g>

            <g>
              <path d="M552 0h96l10 102c2 14 7 17 24 25-10 22-17 39-17 64 0 29 11 47 23 70 17 31 23 63 14 91H500c-9-28-3-60 14-91 12-23 23-41 23-70 0-25-7-42-17-64 17-8 22-11 24-25Z" fill="var(--bark)" opacity="0.88" />
              <path d="M560 0h12l8 104c2 13 9 17 22 24-12 23-17 41-17 63 0 30 12 48 22 72 14 29 17 55 12 84h-70c-5-29 1-55 14-84 11-24 23-42 23-72 0-22-5-40-17-63 13-7 19-11 20-24Z" fill="var(--bark-light)" opacity="0.3" />
              <path d="M548 0h8v112c0 13-8 17-20 23 11 26 18 45 18 69 0 31-13 49-25 75-15 30-18 58-12 88h-20c-11-33-6-65 11-98 12-22 23-40 23-65 0-24-8-43-22-69 14-6 22-12 23-25Z" fill="var(--bark-dark)" opacity="0.55" />
            </g>

            <g className="root-lines" stroke="var(--root)" strokeLinecap="round" fill="none">
              <path d="M526 336c-31 13-82 8-120 26-47 22-104 13-161 34-34 13-71 12-105 34" strokeWidth="8" />
              <path d="M674 336c31 13 82 8 120 26 47 22 104 13 161 34 34 13 71 12 105 34" strokeWidth="9" />
              <path d="M548 366c-32 19-63 19-105 31-29 9-63 23-87 46-25 16-56 17-82 27" strokeWidth="5" />
              <path d="M652 366c32 19 63 19 105 31 29 9 63 23 87 46 25 16 56 17 82 27" strokeWidth="5.5" />
              <path d="M548 397c-27 21-55 32-79 63-14 15-39 18-64 20M652 397c27 21 55 32 79 63 14 15 39 18 64 20" strokeWidth="2.6" opacity="0.8" />
              <path d="M586 337c-4 41-13 73-13 119M614 337c4 41 13 73 13 119" strokeWidth="4" opacity="0.65" />
              <path d="M486 351c-15 36-41 58-70 87M714 351c15 36 41 58 70 87" strokeWidth="2" opacity="0.65" />
              <path d="M417 393c-17 25-37 37-55 62M783 393c17 25 37 37 55 62" strokeWidth="1.2" opacity="0.6" />
              <path d="M115 357c53 4 85 18 119 21M1085 357c-53 4-85 18-119 21" strokeWidth="1.2" opacity="0.55" />
            </g>

            <g stroke="var(--fungus)" strokeWidth="1" fill="none" opacity="0.82">
              <path d="M239 385c20-26 46-30 66-51 13-16 38-18 59-10M306 410c20-13 44-8 64 6M911 380c-17-22-43-27-61-46-14-15-36-16-54-9M877 417c-19-10-38-9-55 3" />
              {[187, 268, 401, 505, 723, 856, 953, 1042, 603, 326, 875].map((x, i) => (
                <circle key={x} cx={x} cy={375 + ((i * 17) % 75)} r={i % 3 === 0 ? 3.4 : 2} opacity="0.85" />
              ))}
              {Array.from({ length: 18 }, (_, i) => (
                <path
                  key={i}
                  d={`M${90 + i * 58} ${447 + (i % 3) * 9}c8-8 14-16 20-29M${120 + i * 58} ${449 + (i % 4) * 8}c-5-7-8-15-11-24`}
                  opacity="0.52"
                />
              ))}
            </g>

            <g fontFamily="var(--font-mono)" fontSize="11" fill="var(--ink-faint)">
              <text x="36" y="112">the grove floor · 0 m</text>
              <text x="930" y="112">root plate · 3 to 4 m deep</text>
              <path d="M878 106h-132" stroke="var(--ink-faint)" strokeWidth="0.8" />
            </g>
          </svg>
        </div>

        <div className="root-notes">
          <article>
            <p className="root-notes__index">01</p>
            <h3>Wide, not deep</h3>
            <p>
              Roots usually stay in the top three to four metres of soil, spreading eighteen to
              twenty-four metres sideways. Neighbouring root plates overlap.
            </p>
          </article>
          <article>
            <p className="root-notes__index">02</p>
            <h3>A trade below ground</h3>
            <p>
              Mycorrhizal fungi thread through the soil and root tips, trading water and minerals
              for sugars. The underground grove is a market as much as a web.
            </p>
          </article>
          <article>
            <p className="root-notes__index">03</p>
            <h3>A fall is a beginning</h3>
            <p>
              A fallen redwood can become a nurse log. Seedlings root in its softening wood, lining
              up along the trunk like children on a bench.
            </p>
          </article>
        </div>
        <p className="source-line">
          Root dimensions from the National Park Service. Mycorrhizal relationships are described
          in current redwood forest research. <a href="#sources">See sources</a>.
        </p>
      </div>
    </section>
  );
}

export function RemainsSection() {
  return (
    <section id="remains" className="sheet sheet--pale" aria-labelledby="remains-title">
      <div className="shell">
        <div className="remains-head">
          <h2 id="remains-title">
            What remains
            <br />
            is still a world.
          </h2>
          <p>
            Old-growth coast redwood forest once ran along hundreds of miles of coast. An estimated
            96 percent of it was logged. What is left is an irreplaceable fragment, and a lesson in
            how long a forest takes.
          </p>
        </div>

        <div className="remains-grid">
          <div className="remains-data">
            <div className="percent-grid" aria-hidden="true">
              {Array.from({ length: 100 }, (_, i) => (
                <i key={i} className={i < 4 ? "is-filled" : ""} />
              ))}
            </div>
            <p className="percent-caption">
              <span>4 in 100</span>
              squares represent the old-growth coast redwood forest that remains. Less than 5% of
              the original extent.
            </p>
            <dl className="remains-facts">
              <div>
                <dt>A life span</dt>
                <dd>2,000+ years</dd>
              </div>
              <div>
                <dt>The tallest known</dt>
                <dd>116 metres</dd>
              </div>
            </dl>
            <a className="button button--dark" href="#visit">
              Find a grove that still stands
            </a>
          </div>

          <figure className="remains-figure">
            <div className="remains-figure__image">
              <img
                src="/images/canopy-up.jpg"
                alt="Sunlight filtering through the high canopy of tall redwood trees"
                loading="lazy"
              />
            </div>
            <figcaption>
              <span>Looking up, not down</span>
              Old-growth redwood is protected in parks, but a forest of this age cannot be
              replanted quickly. The most important thing is the one that still stands.
              <i>Photo: John Hanson, Pexels</i>
            </figcaption>
          </figure>
        </div>
        <p className="source-line source-line--dark">
          Logging estimate: National Park Service. The IUCN lists coast redwood as endangered.
        </p>
      </div>
    </section>
  );
}
