import { useState } from "react";
import { groves, sources } from "../data/content";
import { SoundButton } from "./Header";
import type { useForestSound } from "../hooks/useForestSound";

type SoundState = ReturnType<typeof useForestSound>;

const fallbackImages = [
  { image: "/images/forest-path.jpg", credit: "Frank Minjarez / Pexels" },
  { image: "/images/redwood-fog.jpg", credit: "Ambient Vista / Pexels" },
  { image: "/images/grove-path.jpg", credit: "ArtHouse Studio / Pexels" },
  { image: "/images/canopy-up.jpg", credit: "John Hanson / Pexels" },
];

function CaliforniaMap({
  active,
  onSelect,
}: {
  active: number;
  onSelect: (index: number) => void;
}) {
  const pins = [
    { x: 64, y: 45, label: "Redwood National and State Parks" },
    { x: 72, y: 132, label: "Humboldt Redwoods State Park" },
    { x: 102, y: 226, label: "Muir Woods National Monument" },
    { x: 115, y: 248, label: "Big Basin Redwoods State Park" },
  ];
  return (
    <div className="grove-map">
      <svg viewBox="0 0 280 390" role="group" aria-label="A rough map of California with four redwood parks marked">
        <path
          d="M28 6 138 18l34 34 19 25 9 41-25 31-6 33 19 35-11 37-23 36-17 46-12 34-30-15-22-42-29-34-9-40 25-45 16-53-2-50 17-43Z"
          fill="var(--map-fill)"
          stroke="var(--map-line)"
          strokeWidth="1.4"
        />
        <path d="M28 6 138 18l34 34 19 25 9 41" fill="none" stroke="var(--map-coast)" strokeWidth="2.4" strokeLinecap="round" />
        <g stroke="var(--map-line)" strokeWidth="0.7" opacity="0.5">
          <path d="M36 86h74M42 131h90M54 176h74M63 269h73M58 315h62M72 348h45" />
          <path d="M168 72h46M178 112h41M184 151h36M174 210h34M166 285h27" />
        </g>
        <text x="200" y="345" fill="var(--map-label)" fontFamily="var(--font-body)" fontSize="10">
          California
        </text>
        <text x="48" y="26" fill="var(--map-label)" fontFamily="var(--font-body)" fontSize="10">
          Oregon border
        </text>
        <text x="26" y="240" fill="var(--map-label)" fontFamily="var(--font-body)" fontSize="9" transform="rotate(-62 26 240)">
          Pacific coast
        </text>
        {pins.map((pin, index) => (
          <g
            key={pin.label}
            className={`grove-map__pin${index === active ? " is-active" : ""}`}
            onClick={() => onSelect(index)}
            onKeyDown={(event) => {
              if (event.key === "Enter" || event.key === " ") onSelect(index);
            }}
            role="button"
            tabIndex={0}
            aria-label={`Show ${pin.label}`}
            aria-pressed={index === active}
          >
            <circle cx={pin.x} cy={pin.y} r={index === active ? 12 : 8} className="grove-map__halo" />
            <circle cx={pin.x} cy={pin.y} r={index === active ? 4.2 : 3} className="grove-map__dot" />
            <text x={pin.x + 12} y={pin.y + 4} className="grove-map__num" fontFamily="var(--font-mono)" fontSize="11">
              {String(index + 1).padStart(2, "0")}
            </text>
          </g>
        ))}
      </svg>
      <p>
        Not to scale. The coast redwood grows in a narrow fog belt, from southwest Oregon to the Big
        Sur coast.
      </p>
    </div>
  );
}

export function Visit({ sound }: { sound: SoundState }) {
  const [active, setActive] = useState(1);
  const grove = groves[active];
  const fallback = fallbackImages[active % fallbackImages.length];
  const image = grove.image ?? fallback.image;
  const credit = grove.credit ?? fallback.credit;

  return (
    <section id="visit" className="visit" aria-labelledby="visit-title">
      <div className="shell">
        <div className="visit-head">
          <h2 id="visit-title">
            Go stand
            <br />
            beneath one.
          </h2>
          <div className="visit-head__aside">
            <p>
              You do not have to travel far to meet old growth. You have to arrive quietly, look up,
              and then look down. Four places to begin.
            </p>
            <SoundButton sound={sound} />
          </div>
        </div>

        <div className="visit-grid">
          <div className="visit-list-wrap">
            <CaliforniaMap active={active} onSelect={setActive} />
            <div className="visit-list" role="group" aria-label="Choose a redwood grove">
              {groves.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  className={`visit-row${index === active ? " is-active" : ""}`}
                  onClick={() => setActive(index)}
                  aria-pressed={index === active}
                  aria-controls="grove-detail"
                >
                  <span className="visit-row__index">{String(index + 1).padStart(2, "0")}</span>
                  <span className="visit-row__name">
                    <strong>{item.name}</strong>
                    <span>{item.place}</span>
                  </span>
                  <span className="visit-row__coords">
                    {item.lat}
                    <br />
                    {item.lon}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <article className="grove-detail" id="grove-detail">
            <div className="grove-detail__media">
              <img src={image} alt={grove.alt ?? "Redwood forest scenery"} loading="lazy" />
              <span>{String(active + 1).padStart(2, "0")} / 04</span>
            </div>
            <div className="grove-detail__body" key={grove.id}>
              <h3>{grove.name}</h3>
              <p className="grove-detail__place">{grove.place}</p>
              <p>{grove.note}</p>
              <div className="grove-detail__foot">
                <a className="button button--small button--light" href={grove.url} target="_blank" rel="noreferrer">
                  Park website
                  <svg viewBox="0 0 16 16" fill="none" aria-hidden="true">
                    <path d="M4 12 12 4M6 4h6v6" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </a>
                <span>Photo: {credit}</span>
              </div>
            </div>
          </article>
        </div>

        <div className="visit-notes">
          <p className="visit-notes__title">Before you go</p>
          <div className="visit-notes__grid">
            <p>
              <strong>Early, if you can.</strong> Summer fog usually lifts by midday. The quiet
              arrives before the crowds.
            </p>
            <p>
              <strong>Check access.</strong> Some parks require parking reservations or have trail
              closures after storms and fire.
            </p>
            <p>
              <strong>Stay on the trail.</strong> Redwood roots lie close to the surface. A
              shortcut can outlast your visit.
            </p>
          </div>
        </div>

        <figure className="visit-closing">
          <img src="/images/moss-fern.jpg" alt="Ferns and moss growing along a fallen branch on the forest floor" loading="lazy" />
          <figcaption>
            <span>The floor is not the bottom.</span>
            <p>It is the beginning of the next forest. Photo: Steve B / Pexels.</p>
          </figcaption>
        </figure>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer id="sources" className="site-footer">
      <div className="shell">
        <div className="site-footer__top">
          <div>
            <a className="wordmark wordmark--footer" href="#top">
              <span className="wordmark__type">Understory</span>
            </a>
            <p className="site-footer__statement">
              A vertical field guide to the coast redwood. Read from the crown down, then go and
              meet one in person.
            </p>
          </div>
          <div className="site-footer__back">
            <a className="text-link" href="#top">
              Back to the canopy
            </a>
            <p>One page, five layers, one very tall tree.</p>
          </div>
        </div>

        <div className="site-footer__grid">
          <div>
            <h2>Sources &amp; further reading</h2>
            <ul>
              {sources.map((source) => (
                <li key={source.url}>
                  <a href={source.url} target="_blank" rel="noreferrer">
                    {source.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2>Photographs</h2>
            <ul>
              <li>Frank Minjarez — trail and grove</li>
              <li>Ambient Vista — coastal mist</li>
              <li>ArtHouse Studio — the long path</li>
              <li>John Hanson — looking up in Mill Valley</li>
              <li>Steve B — ferns on a fallen branch</li>
            </ul>
            <p className="site-footer__small">All photographs via Pexels. Used with credit.</p>
          </div>
          <div>
            <h2>Colophon</h2>
            <p>
              Set in Bricolage Grotesque and Hanken Grotesk, with DM Mono for measurements. The
              forest is a real-time WebGL scene; if your device cannot draw it, the photographs and
              words remain.
            </p>
            <p className="site-footer__small">
              An independent, non-commercial field guide. No trackers, no newsletter, no cookies.
            </p>
          </div>
        </div>

        <div className="site-footer__bottom">
          <p>Understory · 2026</p>
          <p>Facts checked against the National Park Service and Save the Redwoods League.</p>
          <p>Pacific coast, 41° N.</p>
        </div>
      </div>
    </footer>
  );
}
