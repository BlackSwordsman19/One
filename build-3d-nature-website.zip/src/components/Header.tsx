import { useEffect, useState } from "react";
import { usePageChrome } from "../hooks/useScroll";
import type { useForestSound } from "../hooks/useForestSound";

type SoundState = ReturnType<typeof useForestSound>;

const links = [
  { href: "#descent", label: "The descent" },
  { href: "#anatomy", label: "Anatomy" },
  { href: "#water", label: "Fog" },
  { href: "#roots", label: "Underground" },
  { href: "#visit", label: "Visit" },
];

export function GroveMark({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 40 44" aria-hidden="true" fill="none">
      <path d="M20 40V17" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      <path
        d="M20 23 8 12M20 23l12-11M20 31 11 22M20 31l9-9M20 36l-6-6M20 36l6-6"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M20 17c-5.7-1.8-8.4-6.6-8.2-12 5.5.8 8.4 5 8.2 12Zm0 0c5.7-1.8 8.4-6.6 8.2-12-5.5.8-8.4 5-8.2 12Z"
        fill="currentColor"
      />
    </svg>
  );
}

export function SoundButton({ sound, compact = false }: { sound: SoundState; compact?: boolean }) {
  return (
    <button
      type="button"
      className={`sound-button${sound.on ? " is-playing" : ""}${compact ? " sound-button--compact" : ""}`}
      onClick={sound.toggle}
      aria-pressed={sound.on}
      aria-label={sound.on ? "Turn grove sound off" : "Turn grove sound on"}
      disabled={sound.starting}
    >
      <span className="sound-button__bars" aria-hidden="true">
        <i />
        <i />
        <i />
        <i />
      </span>
      <span className="sound-button__label">
        {sound.starting ? "Opening the grove" : sound.on ? "Grove sound on" : "Grove sound"}
      </span>
    </button>
  );
}

export default function Header({ sound }: { sound: SoundState }) {
  const { scrollY } = usePageChrome();
  const [menuOpen, setMenuOpen] = useState(false);
  const scrolled = scrollY > 36;

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, []);

  return (
    <header className={`site-header${scrolled ? " is-solid" : ""}${menuOpen ? " is-open" : ""}`}>
      <div className="site-header__inner">
        <a className="wordmark" href="#top" aria-label="Understory, back to the top">
          <GroveMark className="wordmark__mark" />
          <span className="wordmark__type">Understory</span>
        </a>

        <nav className="site-nav" aria-label="Primary">
          {links.map((link) => (
            <a key={link.href} href={link.href}>
              {link.label}
            </a>
          ))}
        </nav>

        <div className="site-header__actions">
          <SoundButton sound={sound} />
          <a className="button button--small button--light" href="#visit">
            Find a grove
          </a>
          <button
            type="button"
            className="menu-button"
            aria-expanded={menuOpen}
            aria-controls="mobile-menu"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span>{menuOpen ? "Close" : "Menu"}</span>
            <span className={`menu-button__icon${menuOpen ? " is-open" : ""}`} aria-hidden="true">
              <i />
              <i />
            </span>
          </button>
        </div>
      </div>

      <div
        className={`mobile-menu${menuOpen ? " is-open" : ""}`}
        id="mobile-menu"
        aria-hidden={!menuOpen}
        inert={!menuOpen}
      >
        <div className="mobile-menu__inner">
          <nav aria-label="Mobile">
            {links.map((link, index) => (
              <a
                key={link.href}
                href={link.href}
                tabIndex={menuOpen ? 0 : -1}
                onClick={() => setMenuOpen(false)}
              >
                <span className="mobile-menu__index" aria-hidden="true">
                  {String(index + 1).padStart(2, "0")}
                </span>
                {link.label}
              </a>
            ))}
          </nav>
          <div className="mobile-menu__foot">
            <p>
              A field guide to the coast redwood. Read it from the crown down, then go get your feet
              wet.
            </p>
            <SoundButton sound={sound} compact />
          </div>
        </div>
      </div>
    </header>
  );
}
