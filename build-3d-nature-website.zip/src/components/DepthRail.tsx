import { useEffect, useState } from "react";
import { descentChapters } from "../data/content";

export default function DepthRail() {
  const [depth, setDepth] = useState(116);
  const [visible, setVisible] = useState(true);
  const [active, setActive] = useState(0);

  useEffect(() => {
    let frame = 0;
    const update = () => {
      frame = 0;
      const track = document.getElementById("scene-track");
      const descent = document.getElementById("descent");
      if (!track || !descent) return;
      const start = track.offsetTop;
      const end = track.offsetTop + track.offsetHeight - window.innerHeight;
      const progress = Math.min(1, Math.max(0, (window.scrollY - start) / Math.max(1, end - start)));
      setDepth(Math.round(116 * (1 - progress)));
      const descentTop = descent.offsetTop;
      const descentHeight = Math.max(1, descent.offsetHeight - window.innerHeight);
      const chapterProgress = Math.min(1, Math.max(0, (window.scrollY - descentTop) / descentHeight));
      setActive(Math.min(descentChapters.length - 1, Math.floor(chapterProgress * descentChapters.length)));
      const inDescent = window.scrollY > start + window.innerHeight * 0.55;
      setVisible(inDescent && window.scrollY < end - window.innerHeight * 0.12);
    };
    const onScroll = () => {
      if (!frame) frame = window.requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (frame) window.cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <div className={`depth-rail${visible ? " is-visible" : ""}`} aria-hidden="true">
      <div className="depth-rail__readout">
        <span className="depth-rail__value">{String(depth).padStart(3, "0")}</span>
        <span className="depth-rail__unit">
          metres above
          <br />
          the forest floor
        </span>
      </div>
      <div className="depth-rail__scale">
        <div className="depth-rail__track">
          <span
            className="depth-rail__fill"
            style={{ transform: `scaleY(${Math.max(0.016, (116 - depth) / 116)})` }}
          />
          <span
            className="depth-rail__thumb"
            style={{ top: `${Math.min(100, Math.max(0, ((116 - depth) / 116) * 100))}%` }}
          />
        </div>
        <ol className="depth-rail__ticks">
          {descentChapters.map((chapter, index) => (
            <li key={chapter.id} className={index === active ? "is-active" : ""}>
              <span>{chapter.altitude}</span>
              {chapter.id === "crown" ? <b>crown</b> : null}
              {chapter.id === "floor" ? <b>forest floor</b> : null}
            </li>
          ))}
        </ol>
      </div>
    </div>
  );
}
