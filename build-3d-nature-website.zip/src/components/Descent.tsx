import { descentChapters } from "../data/content";

export function Hero() {
  return (
    <section className="hero" id="top" aria-labelledby="hero-title">
      <div className="hero__inner shell">
        <div className="hero__copy">
          <p className="hero__species">
            <span>Coast redwood</span>
            <i aria-hidden="true" />
            <span>Sequoia sempervirens</span>
          </p>
          <h1 id="hero-title" className="hero__title">
            <span>Some trees</span>
            <span>make their</span>
            <span>own weather.</span>
          </h1>
          <p className="hero__lede">
            A field guide to the tallest living thing on Earth: from the fog in its crown to the
            fungal web beneath the forest floor.
          </p>
          <div className="hero__actions">
            <a className="button button--primary" href="#descent">
              Begin the descent
            </a>
            <a className="button button--ghost" href="#visit">
              Find a place to stand
            </a>
          </div>
        </div>

        <div className="hero__aside">
          <p className="hero__measure">
            <span>Height</span>
            <strong>116<small>m</small></strong>
            <em>the tallest known coast redwood</em>
          </p>
          <p className="hero__place">
            <span>Pacific coast</span>
            <strong>41° N</strong>
            <em>a narrow belt of summer fog</em>
          </p>
        </div>

        <div className="hero__base">
          <p className="hero__scroll">
            <span>Scroll to descend</span>
            <i aria-hidden="true" />
          </p>
          <p className="hero__caption">
            An interactive field guide
            <br />
            to old-growth forest
          </p>
        </div>
      </div>
    </section>
  );
}

export function Descent() {
  return (
    <section id="descent" className="descent" aria-labelledby="descent-title">
      <div className="descent__header shell">
        <p className="descent__chapter-label">The descent</p>
        <h2 id="descent-title" className="sr-only">
          A descent through the coast redwood
        </h2>
      </div>
      {descentChapters.map((chapter, index) => (
        <article
          key={chapter.id}
          id={chapter.id}
          className={`chapter chapter--${chapter.side}`}
          aria-labelledby={`chapter-${chapter.id}`}
        >
          <div className="chapter__inner shell">
            <div className="chapter__plate" data-reveal>
              <div className="chapter__meter">
                <span className="chapter__altitude">
                  {chapter.altitude}
                  <small>{chapter.metres === 0 ? "the forest floor" : "above the forest floor"}</small>
                </span>
                <span className="chapter__count">
                  {String(index + 1).padStart(2, "0")} <i /> {String(descentChapters.length).padStart(2, "0")}
                </span>
              </div>
              <h3 id={`chapter-${chapter.id}`} className="chapter__title">
                {chapter.title}
              </h3>
              <p className="chapter__body">{chapter.body}</p>
              <p className="chapter__note">
                <span aria-hidden="true" />
                {chapter.note}
              </p>
            </div>
          </div>
        </article>
      ))}
      <div className="descent__end shell">
        <p>
          Keep going.
          <span> What holds the tree up lives below it.</span>
        </p>
        <a className="text-link" href="#anatomy">
          Read the anatomy
        </a>
      </div>
    </section>
  );
}
