import { useCallback, useEffect, useRef, useState } from "react";

type Grove = {
  ctx: AudioContext;
  master: GainNode;
  windGain: GainNode;
  shimmerGain: GainNode;
  interval?: number;
};

function createNoiseBuffer(ctx: AudioContext) {
  const buffer = ctx.createBuffer(1, ctx.sampleRate * 5, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < data.length; i += 1) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.02 * white) / 1.02;
    data[i] = last * 3.4;
  }
  return buffer;
}

export function useForestSound() {
  const [on, setOn] = useState(false);
  const [starting, setStarting] = useState(false);
  const groveRef = useRef<Grove | null>(null);

  const stop = useCallback(() => {
    const grove = groveRef.current;
    if (!grove) return;
    const now = grove.ctx.currentTime;
    grove.master.gain.cancelScheduledValues(now);
    grove.master.gain.setTargetAtTime(0.0001, now, 0.2);
    if (grove.interval) window.clearInterval(grove.interval);
    window.setTimeout(() => {
      void grove.ctx.close();
      if (groveRef.current === grove) groveRef.current = null;
    }, 700);
    setOn(false);
  }, []);

  const start = useCallback(async () => {
    if (groveRef.current) return;
    const AudioCtor = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtor) return;
    setStarting(true);
    try {
      const ctx = new AudioCtor();
      await ctx.resume();
      const master = ctx.createGain();
      master.gain.setValueAtTime(0.0001, ctx.currentTime);
      master.gain.exponentialRampToValueAtTime(0.16, ctx.currentTime + 2.4);
      master.connect(ctx.destination);

      const wind = ctx.createBufferSource();
      wind.buffer = createNoiseBuffer(ctx);
      wind.loop = true;
      const windFilter = ctx.createBiquadFilter();
      windFilter.type = "lowpass";
      windFilter.frequency.value = 620;
      windFilter.Q.value = 0.55;
      const windGain = ctx.createGain();
      windGain.gain.value = 0.36;
      wind.connect(windFilter).connect(windGain).connect(master);
      wind.start();

      const shimmer = ctx.createBufferSource();
      shimmer.buffer = createNoiseBuffer(ctx);
      shimmer.loop = true;
      const shimmerFilter = ctx.createBiquadFilter();
      shimmerFilter.type = "bandpass";
      shimmerFilter.frequency.value = 2600;
      shimmerFilter.Q.value = 1.1;
      const shimmerGain = ctx.createGain();
      shimmerGain.gain.value = 0.024;
      shimmer.connect(shimmerFilter).connect(shimmerGain).connect(master);
      shimmer.start();

      const lfo = ctx.createOscillator();
      lfo.frequency.value = 0.07;
      const lfoGain = ctx.createGain();
      lfoGain.gain.value = 190;
      lfo.connect(lfoGain).connect(windFilter.frequency);
      lfo.start();

      const drone = ctx.createOscillator();
      drone.type = "sine";
      drone.frequency.value = 73.4;
      const droneGain = ctx.createGain();
      droneGain.gain.value = 0.045;
      drone.connect(droneGain).connect(master);
      drone.start();

      const grove: Grove = { ctx, master, windGain, shimmerGain };

      const chirp = () => {
        if (ctx.state !== "running") return;
        const now = ctx.currentTime;
        const notes = 1 + Math.floor(Math.random() * 3);
        for (let i = 0; i < notes; i += 1) {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = Math.random() > 0.5 ? "triangle" : "sine";
          osc.frequency.setValueAtTime(1800 + Math.random() * 1600, now + i * 0.16);
          osc.frequency.exponentialRampToValueAtTime(2400 + Math.random() * 1400, now + i * 0.16 + 0.09);
          gain.gain.setValueAtTime(0.0001, now + i * 0.16);
          gain.gain.exponentialRampToValueAtTime(0.016 + Math.random() * 0.014, now + i * 0.16 + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.16 + 0.15);
          osc.connect(gain).connect(master);
          osc.start(now + i * 0.16);
          osc.stop(now + i * 0.16 + 0.2);
        }
      };
      grove.interval = window.setInterval(chirp, 5200 + Math.random() * 4200);
      groveRef.current = grove;
      setOn(true);
    } catch {
      setOn(false);
    } finally {
      setStarting(false);
    }
  }, []);

  const toggle = useCallback(() => {
    if (on) stop();
    else void start();
  }, [on, start, stop]);

  useEffect(() => {
    const onVisibility = () => {
      const grove = groveRef.current;
      if (!grove) return;
      if (document.hidden) void grove.ctx.suspend();
      else void grove.ctx.resume();
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      const grove = groveRef.current;
      if (grove) {
        if (grove.interval) window.clearInterval(grove.interval);
        void grove.ctx.close();
        groveRef.current = null;
      }
    };
  }, []);

  return { on, starting, toggle };
}
