export type DescentChapter = {
  id: string;
  altitude: string;
  metres: number | null;
  title: string;
  body: string;
  note: string;
  side: "left" | "right";
};

export const descentChapters: DescentChapter[] = [
  {
    id: "crown",
    altitude: "116 m",
    metres: 116,
    title: "Weather begins up here.",
    body:
      "Hyperion, the tallest coast redwood on record, stands a little over 116 metres. Its crown takes the wind first, drinks fog through its needles, and holds a whole climate in its branches. The tree's exact location stays unpublished: a giant can be loved and still left alone.",
    note: "Tallest known living tree · measured 2006",
    side: "left",
  },
  {
    id: "canopy",
    altitude: "78 m",
    metres: 78,
    title: "A forest with a second floor.",
    body:
      "On old limbs, fallen needles and moss gather into roof-deep soil. Ferns unroll there. Worms work there. Some plants spend their whole lives two hundred feet above the ground, never once touching the forest floor.",
    note: "Canopy soil · an aerial garden",
    side: "right",
  },
  {
    id: "middle",
    altitude: "46 m",
    metres: 46,
    title: "Tenants of the middle air.",
    body:
      "The marbled murrelet flies between the sea and the mossy branch where it nests. The wandering salamander walks through this miniature landscape, then leaps, spreading its feet to parachute down. A single old tree is a neighbourhood.",
    note: "Marbled murrelet · wandering salamander",
    side: "left",
  },
  {
    id: "understory",
    altitude: "18 m",
    metres: 18,
    title: "Where the light arrives in pieces.",
    body:
      "Under the crowns, light falls in slow green coins. Sword ferns hold the shade; huckleberry and redwood sorrel make a low ceiling. This is the layer that catches the fog the tallest tree cannot use, and passes it down again.",
    note: "Summer fog · a second water supply",
    side: "right",
  },
  {
    id: "floor",
    altitude: "0 m",
    metres: 0,
    title: "Everything begins with what falls.",
    body:
      "A redwood falls and becomes a nurse log: a raised, rotting cradle for the next generation. Its roots are shallow, only a few metres deep, yet reach sideways and intertwine with the grove around it. The tallest forest is built on the ground.",
    note: "Nurse logs · shallow, interlocking roots",
    side: "left",
  },
];

export type TreeLayer = {
  id: string;
  band: string;
  metres: string;
  title: string;
  body: string;
  fact: string;
  top: number;
  height: number;
};

export const treeLayers: TreeLayer[] = [
  {
    id: "emergent",
    band: "Emergent",
    metres: "116 m",
    title: "The crown",
    body:
      "Leaves here are small and overlapping, built to shed water and take a beating from the wind. The top of an old redwood is a dry, bright, broken place for most of the year.",
    fact: "The tallest known coast redwood, Hyperion, is about 116 metres tall.",
    top: 4,
    height: 15,
  },
  {
    id: "canopy",
    band: "Upper canopy",
    metres: "94 m",
    title: "The aerial garden",
    body:
      "Branches thick enough to walk on collect soil, moss, lichens, even small shrubs. This mat of canopy soil is a habitat above a habitat, alive with insects and worms.",
    fact: "The soil mats on old redwood limbs can hold ferns, shrubs and a community of insects.",
    top: 19,
    height: 17,
  },
  {
    id: "mid",
    band: "Middle canopy",
    metres: "62 m",
    title: "The neighbourhood",
    body:
      "Marbled murrelets nest on broad moss-covered limbs. Wandering salamanders live in the air, too, moving through the canopy like tiny, damp commuters.",
    fact: "An old redwood can support animals that never visit the ground.",
    top: 36,
    height: 18,
  },
  {
    id: "understory",
    band: "Understory",
    metres: "22 m",
    title: "The green room",
    body:
      "Light is filtered, air is still, and the shade keeps moisture in place. Sword ferns, sorrel and huckleberry thrive below the crowns, feeding on what the canopy lets go.",
    fact: "Only a small fraction of daylight reaches the forest floor.",
    top: 54,
    height: 19,
  },
  {
    id: "floor",
    band: "Forest floor",
    metres: "0 m",
    title: "The nursery",
    body:
      "Fallen branches, needles and trunks become a damp seedbed. Root systems spread wide rather than deep, binding the grove together into one wind-resistant structure.",
    fact: "The National Park Service reports roots spreading 18–24 metres sideways, with most of that growth in the top few metres of soil.",
    top: 73,
    height: 18,
  },
  {
    id: "roots",
    band: "Root zone",
    metres: "−4 m",
    title: "The shared foundation",
    body:
      "Fungal threads connect roots to soil, water and one another. The grove is not a collection of individuals but a slow, subterranean conversation.",
    fact: "Redwood roots usually stay within the top few metres of soil.",
    top: 91,
    height: 9,
  },
];

export type Grove = {
  id: string;
  name: string;
  place: string;
  lat: string;
  lon: string;
  note: string;
  url: string;
  image?: string;
  alt?: string;
  credit?: string;
};

export const groves: Grove[] = [
  {
    id: "rnsp",
    name: "Redwood National and State Parks",
    place: "Del Norte & Humboldt Counties, California",
    lat: "41.21° N",
    lon: "124.00° W",
    note: "Four parks, one continuous old-growth landscape. Start at Prairie Creek or Jedediah Smith.",
    url: "https://www.nps.gov/redw/",
    image: "/images/forest-path.jpg",
    alt: "A trail winding between tall redwoods with ferns along the edges",
    credit: "Frank Minjarez / Pexels",
  },
  {
    id: "humboldt",
    name: "Humboldt Redwoods State Park",
    place: "Weott, California",
    lat: "40.35° N",
    lon: "123.92° W",
    note: "The Avenue of the Giants runs through it. Rockefeller Forest holds some of the tallest trees in the world.",
    url: "https://www.parks.ca.gov/?page_id=425",
  },
  {
    id: "muir",
    name: "Muir Woods National Monument",
    place: "Mill Valley, California",
    lat: "37.89° N",
    lon: "122.58° W",
    note: "The closest old-growth grove to San Francisco. Reserve parking before you go; the road is narrow.",
    url: "https://www.nps.gov/muwo/index.htm",
    image: "/images/grove-path.jpg",
    alt: "A quiet path through a dense grove of redwood trees",
    credit: "ArtHouse Studio / Pexels",
  },
  {
    id: "big-basin",
    name: "Big Basin Redwoods State Park",
    place: "Boulder Creek, California",
    lat: "37.17° N",
    lon: "122.22° W",
    note: "California's oldest state park. Much of it is recovering after the 2020 fires; check access first.",
    url: "https://www.parks.ca.gov/?page_id=540",
  },
];

export const sources = [
  {
    label: "National Park Service, Redwood National and State Parks",
    url: "https://www.nps.gov/redw/learn/nature/coast-redwoods.htm",
  },
  {
    label: "Save the Redwoods League, coast redwood facts",
    url: "https://www.savetheredwoods.org/redwoods/coast-redwoods/",
  },
  {
    label: "Sempervirens Fund, what makes a redwood",
    url: "https://www.sempervirens.org/",
  },
  {
    label: "California State Parks, Humboldt Redwoods",
    url: "https://www.parks.ca.gov/?page_id=425",
  },
];
