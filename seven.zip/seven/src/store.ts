import { useSyncExternalStore } from "react";

/**
 * A tiny mutable store shared by the scroll layer, the 3D scene and the UI.
 * The 3D scene reads `progress` inside useFrame without causing React renders.
 */
export type SevenState = {
  progress: number;
  velocity: number;
  active: number;
  glbReady: boolean;
  fontsReady: boolean;
  reducedMotion: boolean;
  webgl: boolean;
  contextLost: boolean;
  hq: boolean;
  bloom: boolean;
  dpr: number;
  frameMedian: number;
  calls: number;
  triangles: number;
};

export const state: SevenState = {
  progress: 0,
  velocity: 0,
  active: 0,
  glbReady: false,
  fontsReady: false,
  reducedMotion: false,
  webgl: true,
  contextLost: false,
  hq: false,
  bloom: true,
  dpr: 1,
  frameMedian: 0,
  calls: 0,
  triangles: 0,
};

type Listener = () => void;
const listeners = new Set<Listener>();
let snapshot = { ...state };

function emit() {
  snapshot = { ...state };
  listeners.forEach((l) => l());
}

export function setState(patch: Partial<SevenState>) {
  let changed = false;
  for (const k of Object.keys(patch) as (keyof SevenState)[]) {
    if (state[k] !== patch[k]) {
      (state as Record<string, unknown>)[k] = patch[k];
      changed = true;
    }
  }
  if (changed) emit();
}

export function setStateSilent(patch: Partial<SevenState>) {
  for (const k of Object.keys(patch) as (keyof SevenState)[]) {
    (state as Record<string, unknown>)[k] = patch[k];
  }
  snapshot = { ...state };
}

export function subscribe(listener: Listener) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getSnapshot() {
  return snapshot;
}

export function useSeven<T>(selector: (s: SevenState) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(snapshot),
    () => selector(snapshot),
  );
}

export function isMobile() {
  return typeof window !== "undefined" && window.innerWidth < 900;
}

export function prefersReducedMotion() {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

export function clamp(v: number, a: number, b: number) {
  return Math.min(b, Math.max(a, v));
}

export function smoothstep(a: number, b: number, x: number) {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}
