import { useCallback, useEffect, useState } from "react";
import { Scene } from "./scene/Scene";
import { ChapterText } from "./ui/ChapterText";
import { Counter, Rail, Wordmark } from "./ui/Chrome";
import { Preloader } from "./ui/Preloader";
import { Semantic } from "./ui/Semantic";
import { Fallback } from "./ui/Fallback";
import { useScrollProgress } from "./hooks/useScrollProgress";
import { CHAPTERS } from "./content/chapters";
import { setState, useSeven } from "./store";

export default function App() {
  const [webgl] = useState(() => {
    try {
      const c = document.createElement("canvas");
      return !!c.getContext("webgl2");
    } catch {
      return false;
    }
  });
  const contextLost = useSeven((s) => s.contextLost);
  const showFallback = !webgl || contextLost;
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setState({ webgl, contextLost: false });
    if (showFallback) setState({ glbReady: true });
  }, [webgl, showFallback]);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        await Promise.all([
          document.fonts.load('400 16px "Anton"'),
          document.fonts.load('400 16px "Archivo"'),
          document.fonts.load('italic 400 16px "Instrument Serif"'),
          document.fonts.load('400 16px "IBM Plex Mono"'),
        ]);
        await document.fonts.ready;
      } catch {
        /* fonts fall back to the local stacks */
      }
      if (!cancelled) setState({ fontsReady: true });
    };
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  const onDone = useCallback(() => {
    setLoaded(true);
    document.body.style.overflow = "";
  }, []);

  useScrollProgress(!showFallback);

  return (
    <div className={`site${loaded ? " loaded" : ""}`} aria-busy={!loaded}>
      {!showFallback ? (
        <>
          <Scene />
          <div className="edge-feather left" />
          <div className="edge-feather right" />
          <ChapterText />
          <Wordmark />
          <Counter />
          <Rail />
          <Semantic />
          <div className="scroll-track" aria-hidden="true">
            <div className="track-entry" />
            {CHAPTERS.map((ch) => (
              <div className="track-chapter" key={ch.id} />
            ))}
            <div className="track-close" />
          </div>
        </>
      ) : (
        <Fallback />
      )}
      <Preloader onDone={onDone} />
    </div>
  );
}
