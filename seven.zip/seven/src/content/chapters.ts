/**
 * SEVEN — the only place copy lives.
 * All text is locked to the build brief, section 3. Do not edit for tone.
 */

export type Quote = {
  text: string;
  cite: string;
};

export type Chapter = {
  id: string;
  index: string;
  eyebrow: string;
  display: string[];
  body: string;
  stat?: string;
  quote?: Quote;
  ledger?: string[];
  close?: string;
  side: "left" | "right";
  pStart: number;
  pEnd: number;
};

export const ENTRY = {
  eyebrow: "CRISTIANO RONALDO · 1985",
  display: "SEVEN",
  body: "One number. Seven chapters. Twenty-three years.",
  cue: "SCROLL",
  pStart: 0,
  pEnd: 0.06,
};

export const CHAPTERS: Chapter[] = [
  {
    id: "madeira",
    index: "01",
    eyebrow: "01 / MADEIRA · 2002–2003",
    display: ["BORN", "ON AN", "ISLAND"],
    body: "Funchal, 5 February 1985. He left home at twelve for Lisbon, and debuted for Sporting at seventeen: 31 matches, 5 goals.",
    stat: "31 APPS — 5 GOALS · SPORTING CP",
    side: "left",
    pStart: 0.06,
    pEnd: 0.143,
  },
  {
    id: "manchester",
    index: "02",
    eyebrow: "02 / MANCHESTER · 2003–2009",
    display: ["GIVEN", "THE", "SEVEN"],
    body: "He asked for 28. Ferguson gave him 7. Six seasons later: 292 matches, 118 goals, three league titles, a European Cup and the first Ballon d'Or.",
    stat: "292 APPS — 118 GOALS — 3 PREMIER LEAGUE",
    side: "right",
    pStart: 0.143,
    pEnd: 0.286,
  },
  {
    id: "madrid",
    index: "03",
    eyebrow: "03 / MADRID · 2009–2018",
    display: ["450", "IN", "438"],
    body: "Four European Cups in five years. Two league titles. Four more Ballons d'Or. The most prolific spell in the history of the club.",
    stat: "450 GOALS — 438 MATCHES",
    side: "left",
    pStart: 0.286,
    pEnd: 0.429,
  },
  {
    id: "turin",
    index: "04",
    eyebrow: "04 / TURIN · 2018–2021",
    display: ["101", "GOALS"],
    body: "A different league, the same appetite. Two Serie A titles, and the fastest hundred goals Juventus had ever seen.",
    stat: "134 APPS — 101 GOALS — 2 SERIE A",
    quote: {
      text: "Your love makes me strong, your hate makes me unstoppable.",
      cite: "Cristiano Ronaldo, 2015",
    },
    side: "right",
    pStart: 0.429,
    pEnd: 0.571,
  },
  {
    id: "portugal",
    index: "05",
    eyebrow: "05 / PORTUGAL · 2003–",
    display: ["NOTHING", "BETTER"],
    body: "233 caps. 146 goals. European champion in 2016, Nations League winner in 2019 and 2025. The first player to score at six World Cups.",
    quote: {
      text: "Winning for Portugal is always special. I have many titles with clubs, but nothing is better than winning for Portugal.",
      cite: "Cristiano Ronaldo, after the UEFA Nations League final, 8 June 2025",
    },
    side: "left",
    pStart: 0.571,
    pEnd: 0.714,
  },
  {
    id: "riyadh",
    index: "06",
    eyebrow: "06 / RIYADH · 2023–",
    display: ["NINE", "HUNDRED"],
    body: "January 2023, Al-Nassr. On 5 September 2024 he became the first man to reach 900 career goals. The next number has four digits.",
    stat: "900+ CAREER GOALS — CHASING 1,000",
    side: "right",
    pStart: 0.714,
    pEnd: 0.857,
  },
  {
    id: "seven",
    index: "07",
    eyebrow: "07 / SEVEN",
    display: ["SEVEN", "LEAGUE", "TITLES"],
    body: "The ledger. Read it slowly. Then:",
    quote: {
      text: "Talent without working hard is nothing.",
      cite: "Cristiano Ronaldo",
    },
    ledger: [
      "5  Ballon d'Or",
      "5  UEFA Champions League",
      "3  Premier League",
      "2  La Liga",
      "2  Serie A",
      "7  League titles in total",
      "1  UEFA European Championship (2016)",
      "2  UEFA Nations League (2019, 2025)",
      "4  European Golden Shoes",
      "140  UEFA Champions League goals (all-time record)",
      "146  International goals (all-time men's record)",
      "11  World Cup goals across six tournaments",
    ],
    close:
      "SEVEN · Stats as of November 2026 · Built as an original design; no official kit, crest, mark or likeness used.",
    side: "left",
    pStart: 0.857,
    pEnd: 1,
  },
];

export const CLOSE = {
  pStart: 0.857,
  pEnd: 1,
};

export const CHAPTER_BOUNDARIES = [0, 0.06, 0.143, 0.286, 0.429, 0.571, 0.714, 0.857, 1];

export const MACRO = { start: 0.315, end: 0.355, fullReturn: 0.375 };

export const TOTAL_CHAPTERS = CHAPTERS.length;
