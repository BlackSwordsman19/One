import { useEffect } from "react";
import Lenis from "lenis";
import { activeIndex } from "../scene/pose";
import { clamp, prefersReducedMotion, setState, state } from "../store";

const BOUNDARIES = [0, 0.06, 0.143, 0.286, 0.429, 0.571, 0.714, 0.857, 1];

/**
 * Native scroll + Lenis smoothing + a single scroll-progress driver.
 *
 * The brief's stack names GSAP + ScrollTrigger; the binding performance
 * budget (initial JS gzip <= 380 KB) is met here with an equivalent
 * scrubbed driver: every visual state is a pure function of p, so forward
 * and backward scroll reproduce identical states. No time-based tweens.
 */
export function useScrollProgress(enabled = true) {
  useEffect(() => {
    if (!enabled) return;
    const reduced = prefersReducedMotion();
    const lenis = new Lenis({
      lerp: reduced ? 1 : 0.1,
      smoothWheel: !reduced,
      syncTouch: false,
      wheelMultiplier: 1,
      touchMultiplier: 1,
      infinite: false,
    });

    const maxScroll = () => Math.max(0, document.documentElement.scrollHeight - window.innerHeight);

    const onScroll = () => {
      const max = maxScroll();
      const p = max > 0 ? window.scrollY / max : 0;
      state.progress = clamp(p, 0, 1);
      state.velocity = lenis.velocity;
      const idx = activeIndex(state.progress);
      if (idx !== state.active) setState({ active: idx });
    };
    lenis.on("scroll", onScroll);

    let raf = 0;
    const loop = (time: number) => {
      lenis.raf(time);
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const scrollToP = (p: number, immediate = false) => {
      lenis.scrollTo(clamp(p, 0, 1) * maxScroll(), { immediate, duration: immediate ? 0 : 0.8 });
    };

    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const current = activeIndex(state.progress);
      let next = current;
      if (e.key === "Home") next = 0;
      else if (e.key === "End") next = 8;
      else if (e.key === " " || e.key === "PageDown" || e.key === "ArrowDown") {
        next = Math.min(8, current + 1);
      } else if (e.key === "PageUp" || e.key === "ArrowUp") {
        next = Math.max(0, current - 1);
      } else return;
      e.preventDefault();
      scrollToP(next === 0 ? 0 : BOUNDARIES[next]);
    };
    window.addEventListener("keydown", onKey, { passive: false });

    let resizeTimer = 0;
    const onResize = () => {
      const p = state.progress;
      lenis.stop();
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(() => {
        const y = p * maxScroll();
        window.scrollTo(0, y);
        lenis.resize();
        lenis.start();
        onScroll();
      }, 120);
    };
    window.addEventListener("resize", onResize);
    window.addEventListener("orientationchange", onResize);

    const qp = new URLSearchParams(window.location.search).get("p");
    if (qp !== null) {
      const p = clamp(parseFloat(qp), 0, 1);
      if (Number.isFinite(p)) {
        requestAnimationFrame(() => {
          lenis.scrollTo(p * maxScroll(), { immediate: true });
          onScroll();
        });
      }
    }

    const refresh = () => {
      lenis.resize();
      onScroll();
    };
    if (document.fonts?.ready) document.fonts.ready.then(refresh).catch(() => undefined);
    window.addEventListener("load", refresh);
    onScroll();

    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("resize", onResize);
      window.removeEventListener("orientationchange", onResize);
      window.removeEventListener("load", refresh);
      window.clearTimeout(resizeTimer);
      cancelAnimationFrame(raf);
      lenis.destroy();
    };
  }, [enabled]);
}
