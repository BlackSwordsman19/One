import { useEffect, useRef } from "react";
import { CHAPTERS, ENTRY } from "../content/chapters";
import { smoothstep, state } from "../store";

function setBlock(el: HTMLElement | null, o: number, y: number) {
  if (!el) return;
  el.style.opacity = o.toFixed(3);
  el.style.visibility = o > 0.002 ? "visible" : "hidden";
  el.style.setProperty("--fade-y", `${y.toFixed(2)}px`);
}

/**
 * The fixed type layer. Every opacity/translate is a pure function of the
 * same scroll progress that drives the 3D scene, so scrubbing backwards
 * reproduces every state exactly. No time-based tweens.
 */
export function ChapterText() {
  const entryWrap = useRef<HTMLDivElement>(null);
  const entry = useRef<HTMLDivElement>(null);
  const cue = useRef<HTMLParagraphElement>(null);
  const mainRefs = useRef<(HTMLDivElement | null)[]>([]);
  const asideRefs = useRef<(HTMLDivElement | null)[]>([]);
  const wrapRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const update = (p: number) => {

      const eo = 1 - smoothstep(0.04, 0.06, p);
      setBlock(entry.current, eo, (1 - eo) * -24);
      if (entryWrap.current) {
        entryWrap.current.style.visibility = eo > 0.002 ? "visible" : "hidden";
      }
      if (cue.current) {
        cue.current.style.opacity = String(1 - smoothstep(0, 0.02, p));
      }

      CHAPTERS.forEach((ch, i) => {
        const fadeIn = smoothstep(ch.pStart, ch.pStart + 0.02, p);
        const fadeOut = i === CHAPTERS.length - 1 ? 1 : 1 - smoothstep(ch.pEnd - 0.02, ch.pEnd, p);
        const o = Math.min(fadeIn, fadeOut);
        const y = (1 - fadeIn) * 24 + (1 - fadeOut) * -24;
        setBlock(mainRefs.current[i], o, y);

        const aIn = smoothstep(ch.pStart + 0.004, ch.pStart + 0.024, p);
        const aOut = i === CHAPTERS.length - 1 ? 1 : 1 - smoothstep(ch.pEnd - 0.024, ch.pEnd - 0.004, p);
        const ao = Math.min(aIn, aOut);
        const ay = (1 - aIn) * 24 + (1 - aOut) * -24;
        setBlock(asideRefs.current[i], ao, ay);

        const wrap = wrapRefs.current[i];
        if (wrap) {
          wrap.style.visibility = o > 0.002 || ao > 0.002 ? "visible" : "hidden";
        }
      });
    };

    let raf = 0;
    let lastP = -1;
    const loop = () => {
      const p = state.progress;
      if (p !== lastP) {
        lastP = p;
        update(p);
      }
      raf = requestAnimationFrame(loop);
    };
    update(state.progress);
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  return (
    <div className="text-layer" aria-hidden="true">
      <div className="chapter-text entry" ref={entryWrap}>
        <div className="entry-block" ref={entry}>
          <p className="eyebrow">{ENTRY.eyebrow}</p>
          <h2 className="display">
            <span>SEVEN</span>
          </h2>
          <p className="body">{ENTRY.body}</p>
          <p className="cue" ref={cue}>
            {ENTRY.cue}
          </p>
        </div>
      </div>

      {CHAPTERS.map((ch, i) => (
        <div
          className="chapter-text"
          key={ch.id}
          ref={(el) => {
            wrapRefs.current[i] = el;
          }}
        >
          <div
            className={`block main ${ch.side}`}
            ref={(el) => {
              mainRefs.current[i] = el;
            }}
          >
            <p className="eyebrow">{ch.eyebrow}</p>
            <h2 className="display">
              {ch.display.map((line) => (
                <span key={line}>{line}</span>
              ))}
            </h2>
            <p className="body">{ch.body}</p>
            {ch.stat ? <p className="stat">{ch.stat}</p> : null}
            {ch.close ? <p className="close-line">{ch.close}</p> : null}
          </div>

          {ch.quote || ch.ledger ? (
            <div
              className={`block aside ${ch.side === "left" ? "right" : "left"}`}
              ref={(el) => {
                asideRefs.current[i] = el;
              }}
            >
              {ch.ledger ? (
                <ul className="ledger">
                  {ch.ledger.map((row) => {
                    const m = row.match(/^(\d+)\s+(.*)$/);
                    return (
                      <li key={row}>
                        <span className="n">{m ? m[1] : ""}</span>
                        <span>
                          {m ? m[2] : row}
                          {ch.id === "seven" && m && m[1] === "7" ? (
                            <span className="note">3 + 2 + 2</span>
                          ) : null}
                        </span>
                      </li>
                    );
                  })}
                </ul>
              ) : null}
              {ch.quote ? (
                <blockquote className="quote">
                  <p>{ch.quote.text}</p>
                  <cite>{ch.quote.cite}</cite>
                </blockquote>
              ) : null}
            </div>
          ) : null}
        </div>
      ))}
    </div>
  );
}
