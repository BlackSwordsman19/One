import { CHAPTERS, ENTRY } from "../content/chapters";

/**
 * The accessible mirror of the whole story. Visually hidden, fully semantic.
 * The visible type layer is aria-hidden; this is what assistive tech reads.
 */
export function Semantic() {
  return (
    <section className="sr-only" aria-label="SEVEN — Cristiano Ronaldo">
      <h1>SEVEN — Cristiano Ronaldo</h1>
      <p>{ENTRY.eyebrow}</p>
      <p>{ENTRY.body}</p>
      {CHAPTERS.map((ch) => (
        <section key={ch.id} aria-labelledby={`${ch.id}-title`}>
          <h2 id={`${ch.id}-title`}>{ch.display.join(" ")}</h2>
          <p>{ch.eyebrow}</p>
          <p>{ch.body}</p>
          {ch.stat ? <p>{ch.stat}</p> : null}
          {ch.quote ? (
            <blockquote>
              <p>{ch.quote.text}</p>
              <cite>{ch.quote.cite}</cite>
            </blockquote>
          ) : null}
          {ch.ledger ? (
            <ul>
              {ch.ledger.map((row) => {
                const m = row.match(/^(\d+)\s+(.*)$/);
                return (
                  <li key={row}>
                    {m ? <span>{m[1]}</span> : null} {m ? m[2] : row}
                  </li>
                );
              })}
            </ul>
          ) : null}
          {ch.close ? <p>{ch.close}</p> : null}
        </section>
      ))}
    </section>
  );
}
