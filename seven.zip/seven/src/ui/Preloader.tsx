import { useEffect, useState } from "react";
import { useSeven } from "../store";

export function Preloader({ onDone }: { onDone: () => void }) {
  const glbReady = useSeven((s) => s.glbReady);
  const fontsReady = useSeven((s) => s.fontsReady);
  const [count, setCount] = useState(0);
  const [done, setDone] = useState(false);

  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const k = Math.min(1, (t - start) / 1200);
      setCount(Math.min(7, Math.floor(k * 7.999)));
      if (k < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    if (!glbReady || !fontsReady || count < 7) return;
    const t = window.setTimeout(() => {
      setDone(true);
      onDone();
    }, 250);
    return () => window.clearTimeout(t);
  }, [glbReady, fontsReady, count, onDone]);

  return (
    <div className={`preloader${done ? " done" : ""}`} aria-hidden={done ? true : undefined}>
      <div className="wordmark">SEVEN</div>
      <div className="count">{count}</div>
      <div className="meta">
        <span>Cristiano Ronaldo · 1985</span>
        <span>Stats as of November 2026</span>
      </div>
    </div>
  );
}
