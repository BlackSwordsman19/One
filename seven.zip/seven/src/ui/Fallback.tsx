import { CHAPTERS, ENTRY } from "../content/chapters";

/**
 * No-WebGL / context-lost fallback. A still exported from the same scene,
 * plus the full text. No error dialog, no apology copy.
 */
export function Fallback() {
  return (
    <div className="fallback">
      <div className="fallback-hero">
        <img
          src="/og/poster.jpg"
          alt="The Portugal No. 7 jersey, back view: RONALDO arched above a large gold numeral 7."
          width={1200}
          height={630}
        />
      </div>
      <h1>SEVEN</h1>
      <p className="body">{ENTRY.body}</p>
      <div className="fallback-grid">
        {CHAPTERS.map((ch) => (
          <article className="fallback-chapter" key={ch.id}>
            <p className="eyebrow">{ch.eyebrow}</p>
            <h2>{ch.display.join(" ")}</h2>
            <p>{ch.body}</p>
            {ch.stat ? <p className="stat">{ch.stat}</p> : null}
            {ch.quote ? (
              <blockquote>
                <p>{ch.quote.text}</p>
                <cite>{ch.quote.cite}</cite>
              </blockquote>
            ) : null}
            {ch.ledger ? (
              <ul className="ledger">
                {ch.ledger.map((row) => {
                  const m = row.match(/^(\d+)\s+(.*)$/);
                  return (
                    <li key={row}>
                      <span className="n">{m ? m[1] : ""}</span>
                      <span>
                        {m ? m[2] : row}
                        {ch.id === "seven" && m && m[1] === "7" ? (
                          <span className="note">3 + 2 + 2</span>
                        ) : null}
                      </span>
                    </li>
                  );
                })}
              </ul>
            ) : null}
            {ch.close ? <p className="fallback-close">{ch.close}</p> : null}
          </article>
        ))}
      </div>
    </div>
  );
}
