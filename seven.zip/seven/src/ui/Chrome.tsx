import { useEffect, useState } from "react";
import { useSeven } from "../store";

export function Wordmark() {
  return (
    <div className="wordmark" aria-hidden="true">
      SEVEN
    </div>
  );
}

export function Counter() {
  const active = useSeven((s) => s.active);
  const [display, setDisplay] = useState(active);
  const [fading, setFading] = useState(false);

  useEffect(() => {
    setFading(true);
    const t = window.setTimeout(() => {
      setDisplay(active);
      setFading(false);
    }, 100);
    return () => window.clearTimeout(t);
  }, [active]);

  return (
    <div className="counter" style={{ opacity: fading ? 0 : 1 }} aria-hidden="true">
      {String(display).padStart(2, "0")} / 07
    </div>
  );
}

const BOUNDARIES = [0.06, 0.143, 0.286, 0.429, 0.571, 0.714, 0.857];

export function Rail() {
  const active = useSeven((s) => s.active);
  return (
    <div className="rail" aria-hidden="true">
      {BOUNDARIES.map((p, i) => (
        <span
          key={p}
          className={`dot${active === i + 1 ? " active" : ""}`}
          style={{ top: `${p * 100}%` }}
        />
      ))}
    </div>
  );
}
