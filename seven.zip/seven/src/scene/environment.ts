import * as THREE from "three";

/**
 * A studio environment built from scratch: a gradient dome and three
 * softbox cards, baked once through PMREMGenerator. No HDRI download.
 */
export function createStudioEnvironment(renderer: THREE.WebGLRenderer) {
  const envScene = new THREE.Scene();

  const dome = new THREE.Mesh(
    new THREE.SphereGeometry(12, 32, 24),
    new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {},
      vertexShader: /* glsl */ `
        varying vec3 vWorld;
        void main() {
          vec4 wp = modelMatrix * vec4(position, 1.0);
          vWorld = wp.xyz;
          gl_Position = projectionMatrix * viewMatrix * wp;
        }
      `,
      fragmentShader: /* glsl */ `
        varying vec3 vWorld;
        void main() {
          float h = normalize(vWorld).y;
          vec3 low = vec3(0.010, 0.010, 0.012);
          vec3 mid = vec3(0.075, 0.075, 0.085);
          vec3 high = vec3(0.20, 0.20, 0.22);
          vec3 c = mix(low, mid, smoothstep(-0.75, 0.05, h));
          c = mix(c, high, smoothstep(0.05, 0.9, h));
          gl_FragColor = vec4(c, 1.0);
        }
      `,
    }),
  );
  envScene.add(dome);

  const card = (
    w: number,
    h: number,
    pos: [number, number, number],
    color: [number, number, number],
    look: [number, number, number] = [0, 0, 0],
  ) => {
    const mesh = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      new THREE.MeshBasicMaterial({ color: new THREE.Color(...color), side: THREE.DoubleSide }),
    );
    mesh.position.set(...pos);
    mesh.lookAt(new THREE.Vector3(...look));
    envScene.add(mesh);
    return mesh;
  };

  // key softbox, upper-left front
  card(4.5, 3.2, [-3.6, 4.2, 4.2], [5.2, 4.9, 4.4]);
  // cool fill, right
  card(3.2, 2.2, [4.2, 1.4, 2.0], [1.1, 1.35, 1.8]);
  // warm rim / kicker, behind
  card(3.4, 2.0, [0.4, 2.2, -4.4], [3.4, 2.5, 1.25]);
  // overhead bounce
  card(6.0, 6.0, [0, 6.5, 0], [1.4, 1.4, 1.45]);
  // large frontal card: gives the flat gold appliqué a clean champagne reflection
  card(5.0, 3.0, [0, 1.5, 5.5], [2.0, 2.0, 2.0]);
  // dark red floor bounce
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(14, 14),
    new THREE.MeshBasicMaterial({ color: new THREE.Color(0.10, 0.006, 0.006) }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.position.y = -3;
  envScene.add(floor);

  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const target = pmrem.fromScene(envScene, 0.035);
  const texture = target.texture;

  // cleanup the temporary scene; the PMREM texture stays alive
  envScene.traverse((o) => {
    if (o instanceof THREE.Mesh) {
      o.geometry.dispose();
      const m = o.material as THREE.Material | THREE.Material[];
      if (Array.isArray(m)) m.forEach((x) => x.dispose());
      else m.dispose();
    }
  });
  pmrem.dispose();

  return {
    texture,
    dispose: () => {
      texture.dispose();
      target.dispose();
    },
  };
}
