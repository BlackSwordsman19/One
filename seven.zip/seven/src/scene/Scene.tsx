import { useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import * as THREE from "three";
import { Hero } from "./Hero";
import { Lights } from "./Lights";
import { Dust } from "./Dust";
import { Post } from "./Post";
import { PerformanceGuard } from "./PerformanceGuard";
import { isMobile, prefersReducedMotion, setState, state } from "../store";

export function Scene() {
  useEffect(() => {
    const mobile = isMobile();
    const dpr = Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 2);
    setState({
      dpr,
      bloom: !mobile,
      reducedMotion: prefersReducedMotion(),
      hq: new URLSearchParams(window.location.search).get("hq") === "1",
    });
    state.dpr = dpr;
  }, []);

  return (
    <div className="scene-layer" aria-hidden="true">
      <Canvas
        shadows="soft"
        dpr={Math.min(window.devicePixelRatio || 1, isMobile() ? 1.5 : 2)}
        camera={{ fov: 30, near: 0.05, far: 20, position: [0, 0.2, 3.4] }}
        gl={{
          antialias: true,
          alpha: false,
          preserveDrawingBuffer: false,
          powerPreference: "high-performance",
        }}
        onCreated={({ gl, scene }) => {
          gl.toneMapping = THREE.ACESFilmicToneMapping;
          gl.toneMappingExposure = isMobile() ? 1.15 : 1.0;
          gl.outputColorSpace = THREE.SRGBColorSpace;
          gl.shadowMap.type = THREE.PCFSoftShadowMap;
          gl.info.autoReset = false;
          gl.domElement.setAttribute("aria-hidden", "true");
          gl.domElement.style.touchAction = "auto";
          gl.domElement.addEventListener("webglcontextlost", (e) => {
            e.preventDefault();
            setState({ contextLost: true });
          });
          scene.background = new THREE.Color("#08090B");
        }}
      >
        <Hero />
        <Lights />
        <Dust />
        <Post />
        <PerformanceGuard />
      </Canvas>
    </div>
  );
}
