import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { EffectComposer } from "three/examples/jsm/postprocessing/EffectComposer.js";
import { RenderPass } from "three/examples/jsm/postprocessing/RenderPass.js";
import { ShaderPass } from "three/examples/jsm/postprocessing/ShaderPass.js";
import { UnrealBloomPass } from "three/examples/jsm/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/examples/jsm/postprocessing/OutputPass.js";
import { isMobile, state } from "../store";

const FinishShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    uTime: { value: 0 },
    uGrain: { value: 0.025 },
    uVignette: { value: 0.25 },
    uAberration: { value: 0 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse;
    uniform float uTime;
    uniform float uGrain;
    uniform float uVignette;
    uniform float uAberration;
    varying vec2 vUv;

    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
    }

    void main() {
      vec2 uv = vUv;
      vec2 dir = uv - 0.5;
      float d = length(dir);
      float ab = uAberration * (0.35 + d);
      vec3 col;
      col.r = texture2D(tDiffuse, uv + dir * ab).r;
      col.g = texture2D(tDiffuse, uv).g;
      col.b = texture2D(tDiffuse, uv - dir * ab).b;

      float vig = smoothstep(0.92, 0.28, d);
      col *= mix(1.0, vig, uVignette);

      float t = floor(uTime * 24.0);
      float g = hash(uv * vec2(1920.0, 1080.0) + t) - 0.5;
      col += g * uGrain;

      gl_FragColor = vec4(col, 1.0);
    }
  `,
};

const BOUNDARIES = [0.06, 0.143, 0.286, 0.429, 0.571, 0.714, 0.857];

export function Post() {
  const { gl, scene, camera, size } = useThree();
  const composer = useRef<EffectComposer | null>(null);
  const bloom = useRef<UnrealBloomPass | null>(null);
  const finish = useRef<ShaderPass | null>(null);
  const mobile = useRef(isMobile());

  useEffect(() => {
    const target = new THREE.WebGLRenderTarget(1, 1, {
      type: THREE.HalfFloatType,
      samples: mobile.current ? 2 : 4,
    });
    const comp = new EffectComposer(gl, target);
    comp.setPixelRatio(gl.getPixelRatio());
    comp.setSize(size.width, size.height);

    const renderPass = new RenderPass(scene, camera);
    comp.addPass(renderPass);

    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(size.width, size.height),
      0.18,
      0.4,
      0.9,
    );
    bloomPass.enabled = !mobile.current;
    comp.addPass(bloomPass);
    bloom.current = bloomPass;

    const output = new OutputPass();
    comp.addPass(output);

    const finishPass = new ShaderPass(FinishShader);
    finishPass.uniforms.uGrain.value = mobile.current ? 0 : 0.025;
    comp.addPass(finishPass);
    finish.current = finishPass;

    composer.current = comp;
    return () => {
      comp.dispose();
      target.dispose();
      composer.current = null;
    };
  }, [gl, scene, camera, size.width, size.height]);

  useEffect(() => {
    const comp = composer.current;
    if (!comp) return;
    comp.setPixelRatio(gl.getPixelRatio());
    comp.setSize(size.width, size.height);
  }, [gl, size.width, size.height]);

  useFrame(({ clock }) => {
    const comp = composer.current;
    if (!comp) return;
    if (bloom.current) bloom.current.enabled = state.bloom;
    if (finish.current) {
      finish.current.uniforms.uTime.value = clock.elapsedTime;
      finish.current.uniforms.uGrain.value = state.reducedMotion || mobile.current ? 0 : 0.025;
      let ab = 0;
      if (!state.reducedMotion) {
        for (const b of BOUNDARIES) {
          const v = 1 - Math.abs(state.progress - b) / 0.006;
          if (v > ab) ab = v;
        }
      }
      finish.current.uniforms.uAberration.value = 0.0004 * Math.max(0, ab);
    }
    comp.render();
  }, 1);

  return null;
}
