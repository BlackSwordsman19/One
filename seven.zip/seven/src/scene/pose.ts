import * as THREE from "three";
import { clamp, smoothstep } from "../store";

/**
 * The scroll choreography. Everything here is a pure function of p.
 * Camera distances are the brief's values, refined by a constant 0.82
 * framing factor so the garment reads as a held object rather than a
 * background filling the frame. Yaw 0 = back / numeral 7 faces the viewer.
 */

export type Pose = {
  d: number;
  elev: number;
  az: number;
  yaw: number;
  target: [number, number, number];
  fitWidth: number;
  keyTemp: number;
  keyIntensity: number;
  fill: number;
  rim: number;
  rimColor: string;
  bounce: number;
  spec: number;
};

const D = 0.82;

export const KEYFRAMES: { p: number; pose: Pose }[] = [
  {
    p: 0.0,
    pose: { d: 3.4 * D, elev: 6, az: 0, yaw: 0, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5600, keyIntensity: 2.2, fill: 0.6, rim: 0.8, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.03,
    pose: { d: 3.4 * D, elev: 6, az: 0, yaw: 0, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5600, keyIntensity: 2.2, fill: 0.6, rim: 0.8, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.06,
    pose: { d: 3.4 * 0.95, elev: 8, az: 0, yaw: 0, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 6400, keyIntensity: 1.9, fill: 0.9, rim: 0.8, rimColor: "#AFC4D8", bounce: 0, spec: 0 },
  },
  {
    p: 0.135,
    pose: { d: 3.05 * 0.95, elev: 2, az: 0, yaw: -8, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 6400, keyIntensity: 1.9, fill: 0.9, rim: 0.8, rimColor: "#AFC4D8", bounce: 0, spec: 0 },
  },
  {
    p: 0.143,
    pose: { d: 3.05 * 0.9, elev: 0, az: -6, yaw: -8, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5200, keyIntensity: 2.4, fill: 0.6, rim: 1.0, rimColor: "#C8D2DC", bounce: 0, spec: 0 },
  },
  {
    p: 0.278,
    pose: { d: 2.8 * 0.9, elev: 0, az: -6, yaw: -16, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5200, keyIntensity: 2.4, fill: 0.6, rim: 1.0, rimColor: "#C8D2DC", bounce: 0, spec: 0 },
  },
  {
    p: 0.286,
    pose: { d: 2.8, elev: 0, az: 0, yaw: -16, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 4300, keyIntensity: 2.8, fill: 0.5, rim: 1.2, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.3,
    pose: { d: 2.8, elev: 0, az: 0, yaw: -8, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 4300, keyIntensity: 2.8, fill: 0.5, rim: 1.2, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.315,
    pose: { d: 1.15 * D, elev: -6, az: 0, yaw: 0, target: [0, 0.0425, 0.16], fitWidth: 0.21, keyTemp: 4300, keyIntensity: 2.8, fill: 0.5, rim: 1.2, rimColor: "#D8B45A", bounce: 0, spec: 1 },
  },
  {
    p: 0.355,
    pose: { d: 1.15 * D, elev: -6, az: 0, yaw: 0, target: [0, 0.0425, 0.16], fitWidth: 0.21, keyTemp: 4300, keyIntensity: 2.8, fill: 0.5, rim: 1.2, rimColor: "#D8B45A", bounce: 0, spec: 1 },
  },
  {
    p: 0.375,
    pose: { d: 2.7 * 0.9, elev: 0, az: 0, yaw: 18, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 4300, keyIntensity: 2.8, fill: 0.5, rim: 1.2, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.421,
    pose: { d: 3.05, elev: 18, az: 10, yaw: 18, target: [0, 0.02, 0], fitWidth: 0.82, keyTemp: 3800, keyIntensity: 1.6, fill: 0.4, rim: 1.0, rimColor: "#9FB6C8", bounce: 0, spec: 0 },
  },
  {
    p: 0.429,
    pose: { d: 3.05, elev: 18, az: 10, yaw: 18, target: [0, 0.02, 0], fitWidth: 0.82, keyTemp: 3800, keyIntensity: 1.6, fill: 0.4, rim: 1.0, rimColor: "#9FB6C8", bounce: 0, spec: 0 },
  },
  {
    p: 0.56,
    pose: { d: 3.05, elev: 18, az: 10, yaw: 96, target: [0, 0.02, 0], fitWidth: 0.82, keyTemp: 3800, keyIntensity: 1.6, fill: 0.4, rim: 1.0, rimColor: "#9FB6C8", bounce: 0, spec: 0 },
  },
  {
    p: 0.571,
    pose: { d: 2.6 * 0.92, elev: -8, az: 0, yaw: 96, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5600, keyIntensity: 2.0, fill: 0.6, rim: 0.8, rimColor: "#D8B45A", bounce: 0.12, spec: 0 },
  },
  {
    p: 0.705,
    pose: { d: 2.6 * 0.92, elev: -8, az: 0, yaw: 180, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5600, keyIntensity: 2.0, fill: 0.6, rim: 0.8, rimColor: "#D8B45A", bounce: 0.12, spec: 0 },
  },
  {
    p: 0.714,
    pose: { d: 3.0 * D, elev: 8, az: -14, yaw: 180, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 3200, keyIntensity: 2.4, fill: 0.5, rim: 1.0, rimColor: "#E0A45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.85,
    pose: { d: 3.0 * D, elev: 8, az: -14, yaw: 228, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 3200, keyIntensity: 2.4, fill: 0.5, rim: 1.0, rimColor: "#E0A45A", bounce: 0, spec: 0 },
  },
  {
    p: 0.857,
    pose: { d: 2.5 * 0.97, elev: 4, az: -4, yaw: 228, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5000, keyIntensity: 2.6, fill: 0.5, rim: 1.4, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
  {
    p: 1.0,
    pose: { d: 2.9 * 0.95, elev: 4, az: 0, yaw: 360, target: [0, 0, 0], fitWidth: 0.82, keyTemp: 5000, keyIntensity: 2.6, fill: 0.5, rim: 1.4, rimColor: "#D8B45A", bounce: 0, spec: 0 },
  },
];

const tmpColor = new THREE.Color();

export function samplePose(p: number): Pose {
  const x = clamp(p, 0, 1);
  let i = 0;
  while (i < KEYFRAMES.length - 2 && x > KEYFRAMES[i + 1].p) i++;
  const a = KEYFRAMES[i];
  const b = KEYFRAMES[i + 1];
  const span = Math.max(b.p - a.p, 1e-6);
  const t = smoothstep(0, 1, clamp((x - a.p) / span, 0, 1));
  const mix = (u: number, v: number) => u + (v - u) * t;
  const target: [number, number, number] = [
    mix(a.pose.target[0], b.pose.target[0]),
    mix(a.pose.target[1], b.pose.target[1]),
    mix(a.pose.target[2], b.pose.target[2]),
  ];
  tmpColor.set(a.pose.rimColor);
  const ca = tmpColor.clone();
  tmpColor.set(b.pose.rimColor);
  const cb = tmpColor.clone();
  const rim = ca.lerp(cb, t);
  return {
    d: mix(a.pose.d, b.pose.d),
    elev: mix(a.pose.elev, b.pose.elev),
    az: mix(a.pose.az, b.pose.az),
    yaw: mix(a.pose.yaw, b.pose.yaw),
    target,
    fitWidth: mix(a.pose.fitWidth, b.pose.fitWidth),
    keyTemp: mix(a.pose.keyTemp, b.pose.keyTemp),
    keyIntensity: mix(a.pose.keyIntensity, b.pose.keyIntensity),
    fill: mix(a.pose.fill, b.pose.fill),
    rim: mix(a.pose.rim, b.pose.rim),
    rimColor: `#${rim.getHexString()}`,
    bounce: mix(a.pose.bounce, b.pose.bounce),
    spec: mix(a.pose.spec, b.pose.spec),
  };
}

/** Approximate black-body colour, 1000–12000 K. */
export function kelvinToColor(kelvin: number): THREE.Color {
  const t = clamp(kelvin, 1000, 12000) / 100;
  let r: number;
  let g: number;
  let b: number;
  if (t <= 66) {
    r = 255;
    g = 99.4708025861 * Math.log(t) - 161.1195681661;
    b = t <= 19 ? 0 : 138.5177312231 * Math.log(t - 10) - 305.0447927307;
  } else {
    r = 329.698727446 * Math.pow(t - 60, -0.1332047592);
    g = 288.1221695283 * Math.pow(t - 60, -0.0755148492);
    b = 255;
  }
  return new THREE.Color(clamp(r, 0, 255) / 255, clamp(g, 0, 255) / 255, clamp(b, 0, 255) / 255);
}

export function activeIndex(p: number) {
  if (p < 0.06) return 0;
  if (p < 0.143) return 1;
  if (p < 0.286) return 2;
  if (p < 0.429) return 3;
  if (p < 0.571) return 4;
  if (p < 0.714) return 5;
  if (p < 0.857) return 6;
  return 7;
}
