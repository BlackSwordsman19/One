import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { isMobile, state } from "../store";

function moteTexture() {
  const size = 64;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, "rgba(255,255,255,0.9)");
  g.addColorStop(0.35, "rgba(255,255,255,0.35)");
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function Dust() {
  const { camera } = useThree();
  const points = useRef<THREE.Points>(null);
  const count = useMemo(() => (isMobile() ? 60 : 120), []);

  const { geometry, material, base, seeds } = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const seeds = new Float32Array(count);
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 2.4;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 2.0;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 2.0;
      seeds[i] = Math.random() * Math.PI * 2;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: new THREE.Color("#C8C4B8"),
      size: 0.0032,
      sizeAttenuation: true,
      map: moteTexture(),
      transparent: true,
      opacity: 0.32,
      depthWrite: false,
      blending: THREE.NormalBlending,
    });
    return { geometry: geo, material: mat, base: positions.slice(), seeds };
  }, [count]);

  useFrame(({ clock }) => {
    if (!points.current) return;
    points.current.visible = !state.reducedMotion;
    if (state.reducedMotion) return;
    const t = clock.elapsedTime;
    const attr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const arr = attr.array as Float32Array;
    for (let i = 0; i < count; i++) {
      const s = seeds[i];
      arr[i * 3] = base[i * 3] + Math.sin(t * 0.07 + s) * 0.035;
      arr[i * 3 + 1] = base[i * 3 + 1] + Math.sin(t * 0.05 + s * 1.7) * 0.045;
      arr[i * 3 + 2] = base[i * 3 + 2] + Math.cos(t * 0.06 + s) * 0.03;
    }
    attr.needsUpdate = true;
    points.current.position.x = camera.position.x * 0.018;
    points.current.position.y = camera.position.y * 0.018;
  });

  return <points ref={points} geometry={geometry} material={material} frustumCulled={false} />;
}
