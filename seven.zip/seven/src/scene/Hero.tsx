import { useEffect, useMemo, useRef } from "react";
import { useFrame, useLoader, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { GLTFLoader } from "three/examples/jsm/loaders/GLTFLoader.js";
import { clamp, isMobile, setState, state } from "../store";
import { samplePose } from "./pose";

const D2R = Math.PI / 180;
const FOV = 30;

export function Hero() {
  const gltf = useLoader(GLTFLoader, "/models/sev7_kit.glb");
  const group = useRef<THREE.Group>(null);
  const { camera, size } = useThree();
  const smooth = useRef(0);
  const prev = useRef(0);
  const sway = useRef(0);
  const mouse = useRef({ x: 0, y: 0 });
  const mouseSmooth = useRef({ x: 0, y: 0 });

  const model = useMemo(() => {
    const m = gltf.scene.clone(true);
    const box = new THREE.Box3().setFromObject(m);
    const center = box.getCenter(new THREE.Vector3());
    m.position.y -= center.y;
    m.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.castShadow = true;
        o.receiveShadow = true;
        const mats = Array.isArray(o.material) ? o.material : [o.material];
        for (const mat of mats) {
          if (!mat) continue;
          const name = mat.name || "";
          const std = mat as THREE.MeshStandardMaterial;
          const phys = mat as THREE.MeshPhysicalMaterial;
          if ("envMapIntensity" in std) {
            std.envMapIntensity = name.includes("Gold")
              ? 1.55
              : name.includes("Ivory")
                ? 0.42
                : name.includes("Trim")
                  ? 0.2
                  : name.includes("Stitch")
                    ? 0.14
                    : 0.22;
          }
          if (name === "M_Kit_Red") {
            phys.sheen = 0.24;
            phys.sheenRoughness = 0.78;
            phys.sheenColor = new THREE.Color("#C8202E");
          }
          if (name === "M_Stitch") std.side = THREE.DoubleSide;
          std.needsUpdate = true;
        }
      }
    });
    return m;
  }, [gltf]);

  useEffect(() => {
    setState({ glbReady: true });
  }, []);

  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    cam.fov = FOV;
    cam.near = 0.05;
    cam.far = 20;
    cam.updateProjectionMatrix();
  }, [camera]);

  useEffect(() => {
    const onMove = (e: PointerEvent) => {
      if (e.pointerType === "touch") return;
      mouse.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      mouse.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener("pointermove", onMove, { passive: true });
    return () => window.removeEventListener("pointermove", onMove);
  }, []);

  useFrame((_, delta) => {
    const dt = Math.min(delta, 0.1);
    const target = state.progress;
    smooth.current += (target - smooth.current) * (1 - Math.exp(-dt * 4.2));
    const p = clamp(smooth.current, 0, 1);
    const pose = samplePose(p);

    const mobile = isMobile();
    const aspect = size.width / Math.max(size.height, 1);
    const vFov = FOV * D2R;
    const requiredD = pose.fitWidth / (2 * Math.tan(vFov / 2) * Math.max(aspect, 0.2) * 0.85);
    const fitScale = Math.max(1, requiredD / Math.max(pose.d, 0.001));
    const d = pose.d * fitScale;
    const visibleHeight = 2 * d * Math.tan(vFov / 2);

    // On narrow screens the jersey lives in the upper 58vh, so lift the
    // look-at target to place its centre at 29% of the viewport height.
    const lift = mobile ? visibleHeight * 0.21 : 0;
    const targetY = pose.target[1] - lift;

    const az = (pose.az + (state.reducedMotion ? 0 : mouseSmooth.current.x * 3)) * D2R;
    const elev = (pose.elev + (state.reducedMotion ? 0 : -mouseSmooth.current.y * 1.5)) * D2R;
    const ce = Math.cos(elev);
    const offset = new THREE.Vector3(d * ce * Math.sin(az), d * Math.sin(elev), d * ce * Math.cos(az));
    const look = new THREE.Vector3(pose.target[0], targetY, pose.target[2]);
    camera.position.copy(look).add(offset);
    camera.lookAt(look);

    if (group.current) {
      group.current.rotation.y = pose.yaw * D2R;
      const vel = (target - prev.current) / Math.max(dt, 0.001);
      prev.current = target;
      const swayTarget = state.reducedMotion ? 0 : clamp(vel * 0.0016, -0.004, 0.004);
      sway.current += (swayTarget - sway.current) * (1 - Math.exp(-dt * 5.0));
      group.current.position.x = sway.current;
      group.current.position.y = 0;
      group.current.rotation.z = sway.current * 0.55;
    }

    const mouseEase = 1 - Math.exp(-dt / 0.4);
    mouseSmooth.current.x += (mouse.current.x - mouseSmooth.current.x) * mouseEase;
    mouseSmooth.current.y += (mouse.current.y - mouseSmooth.current.y) * mouseEase;
  });

  return (
    <>
      <group ref={group}>
        <primitive object={model} />
      </group>
      <mesh rotation-x={-Math.PI / 2} position-y={-0.4} receiveShadow>
        <planeGeometry args={[6, 6]} />
        <shadowMaterial transparent opacity={0.3} color="#000000" />
      </mesh>
    </>
  );
}
