import { useEffect, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { setState, setStateSilent, state } from "../store";

declare global {
  interface Window {
    __SEVEN_PERF__?: {
      median: number;
      fps: number;
      dpr: number;
      bloom: boolean;
      calls: number;
      triangles: number;
    };
  }
}

/**
 * Frame-time guard. If the median frame time stays above 20 ms for two
 * seconds, drop the DPR in 0.25 steps to a floor of 1.0 and disable bloom
 * before touching geometry. Also publishes renderer statistics for the
 * verification pass.
 */
export function PerformanceGuard() {
  const { gl, setDpr } = useThree();
  const samples = useRef<number[]>([]);
  const over = useRef(0);
  const degraded = useRef(false);

  useEffect(() => {
    window.__SEVEN_PERF__ = {
      median: 0,
      fps: 0,
      dpr: state.dpr,
      bloom: state.bloom,
      calls: 0,
      triangles: 0,
    };
  }, []);

  useFrame((_, delta) => {
    if (state.hq) {
      if (window.__SEVEN_PERF__) {
        window.__SEVEN_PERF__.calls = gl.info.render.calls;
        window.__SEVEN_PERF__.triangles = gl.info.render.triangles;
      }
      gl.info.reset();
      return;
    }
    const dt = Math.min(delta, 0.25);
    if (dt <= 0) return;
    const arr = samples.current;
    arr.push(dt);
    if (arr.length > 120) arr.shift();
    if (arr.length < 30) return;
    const sorted = [...arr].sort((a, b) => a - b);
    const median = sorted[Math.floor(sorted.length / 2)];
    setStateSilent({ frameMedian: median, calls: gl.info.render.calls, triangles: gl.info.render.triangles });
    if (window.__SEVEN_PERF__) {
      window.__SEVEN_PERF__.median = median;
      window.__SEVEN_PERF__.fps = 1 / Math.max(median, 0.0001);
      window.__SEVEN_PERF__.dpr = state.dpr;
      window.__SEVEN_PERF__.calls = gl.info.render.calls;
      window.__SEVEN_PERF__.triangles = gl.info.render.triangles;
    }
    if (median > 0.020) over.current += dt;
    else over.current = 0;
    if (over.current > 2 && !degraded.current) {
      const next = Math.max(1.0, state.dpr - 0.25);
      if (next < state.dpr) {
        degraded.current = true;
        setDpr(next);
        setState({ dpr: next, bloom: false });
      } else if (state.bloom) {
        degraded.current = true;
        setState({ bloom: false });
      }
      over.current = 0;
    }
    if (window.__SEVEN_PERF__) {
      window.__SEVEN_PERF__.dpr = state.dpr;
      window.__SEVEN_PERF__.bloom = state.bloom;
    }
    gl.info.reset();
  }, 2);

  return null;
}
