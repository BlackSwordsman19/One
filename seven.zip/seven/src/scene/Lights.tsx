import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { createStudioEnvironment } from "./environment";
import { kelvinToColor, samplePose } from "./pose";
import { state } from "../store";

export function Lights() {
  const { scene, gl } = useThree();
  const key = useRef<THREE.DirectionalLight>(null);
  const fill = useRef<THREE.DirectionalLight>(null);
  const rim = useRef<THREE.DirectionalLight>(null);
  const bounceL = useRef<THREE.PointLight>(null);
  const bounceR = useRef<THREE.PointLight>(null);

  const spot = useMemo(() => {
    const target = new THREE.Object3D();
    target.position.set(0, 0.04, 0.16);
    const l = new THREE.SpotLight("#D8B45A", 0, 6, 0.34, 0.6, 2);
    l.position.set(0, 0.5, 2.45);
    l.target = target;
    return l;
  }, []);

  useEffect(() => {
    const env = createStudioEnvironment(gl);
    scene.environment = env.texture;
    scene.environmentIntensity = 0.55;
    return () => {
      scene.environment = null;
      env.dispose();
    };
  }, [gl, scene]);

  useFrame(() => {
    const pose = samplePose(state.progress);
    const kc = kelvinToColor(pose.keyTemp);
    if (key.current) {
      key.current.color.copy(kc);
      key.current.intensity = pose.keyIntensity;
    }
    if (fill.current) {
      fill.current.intensity = pose.fill;
    }
    if (rim.current) {
      rim.current.color.set(pose.rimColor);
      rim.current.intensity = pose.rim;
    }
    if (bounceL.current) bounceL.current.intensity = pose.bounce;
    if (bounceR.current) bounceR.current.intensity = pose.bounce;

    const spec = pose.spec;
    spot.intensity = spec * 8.0;
    const sweep = THREE.MathUtils.clamp((state.progress - 0.312) / 0.046, 0, 1);
    spot.position.x = -1.15 + 2.3 * sweep;
    spot.position.y = 0.5;
    spot.position.z = 2.45;
  });

  return (
    <>
      <directionalLight
        ref={key}
        position={[-2.5, 3.5, 3.0]}
        intensity={2.2}
        color="#FFF4E2"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.02}
        shadow-camera-left={-1.2}
        shadow-camera-right={1.2}
        shadow-camera-top={1.2}
        shadow-camera-bottom={-1.2}
        shadow-camera-near={0.1}
        shadow-camera-far={10}
      />
      <directionalLight ref={fill} position={[3.0, 1.5, 1.5]} intensity={0.6} color="#BFD4E8" />
      <directionalLight ref={rim} position={[0.4, 1.6, -3.0]} intensity={0.8} color="#D8B45A" />
      <pointLight ref={bounceL} position={[-1.6, -0.1, 0.2]} intensity={0} color="#046A38" distance={3} decay={2} />
      <pointLight ref={bounceR} position={[1.6, -0.1, 0.2]} intensity={0} color="#A5121E" distance={3} decay={2} />
      <primitive object={spot} />
      <primitive object={spot.target} />
    </>
  );
}
