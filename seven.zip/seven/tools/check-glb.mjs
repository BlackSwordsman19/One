import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
for (const p of [0.000, 0.335, 1.000]) {
  const page = await context.newPage();
  const errors=[]; page.on('pageerror', e=>errors.push(e.message)); page.on('console', m=>{ if(m.type()==='error') errors.push(m.text()); });
  await page.goto(`http://localhost:5173/?p=${p.toFixed(3)}&hq=1`, { waitUntil: 'load', timeout: 60000 });
  await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
  await page.waitForTimeout(1300);
  const perf = await page.evaluate(() => ({ perf: window.__SEVEN_PERF__, progress: window.scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight), canvas: !!document.querySelector('canvas') }));
  console.log(p, JSON.stringify(perf), 'errors', errors.length, errors.slice(0,2));
  await page.screenshot({ path: `docs/checkpoints/iteration-1/final-${p.toFixed(3)}.png` });
  await page.close();
}
await browser.close();
