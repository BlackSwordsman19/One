import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";

const OUT = path.resolve("docs/checkpoints/iteration-1");
fs.mkdirSync(OUT, { recursive: true });

const CHECKPOINTS = [0.0, 0.06, 0.1, 0.2, 0.3, 0.335, 0.38, 0.5, 0.64, 0.78, 0.9, 1.0];
const VIEWPORTS = [
  { name: "desktop", width: 1440, height: 900 },
  { name: "mobile", width: 390, height: 844 },
];

const browser = await chromium.launch({ headless: true });
const results = [];

for (const vp of VIEWPORTS) {
  const context = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    deviceScaleFactor: 1,
    isMobile: vp.name === "mobile",
    hasTouch: vp.name === "mobile",
  });
  for (const p of CHECKPOINTS) {
    const page = await context.newPage();
    const errors = [];
    const warnings = [];
    const requests = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") errors.push(msg.text());
      if (msg.type() === "warning") warnings.push(msg.text());
    });
    page.on("pageerror", (err) => errors.push(`PAGEERROR: ${err.message}`));
    page.on("request", (req) => requests.push(req.url()));
    const url = `http://localhost:5173/?p=${p.toFixed(3)}&hq=1`;
    await page.goto(url, { waitUntil: "load", timeout: 60000 });
    try {
      await page.waitForSelector(".preloader.done", { state: "attached", timeout: 30000 });
    } catch {
      errors.push("PRELOADER_TIMEOUT");
    }
    await page.waitForTimeout(1400);
    const dom = await page.evaluate(() => {
      const vw = innerWidth;
      const vh = innerHeight;
      const isMobile = vw < 900;
      const zone = isMobile
        ? { left: 0, top: 0, right: vw, bottom: vh * 0.58 }
        : { left: vw * 0.26, top: vh * 0.12, right: vw * 0.74, bottom: vh * 0.88 };
      const els = [...document.querySelectorAll(".block, .entry-block")];
      const visible = els
        .filter((el) => {
          const cs = getComputedStyle(el);
          return cs.visibility === "visible" && parseFloat(cs.opacity) > 0.01;
        })
        .map((el) => {
          const r = el.getBoundingClientRect();
          return {
            cls: el.className,
            text: (el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 70),
            left: Math.round(r.left),
            top: Math.round(r.top),
            right: Math.round(r.right),
            bottom: Math.round(r.bottom),
          };
        });
      const intersects = (r, z) => r.left < z.right && r.right > z.left && r.top < z.bottom && r.bottom > z.top;
      const violations = visible.filter((r) => intersects(r, zone));
      const chrome = [...document.querySelectorAll(".wordmark, .counter, .rail")].map((el) => {
        const r = el.getBoundingClientRect();
        const cs = getComputedStyle(el);
        return {
          cls: el.className,
          left: Math.round(r.left),
          top: Math.round(r.top),
          right: Math.round(r.right),
          bottom: Math.round(r.bottom),
          visibility: cs.visibility,
          opacity: cs.opacity,
        };
      });
      const chromeViolations = chrome.filter((r) => r.visibility === "visible" && intersects(r, zone));
      return {
        vw,
        vh,
        isMobile,
        zone,
        visible,
        violations,
        chrome,
        chromeViolations,
        progress: window.scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight),
        perf: window.__SEVEN_PERF__,
        preloaderDone: !!document.querySelector(".preloader.done"),
        canvas: !!document.querySelector("canvas"),
        bodyOverflow: getComputedStyle(document.body).overflow,
      };
    });
    const file = path.join(OUT, `${vp.name}-p${p.toFixed(3)}.png`);
    await page.screenshot({ path: file });
    results.push({
      viewport: vp.name,
      p,
      file: path.relative(process.cwd(), file),
      errors,
      warnings,
      requests,
      dom,
    });
    await page.close();
  }
  await context.close();
}

await browser.close();
fs.writeFileSync(path.join(OUT, "results.json"), JSON.stringify(results, null, 2));
console.log(`wrote ${results.length} checkpoints to ${OUT}`);
for (const r of results) {
  console.log(
    `${r.viewport} p=${r.p.toFixed(3)} progress=${r.dom.progress.toFixed(3)} visible=${r.dom.visible.length} violations=${r.dom.violations.length} chromeViolations=${r.dom.chromeViolations.length} errors=${r.errors.length} warnings=${r.warnings.length} perf=${JSON.stringify(r.dom.perf)}`,
  );
}
