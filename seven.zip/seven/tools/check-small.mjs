import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
for (const vp of [{w:320,h:568,name:'320'},{w:720,h:450,name:'zoom200'}]) {
  const context = await browser.newContext({ viewport: { width: vp.w, height: vp.h }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
  for (const p of [0.100, 0.500, 0.900, 1.000]) {
    const page = await context.newPage();
    await page.goto(`http://localhost:5173/?p=${p.toFixed(3)}&hq=1`, { waitUntil: 'load', timeout: 60000 });
    await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
    await page.waitForTimeout(1200);
    const info = await page.evaluate(() => {
      const vw=innerWidth, vh=innerHeight; const isMobile=vw<900;
      const zone = isMobile ? {left:0,top:0,right:vw,bottom:vh*0.58} : {left:vw*0.26,top:vh*0.12,right:vw*0.74,bottom:vh*0.88};
      const blocks=[...document.querySelectorAll('.block, .entry-block')].filter(el=>getComputedStyle(el).visibility==='visible'&&parseFloat(getComputedStyle(el).opacity)>0.01);
      const rects=blocks.map(el=>{const r=el.getBoundingClientRect(); return {cls:el.className,top:Math.round(r.top),bottom:Math.round(r.bottom),left:Math.round(r.left),right:Math.round(r.right),scrollH:el.scrollHeight,clientH:el.clientHeight};});
      const inter=(r)=>r.left<zone.right&&r.right>zone.left&&r.top<zone.bottom&&r.bottom>zone.top;
      return {vw,vh,zone,rects,violations:rects.filter(inter),overflow:rects.filter(r=>r.scrollH>r.clientH+1)};
    });
    console.log(vp.name,p,JSON.stringify(info));
    await page.screenshot({ path: `docs/checkpoints/iteration-1/small-${vp.name}-${p.toFixed(3)}.png` });
    await page.close();
  }
  await context.close();
}
await browser.close();
