import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, isMobile: true, hasTouch: true });
for (const p of [0.100, 0.500, 0.640, 0.900, 1.000]) {
  const page = await context.newPage();
  await page.goto(`http://localhost:5173/?p=${p.toFixed(3)}&hq=1`, { waitUntil: 'load', timeout: 60000 });
  await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
  await page.waitForTimeout(1300);
  await page.screenshot({ path: `docs/checkpoints/iteration-1/mobile2-${p.toFixed(3)}.png` });
  const info = await page.evaluate(() => {
    const blocks = [...document.querySelectorAll('.block, .entry-block')].filter(el => getComputedStyle(el).visibility === 'visible' && parseFloat(getComputedStyle(el).opacity) > 0.01);
    return blocks.map(el => { const r=el.getBoundingClientRect(); return { cls: el.className, top: Math.round(r.top), bottom: Math.round(r.bottom), h: Math.round(r.height), scrollH: el.scrollHeight, clientH: el.clientHeight, text: (el.textContent||'').replace(/\s+/g,' ').slice(0,40) }; });
  });
  console.log(p, JSON.stringify(info));
  await page.close();
}
await browser.close();
