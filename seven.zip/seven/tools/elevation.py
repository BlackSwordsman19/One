#!/usr/bin/env python3
"""
SEVEN — technical elevations.

Draws dimensioned front and back elevations of the kit from the same profile
used by tools/build_jersey.py. Millimetre landmarks come from brief section 4.

Run: python3 tools/elevation.py
"""

from __future__ import annotations

import math
import os

import numpy as np

import build_jersey as bj

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "docs")

S = 1000.0  # px per metre
CX = 500.0
BASE = 900.0


def X(x: float) -> float:
    return CX + x * S


def Y(y: float) -> float:
    return BASE - y * S


def path(points, close=True):
    d = "M " + " L ".join(f"{X(x):.2f} {Y(y):.2f}" for x, y in points)
    return d + (" Z" if close else "")


def dim_h(x0, x1, y, label, tick=6):
    """Horizontal dimension line at height y (metres)."""
    yy = Y(y)
    return (
        f'<line x1="{X(x0):.1f}" y1="{yy:.1f}" x2="{X(x1):.1f}" y2="{yy:.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<line x1="{X(x0):.1f}" y1="{yy-tick:.1f}" x2="{X(x0):.1f}" y2="{yy+tick:.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<line x1="{X(x1):.1f}" y1="{yy-tick:.1f}" x2="{X(x1):.1f}" y2="{yy+tick:.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<text x="{(X(x0)+X(x1))/2:.1f}" y="{yy-6:.1f}" text-anchor="middle" font-family="monospace" font-size="11" fill="#3A3B3E">{label}</text>'
    )


def dim_v(x, y0, y1, label, tick=6):
    """Vertical dimension line at x (metres)."""
    xx = X(x)
    return (
        f'<line x1="{xx:.1f}" y1="{Y(y0):.1f}" x2="{xx:.1f}" y2="{Y(y1):.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<line x1="{xx-tick:.1f}" y1="{Y(y0):.1f}" x2="{xx+tick:.1f}" y2="{Y(y0):.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<line x1="{xx-tick:.1f}" y1="{Y(y1):.1f}" x2="{xx+tick:.1f}" y2="{Y(y1):.1f}" stroke="#6E6F73" stroke-width="1"/>'
        f'<text x="{xx-8:.1f}" y="{(Y(y0)+Y(y1))/2:.1f}" text-anchor="end" font-family="monospace" font-size="11" fill="#3A3B3E">{label}</text>'
    )


def note(x, y, text, anchor="start", size=10, fill="#6E6F73"):
    return (
        f'<text x="{X(x):.1f}" y="{Y(y):.1f}" text-anchor="{anchor}" font-family="monospace" '
        f'font-size="{size}" fill="{fill}">{text}</text>'
    )


def torso_outline(front=True):
    """Silhouette of the body: sides + neckline + hem wave."""
    ys = np.linspace(0.0, 0.620, 80)
    left = []
    right = []
    for y in ys:
        a = float(bj.profile(y)[0])
        left.append((-a, float(y)))
        right.append((a, float(y)))
    # neckline: front dips to 0.688, back to 0.718
    neck_mid = 0.688 if front else 0.718
    neck = [(-0.230, 0.620), (-0.150, 0.655 if front else 0.690), (0.0, neck_mid),
            (0.150, 0.655 if front else 0.690), (0.230, 0.620)]
    # hem wave
    hem = []
    for i in range(81):
        theta = 2 * math.pi * i / 80
        hem.append((float(bj.profile(0.0)[0]) * math.sin(theta), float(bj.hem_wave(theta))))
    # left side down, hem, right side up, neckline
    pts = list(reversed(left)) + hem + right + list(reversed(neck))
    return pts


def sleeve_shape(side):
    s = 1.0 if side == "R" else -1.0
    top = []
    bottom = []
    for i in range(31):
        t = i / 30
        c, tan, sv, up = bj.sleeve_frame(side, t)
        rd, rw = bj.sleeve_radii(t)
        top.append((float(c[0] + up[0] * rw), float(c[1] + up[1] * rw)))
        bottom.append((float(c[0] - up[0] * rw), float(c[1] - up[1] * rw)))
    return top + list(reversed(bottom))


def collar_path(front=True):
    neck_mid = 0.688 if front else 0.718
    pts = [(-0.230, 0.620), (-0.150, 0.655 if front else 0.690), (0.0, neck_mid),
           (0.150, 0.655 if front else 0.690), (0.230, 0.620)]
    return path(pts, close=False)


def shield(w=0.052, h=0.065, cx=0.090, top=0.500):
    pts = []
    pts.append((cx - w / 2, top))
    pts.append((cx + w / 2, top))
    for i in range(1, 17):
        t = i / 16
        x = cx + w / 2 * (1 - t**1.7)
        y = top - h * (0.52 * t + 0.48 * t**2.2)
        pts.append((x, y))
    for i in range(15, -1, -1):
        t = i / 16
        x = cx - w / 2 * (1 - t**1.7)
        y = top - h * (0.52 * t + 0.48 * t**2.2)
        pts.append((x, y))
    return pts


def numeral_7(cx=0.0, top=0.545, h=0.280, w=0.210):
    x0 = cx - w / 2
    x1 = cx + w / 2
    bar = 0.056
    return [
        (x0, top), (x1, top), (x1, top - bar), (0.075 * w, top - bar),
        (-0.215 * w, top - h), (-0.455 * w, top - h), (-0.190 * w, top - bar), (x0, top - bar),
    ]


def svg(front: bool):
    parts = []
    parts.append('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000" width="1000" height="1000">')
    parts.append('<rect width="1000" height="1000" fill="#FFFFFF"/>')
    parts.append(f'<text x="40" y="48" font-family="monospace" font-size="13" letter-spacing="2" fill="#08090B">{"FRONT ELEVATION" if front else "BACK ELEVATION"} · SEVEN KIT · MM</text>')
    parts.append(f'<text x="40" y="68" font-family="monospace" font-size="10" fill="#6E6F73">PORTUGAL No. 7 · SIZE L · COLLAR TOP → HEM 740</text>')

    # sleeves behind body
    for side in ("L", "R"):
        pts = sleeve_shape(side)
        parts.append(f'<path d="{path(pts)}" fill="#A5121E" stroke="#08090B" stroke-width="1.2"/>')
        # cuff
        c, tan, sv, up = bj.sleeve_frame(side, 1.0)
        rd, rw = bj.sleeve_radii(1.0)
        c0, tan0, sv0, up0 = bj.sleeve_frame(side, 1.0 - 0.030 / 0.235)
        cuff = []
        for i in range(25):
            phi = 2 * math.pi * i / 24
            p = c + sv * (rd * math.cos(phi)) + up * (rw * math.sin(phi))
            cuff.append((float(p[0]), float(p[1])))
        parts.append(f'<path d="{path(cuff)}" fill="none" stroke="#046A38" stroke-width="18"/>')

    # body
    body = torso_outline(front)
    parts.append(f'<path d="{path(body)}" fill="#A5121E" stroke="#08090B" stroke-width="1.2"/>')

    # collar
    parts.append(f'<path d="{collar_path(front)}" fill="none" stroke="#046A38" stroke-width="22" stroke-linecap="butt"/>')
    parts.append(f'<path d="{collar_path(front)}" fill="none" stroke="#046A38" stroke-width="22" stroke-linecap="butt" transform="translate(0,-22)" opacity="0.35"/>')

    if front:
        # shield: red field, ivory centre, blue quinas, gold castles
        sp = shield()
        parts.append(f'<path d="{path(sp)}" fill="#C8102E" stroke="#08090B" stroke-width="1"/>')
        inner = shield(0.052 * 0.76, 0.065 * 0.80, 0.090, 0.500 - 0.006)
        parts.append(f'<path d="{path(inner)}" fill="#F2EFE6" stroke="#08090B" stroke-width="0.8"/>')
        for qx, qy in [(0.090, 0.470), (0.0805, 0.470), (0.0995, 0.470), (0.090, 0.4595), (0.090, 0.4805)]:
            q = shield(0.0115, 0.0135, qx, qy + 0.0135)
            parts.append(f'<path d="{path(q)}" fill="#173D7A" stroke="#08090B" stroke-width="0.5"/>')
        for qx, qy in [(0.090, 0.470), (0.0805, 0.470), (0.0995, 0.470), (0.090, 0.4595), (0.090, 0.4805)]:
            for dx, dy in [(0, 0), (-0.0032, 0.0032), (0.0032, 0.0032), (-0.0032, -0.0032), (0.0032, -0.0032)]:
                parts.append(f'<circle cx="{X(qx+dx):.1f}" cy="{Y(qy+0.0135+dy):.1f}" r="1.1" fill="#F2EFE6"/>')
        # dimensions
        parts.append(dim_v(-0.330, 0.0, 0.740, "740"))
        parts.append(dim_h(-0.230, 0.230, 0.585, "460"))
        parts.append(dim_h(-0.280, 0.280, 0.430, "560"))
        parts.append(dim_v(0.430, 0.500, 0.565, "65"))
        parts.append(dim_h(0.000, 0.090, 0.600, "90"))
        parts.append(dim_v(0.330, 0.620, 0.500, "120"))
        parts.append(note(-0.330, 0.760, "COLLAR TOP", anchor="start"))
        parts.append(note(0.430, 0.585, "SHIELD", anchor="start"))
        parts.append(note(0.430, 0.480, "WEARER'S LEFT", anchor="start"))
        parts.append(note(-0.330, 0.410, "CHEST WIDTH 560", anchor="start"))
        parts.append(note(-0.330, 0.300, "SLEEVE 230 · CUFF 30", anchor="start"))
        parts.append(note(-0.330, 0.200, "COLLAR RIB 22", anchor="start"))
        parts.append(note(-0.330, 0.100, "HEM WAVE · SOFT DRAPE", anchor="start"))
    else:
        # name
        parts.append(f'<text x="{X(0):.1f}" y="{Y(0.600):.1f}" text-anchor="middle" font-family="monospace" font-weight="bold" font-size="70" letter-spacing="4" fill="#F2EFE6" stroke="#08090B" stroke-width="0.6">RONALDO</text>')
        # numeral 7
        n = numeral_7()
        parts.append(f'<path d="{path(n)}" fill="#D8B45A" stroke="#8A6A22" stroke-width="1.2"/>')
        # dimensions
        parts.append(dim_v(-0.330, 0.0, 0.740, "740"))
        parts.append(dim_h(-0.230, 0.230, 0.585, "460"))
        parts.append(dim_h(-0.105, 0.105, 0.230, "210"))
        parts.append(dim_v(0.250, 0.265, 0.545, "280"))
        parts.append(dim_v(0.330, 0.685, 0.545, "90"))
        parts.append(dim_v(0.330, 0.575, 0.545, "30"))
        parts.append(dim_v(0.400, 0.575, 0.645, "70"))
        parts.append(note(-0.330, 0.760, "COLLAR TOP", anchor="start"))
        parts.append(note(0.250, 0.200, "NUMERAL 7 · RAISED 3.5", anchor="start"))
        parts.append(note(0.400, 0.560, "NAME ARC R300", anchor="start"))
        parts.append(note(-0.330, 0.410, "CHEST WIDTH 560", anchor="start"))
        parts.append(note(-0.330, 0.300, "SLEEVE 230 · CUFF 30", anchor="start"))
        parts.append(note(-0.330, 0.200, "COLLAR RIB 22", anchor="start"))
        parts.append(note(-0.330, 0.100, "HEM WAVE · SOFT DRAPE", anchor="start"))

    # frame
    parts.append('<rect x="0.5" y="0.5" width="999" height="999" fill="none" stroke="#D8D9DB" stroke-width="1"/>')
    parts.append('</svg>')
    return "\n".join(parts)


def main():
    os.makedirs(OUT, exist_ok=True)
    for front, name in [(True, "kit_front.svg"), (False, "kit_back.svg")]:
        p = os.path.join(OUT, name)
        with open(p, "w", encoding="utf-8") as f:
            f.write(svg(front))
        print(f"wrote {p}")


if __name__ == "__main__":
    main()
