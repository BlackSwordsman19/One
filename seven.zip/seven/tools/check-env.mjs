import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
for (const p of [0.200, 0.335]) {
  const page = await context.newPage();
  await page.goto(`http://localhost:5173/?p=${p.toFixed(3)}&hq=1`, { waitUntil: 'load', timeout: 60000 });
  await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
  await page.waitForTimeout(1300);
  await page.screenshot({ path: `docs/checkpoints/iteration-1/env-${p.toFixed(3)}.png` });
  await page.close();
}
await browser.close();
