import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1, reducedMotion: 'reduce' });
const page = await context.newPage();
const errors=[]; page.on('pageerror', e=>errors.push(e.message)); page.on('console', m=>{ if(m.type()==='error') errors.push(m.text()); });
await page.goto('http://localhost:5173/?p=0.200&hq=1', { waitUntil: 'load', timeout: 60000 });
await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
await page.waitForTimeout(1500);
const info = await page.evaluate(() => ({
  reduced: matchMedia('(prefers-reduced-motion: reduce)').matches,
  visible: [...document.querySelectorAll('.block, .entry-block')].filter(el=>getComputedStyle(el).visibility==='visible'&&parseFloat(getComputedStyle(el).opacity)>0.01).map(el=>(el.textContent||'').replace(/\s+/g,' ').slice(0,30)),
  canvas: !!document.querySelector('canvas'),
  preloaderDone: !!document.querySelector('.preloader.done'),
}));
console.log(JSON.stringify(info, null, 2), 'errors', errors.slice(0,3));
await page.screenshot({ path: 'docs/checkpoints/iteration-1/reduced-motion.png' });
await browser.close();
