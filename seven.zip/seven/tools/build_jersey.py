#!/usr/bin/env python3
"""
SEVEN — procedural Portugal No. 7 kit builder.

Builds the complete hero garment from scratch (no Blender, no external or
third-party assets) and writes a single self-contained binary glTF:

    public/models/sev7_kit.glb

Everything is generated from the landmark table in the build brief:
  * lofted hollow jersey body with sloped yoke, set-in sleeves, soft hem wave
  * ribbed crew collar and ribbed cuffs
  * raised, beveled appliqué numeral 7 drawn by hand as a heavy athletic block
  * raised, beveled, arched RONALDO name set from an OFL grotesque outline
  * simplified heraldic Portuguese chest shield (public-domain arms language)
  * procedural knit normal + roughness maps embedded in the GLB

Run:  python3 tools/build_jersey.py
"""

from __future__ import annotations

import json
import math
import os
import struct
from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np
from fontTools.pens.basePen import BasePen
from fontTools.ttLib import TTFont
from PIL import Image
import mapbox_earcut as earcut

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "public", "models", "sev7_kit.glb")
FONT = os.path.join(ROOT, "public", "fonts", "anton-400.woff2")

TAU = math.pi * 2.0
D2R = math.pi / 180.0

# ----------------------------------------------------------------------------
# palette (sRGB hex from the brief)
# ----------------------------------------------------------------------------
C_KIT_RED = "#A5121E"
C_KIT_TRIM = "#046A38"
C_NUMERAL_GOLD = "#D8B45A"
C_NAME_IVORY = "#F2EFE6"
C_CREST_GOLD = "#C9A227"
C_CREST_BLUE = "#173D7A"
C_CREST_RED = "#C8102E"
C_STITCH = "#6E0B13"


def srgb_to_linear(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def hex_lin(h: str) -> list[float]:
    h = h.lstrip("#")
    return [srgb_to_linear(int(h[i : i + 2], 16) / 255.0) for i in (0, 2, 4)] + [1.0]


# ----------------------------------------------------------------------------
# garment profile — metres, Y up, collar top at 0.740, hem at 0.0
# ----------------------------------------------------------------------------
# key heights: hem, waist, chest, shoulder seam, yoke, neck
PROFILE = [
    # y,     a,     b_front, b_back
    (0.000, 0.280, 0.160, 0.150),
    (0.060, 0.274, 0.158, 0.148),
    (0.140, 0.260, 0.152, 0.143),
    (0.220, 0.250, 0.147, 0.140),
    (0.300, 0.248, 0.149, 0.142),
    (0.380, 0.256, 0.158, 0.147),
    (0.460, 0.266, 0.170, 0.153),
    (0.530, 0.270, 0.176, 0.156),
    (0.580, 0.262, 0.172, 0.153),
    (0.620, 0.230, 0.160, 0.145),
    (0.632, 0.214, 0.152, 0.139),
    (0.644, 0.198, 0.144, 0.133),
    (0.656, 0.182, 0.136, 0.127),
    (0.668, 0.162, 0.126, 0.120),
    (0.678, 0.136, 0.113, 0.110),
    (0.685, 0.085, 0.085, 0.085),
]
P_Y = np.array([p[0] for p in PROFILE])
P_A = np.array([p[1] for p in PROFILE])
P_BF = np.array([p[2] for p in PROFILE])
P_BB = np.array([p[3] for p in PROFILE])

SHOULDER_Y = 0.620
NECK_A = 0.085
COLLAR_TOP = 0.740


def _catmull(ts: np.ndarray, vs: np.ndarray, x: np.ndarray) -> np.ndarray:
    """Catmull-Rom through (ts, vs), clamped at the ends."""
    x = np.clip(x, ts[0], ts[-1])
    i = np.clip(np.searchsorted(ts, x, side="right") - 1, 0, len(ts) - 2)
    t = (x - ts[i]) / (ts[i + 1] - ts[i])
    p0 = vs[np.maximum(i - 1, 0)]
    p1 = vs[i]
    p2 = vs[i + 1]
    p3 = vs[np.minimum(i + 2, len(vs) - 1)]
    return 0.5 * (
        (2 * p1)
        + (-p0 + p2) * t
        + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
        + (-p0 + 3 * p1 - 3 * p2 + p3) * t * t * t
    )


def profile(y):
    y = np.asarray(y, dtype=float)
    return _catmull(P_Y, P_A, y), _catmull(P_Y, P_BF, y), _catmull(P_Y, P_BB, y)


def neck_y(theta):
    """Crew neckline: lower at the front (theta=0), higher at the back."""
    return 0.703 - 0.015 * np.cos(theta)


def superellipse(theta, a, bf, bb, n=2.55):
    """Cross-section. theta=0 is front (-Z), theta=pi is back (+Z)."""
    s = np.sin(theta)
    c = np.cos(theta)
    x = a * np.sign(s) * np.abs(s) ** (2.0 / n)
    b = np.where(c >= 0, bf, bb)
    z = -b * np.sign(c) * np.abs(c) ** (2.0 / n)
    return x, z


def hem_wave(theta):
    return 0.010 * np.sin(3.0 * theta + 0.4) + 0.005 * np.sin(7.0 * theta + 1.1)


def torso_point(theta, y):
    a, bf, bb = profile(y)
    x, z = superellipse(theta, a, bf, bb)
    # soft vertical drape folds, strongest near the hem
    w = np.clip((0.30 - y) / 0.30, 0.0, 1.0)
    fold = (0.0022 * np.sin(6.0 * theta + 1.3) + 0.0011 * np.sin(11.0 * theta + 0.7)) * w
    # radial direction of the cross-section
    r = np.sqrt((x / max(a, 1e-6)) ** 2 + (z / max(bf if z < 0 else bb, 1e-6)) ** 2) + 1e-9
    x = x + fold * (x / (a * r))
    z = z + fold * (z / ((bf if z < 0 else bb) * r))
    return x, y, z


def torso_frame(theta, y):
    """Point + outward normal on the torso (finite differences)."""
    e = 1e-4
    p = np.array(torso_point(theta, y))
    pt = np.array(torso_point(theta + e, y))
    pu = np.array(torso_point(theta, min(y + e, 0.6849)))
    pd = np.array(torso_point(theta, max(y - e, 0.0)))
    n = np.cross(pt - p, pu - pd)
    if np.dot(n, np.array([p[0], 0.0, p[2]])) < 0:
        n = -n
    ln = np.linalg.norm(n)
    return p, n / ln if ln > 1e-12 else np.array([0.0, 0.0, 1.0])


def back_map(x, y, offset=0.0):
    """Map a flat back-panel coordinate (x right, y up) onto the back surface."""
    a, bf, bb = profile(y)
    theta = np.pi - np.clip(x / np.maximum(a, 1e-4), -2.4, 2.4)
    p, n = torso_frame(theta, y)
    return p + n * offset, n


def front_map(x, y, offset=0.0):
    """Map a flat front-panel coordinate (x right, y up) onto the front surface."""
    a, bf, bb = profile(y)
    theta = np.clip(x / np.maximum(a, 1e-4), -2.4, 2.4)
    p, n = torso_frame(theta, y)
    return p + n * offset, n


# ----------------------------------------------------------------------------
# mesh builder
# ----------------------------------------------------------------------------
@dataclass
class Mesh:
    pos: list = field(default_factory=list)
    nor: list = field(default_factory=list)
    uv: list = field(default_factory=list)
    idx: list = field(default_factory=list)

    def vert(self, p, n, uv):
        self.pos.append((float(p[0]), float(p[1]), float(p[2])))
        self.nor.append((float(n[0]), float(n[1]), float(n[2])))
        self.uv.append((float(uv[0]), float(uv[1])))
        return len(self.pos) - 1

    def tri(self, a, b, c):
        self.idx.extend((a, b, c))

    def quad(self, a, b, c, d):
        self.idx.extend((a, b, c, a, c, d))

    def add_grid(self, rows, cols, fn, uv_fn, close_u=False, flip=False):
        """rows x cols grid of vertices; fn(i,j)->(p,n), uv_fn(i,j)->(u,v)."""
        base = len(self.pos)
        for j in range(rows):
            for i in range(cols):
                p, n = fn(i, j)
                self.vert(p, n, uv_fn(i, j))
        for j in range(rows - 1):
            for i in range(cols - 1):
                a = base + j * cols + i
                b = a + 1
                c = a + cols + 1
                d = a + cols
                if flip:
                    self.quad(a, d, c, b)
                else:
                    self.quad(a, b, c, d)

    def merge(self, other: "Mesh"):
        base = len(self.pos)
        self.pos.extend(other.pos)
        self.nor.extend(other.nor)
        self.uv.extend(other.uv)
        self.idx.extend(base + i for i in other.idx)

    def bounds(self):
        p = np.array(self.pos)
        return p.min(axis=0), p.max(axis=0)


def grid_normals(rows, cols, pts, close_u=False):
    """Smooth normals from a regular grid of points."""
    pts = np.asarray(pts, dtype=float)
    if pts.ndim == 2:
        pts = pts.reshape(rows, cols, 3)
    normals = np.zeros_like(pts)
    for j in range(rows):
        for i in range(cols):
            i0 = (i - 1) % cols if close_u else max(i - 1, 0)
            i1 = (i + 1) % cols if close_u else min(i + 1, cols - 1)
            j0 = max(j - 1, 0)
            j1 = min(j + 1, rows - 1)
            du = pts[j, i1] - pts[j, i0]
            dv = pts[j1, i] - pts[j0, i]
            n = np.cross(du, dv)
            ln = np.linalg.norm(n)
            normals[j, i] = n / ln if ln > 1e-12 else (0, 0, 1)
    # orient outward from the vertical axis
    radial = np.stack([pts[:, :, 0], np.zeros_like(pts[:, :, 0]), pts[:, :, 2]], axis=-1)
    flip = np.einsum("ijk,ijk->ij", normals, radial) < 0
    normals[flip] *= -1
    return normals


# ----------------------------------------------------------------------------
# torso
# ----------------------------------------------------------------------------
def build_torso(n_theta=232, n_lower=88, n_yoke=30):
    rows = n_lower + n_yoke + 1
    cols = n_theta + 1
    pts = []
    for j in range(rows):
        for i in range(cols):
            theta = TAU * i / n_theta
            if j <= n_lower:
                v = j / n_lower
                y0 = hem_wave(theta)
                y = y0 + v * (SHOULDER_Y - y0)
                x, yy, z = torso_point(theta, y)
            else:
                t = (j - n_lower) / n_yoke
                y = (1 - t) * SHOULDER_Y + t * neck_y(theta)
                a = (1 - t) * 0.230 + t * NECK_A
                bf = (1 - t) * 0.160 + t * NECK_A
                bb = (1 - t) * 0.145 + t * NECK_A
                x, z = superellipse(theta, a, bf, bb)
                # a small shoulder-seam ridge
                ridge = 0.0018 * math.exp(-((t - 0.06) / 0.05) ** 2)
                x += ridge * math.sin(theta)
                z -= ridge * math.cos(theta)
            pts.append((x, y, z))
    normals = grid_normals(rows, cols, pts, close_u=True)
    mesh = Mesh()
    for j in range(rows):
        for i in range(cols):
            theta = TAU * i / n_theta
            y = pts[j * cols + i][1]
            u = i / n_theta
            v = 0.5 + 0.5 * (y / COLLAR_TOP)
            mesh.vert(pts[j * cols + i], normals[j, i], (u, v))
    for j in range(rows - 1):
        for i in range(n_theta):
            a = j * cols + i
            b = a + 1
            c = a + cols + 1
            d = a + cols
            mesh.quad(a, b, c, d)
    return mesh


def build_hem_band(n_theta=232):
    """Small inward flange at the hem so the garment reads as cloth with body."""
    mesh = Mesh()
    cols = n_theta + 1
    rows = 2
    pts = []
    for j in range(rows):
        for i in range(cols):
            theta = TAU * i / n_theta
            y0 = hem_wave(theta)
            if j == 0:
                x, y, z = torso_point(theta, y0 + 0.001)
            else:
                x, y, z = torso_point(theta, y0 + 0.018)
                # pull inward toward the body
                x *= 0.965
                z *= 0.94
            pts.append((x, y, z))
    normals = grid_normals(rows, cols, pts, close_u=True)
    for j in range(rows):
        for i in range(cols):
            mesh.vert(pts[j * cols + i], normals[j, i], (i / n_theta, 0.02 + j * 0.02))
    for i in range(n_theta):
        a = i
        b = i + 1
        c = cols + i + 1
        d = cols + i
        mesh.quad(a, b, c, d)
    return mesh


# ----------------------------------------------------------------------------
# sleeves
# ----------------------------------------------------------------------------
def sleeve_path(side):
    s = 1.0 if side == "R" else -1.0
    p0 = np.array([0.205 * s, 0.590, 0.000])
    p1 = np.array([0.255 * s, 0.545, -0.012])
    p2 = np.array([0.300 * s, 0.465, -0.032])
    p3 = np.array([0.325 * s, 0.375, -0.048])
    return p0, p1, p2, p3


def bezier(p0, p1, p2, p3, t):
    t = np.asarray(t)
    mt = 1 - t
    return (
        mt**3 * p0
        + 3 * mt**2 * t * p1
        + 3 * mt * t**2 * p2
        + t**3 * p3
    )


def bezier_tan(p0, p1, p2, p3, t):
    t = np.asarray(t)
    mt = 1 - t
    return (
        3 * mt**2 * (p1 - p0)
        + 6 * mt * t * (p2 - p1)
        + 3 * t**2 * (p3 - p2)
    )


def sleeve_frame(side, t):
    p0, p1, p2, p3 = sleeve_path(side)
    c = bezier(p0, p1, p2, p3, t)
    tan = bezier_tan(p0, p1, p2, p3, t)
    tan = tan / np.linalg.norm(tan)
    up = np.array([0.0, 1.0, 0.0])
    side_v = np.cross(up, tan)
    side_v /= np.linalg.norm(side_v)
    up2 = np.cross(tan, side_v)
    up2 /= np.linalg.norm(up2)
    return c, tan, side_v, up2


def sleeve_radii(t):
    # depth (front-back) and width (up-down)
    rd = 0.116 * (1 - t) + 0.088 * t
    rw = 0.106 * (1 - t) + 0.078 * t
    return rd, rw


def build_sleeve(side, n_path=56, n_theta=96):
    cols = n_theta + 1
    rows = n_path + 1
    pts = []
    for j in range(rows):
        t = j / n_path
        c, tan, sv, up = sleeve_frame(side, t)
        rd, rw = sleeve_radii(t)
        for i in range(cols):
            phi = TAU * i / n_theta
            # subtle cloth folds along the sleeve
            fold = 0.0016 * math.sin(5 * phi + 9 * t) * math.sin(math.pi * t)
            p = c + sv * ((rd + fold) * math.cos(phi)) + up * ((rw + fold) * math.sin(phi))
            pts.append(p)
    normals = grid_normals(rows, cols, pts, close_u=True)
    # grid_normals orients radially from the Y axis; sleeves need their own axis
    for j in range(rows):
        c, tan, sv, up = sleeve_frame(side, j / n_path)
        for i in range(cols):
            phi = TAU * i / n_theta
            radial = sv * math.cos(phi) + up * math.sin(phi)
            n = normals[j, i]
            if np.dot(n, radial) < 0:
                normals[j, i] = -n
    mesh = Mesh()
    u0 = 0.0 if side == "R" else 0.5
    for j in range(rows):
        for i in range(cols):
            mesh.vert(pts[j * cols + i], normals[j, i], (u0 + 0.5 * i / n_theta, 0.5 * j / n_path))
    for j in range(rows - 1):
        for i in range(n_theta):
            a = j * cols + i
            b = a + 1
            c = a + cols + 1
            d = a + cols
            mesh.quad(a, b, c, d)
    return mesh


def build_cuff(side, n_theta=96):
    """Ribbed cuff, 30 mm, wrapped around the sleeve end."""
    t0 = 1.0 - 0.030 / 0.235
    rows = 2
    cols = n_theta + 1
    mesh = Mesh()
    # four walls: outer, end rim, inner, start rim
    rings = []
    for layer in range(4):
        ring = []
        for i in range(cols):
            phi = TAU * i / n_theta
            if layer == 0:  # outer wall bottom
                t = t0
                c, tan, sv, up = sleeve_frame(side, t)
                rd, rw = sleeve_radii(t)
                rib = 0.0012 * math.cos(40 * phi)
                p = c + sv * ((rd + 0.005 + rib) * math.cos(phi)) + up * ((rw + 0.005 + rib) * math.sin(phi))
                n = (sv * math.cos(phi) + up * math.sin(phi)).copy()
            elif layer == 1:  # outer wall top
                t = 1.0
                c, tan, sv, up = sleeve_frame(side, t)
                rd, rw = sleeve_radii(t)
                rib = 0.0012 * math.cos(40 * phi)
                p = c + sv * ((rd + 0.005 + rib) * math.cos(phi)) + up * ((rw + 0.005 + rib) * math.sin(phi))
                n = tan.copy()
            elif layer == 2:  # inner wall top
                t = 1.0
                c, tan, sv, up = sleeve_frame(side, t)
                rd, rw = sleeve_radii(t)
                p = c + sv * ((rd - 0.004) * math.cos(phi)) + up * ((rw - 0.004) * math.sin(phi))
                n = tan.copy()
            else:  # inner wall bottom
                t = t0
                c, tan, sv, up = sleeve_frame(side, t)
                rd, rw = sleeve_radii(t)
                p = c + sv * ((rd - 0.004) * math.cos(phi)) + up * ((rw - 0.004) * math.sin(phi))
                n = -(sv * math.cos(phi) + up * math.sin(phi))
            ring.append((p, n))
        rings.append(ring)
    base = len(mesh.pos)
    for layer, ring in enumerate(rings):
        for i in range(cols):
            p, n = ring[i]
            mesh.vert(p, n, (i / n_theta, 0.02 + layer * 0.02))
    for layer in range(4):
        for i in range(n_theta):
            a = base + layer * cols + i
            b = a + 1
            c = base + ((layer + 1) % 4) * cols + i + 1
            d = base + ((layer + 1) % 4) * cols + i
            mesh.quad(a, b, c, d)
    return mesh


# ----------------------------------------------------------------------------
# collar
# ----------------------------------------------------------------------------
def build_collar(n_theta=128):
    cols = n_theta + 1
    layers = 4
    rings = []
    for layer in range(layers):
        ring = []
        for i in range(cols):
            theta = TAU * i / n_theta
            y0 = neck_y(theta)
            if layer == 0:  # outer base
                r = 0.092 + 0.0012 * math.cos(48 * theta)
                p = np.array([r * math.sin(theta), y0, -r * math.cos(theta)])
                n = np.array([math.sin(theta), 0.0, -math.cos(theta)])
            elif layer == 1:  # outer top
                r = 0.092 + 0.0012 * math.cos(48 * theta)
                p = np.array([r * math.sin(theta), y0 + 0.022, -r * math.cos(theta)])
                n = np.array([math.sin(theta), 1.4, -math.cos(theta)])
                n /= np.linalg.norm(n)
            elif layer == 2:  # inner top
                r = 0.080 + 0.0008 * math.cos(48 * theta)
                p = np.array([r * math.sin(theta), y0 + 0.022, -r * math.cos(theta)])
                n = np.array([-math.sin(theta), 1.4, math.cos(theta)])
                n /= np.linalg.norm(n)
            else:  # inner base
                r = 0.080 + 0.0008 * math.cos(48 * theta)
                p = np.array([r * math.sin(theta), y0, -r * math.cos(theta)])
                n = -np.array([math.sin(theta), 0.0, -math.cos(theta)])
            ring.append((p, n))
        rings.append(ring)
    mesh = Mesh()
    base = len(mesh.pos)
    for layer, ring in enumerate(rings):
        for i in range(cols):
            p, n = ring[i]
            mesh.vert(p, n, (i / n_theta, 0.02 + layer * 0.02))
    for layer in range(layers):
        for i in range(n_theta):
            a = base + layer * cols + i
            b = a + 1
            c = base + ((layer + 1) % layers) * cols + i + 1
            d = base + ((layer + 1) % layers) * cols + i
            mesh.quad(a, b, c, d)
    return mesh


# ----------------------------------------------------------------------------
# 2D shape utilities (extrusion + triangulation)
# ----------------------------------------------------------------------------
def signed_area(contour):
    c = np.asarray(contour, dtype=float)
    return 0.5 * np.sum(c[:, 0] * np.roll(c[:, 1], -1) - np.roll(c[:, 0], -1) * c[:, 1])


def clean_contour(contour, eps=1e-7):
    out = []
    for p in contour:
        if not out or abs(p[0] - out[-1][0]) + abs(p[1] - out[-1][1]) > eps:
            out.append((float(p[0]), float(p[1])))
    if len(out) > 1 and abs(out[0][0] - out[-1][0]) + abs(out[0][1] - out[-1][1]) < eps:
        out.pop()
    return out


def contour_centroid(contour):
    c = np.asarray(contour, dtype=float)
    a = signed_area(c)
    if abs(a) < 1e-12:
        return c.mean(axis=0)
    x = (c[:, 0] + np.roll(c[:, 0], -1)) * (c[:, 0] * np.roll(c[:, 1], -1) - np.roll(c[:, 0], -1) * c[:, 1])
    y = (c[:, 1] + np.roll(c[:, 1], -1)) * (c[:, 0] * np.roll(c[:, 1], -1) - np.roll(c[:, 0], -1) * c[:, 1])
    return np.array([x.sum() / (6 * a), y.sum() / (6 * a)])


def scale_contour(contour, factor, center=None):
    c = np.asarray(contour, dtype=float)
    if center is None:
        center = contour_centroid(c)
    return (c - center) * factor + center


def triangulate(contours):
    """Ear-cut a polygon with holes. Returns (vertices Nx2, triangles Mx3)."""
    verts = []
    rings = []
    for c in contours:
        start = len(verts)
        verts.extend([tuple(p) for p in c])
        rings.append(len(verts))
    v = np.asarray(verts, dtype=np.float32)
    r = np.asarray(rings, dtype=np.uint32)
    tris = earcut.triangulate_float32(v, r)
    return v, tris.reshape(-1, 3)


def add_extruded_shape(
    mesh: Mesh,
    contours: Sequence[Sequence[tuple[float, float]]],
    map_fn,
    base_offset: float,
    top_offset: float,
    bevel: float = 0.985,
    uv_scale: float = 1.0,
    back_face: bool = True,
):
    """
    Extrude a 2D contour (with holes) onto a curved surface.

    contours[0] is the outer contour, the rest are holes. The base ring sits at
    base_offset, the front ring is scaled by `bevel` and sits at top_offset.
    """
    contours = [clean_contour(c) for c in contours]
    center = contour_centroid(contours[0])
    scaled = [scale_contour(c, bevel, center) for c in contours]

    # front face (scaled contours, at top offset)
    v2, tris = triangulate(scaled)
    front_start = len(mesh.pos)
    front_normals = []
    for (x, y) in v2:
        p, n = map_fn(x, y, top_offset)
        mesh.vert(p, n, (x * uv_scale + 0.5, y * uv_scale + 0.5))
        front_normals.append(n)
    # orient each front triangle outward
    for t in tris:
        a, b, c = int(t[0]), int(t[1]), int(t[2])
        p0, p1, p2 = np.array(mesh.pos[front_start + a]), np.array(mesh.pos[front_start + b]), np.array(mesh.pos[front_start + c])
        fn = np.cross(p1 - p0, p2 - p0)
        if np.dot(fn, front_normals[a]) < 0:
            mesh.idx.extend((front_start + a, front_start + c, front_start + b))
        else:
            mesh.idx.extend((front_start + a, front_start + b, front_start + c))

    # back face (base contours, at base offset) — optional, hidden against cloth
    if back_face:
        v2b, trisb = triangulate(contours)
        back_start = len(mesh.pos)
        back_normals = []
        for (x, y) in v2b:
            p, n = map_fn(x, y, base_offset)
            mesh.vert(p, -n, (x * uv_scale + 0.5, y * uv_scale + 0.5))
            back_normals.append(-n)
        for t in trisb:
            a, b, c = int(t[0]), int(t[1]), int(t[2])
            p0, p1, p2 = np.array(mesh.pos[back_start + a]), np.array(mesh.pos[back_start + b]), np.array(mesh.pos[back_start + c])
            fn = np.cross(p1 - p0, p2 - p0)
            if np.dot(fn, back_normals[a]) < 0:
                mesh.idx.extend((back_start + a, back_start + c, back_start + b))
            else:
                mesh.idx.extend((back_start + a, back_start + b, back_start + c))

    # side walls
    for ci, (base_c, top_c) in enumerate(zip(contours, scaled)):
        n = len(base_c)
        is_hole = ci > 0
        # orientation sign: outer contours CCW, holes CW (earcut doesn't care)
        orient = 1.0 if not is_hole else -1.0
        if signed_area(base_c) < 0:
            orient *= -1.0
        for i in range(n):
            j = (i + 1) % n
            b0 = base_c[i]
            b1 = base_c[j]
            t0 = top_c[i]
            t1 = top_c[j]
            p0, n0 = map_fn(b0[0], b0[1], base_offset)
            p1, n1 = map_fn(b1[0], b1[1], base_offset)
            p2, n2 = map_fn(t1[0], t1[1], top_offset)
            p3, n3 = map_fn(t0[0], t0[1], top_offset)
            # flat side normal, pointing away from the shape
            e = np.array(p1) - np.array(p0)
            up = np.array(p3) - np.array(p0)
            fn = np.cross(e, up)
            mid = (np.array(p0) + np.array(p1)) * 0.5
            cen = map_fn(center[0], center[1], base_offset)[0]
            outward = mid - cen
            if np.dot(fn, outward) < 0:
                fn = -fn
            ln = np.linalg.norm(fn)
            if ln < 1e-12:
                fn = n0
            else:
                fn = fn / ln
            i0 = mesh.vert(p0, fn, (0.0, 0.0))
            i1 = mesh.vert(p1, fn, (1.0, 0.0))
            i2 = mesh.vert(p2, fn, (1.0, 1.0))
            i3 = mesh.vert(p3, fn, (0.0, 1.0))
            # wind the quad so its face normal agrees with fn
            p0v, p1v, p2v = np.array(mesh.pos[i0]), np.array(mesh.pos[i1]), np.array(mesh.pos[i2])
            if np.dot(np.cross(p1v - p0v, p2v - p0v), fn) >= 0:
                mesh.quad(i0, i1, i2, i3)
            else:
                mesh.quad(i0, i3, i2, i1)


# ----------------------------------------------------------------------------
# numeral 7 — hand-drawn heavy athletic block
# ----------------------------------------------------------------------------
NUMERAL_TOP = 0.545
NUMERAL_H = 0.280
NUMERAL_W = 0.210


def numeral_contour():
    """Custom heavy athletic block 7. 210 x 280 mm, squared counters."""
    w = NUMERAL_W
    h = NUMERAL_H
    x0 = -w / 2
    x1 = w / 2
    bar = 0.056 * h / 0.280  # top bar thickness
    # points, counter-clockwise, starting top-left
    pts = [
        (x0, h),
        (x1, h),
        (x1, h - bar),
        (0.075 * w, h - bar),
        (-0.215 * w, 0.0),
        (-0.455 * w, 0.0),
        (-0.190 * w, h - bar),
        (x0, h - bar),
    ]
    return [clean_contour(pts)]


def build_numeral():
    contour = numeral_contour()
    mesh = Mesh()

    def map_fn(x, y, off):
        return back_map(x, NUMERAL_TOP - NUMERAL_H + y, off)

    add_extruded_shape(mesh, contour, map_fn, 0.0006, 0.0042, bevel=0.972, uv_scale=2.0, back_face=True)
    return mesh


# ----------------------------------------------------------------------------
# name — RONALDO, set from an OFL grotesque outline, arched, raised
# ----------------------------------------------------------------------------
class FlattenPen(BasePen):
    def __init__(self, glyph_set):
        super().__init__(glyph_set)
        self.contours = []
        self.current = []

    def _moveTo(self, p):
        if self.current:
            self.contours.append(self.current)
        self.current = [p]

    def _lineTo(self, p):
        self.current.append(p)

    def _qCurveToOne(self, p1, p2):
        x0, y0 = self.current[-1]
        steps = 10
        for i in range(1, steps + 1):
            t = i / steps
            mt = 1 - t
            x = mt * mt * x0 + 2 * mt * t * p1[0] + t * t * p2[0]
            y = mt * mt * y0 + 2 * mt * t * p1[1] + t * t * p2[1]
            self.current.append((x, y))

    def _curveToOne(self, p1, p2, p3):
        x0, y0 = self.current[-1]
        steps = 12
        for i in range(1, steps + 1):
            t = i / steps
            mt = 1 - t
            x = mt**3 * x0 + 3 * mt * mt * t * p1[0] + 3 * mt * t * t * p2[0] + t**3 * p3[0]
            y = mt**3 * y0 + 3 * mt * mt * t * p1[1] + 3 * mt * t * t * p2[1] + t**3 * p3[1]
            self.current.append((x, y))

    def _closePath(self):
        if self.current:
            self.contours.append(self.current)
            self.current = []

    def _endPath(self):
        if self.current:
            self.contours.append(self.current)
            self.current = []


def glyph_contours(font, glyph_name):
    glyph_set = font.getGlyphSet()
    pen = FlattenPen(glyph_set)
    glyph_set[glyph_name].draw(pen)
    if pen.current:
        pen.contours.append(pen.current)
    return [clean_contour(c) for c in pen.contours if len(c) >= 3]


def order_contours(contours):
    """Outer contour first, then holes (largest absolute area is outer)."""
    areas = [abs(signed_area(c)) for c in contours]
    outer = int(np.argmax(areas))
    rest = [i for i in range(len(contours)) if i != outer]
    rest.sort(key=lambda i: -areas[i])
    return [contours[outer]] + [contours[i] for i in rest]


def build_name():
    font = TTFont(FONT)
    cmap = font.getBestCmap()
    hmtx = font["hmtx"]
    upm = font["head"].unitsPerEm
    cap = font["OS/2"].sCapHeight
    scale = 0.070 / cap
    text = "RONALDO"
    tracking = 0.0025
    # measure
    advances = []
    glyphs = []
    for ch in text:
        gname = cmap[ord(ch)]
        advances.append(hmtx[gname][0] * scale)
        glyphs.append((gname, glyph_contours(font, gname)))
    total = sum(advances) + tracking * (len(text) - 1)
    # arc: gentle upward-opening arc (ends slightly higher), radius 900 mm
    R = 0.900
    base_y = 0.575
    mesh = Mesh()
    pen_x = -total / 2
    for (gname, contours), adv in zip(glyphs, advances):
        contours = order_contours(contours)
        # build the glyph as one shape (outer + holes)
        mapped_contours = []
        for contour in contours:
            local = [(pen_x + x * scale, y * scale) for (x, y) in contour]
            mapped = []
            for (lx, ly) in local:
                phi = lx / R
                ax = (R - ly) * math.sin(phi)
                ay = base_y + R - (R - ly) * math.cos(phi)
                mapped.append((ax, ay))
            mapped_contours.append(mapped)

        def map_fn(x, y, off, _mapped=mapped_contours):
            # x,y are already in the arched word space; map to the back
            return back_map(x, y, off)

        add_extruded_shape(
            mesh,
            mapped_contours,
            map_fn,
            0.0004,
            0.0028,
            bevel=0.982,
            uv_scale=3.0,
            back_face=True,
        )
        pen_x += adv + tracking
    return mesh


# ----------------------------------------------------------------------------
# chest shield — simplified Portuguese arms (public domain language)
# ----------------------------------------------------------------------------
def shield_outline(w, h, n=28):
    """Heraldic shield, flat top, curved sides, pointed base."""
    pts = []
    # top edge
    pts.append((-w / 2, 0.0))
    pts.append((w / 2, 0.0))
    # right side down
    for i in range(1, n + 1):
        t = i / n
        x = w / 2 * (1 - t**1.7)
        y = -h * (0.52 * t + 0.48 * t**2.2)
        pts.append((x, y))
    # left side up
    for i in range(n - 1, -1, -1):
        t = i / n
        x = -w / 2 * (1 - t**1.7)
        y = -h * (0.52 * t + 0.48 * t**2.2)
        pts.append((x, y))
    return clean_contour(pts)


def mini_shield(w, h):
    return shield_outline(w, h, n=12)


def build_shield():
    """Layered simplified Portuguese shield on the wearer's left chest."""
    cx = -0.090
    top = 0.500
    w, h = 0.052, 0.065
    mesh = Mesh()

    def layer_map(dx, dy, off):
        def fn(x, y, o):
            return front_map(cx + x, top + y, o)
        return fn

    # We build each layer as its own Mesh, then merge with material groups later.
    # For simplicity, return a dict of meshes keyed by material.
    parts = {}

    # outer red shield
    m = Mesh()
    add_extruded_shape(m, [shield_outline(w, h)], layer_map(0, 0, 0), 0.0012, 0.0030, bevel=0.985, uv_scale=8.0, back_face=False)
    parts["red"] = m

    # ivory field
    m = Mesh()
    add_extruded_shape(m, [shield_outline(w * 0.76, h * 0.80)], layer_map(0, -0.006, 0), 0.0030, 0.0042, bevel=0.985, uv_scale=8.0, back_face=False)
    parts["ivory"] = m

    # five blue quinas in cross
    m = Mesh()
    qw, qh = 0.0115, 0.0135
    positions = [(0.0, -0.030), (-0.0095, -0.030), (0.0095, -0.030), (0.0, -0.0405), (0.0, -0.0195)]
    for (qx, qy) in positions:
        add_extruded_shape(
            m,
            [mini_shield(qw, qh)],
            layer_map(qx, qy, 0),
            0.0042,
            0.0052,
            bevel=0.97,
            uv_scale=12.0,
            back_face=False,
        )
    parts["blue"] = m

    # white bezants (5 per quina)
    m = Mesh()
    for (qx, qy) in positions:
        for (dx, dy) in [(0.0, 0.0), (-0.0032, 0.0032), (0.0032, 0.0032), (-0.0032, -0.0032), (0.0032, -0.0032)]:
            # tiny low-poly cylinder, axis along the surface normal
            p, n = front_map(cx + qx + dx, top + qy + dy, 0.0054)
            # build a small disc facing outward
            tangent = np.cross(n, np.array([0.0, 1.0, 0.0]))
            if np.linalg.norm(tangent) < 1e-6:
                tangent = np.array([1.0, 0.0, 0.0])
            tangent /= np.linalg.norm(tangent)
            bitangent = np.cross(n, tangent)
            r = 0.0011
            center = p
            ring = []
            for k in range(8):
                a = TAU * k / 8
                ring.append(center + tangent * (r * math.cos(a)) + bitangent * (r * math.sin(a)))
            base = len(m.pos)
            for k in range(8):
                m.vert(ring[k], n, (0.5 + 0.5 * math.cos(TAU * k / 8), 0.5 + 0.5 * math.sin(TAU * k / 8)))
            m.vert(center + n * 0.0008, n, (0.5, 0.5))
            for k in range(8):
                m.tri(base + k, base + (k + 1) % 8, base + 8)
    parts["white"] = m

    # seven gold castles around the border
    m = Mesh()
    castle_positions = [
        (-0.014, -0.006), (0.0, -0.004), (0.014, -0.006),
        (-0.019, -0.016), (0.019, -0.016),
        (-0.014, -0.026), (0.014, -0.026),
    ]
    for (qx, qy) in castle_positions:
        p, n = front_map(cx + qx, top + qy, 0.0044)
        tangent = np.cross(n, np.array([0.0, 1.0, 0.0]))
        if np.linalg.norm(tangent) < 1e-6:
            tangent = np.array([1.0, 0.0, 0.0])
        tangent /= np.linalg.norm(tangent)
        bitangent = np.cross(n, tangent)
        # small square block
        c = p
        s = 0.0016
        corners = [c + tangent * s + bitangent * s, c - tangent * s + bitangent * s, c - tangent * s - bitangent * s, c + tangent * s - bitangent * s]
        base = len(m.pos)
        for k, corner in enumerate(corners):
            m.vert(corner + n * 0.0012, n, (k / 3, 0.0))
        for k, corner in enumerate(corners):
            m.vert(corner, n, (k / 3, 1.0))
        m.quad(base, base + 1, base + 2, base + 3)
        m.quad(base + 4, base + 7, base + 6, base + 5)
        for k in range(4):
            a = base + k
            b = base + (k + 1) % 4
            c2 = base + 4 + (k + 1) % 4
            d = base + 4 + k
            m.quad(a, b, c2, d)
    parts["gold"] = m
    return parts


# ----------------------------------------------------------------------------
# stitch details
# ----------------------------------------------------------------------------
def tube_along(points, radius, n_side=8, closed=False):
    """Small tube through a list of points (used for seams)."""
    pts = [np.array(p, dtype=float) for p in points]
    mesh = Mesh()
    rings = []
    for i, p in enumerate(pts):
        if i == 0:
            t = pts[1] - pts[0]
        elif i == len(pts) - 1:
            t = pts[-1] - pts[-2]
        else:
            t = pts[i + 1] - pts[i - 1]
        t /= np.linalg.norm(t) + 1e-12
        ref = np.array([0.0, 1.0, 0.0])
        if abs(np.dot(t, ref)) > 0.95:
            ref = np.array([1.0, 0.0, 0.0])
        s = np.cross(t, ref)
        s /= np.linalg.norm(s) + 1e-12
        u = np.cross(t, s)
        ring = []
        for k in range(n_side):
            a = TAU * k / n_side
            ring.append(p + s * (radius * math.cos(a)) + u * (radius * math.sin(a)))
        rings.append(ring)
    base = len(mesh.pos)
    for i, ring in enumerate(rings):
        for k, p in enumerate(ring):
            n = p - pts[i]
            n /= np.linalg.norm(n) + 1e-12
            mesh.vert(p, n, (k / n_side, i / max(len(rings) - 1, 1)))
    for i in range(len(rings) - 1):
        for k in range(n_side):
            a = base + i * n_side + k
            b = base + i * n_side + (k + 1) % n_side
            c = base + (i + 1) * n_side + (k + 1) % n_side
            d = base + (i + 1) * n_side + k
            mesh.quad(a, b, c, d)
    return mesh


def build_stitches():
    mesh = Mesh()
    # hem stitch line
    pts = []
    for i in range(233):
        theta = TAU * i / 232
        y = hem_wave(theta) + 0.010
        p, n = torso_frame(theta, y)
        pts.append(p + n * 0.0015)
    mesh.merge(tube_along(pts, 0.0014, n_side=6))
    # collar base stitch
    pts = []
    for i in range(129):
        theta = TAU * i / 128
        y = neck_y(theta) + 0.001
        r = 0.0925
        pts.append(np.array([r * math.sin(theta), y, -r * math.cos(theta)]))
    mesh.merge(tube_along(pts, 0.0012, n_side=6))
    # sleeve seam rings
    for side in ("R", "L"):
        pts = []
        for i in range(65):
            phi = TAU * i / 64
            t = 0.035
            c, tan, sv, up = sleeve_frame(side, t)
            rd, rw = sleeve_radii(t)
            p = c + sv * ((rd + 0.003) * math.cos(phi)) + up * ((rw + 0.003) * math.sin(phi))
            pts.append(p)
        mesh.merge(tube_along(pts, 0.0016, n_side=6))
    return mesh


# ----------------------------------------------------------------------------
# procedural textures
# ----------------------------------------------------------------------------
def knit_height(size=1024, repeats=56):
    y, x = np.mgrid[0:size, 0:size].astype(np.float32)
    u = x / size * repeats
    v = y / size * repeats
    # interlocking stockinette loops
    h = (
        0.55 * np.cos(TAU * u)
        + 0.45 * np.cos(TAU * v)
        + 0.28 * np.cos(TAU * (u + v))
        + 0.18 * np.cos(TAU * (u - v))
        + 0.10 * np.cos(TAU * (2 * u + v))
    )
    # fine fibre noise, tileable
    noise = (
        np.sin(TAU * (3 * u + 0.5 * v) + 0.7)
        + np.sin(TAU * (5 * u - 2 * v) + 1.3)
        + np.sin(TAU * (7 * u + 3 * v) + 2.1)
    )
    return h + 0.10 * noise


def make_normal_map(size=1024):
    h = knit_height(size)
    gy, gx = np.gradient(h)
    strength = 2.2
    nx = -gx * strength
    ny = -gy * strength
    nz = np.ones_like(h)
    ln = np.sqrt(nx * nx + ny * ny + nz * nz)
    nx /= ln
    ny /= ln
    nz /= ln
    rgb = np.stack([nx * 0.5 + 0.5, ny * 0.5 + 0.5, nz * 0.5 + 0.5], axis=-1)
    return (np.clip(rgb, 0, 1) * 255).astype(np.uint8)


def make_roughness_map(size=512):
    h = knit_height(size, repeats=28)
    r = 0.70 + 0.055 * np.tanh(h)
    # metallic stays 0 (B), roughness in G
    rgb = np.stack([np.full_like(r, 0.0), r, np.full_like(r, 0.0)], axis=-1)
    return (np.clip(rgb, 0, 1) * 255).astype(np.uint8)


def png_bytes(arr):
    from io import BytesIO

    buf = BytesIO()
    Image.fromarray(arr, mode="RGB").save(buf, format="PNG", optimize=True)
    return buf.getvalue()


# ----------------------------------------------------------------------------
# GLB writer
# ----------------------------------------------------------------------------
class GLB:
    def __init__(self):
        self.buf = bytearray()
        self.buffer_views = []
        self.accessors = []
        self.meshes = []
        self.nodes = []
        self.materials = []
        self.textures = []
        self.images = []
        self.samplers = []
        self.extensions_used = set()

    def _align(self, n=4):
        while len(self.buf) % n != 0:
            self.buf.append(0)

    def add_view(self, data: bytes, target=None):
        self._align()
        off = len(self.buf)
        self.buf.extend(data)
        view = {"buffer": 0, "byteOffset": off, "byteLength": len(data)}
        if target is not None:
            view["target"] = target
        self.buffer_views.append(view)
        return len(self.buffer_views) - 1

    def add_accessor(self, arr, ctype, atype, target=None, minmax=False):
        arr = np.ascontiguousarray(arr)
        view = self.add_view(arr.tobytes(), target)
        acc = {
            "bufferView": view,
            "componentType": ctype,
            "count": int(arr.shape[0]),
            "type": atype,
        }
        if minmax:
            acc["min"] = [float(x) for x in arr.min(axis=0)]
            acc["max"] = [float(x) for x in arr.max(axis=0)]
        self.accessors.append(acc)
        return len(self.accessors) - 1

    def add_image(self, data: bytes):
        view = self.add_view(data)
        self.images.append({"bufferView": view, "mimeType": "image/png"})
        return len(self.images) - 1

    def add_texture(self, image_idx, sampler_idx=0):
        self.textures.append({"sampler": sampler_idx, "source": image_idx})
        return len(self.textures) - 1

    def add_material(self, name, base, metallic=0.0, roughness=0.5, normal=None, mr=None, double_sided=False, sheen=None, emissive=None):
        pbr = {
            "baseColorFactor": hex_lin(base),
            "metallicFactor": metallic,
            "roughnessFactor": roughness,
        }
        mat = {"name": name, "pbrMetallicRoughness": pbr, "doubleSided": double_sided}
        if normal is not None:
            mat["normalTexture"] = {"index": normal, "scale": 0.55}
        if mr is not None:
            mat["metallicRoughnessTexture"] = {"index": mr}
        if sheen is not None:
            mat["extensions"] = {
                "KHR_materials_sheen": {
                    "sheenColorFactor": hex_lin(sheen[0])[:3],
                    "sheenRoughnessFactor": sheen[1],
                    "sheenIntensity": sheen[2],
                }
            }
            self.extensions_used.add("KHR_materials_sheen")
        if emissive is not None:
            mat["emissiveFactor"] = emissive
        self.materials.append(mat)
        return len(self.materials) - 1

    def add_mesh(self, name, mesh: Mesh, material_idx, node_name=None):
        pos = np.asarray(mesh.pos, dtype=np.float32)
        nor = np.asarray(mesh.nor, dtype=np.float32)
        uv = np.asarray(mesh.uv, dtype=np.float32)
        idx = np.asarray(mesh.idx, dtype=np.uint32)
        if len(idx) == 0:
            return None
        if idx.max() < 65535:
            idx = idx.astype(np.uint16)
            ctype = 5123
        else:
            ctype = 5125
        a_pos = self.add_accessor(pos, 5126, "VEC3", 34962, minmax=True)
        a_nor = self.add_accessor(nor, 5126, "VEC3", 34962)
        a_uv = self.add_accessor(uv, 5126, "VEC2", 34962)
        a_idx = self.add_accessor(idx, ctype, "SCALAR", 34963)
        prim = {
            "attributes": {"POSITION": a_pos, "NORMAL": a_nor, "TEXCOORD_0": a_uv},
            "indices": a_idx,
            "material": material_idx,
            "mode": 4,
        }
        mesh_idx = len(self.meshes)
        self.meshes.append({"name": name, "primitives": [prim]})
        node = {"name": node_name or name, "mesh": mesh_idx}
        self.nodes.append(node)
        return len(self.nodes) - 1

    def add_multi_material_mesh(self, name, parts, node_name=None):
        """parts: list of (mesh, material_idx)"""
        prims = []
        for mesh, mat_idx in parts:
            pos = np.asarray(mesh.pos, dtype=np.float32)
            nor = np.asarray(mesh.nor, dtype=np.float32)
            uv = np.asarray(mesh.uv, dtype=np.float32)
            idx = np.asarray(mesh.idx, dtype=np.uint32)
            if len(idx) == 0:
                continue
            if idx.max() < 65535:
                idx = idx.astype(np.uint16)
                ctype = 5123
            else:
                ctype = 5125
            a_pos = self.add_accessor(pos, 5126, "VEC3", 34962, minmax=True)
            a_nor = self.add_accessor(nor, 5126, "VEC3", 34962)
            a_uv = self.add_accessor(uv, 5126, "VEC2", 34962)
            a_idx = self.add_accessor(idx, ctype, "SCALAR", 34963)
            prims.append(
                {
                    "attributes": {"POSITION": a_pos, "NORMAL": a_nor, "TEXCOORD_0": a_uv},
                    "indices": a_idx,
                    "material": mat_idx,
                    "mode": 4,
                }
            )
        mesh_idx = len(self.meshes)
        self.meshes.append({"name": name, "primitives": prims})
        node = {"name": node_name or name, "mesh": mesh_idx}
        self.nodes.append(node)
        return len(self.nodes) - 1

    def write(self, path):
        # sampler
        self.samplers.append({"magFilter": 9729, "minFilter": 9987, "wrapS": 10497, "wrapT": 10497})
        # JSON
        doc = {
            "asset": {"version": "2.0", "generator": "SEVEN procedural kit builder (Python, no external assets)"},
            "scene": 0,
            "scenes": [{"name": "SEV7_Kit", "nodes": [0]}],
            "nodes": self.nodes,
            "meshes": self.meshes,
            "materials": self.materials,
            "accessors": self.accessors,
            "bufferViews": self.buffer_views,
            "buffers": [{"byteLength": len(self.buf)}],
            "images": self.images,
            "textures": self.textures,
            "samplers": self.samplers,
        }
        if self.extensions_used:
            doc["extensionsUsed"] = sorted(self.extensions_used)
        # root node becomes the parent of all part nodes
        part_nodes = list(range(1, len(self.nodes) + 1))
        doc["nodes"] = [{"name": "SEV7_Kit", "children": part_nodes}] + self.nodes
        doc["scenes"] = [{"name": "SEV7_Kit", "nodes": [0]}]
        # shift node indices in meshes? node indices are only used for children here
        js = json.dumps(doc, separators=(",", ":")).encode("utf-8")
        while len(js) % 4 != 0:
            js += b" "
        bin_data = bytes(self.buf)
        while len(bin_data) % 4 != 0:
            bin_data += b"\x00"
        total = 12 + 8 + len(js) + 8 + len(bin_data)
        with open(path, "wb") as f:
            f.write(struct.pack("<III", 0x46546C67, 2, total))
            f.write(struct.pack("<II", len(js), 0x4E4F534A))
            f.write(js)
            f.write(struct.pack("<II", len(bin_data), 0x004E4942))
            f.write(bin_data)
        return total


# ----------------------------------------------------------------------------
# build
# ----------------------------------------------------------------------------
def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    print("Building SEVEN kit…")

    torso = build_torso()
    print(f"  torso      {len(torso.pos):>7} verts  {len(torso.idx)//3:>7} tris")
    sleeves = [build_sleeve("R"), build_sleeve("L")]
    for s, m in zip(("R", "L"), sleeves):
        print(f"  sleeve {s}   {len(m.pos):>7} verts  {len(m.idx)//3:>7} tris")
    fabric = Mesh()
    fabric.merge(torso)
    for m in sleeves:
        fabric.merge(m)
    print(f"  fabric     {len(fabric.pos):>7} verts  {len(fabric.idx)//3:>7} tris")

    collar = build_collar()
    cuffs = [build_cuff("R"), build_cuff("L")]
    hem_band = build_hem_band()
    trim = Mesh()
    trim.merge(collar)
    for m in cuffs:
        trim.merge(m)
    print(f"  trim       {len(trim.pos):>7} verts  {len(trim.idx)//3:>7} tris")

    numeral = build_numeral()
    print(f"  numeral    {len(numeral.pos):>7} verts  {len(numeral.idx)//3:>7} tris")
    name = build_name()
    print(f"  name       {len(name.pos):>7} verts  {len(name.idx)//3:>7} tris")
    shield_parts = build_shield()
    for k, m in shield_parts.items():
        print(f"  shield {k:<6} {len(m.pos):>7} verts  {len(m.idx)//3:>7} tris")
    stitches = build_stitches()
    stitches.merge(hem_band)
    print(f"  stitches   {len(stitches.pos):>7} verts  {len(stitches.idx)//3:>7} tris")

    total_tris = (
        len(fabric.idx) + len(trim.idx) + len(numeral.idx) + len(name.idx) + len(stitches.idx)
        + sum(len(m.idx) for m in shield_parts.values())
    ) // 3
    print(f"  TOTAL      {total_tris} triangles")

    print("  textures…")
    normal = make_normal_map(1024)
    rough = make_roughness_map(512)
    n_png = png_bytes(normal)
    r_png = png_bytes(rough)
    print(f"    normal {len(n_png)/1024:.0f} KB · roughness {len(r_png)/1024:.0f} KB")

    g = GLB()
    # textures
    n_img = g.add_image(n_png)
    r_img = g.add_image(r_png)
    n_tex = g.add_texture(n_img)
    r_tex = g.add_texture(r_img)

    m_red = g.add_material(
        "M_Kit_Red", C_KIT_RED, metallic=0.0, roughness=1.0,
        normal=n_tex, mr=r_tex, double_sided=True,
        sheen=("#C8202E", 0.60, 0.35),
    )
    m_trim = g.add_material("M_Kit_Trim", C_KIT_TRIM, metallic=0.0, roughness=0.55, double_sided=True)
    m_gold = g.add_material("M_Numeral_Gold", C_NUMERAL_GOLD, metallic=0.90, roughness=0.28)
    m_ivory = g.add_material("M_Name_Ivory", C_NAME_IVORY, metallic=0.0, roughness=0.50)
    m_crest_gold = g.add_material("M_Crest_Gold", C_CREST_GOLD, metallic=0.85, roughness=0.35)
    m_crest_blue = g.add_material("M_Crest_Blue", C_CREST_BLUE, metallic=0.0, roughness=0.45)
    m_crest_red = g.add_material("M_Crest_Red", C_CREST_RED, metallic=0.0, roughness=0.50)
    m_crest_ivory = g.add_material("M_Crest_Ivory", "#F2EFE6", metallic=0.0, roughness=0.45)
    m_stitch = g.add_material("M_Stitch", C_STITCH, metallic=0.0, roughness=0.80)

    g.add_mesh("Kit_Fabric", fabric, m_red, "Kit_Fabric")
    g.add_mesh("Kit_Trim", trim, m_trim, "Kit_Trim")
    g.add_mesh("Numeral_7", numeral, m_gold, "Numeral_7")
    g.add_mesh("Name_Ronaldo", name, m_ivory, "Name_Ronaldo")
    g.add_multi_material_mesh(
        "Chest_Shield",
        [
            (shield_parts["red"], m_crest_red),
            (shield_parts["ivory"], m_crest_ivory),
            (shield_parts["blue"], m_crest_blue),
            (shield_parts["white"], m_crest_ivory),
            (shield_parts["gold"], m_crest_gold),
        ],
        "Chest_Shield",
    )
    g.add_mesh("Kit_Stitch", stitches, m_stitch, "Kit_Stitch")

    size = g.write(OUT)
    print(f"  wrote {OUT} ({size/1024/1024:.2f} MB)")

    # quick integrity report
    allpos = np.array(fabric.pos + trim.pos + numeral.pos + name.pos + stitches.pos + sum((m.pos for m in shield_parts.values()), []))
    print(f"  bounds min {allpos.min(axis=0).round(3)} max {allpos.max(axis=0).round(3)}")
    print(f"  nodes: {[n['name'] for n in g.nodes]}")
    print(f"  materials: {[m['name'] for m in g.materials]}")


if __name__ == "__main__":
    main()
