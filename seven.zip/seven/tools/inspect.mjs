import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto('http://localhost:5173/?p=0.100&hq=1', { waitUntil: 'load' });
await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
await page.waitForTimeout(1200);
const info = await page.evaluate(() => {
  const el = document.querySelector('.block.main.left');
  const wrap = el?.closest('.chapter-text');
  const cs = el ? getComputedStyle(el) : null;
  const cw = wrap ? getComputedStyle(wrap) : null;
  return {
    el: el ? { cls: el.className, rect: el.getBoundingClientRect().toJSON(), position: cs.position, top: cs.top, left: cs.left, right: cs.right, width: cs.width, transform: cs.transform, display: cs.display, flex: cs.flex } : null,
    wrap: wrap ? { cls: wrap.className, rect: wrap.getBoundingClientRect().toJSON(), position: cw.position, inset: cw.inset, display: cw.display } : null,
    col: getComputedStyle(document.documentElement).getPropertyValue('--col'),
    gutter: getComputedStyle(document.documentElement).getPropertyValue('--gutter'),
    innerWidth,
    matchMobile: matchMedia('(max-width: 899px)').matches,
    sheets: [...document.styleSheets].map(s => s.href || 'inline').slice(0,10),
  };
});
console.log(JSON.stringify(info, null, 2));
await browser.close();
