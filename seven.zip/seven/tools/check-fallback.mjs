import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true, args: ['--disable-webgl', '--disable-3d-apis'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const page = await context.newPage();
const errors=[]; page.on('pageerror', e=>errors.push(e.message)); page.on('console', m=>{ if(m.type()==='error') errors.push(m.text()); });
await page.goto('http://localhost:5173/?hq=1', { waitUntil: 'load', timeout: 60000 });
await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 }).catch(()=>{});
await page.waitForTimeout(1500);
const info = await page.evaluate(() => ({
  fallback: !!document.querySelector('.fallback'),
  img: (() => { const i=document.querySelector('.fallback img'); return i ? {src:i.getAttribute('src'), naturalWidth:i.naturalWidth, naturalHeight:i.naturalHeight} : null; })(),
  h1: document.querySelector('.fallback h1')?.textContent,
  chapters: document.querySelectorAll('.fallback-chapter').length,
  canvas: !!document.querySelector('canvas'),
  preloaderDone: !!document.querySelector('.preloader.done'),
  bodyOverflow: getComputedStyle(document.body).overflow,
  errors: [],
}));
console.log(JSON.stringify(info, null, 2), 'errors', errors.slice(0,3));
await page.screenshot({ path: 'docs/checkpoints/iteration-1/fallback.png', fullPage: false });
await browser.close();
