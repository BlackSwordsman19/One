import { chromium } from 'playwright';
import fs from 'node:fs';
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 1 });
const out = [];
for (const p of [0.100, 0.200, 0.300, 0.380, 0.500, 0.640, 0.780, 0.900, 1.000]) {
  const page = await context.newPage();
  await page.goto(`http://localhost:5173/?p=${p.toFixed(3)}&hq=1`, { waitUntil: 'load', timeout: 60000 });
  await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
  await page.waitForTimeout(1300);
  const file = `docs/checkpoints/iteration-1/margin-${p.toFixed(3)}.png`;
  await page.screenshot({ path: file });
  const dom = await page.evaluate(() => ({ progress: window.scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight), visible: [...document.querySelectorAll('.block, .entry-block')].filter(el => getComputedStyle(el).visibility === 'visible' && parseFloat(getComputedStyle(el).opacity) > 0.01).map(el => (el.textContent||'').replace(/\s+/g,' ').slice(0,30)) }));
  out.push({ p, file, dom });
  await page.close();
}
await browser.close();
fs.writeFileSync('docs/checkpoints/iteration-1/margins.json', JSON.stringify(out, null, 2));
console.log(JSON.stringify(out, null, 2));
