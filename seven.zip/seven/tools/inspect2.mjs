import { chromium } from 'playwright';
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
await page.goto('http://localhost:5173/?p=0.100&hq=1', { waitUntil: 'load' });
await page.waitForSelector('.preloader.done', { state: 'attached', timeout: 30000 });
await page.waitForTimeout(1200);
const info = await page.evaluate(() => {
  const el = document.querySelector('.block.main.left');
  const wrap = document.querySelector('.chapter-text');
  const out = [];
  for (const sheet of document.styleSheets) {
    let rules;
    try { rules = sheet.cssRules; } catch { continue; }
    const walk = (list, media) => {
      for (const rule of list) {
        if (rule.cssRules) { walk(rule.cssRules, rule.conditionText || media); continue; }
        if (!rule.selectorText) continue;
        try {
          if (wrap && wrap.matches(rule.selectorText)) out.push({ selector: rule.selectorText, css: rule.style.cssText, media });
          if (el && el.matches(rule.selectorText)) out.push({ selector: rule.selectorText, css: rule.style.cssText, media, el: true });
        } catch {}
      }
    };
    walk(rules, '');
  }
  return out;
});
console.log(JSON.stringify(info, null, 2));
await browser.close();
