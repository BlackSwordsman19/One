# SEVEN — Cristiano Ronaldo

A premium, scroll-driven single-page website built around one permanent 3D hero
object: **Cristiano Ronaldo's Portugal No. 7 jersey**. The jersey is the site.
Everything else is typography breathing around it.

The back of the jersey — `RONALDO` above a large raised numeral **7** — is the
hero state. The site opens on the 7, performs exactly one full revolution, and
closes on the 7. The chest shield is turned to camera once, in Chapter 05.

**Stats as of November 2026.** No official kit, crest, mark or likeness is used.
No photographic likeness of Ronaldo appears anywhere. The jersey, numeral,
shield and environment are original procedural geometry.

---

## Run

```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # static build in dist/
npm run preview    # serve the production build
```

The project is Vite + React 18 + TypeScript + three.js via
`@react-three/fiber`, with Lenis for smoothing. All assets are local and
same-origin: fonts, GLB, favicon, OG render. No CDN, no third-party requests at
runtime.

### Debug parameters

- `?p=0.335` — read-only scroll progress, useful for screenshots.
- `?hq=1` — disable the frame-time guard for full-quality captures.

---

## Final report

### Project and output

- Project: **SEVEN — Cristiano Ronaldo**
- Run: `npm install` → `npm run dev`
- Build: `npm run build` → `dist/` (deployable static build)
- Build status: **zero errors, zero warnings**
- Initial JS: **302.61 KB gzip** (1,091.61 KB minified)
- CSS: **3.10 KB gzip** (12.56 KB minified)
- GLB: **2.33 MB** (`public/models/sev7_kit.glb`)
- Fonts: **97 KB** (five woff2 files, self-hosted, Latin subset)
- Textures: embedded in the GLB — 1024² procedural knit normal map +
  512² roughness map (≈ 6.7 MB GPU memory with mips)
- Total page weight: **≈ 2.73 MB**
- Draw calls: **37 desktop / 24 mobile**
- Triangles in scene: **176,335** (includes the shadow pass; the GLB itself is
  88,159 triangles)
- Texture memory: ≈ 6.7 MB
- Measured median frame time: **0.25 s (≈ 4 fps)** in headless Chromium 156
  with SwiftShader (software WebGL) at 1440 × 900. This is **not a hardware
  measurement**; the scene is within the design budget (88k GLB triangles,
  37 draw calls, one 2.33 MB GLB, no per-frame React renders). A real GPU is
  required to validate the 60 fps / 40 fps targets.
- LCP / CLS / INP: CLS **0** (fixed canvas and fixed type layer). LCP and INP
  cannot be meaningfully measured in the software-rendered headless browser;
  the production build is minified and the initial JS is 302.61 KB gzip.

### Palette actually used

| Token | Hex |
|---|---|
| Background | `#08090B` |
| Ink | `#F2EFE6` |
| Ink dim | `#A8A9AD` |
| Ink faint | `#6E6F73` |
| Gold | `#D8B45A` |
| Kit red | `#A5121E` |
| Kit trim green | `#046A38` |
| Stitch | `#6E0B13` |
| Crest gold | `#C9A227` |
| Crest blue | `#173D7A` |
| Crest red | `#C8102E` |
| Hairline | `rgba(255,255,255,0.10)` |
| Scrollbar thumb | `#2A2B2E` |

### GLB nodes and materials

- Node `SEV7_Kit` → `Kit_Fabric`, `Kit_Trim`, `Numeral_7`, `Name_Ronaldo`,
  `Chest_Shield`, `Kit_Stitch`
- Materials: `M_Kit_Red`, `M_Kit_Trim`, `M_Numeral_Gold`, `M_Name_Ivory`,
  `M_Crest_Gold`, `M_Crest_Blue`, `M_Crest_Red`, `M_Crest_Ivory`, `M_Stitch`
- The GLB is Y-up, metres, +Z toward viewer, applied transforms, triangulated,
  no cameras/lights/floor/backdrop. Textures and materials are embedded.
- The chest shield is a simplified heraldic shield based on the public-domain
  Portuguese national arms. It is not the FPF crest and carries no lettering.

### Build / verify iterations

1. **Iteration 1 — asset + first full build.** Built the procedural jersey,
  scene, type layer and choreography. Ran the first 24-checkpoint verification.
  Found: the new `layout.css` had been lost and the old CSS was still on disk,
  so the type blocks were full-width at the top of the viewport. Recreated the
  layout CSS with the `.chapter-text` / `.block` rules.
2. **Iteration 2 — centring + camera margins.** Found the ticker's inline
  `transform` was replacing the CSS `translateY(-50%)` centring. Fixed with the
  `--fade-y` custom property. Measured the jersey's projected bounding box at
  every checkpoint and refined the camera distances for Chapters 1, 2, 3, 4, 5
  and 7 so every silhouette has ≥ 6% margin except the Chapter 03 macro. Fixed
  the mobile chapter 07 aside overflow (ledger + Q3) by reducing the mobile
  ledger/quote sizes. Tuned the environment and the moving spot so the gold
  numeral stays champagne instead of clipping to white.
3. **Iteration 3 — final verification.** Re-ran all 24 checkpoints. **0 text/UI
  violations, 0 chrome violations, 0 console errors.** The last chapter is
  visible at p = 1.000. The macro is the only silhouette crop. Added the
  resize-preservation fix (`lenis.stop()` → `window.scrollTo` → `lenis.resize()`
  → `lenis.start()`), the keyboard `End` fix (p = 1.000), the 320 px / 200% zoom
  / landscape-phone breakpoints, the no-WebGL fallback check, the reduced-motion
  check, and `public/robots.txt`.

### Acceptance tests

| # | Test | Result |
|---|---|---|
| 1 | Jersey visible, whole and unoccluded at every checkpoint except the Chapter 03 macro | **PASS** — pixel analysis at all 24 checkpoints; ≥ 6% margins except the macro |
| 2 | No UI block, card, panel, pill, badge, modal or banner | **PASS** |
| 3 | Chrome limited to wordmark + “01 / 07” counter + hairline rail | **PASS** |
| 4 | Exactly seven chapters, copy verbatim, no extra quotes | **PASS** |
| 5 | Numeral 7 is real geometry, legible at 4 m and razor-sharp in the macro | **PASS** — raised beveled geometry, gold pixel count 139,616 in the macro |
| 6 | Backward and forward scroll produce identical states | **PASS** for the scroll-driven layers (text and camera are pure functions of p); dust/grain are the only time-based elements, as permitted |
| 7 | 60 fps desktop, ≥ 40 fps mobile, no long-task stutter | **NOT VERIFIED** in the sandbox — headless SwiftShader measures ≈ 4 fps. Design budget met (88k GLB triangles, 37 draw calls, no per-frame React renders). Requires a real GPU to validate. |
| 8 | Reduced-motion, no-WebGL, 320 px, 200% zoom and landscape phone degrade gracefully | **PASS** — tested at 320 × 568, 720 × 450 (200% zoom), 844 × 390 (landscape), with WebGL disabled, and with `prefers-reduced-motion: reduce`; no sacred-zone violations, no text overflow |
| 9 | Lighthouse targets met; console clean; no third-party requests | **PARTIAL** — accessibility **100**, best practices **100**, SEO **100**; console clean; no third-party requests. Performance **25** in the Vite dev server because Lighthouse measured unminified dev modules, no text compression and a software-rendered SwiftShader scene. The production build is minified (302.61 KB gzip initial JS); the performance target cannot be reached in this sandbox. |
| 10 | Every number matches section 3; the closing line says “Stats as of November 2026” | **PASS** |
| 11 | The site ends on the number 7 facing the viewer | **PASS** — yaw 360° at p = 1.000, last chapter visible |

### Deliberate deviations

1. **GSAP + ScrollTrigger replaced** by a scrubbed `requestAnimationFrame` /
   scroll-progress driver. The binding initial-JS budget (≤ 380 KB gzip) is met
   at 302.61 KB; GSAP + ScrollTrigger pushed the bundle to 451.57 KB. The
   behaviour is identical: every visual state is a pure function of p, forward
   and backward scroll reproduce identical states, no time-based tweens.
2. **RectAreaLight replaced** by a moving SpotLight for the Chapter 03 specular
   sweep. `RectAreaLightUniformsLib` pulls in a 105 KB LTC texture table; the
   spot gives a clean moving highlight on the gold at a fraction of the weight.
3. **Blender is not installed in the sandbox.** The GLB is produced by a custom
   Python glTF writer (`tools/build_jersey.py`), not Blender. It is a real
   binary glTF with embedded textures and no cameras/lights.
4. **GLB is 88,159 triangles**, 2k below the 90k target, to keep the scene
   (including the shadow pass) under the 180k cap. The visual quality is
   unchanged at the delivered resolution.
5. **Name arc radius 900 mm** instead of 300 mm, and **numeral top 140 mm below
   the collar seam** instead of 90 mm, to keep the name and numeral on the torso
   and prevent the name floating over the yoke. Cap heights and widths are exact.
10. **Fabric sheen intensity 0.24** instead of 0.35. At 0.35 the red read as
    coral under the studio environment; 0.24 holds the deep `#A5121E` base.
11. **Mobile jersey centre at 29%** of the viewport height instead of 48%, to
    fit the whole silhouette inside the upper 58vh. The desktop framing law
    (48%) is unchanged.
12. **Mobile chrome in the lower band** (wordmark/counter at 58vh + 10px, rail
    at 60vh → 95vh) so no chrome intersects the full-width mobile sacred zone.
13. **Camera distances refined** from the brief's starting values (documented in
    `docs/DESIGN.md` and `docs/WORKLOG.md`) to satisfy the ≥ 6% margin law at
    every checkpoint.
14. **Headless performance is not a hardware measurement.** The verification
    browser uses SwiftShader; the frame-time guard and Lighthouse performance
    score are not representative of a real GPU.

### Docs and artefacts

- `docs/DESIGN.md` — layout law, locked copy, choreography table, palette,
  asset spec, performance budgets.
- `docs/kit_front.svg`, `docs/kit_back.svg` — dimensioned technical elevations.
- `docs/layout.svg` — sacred-zone / gutter diagram.
- `docs/WORKLOG.md` — every decision and fix.
- `docs/checkpoints/iteration-1/` — 24 final checkpoints (12 desktop, 12
  mobile), `results.json`, `margins.json`, plus the fallback, reduced-motion,
  small-screen and landscape checks.
- `docs/lighthouse.json`, `docs/lighthouse-seo.json` — Lighthouse reports.
- `tools/build_jersey.py` — procedural kit builder / GLB writer.
- `tools/elevation.py` — technical elevation generator.
- `tools/verify.mjs` — Playwright sacred-zone verification.
- `tools/og.html`, `tools/shot-og.mjs` — OG render generator.
- `public/og/og-1200x630.jpg` — 1200 × 630 Open Graph render.
- `public/og/poster.jpg` — no-WebGL fallback still.
- `public/favicon.svg` — numeral 7 in champagne gold on `#08090B`.
- `public/robots.txt` — allow all.

### Notes

- The site is a single page. The URL has no per-chapter hash. `?p=` is a
  read-only debug parameter.
- The preloader counts 0 → 7, waits for the GLB and fonts, then fades over
  500 ms. The page is scrollable the instant it exits.
- The canvas is `aria-hidden`; a visually hidden semantic section mirrors all
  seven chapters. The no-WebGL fallback shows the same text plus a still
  exported from the same scene.
- The site uses native scroll, a hairline scrollbar, right-click, text
  selection and the keyboard. There are no modals, cookie banners, chat
  widgets, audio, autoplay carousels, scroll-jacking or third-party requests.
