# SEVEN — WORKLOG

A chronological record of decisions, fixes and measurements. The brief is the
source of truth; this log records where the build had to make a judgement call.

---

## 0. Environment and plan

- The sandbox has Node 20, npm, Python 3.13, numpy, fontTools, Pillow, shapely,
  mapbox-earcut and Playwright Chromium. **Blender is not installed.**
- Decision: keep React + Vite + TypeScript, use three.js directly through
  `@react-three/fiber` for the scene, and generate the GLB with a custom Python
  glTF writer instead of Blender. The brief's stack is prescriptive but
  behaviour beats stack; the GLB is a real, self-contained binary glTF with
  embedded textures, produced by `tools/build_jersey.py`.
- Decision: build the studio environment procedurally (gradient dome + softbox
  cards baked through `PMREMGenerator`). No HDRI download.
- Decision: hand-write all CSS. No UI kit, no Tailwind, no component library.
- Decision: self-host four OFL fonts (Anton, Archivo, Instrument Serif, IBM Plex
  Mono) as woff2, subset to Latin. No Google Fonts link.

## 1. The jersey asset

- Wrote `tools/build_jersey.py` with:
  - a lofted hollow torso from a millimetre profile, with a sloped yoke, a soft
    hem wave and a subtle drape fold;
  - set-in sleeves on a cubic Bézier path with a forward curl and a ribbed cuff;
  - a ribbed crew collar that follows the neckline;
  - a hand-drawn heavy athletic block `7` (thick verticals, flat terminals,
    squared counters) as a raised, beveled appliqué;
  - `RONALDO` set from an OFL grotesque outline, arched and raised;
  - a layered simplified Portuguese shield (red field, ivory centre, five blue
    quinas, white bezants, seven gold castles) on the wearer's left chest;
  - stitch seams, a hem band and a contact-shadow-friendly geometry;
  - a 1024² procedural knit normal map and a 512² roughness map, embedded;
  - a custom GLB writer (JSON + BIN chunks, PBR materials, KHR_materials_sheen).
- Fixes during the asset build:
  - back-face triangle indices used `front_start` instead of `back_start`;
  - side-wall normals were flipped for holes; removed the incorrect hole flip and
    oriented each quad against its computed face normal;
  - the yoke used the back depth for the front; split `bf`/`bb`;
  - the GLB root node's children were off by one after prepending the root;
  - the sheen colour factor had four components; truncated to three;
  - the torso grid normals were flat because `grid_normals` expected a 2-D array;
    reshape added;
  - the hem band was in the green trim mesh; moved to the dark stitch mesh;
  - the collar/cuff rim normals were radial; blended toward the rim direction.
- Resolution: torso 232 × 118 rings, sleeves 96 × 56. Final GLB: **88,159
  triangles, 2.33 MB**, nodes `SEV7_Kit` → `Kit_Fabric`, `Kit_Trim`,
  `Numeral_7`, `Name_Ronaldo`, `Chest_Shield`, `Kit_Stitch`; materials
  `M_Kit_Red`, `M_Kit_Trim`, `M_Numeral_Gold`, `M_Name_Ivory`,
  `M_Crest_Gold`, `M_Crest_Blue`, `M_Crest_Red`, `M_Crest_Ivory`, `M_Stitch`.
- The GLB re-imports with no missing textures, no cameras, no lights, no floor.
- The name arc uses an effective radius of 900 mm rather than 300 mm: at 300 mm
  the 70 mm name would wrap over the yoke and float above the garment. The
  visual fit wins; the arc is still visibly arched.
- The numeral top sits 140 mm below the back collar seam rather than 90 mm, so
  the name and numeral both sit on the torso and the name does not collide with
  the collar. The proportions (280 mm numeral, 210 mm width, 70 mm name) are
  exact.

## 2. The scene

- `Hero.tsx` loads the GLB, centres it vertically, enables shadows, sets
  per-material `envMapIntensity`, and drives the camera and the jersey yaw from
  the scroll progress. The camera is a pure function of p; the only wall-clock
  motion is a damped 4 mm fabric sway.
- `environment.ts` builds the gradient dome and softbox cards. A large frontal
  card was added after the first renders showed the gold appliqué reading too
  dark: the flat gold face reflects the +Z environment, and the card gives it a
  clean champagne reflection. The card intensity was reduced from 3.2 to 2.0
  after the macro clipped to white.
- `Lights.tsx` implements the key/fill/rim/bounce rig and a moving warm spot
  behind the camera for the Chapter 03 specular sweep. The spot intensity was
  reduced from 42 to 8 after the macro gold clipped to white; the sweep is still
  visible but the numeral stays champagne.
- `Post.tsx` implements ACES tone mapping through `OutputPass`, a bloom pass
  (threshold 0.90, strength 0.18), and a custom finish pass for vignette (0.25),
  grain (0.025 at 24 fps quantised) and chromatic aberration (≤ 0.0006, only
  during chapter crossfades). Mobile disables bloom and grain.
- `PerformanceGuard.tsx` measures the median frame time, drops the DPR in 0.25
  steps to a floor of 1.0 and disables bloom after 2 s above 20 ms. It publishes
  draw calls and triangles to `window.__SEVEN_PERF__` for verification.
- `Dust.tsx` adds 120 (60 mobile) monochrome motes with a procedural sprite,
  slow drift and camera parallax. Disabled under reduced motion.
- The contact shadow is a shadow-only plane under the hem; there is no visible
  floor plane.

## 3. The type layer

- The type layer is **fixed**, not scrolling. The document is an empty 800vh
  scroll track (60vh entry + 7 × 100vh + 40vh close). The type fades through the
  gutters as a pure function of p. This guarantees the text never crosses the
  sacred zone and never needs to be repositioned on scroll.
- Each chapter's opacity and translate are computed from p with a 0.02 fade-in
  and a 0.02 fade-out. The outgoing chapter is fully faded at its `pEnd`; the
  incoming starts at the same `pEnd`. No overlap.
- The last chapter's fade-out is disabled so the ledger, Q3 and the close line
  remain visible at p = 1.000.
- The entry title is in the left gutter at 48vh, aligned to the numeral's
  centre line. The SCROLL cue fades out by p = 0.02.
- The fade translate is applied through a CSS custom property `--fade-y`, so the
  ticker does not overwrite the `translateY(-50%)` centring. This was a real bug:
  the first verification run measured the blocks at full width and the top of
  the viewport because the inline transform replaced the centring transform.
- On mobile the type drops into the lower band (60vh, 38vh high) with the main
  text and the quote/ledger side by side. The ledger and Q3 were initially 62px
  too tall for the band; the mobile ledger was reduced to 8px/1.4 and the quote
  to 18px, and the aside now fits exactly.
- On mobile the wordmark/counter move to the top of the lower band and the rail
  to the lower band, so no chrome intersects the full-width upper 58vh sacred
  zone.
- The preloader counts 0 → 7, waits for the GLB and fonts, then fades over
  500 ms. The page is scrollable the instant it exits.
- The semantic section mirrors all seven chapters for assistive tech; the
  visible type layer is `aria-hidden`.
- The fallback uses a 1200 × 630 render exported from the same scene plus the
  full text. No error dialog, no apology copy.

## 4. Choreography and camera

- Implemented the brief's keyframes with the yaw convention 0° = back / 7,
  180° = front / shield, one full revolution 0° → 360°.
- The camera distances were refined from the brief's starting values after
  measuring the jersey's projected bounding box against the sacred zone:
  - Ch1 start 3.40 → 3.23, end 3.05 → 2.898 (top margin was 16 px);
  - Ch2 3.05/2.80 → 2.745/2.520 (top margin was 31 px);
  - Ch3 start 2.80 (top margin was 9 px at p = 0.300);
  - Ch3 return 2.70 → 2.430 (bottom margin was 36 px);
  - Ch4 2.80 → 3.050, az 20° → 10°, target y +0.02 (right margin was 1 px,
    top margin was 6 px);
  - Ch5 2.60 → 2.392 (bottom margin was 6 px);
  - Ch7 start 2.50 → 2.425, end 2.90 → 2.755 (bottom margin was 1 px).
- After these refinements every desktop checkpoint has ≥ 6% margin on all four
  sides except the Chapter 03 macro, which is the one permitted crop.
- On mobile the distance is scaled so the jersey fills 85% of the viewport
  width (7.5% side margins) and the target is lifted so the jersey centre sits
  at 29% of the viewport height, inside the upper 58vh.
- The macro target is the numeral centroid `(0, 0.0425, 0.16)`; the numeral
  fills the sacred zone and the silhouette is allowed to crop.

## 5. Verification

- Wrote `tools/verify.mjs` (Playwright) to open every checkpoint at 1440 × 900
  and 390 × 844, wait for the preloader, evaluate the DOM, take a screenshot and
  assert that no visible text/UI element or chrome element intersects the
  sacred-zone rectangle.
- First run: 0 errors, but the text blocks were full-width and at the top of the
  viewport. Root cause: the new `layout.css` had been lost when a temporary
  directory was removed; the old CSS was still on disk. Recreated the new
  `layout.css` with the `.chapter-text` / `.block` rules.
- Second run: the blocks were in the gutters but not vertically centred; the
  ticker's inline `transform` replaced the CSS `translateY(-50%)`. Fixed with the
  `--fade-y` custom property.
- Third run: **0 text/UI violations and 0 chrome violations at all 24
  checkpoints**, 0 console errors. The only warnings are SwiftShader driver
  messages in the software-rendered headless browser.
- Pixel analysis of the screenshots measured the jersey's projected bounding
  box against the sacred zone. The camera refinements above were driven by
  those measurements.
- Mobile text overflow was detected by comparing `scrollHeight` to
  `clientHeight`; the chapter 07 aside was 383 px in a 321 px band. Fixed by
  reducing the mobile ledger and quote sizes.
- Draw calls: 37 desktop / 24 mobile. Triangles: 176,335 (including the shadow
  pass), under the 180k cap. GLB: 2.33 MB. Initial JS gzip: 302.5 KB. Fonts:
  97 KB. Total page weight ≈ 2.73 MB.

## 6. Deviations from the brief

1. **GSAP + ScrollTrigger replaced** by a scrubbed requestAnimationFrame /
   scroll-progress driver. The initial JS gzip budget (≤ 380 KB) is binding;
   GSAP + ScrollTrigger pushed the bundle to 451.57 KB. The behaviour is
   identical: every visual state is a pure function of p, forward and backward
   scroll reproduce identical states, no time-based tweens.
2. **RectAreaLight replaced** by a moving SpotLight for the Chapter 03 specular
   sweep. `RectAreaLightUniformsLib` pulls in a 105 KB LTC texture table; the
   spot gives a clean moving highlight on the gold at a fraction of the weight.
3. **Blender not available.** The GLB is produced by a custom Python glTF writer
  (`tools/build_jersey.py`), not Blender. The asset is a real binary glTF with
  embedded textures and no cameras/lights.
4. **GLB triangle count 88,159**, 2k below the 90k target, to keep the scene
  (including the shadow pass) under the 180k cap. The visual quality is
  unchanged at the delivered resolution.
5. **Name arc radius 900 mm** instead of 300 mm, and **numeral top 140 mm below
  the collar seam** instead of 90 mm, to keep the name and numeral on the torso
  and prevent the name from floating over the yoke. The cap heights and widths
  are exact.
6. **Fabric sheen intensity 0.24** instead of 0.35. At 0.35 the red read as
  coral under the studio environment; 0.24 holds the deep `#A5121E` base.
7. **Mobile jersey centre at 29%** of the viewport height instead of 48%, to fit
  the whole silhouette inside the upper 58vh. The desktop framing law (48%) is
  unchanged.
8. **Mobile chrome in the lower band** (wordmark/counter at 58vh + 10px, rail
  at 60vh → 95vh) so no chrome intersects the full-width mobile sacred zone.
9. **Camera distances refined** from the brief's starting values (documented in
  section 4) to satisfy the ≥ 6% margin law at every checkpoint.
10. **Headless performance is not a hardware measurement.** The verification
   browser uses SwiftShader; the frame-time guard and Lighthouse performance
   score are not representative of a real GPU. The design budgets (draw calls,
   triangles, GLB size, JS gzip) are met.

## 7. Open items / honest notes

- The headless Lighthouse performance score cannot meet the 95 desktop / 85
  mobile targets in a software-rendered browser. The accessibility, best
  practices and SEO categories are expected to be 100; the performance category
  is limited by SwiftShader.
- The 60 fps / 40 fps frame-rate targets cannot be verified on real hardware in
  this sandbox. The scene is 88k triangles, 37 draw calls, one 2.33 MB GLB and
  no per-frame React renders, which is within the design budget.
- The 320 px, 200% zoom and landscape-phone checks are covered by the responsive
  CSS (the mobile layout, the 380 px breakpoint and the landscape media query);
  the 390 × 844 and 1440 × 900 checkpoints are the primary verification.

---

## 8. Final verification pass (post-cleanup)

- **Resize preservation.** The first resize handler used `lenis.resize()` then
  `lenis.scrollTo(..., { immediate: true })`. Lenis ignored the immediate scroll
  after a resize and the progress jumped from 0.500 to 0.5625. Fixed by
  stopping Lenis, setting the native scroll to `p × maxScroll()`, resizing
  Lenis, starting it again, and re-reading the progress:
  `lenis.stop()` → `window.scrollTo(0, p*max)` → `lenis.resize()` →
  `lenis.start()` → `onScroll()`. Tested at 1440×900 → 1200×800 → 390×844:
  p = 0.500 before, 0.500 after both resizes (Δ = 0.000, inside ±0.005).
- **Keyboard navigation.** Home → 0, End → 1.000, Space/PageDown/ArrowDown →
  next chapter boundary, PageUp/ArrowUp → previous boundary. The forward keys
  can now reach the final boundary (p = 1.000), not just the start of Chapter
  07. Tested: ArrowDown 0 → 0.060 → 0.143; ArrowUp back to 0.060; End → 1.000;
  Home → 0; PageDown → 0.060; PageUp → 0.
- **320 px, 200% zoom, landscape phone.** Added a 340 px breakpoint and a
  short-landscape (`max-height: 420px`) breakpoint. At 320 × 568, 720 × 450
  (200% zoom of 1440 × 900) and 844 × 390 (landscape phone) the text fits the
  lower band with `scrollHeight === clientHeight`, no sacred-zone violations and
  no overflow. The type is very small at 320 px and landscape, but it does not
  overlap the jersey.
- **No-WebGL fallback.** Chromium launched with `--disable-webgl`: the fallback
  renders, `/og/poster.jpg` loads at 1200 × 630, the h1 is SEVEN, all seven
  chapters are present, no canvas, no console errors.
- **Reduced motion.** A context with `reducedMotion: 'reduce'`: the media query
  matches, the copy is visible, the canvas is present, no console errors. Dust,
  grain, parallax and sway are disabled by the state checks.
- **Lighthouse.** Accessibility **100**, best practices **100**, SEO **100**
  (after adding `public/robots.txt`). Performance **25** in the Vite dev server
  because Lighthouse measured the unminified dev modules, no text compression
  and a software-rendered SwiftShader WebGL scene (FCP 12.4 s, LCP 23.6 s).
  This is not a valid hardware measurement; the production build is minified
  (302.6 KB gzip initial JS) and the design budgets are met. The performance
  category cannot reach 95/85 in this sandbox.
- **Final build.** `npm run build` completes with zero errors and zero warnings.
  Initial JS gzip **302.61 KB**, CSS gzip **3.10 KB**, GLB **2.33 MB**, fonts
  **97 KB**, total page weight ≈ **2.73 MB**.
- **Final verification.** All 24 checkpoints (12 desktop + 12 mobile) have
  **0 text/UI violations, 0 chrome violations, 0 console errors**. The last
  chapter is visible at p = 1.000. The macro is the only silhouette crop.
