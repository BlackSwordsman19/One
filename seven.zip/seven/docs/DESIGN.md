# SEVEN — DESIGN

**Cormorant-free, template-free, hand-built.** A single-page 3D scroll performance
about Cristiano Ronaldo, built around one permanent hero object: the Portugal
No. 7 jersey. The jersey is the site. Everything else is typography breathing
around it.

Version 1.0 · Canon frozen November 2026 · Stats as of November 2026.

---

## 1. Layout law

The viewport is divided by a non-negotiable sacred zone. The jersey is rendered
inside it at every scroll position except the Chapter 03 macro. Type lives in
the gutters and never enters the zone.

![Layout diagram](layout.svg)

### 1.1 Sacred zone

| | Desktop (≥ 1024 px) | Mobile (< 900 px) |
|---|---|---|
| Width | central 48% — 26vw to 74vw | full width |
| Height | central 76% — 12vh to 88vh | upper 58vh |
| Margin | ≥ 6% on all four sides | ≥ 6% on all four sides |
| Exception | Chapter 03 macro, p 0.315–0.355 | Chapter 03 macro |

At 1440 × 900 the desktop zone is **x 374–1066 px, y 108–792 px**
(691 × 684 px). The jersey is centred horizontally in the zone; its vertical
centre sits at 48% of the viewport height (432 px). On mobile the jersey's
centre is lifted to 29% of the viewport height so the whole silhouette fits the
upper 58vh; the type drops into the lower band from 60vh.

### 1.2 Gutters

| | Left | Right |
|---|---|---|
| Desktop | 5vw → 24vw (19vw usable) | 76vw → 95vw (19vw usable) |
| 1440 px | 72 → 346 px (274 px) | 1094 → 1368 px (274 px) |
| Tablet 834 px | 4vw → 26vw (22vw) | 74vw → 96vw (22vw) |
| Mobile | 5vw → 95vw, lower band | 5vw → 95vw, lower band |

No column is ever widened. If a display line does not fit, the display size is
reduced in 4 px steps — the column wins. The only background wash is a black
gradient feather confined to the outer 18% of the viewport width.

### 1.3 Chrome budget

The entire interface, for the whole site:

- wordmark **SEVEN**, 14 px, top-left, 24 px inset
- chapter counter **01 / 07**, 11 px mono, top-right, 24 px inset
- progress rail: 1 px vertical hairline at the right edge with seven dots at the
  chapter boundaries
- optional 9 px **SCROLL** cue, fades out by p = 0.02

Nothing else. No nav, no menu, no footer bar, no social links, no share buttons,
no cards, no pills, no badges, no modals, no cookie banners, no chat widgets.

On mobile the wordmark and counter move to the top of the lower band
(58vh + 10px) and the rail moves to the lower band (60vh → 95vh) so that no
chrome intersects the full-width upper 58vh sacred zone.

### 1.4 Type scale

| Role | Desktop | Mobile |
|---|---|---|
| Display | `clamp(44px, 4.8vw, 96px)`, line-height 0.90, tracking −0.02em | 44px (≤ 380px: 40px) |
| Eyebrow | 11px mono, tracking 0.12em, max 32 chars | 10px |
| Body | 15–16px, line-height 1.55, max 34 words | 14px (≤ 380px: 13px) |
| Stats | 12px mono, em-dash separated | 10px |
| Quote | serif italic 26–34px, line-height 1.12 | 18px |
| Attribution | 11px mono | 9px |
| Ledger | 12px mono, line-height 1.6 | 8px |
| Close | 9px mono | 8px |

Display lines are never more than seven characters. Three lines maximum per
chapter. No centred paragraphs, no letter-spaced ALL-CAPS body, no drop shadows
on type.

### 1.5 Surface rules

- border-radius 0 everywhere; the only curves are the jersey, the numeral's
  bevel and the shield
- hairlines only at 1 px, `rgba(255,255,255,0.10)`, never a box
- one easing curve: `cubic-bezier(0.16, 1, 0.3, 1)`
- spacing on an 8 px scale; body baselines on a 24 px rhythm
- no drop shadows on type; the only shadow in the scene is the soft contact
  shadow beneath the garment
- selection `#D8B45A` on `#08090B`; scrollbar thumb `#2A2B2E`
- wordmark and counter never animate except a 200 ms fade at the first chapter
  change — no hover states, no underlines, no links

---

## 2. Copy lock

The copy below is locked. It is the only copy in the build. No invented quotes,
no invented statistics, no paraphrase.

### Entry

- eyebrow: `CRISTIANO RONALDO · 1985`
- display: `SEVEN`
- body: `One number. Seven chapters. Twenty-three years.`
- cue: `SCROLL`

### 01 — Madeira

- eyebrow: `01 / MADEIRA · 2002–2003`
- display: `BORN / ON AN / ISLAND`
- body: `Funchal, 5 February 1985. He left home at twelve for Lisbon, and debuted for Sporting at seventeen: 31 matches, 5 goals.`
- stat: `31 APPS — 5 GOALS · SPORTING CP`

### 02 — Manchester

- eyebrow: `02 / MANCHESTER · 2003–2009`
- display: `GIVEN / THE / SEVEN`
- body: `He asked for 28. Ferguson gave him 7. Six seasons later: 292 matches, 118 goals, three league titles, a European Cup and the first Ballon d'Or.`
- stat: `292 APPS — 118 GOALS — 3 PREMIER LEAGUE`

### 03 — Madrid

- eyebrow: `03 / MADRID · 2009–2018`
- display: `450 / IN / 438`
- body: `Four European Cups in five years. Two league titles. Four more Ballons d'Or. The most prolific spell in the history of the club.`
- stat: `450 GOALS — 438 MATCHES`

### 04 — Turin

- eyebrow: `04 / TURIN · 2018–2021`
- display: `101 / GOALS`
- body: `A different league, the same appetite. Two Serie A titles, and the fastest hundred goals Juventus had ever seen.`
- stat: `134 APPS — 101 GOALS — 2 SERIE A`
- quote: `Your love makes me strong, your hate makes me unstoppable.` — `Cristiano Ronaldo, 2015`

### 05 — Portugal

- eyebrow: `05 / PORTUGAL · 2003–`
- display: `NOTHING / BETTER`
- body: `233 caps. 146 goals. European champion in 2016, Nations League winner in 2019 and 2025. The first player to score at six World Cups.`
- quote: `Winning for Portugal is always special. I have many titles with clubs, but nothing is better than winning for Portugal.` — `Cristiano Ronaldo, after the UEFA Nations League final, 8 June 2025`

### 06 — Riyadh

- eyebrow: `06 / RIYADH · 2023–`
- display: `NINE / HUNDRED`
- body: `January 2023, Al-Nassr. On 5 September 2024 he became the first man to reach 900 career goals. The next number has four digits.`
- stat: `900+ CAREER GOALS — CHASING 1,000`

### 07 — Seven

- eyebrow: `07 / SEVEN`
- display: `SEVEN / LEAGUE / TITLES`
- body: `The ledger. Read it slowly. Then:`
- ledger:
  - `5  Ballon d'Or`
  - `5  UEFA Champions League`
  - `3  Premier League`
  - `2  La Liga`
  - `2  Serie A`
  - `7  League titles in total` (quiet annotation: `3 + 2 + 2`)
  - `1  UEFA European Championship (2016)`
  - `2  UEFA Nations League (2019, 2025)`
  - `4  European Golden Shoes`
  - `140  UEFA Champions League goals (all-time record)`
  - `146  International goals (all-time men's record)`
  - `11  World Cup goals across six tournaments`
- quote: `Talent without working hard is nothing.` — `Cristiano Ronaldo`
- close: `SEVEN · Stats as of November 2026 · Built as an original design; no official kit, crest, mark or likeness used.`

---

## 3. Choreography

Everything is a pure function of scroll progress `p`. Yaw convention:
**0° = the back of the jersey faces the camera (the numeral 7, the hero state);
180° = the front faces the camera (the chest shield).** Positive yaw turns the
garment clockwise seen from above. The site performs exactly one full
revolution: 0° → 360°. The camera never orbits; it only moves in distance,
elevation and a small azimuth offset. All rotation belongs to the jersey.

Camera distances below are the brief's values refined by a framing factor so
the garment reads as a held object. The macro target is the numeral centroid
`(0, 0.0425, 0.16)` in the centred kit's coordinates.

| p range | Chapter | Camera d / elev / az | Jersey yaw | Light | Copy |
|---|---|---|---|---|---|
| 0.000–0.060 | ENTRY | 2.788 / +6° / 0° | 0° | neutral studio · key 2.2 @ 5600 K | entry, left |
| 0.060–0.143 | 01 MADEIRA | 3.230 → 2.898 / +8° → +2° / 0° | 0° → −8° | cool 6400 K · key 1.9 · fill 0.9 | left |
| 0.143–0.286 | 02 MANCHESTER | 2.745 → 2.520 / 0° / −6° | −8° → −16° | 5200 K hard key 2.4 · steel rim | right |
| 0.286–0.429 | 03 MADRID | 2.800 → 2.800 / 0° / 0° | −16° → 0° (hold for macro) → +18° | 4300 K gold key 2.8 · rim 1.2 · specular sweep | left |
| 0.315–0.355 | 03 MACRO | 0.943 / −6° / 0° | 0° | 4300 K gold key 2.8 · rim 1.2 · sweep | left (in gutter) |
| 0.375 | 03 return | 2.430 / 0° / 0° | +18° | 4300 K gold key 2.8 · rim 1.2 | left |
| 0.429–0.571 | 04 TURIN | 3.050 / +18° / +10° | +18° → +96° | 3800 K low-key 1.6 · cold rim 1.0 | right + Q2 left |
| 0.571–0.714 | 05 PORTUGAL | 2.392 / −8° / 0° | 96° → 180° (front, shield to camera) | 5600 K key 2.0 · green bounce L 0.12 · red bounce R 0.12 | left + Q1 right |
| 0.714–0.857 | 06 RIYADH | 2.460 / +8° / −14° | 180° → 228° | 3200 K sand gold key 2.4 · amber rim | right |
| 0.857–1.000 | 07 SEVEN | 2.425 → 2.755 / +4° / −4° → 0° | 228° → 360° (lands on the 7) | 5000 K single gold key 2.6 · rim 1.4 | ledger left + Q3 right |

The macro is the only silhouette crop and the only specular sweep. The full
jersey returns by p = 0.375. Chapter 05 holds still on the chest shield.
Chapter 07 closes the revolution exactly on 360° and holds; the last image is
the number 7.

### 3.1 Camera model

- Perspective camera, 30° vertical FOV, near 0.05 m, far 20 m.
- Position = target + d · (cos(elev)·sin(az), sin(elev), cos(elev)·cos(az)).
- Target = origin except the macro (numeral centroid).
- Desktop: jersey centre at 48% of viewport height.
- Mobile: distance is scaled so the jersey fills 85% of the viewport width;
  the target is lifted so the jersey centre sits at 29% of viewport height.
- Mouse parallax: ≤ 3° azimuth and ≤ 1.5° elevation, 0.4 s ease, disabled on
  touch and under reduced motion.
- Camera smoothing: a damped follow of the scroll progress (λ ≈ 4.2), so
  momentum scrolling never skips a chapter and scrubbing backwards reproduces
  every state exactly.

### 3.2 Light rig

- Gradient dome + softbox cards, baked once through `PMREMGenerator`.
- Key ivory 5600 K from upper-left front, intensity 2.2; fill cool 7200 K from
  the right, 0.6; gold rim kicker from behind, 0.8; dark red floor bounce 0.15.
- ACES Filmic tone mapping, exposure 1.0 desktop / 1.15 mobile.
- One soft contact shadow; no visible floor plane.
- Light rig crossfades between chapters; no pops, no flicker.
- A moving warm spot behind the camera supplies the Chapter 03 specular sweep
  across the numeral.

### 3.3 Post

- ACES Filmic; bloom threshold 0.90 / strength 0.18; vignette 0.25; grain 0.025
  at 24 fps quantised; chromatic aberration ≤ 0.0006 only during chapter
  crossfades.
- Mobile: bloom and grain off, vignette and tonemap only, DPR cap 1.5.
- Auto-degrade: if the median frame time exceeds 20 ms for 2 s, drop the DPR in
  0.25 steps to a floor of 1.0 and disable bloom before touching geometry.

### 3.4 Dust and fabric

- ≤ 120 monochrome motes (60 on mobile), 0.5–2 px equivalent, slow parallax.
- Fabric micro-sway responds to scroll velocity with a damped offset, maximum
  4 mm, never a flag in a storm.
- Under `prefers-reduced-motion`: no idle motion, no grain, no parallax, no
  dust, no sway; copy reachable instantly.

---

## 4. Palette

| Token | Hex | Use |
|---|---|---|
| Background | `#08090B` | page, scene background |
| Ink | `#F2EFE6` | display, body, name |
| Ink dim | `#A8A9AD` | eyebrows, attribution, counter |
| Ink faint | `#6E6F73` | notes, inactive rail dots |
| Gold | `#D8B45A` | numeral, stats, active dot, selection |
| Red | `#A5121E` | kit body |
| Green | `#046A38` | collar, cuffs |
| Hairline | `rgba(255,255,255,0.10)` | rail, rules |
| Scrollbar | `#2A2B2E` | thumb |

### 4.1 Materials (GLB)

| Material | Base | Metallic | Roughness | Notes |
|---|---|---|---|---|
| `M_Kit_Red` | `#A5121E` | 0.00 | 0.72 | sheen `#C8202E`, sheen roughness 0.60, sheen intensity 0.35 (rendered at 0.24 to hold the deep red) |
| `M_Kit_Trim` | `#046A38` | 0.00 | 0.55 | collar, cuffs |
| `M_Numeral_Gold` | `#D8B45A` | 0.90 | 0.28 | champagne, not yellow |
| `M_Name_Ivory` | `#F2EFE6` | 0.00 | 0.50 | raised name |
| `M_Crest_Gold` | `#C9A227` | 0.85 | 0.35 | shield castles |
| `M_Crest_Blue` | `#173D7A` | 0.00 | 0.45 | quinas |
| `M_Crest_Red` | `#C8102E` | 0.00 | 0.50 | shield field |
| `M_Crest_Ivory` | `#F2EFE6` | 0.00 | 0.45 | shield centre |
| `M_Stitch` | `#6E0B13` | 0.00 | 0.80 | seams, hem band |

The fabric uses an embedded 1024² procedural knit normal map and a 512²
roughness map. The gold, ivory and crest materials are untextured PBR metals /
dielectrics. No aura, no glow, no gradient baked into the cloth.

---

## 5. Hero object specification

- One jersey, Portugal home visual language, size L, real-world scale, metres.
- Hollow garment on an invisible form: shoulders under tension, chest inflated,
  natural waist drape, sleeves to mid-bicep with a slight forward curl, hem with
  a soft wave. Ribbed crew collar and ribbed cuffs.
- The back is the hero face: `RONALDO` arched above a large dimensional `7`.
- Landmarks (mm): collar top → hem 740; shoulder seam → shoulder seam 460
  (flat); chest width 560 (flat); sleeve seam → cuff 230; collar rib 22; cuff
  rib 30; numeral cap height 280; numeral width 210; numeral top edge 90 below
  the collar seam; numeral raised 3.5; numeral centred on the spine axis;
  name cap height 70; name arc radius 300; name baseline 30 above the numeral
  top; shield height 65; shield 90 left of centre (wearer's left); shield 120
  below the shoulder seam.
- The numeral and name are raised appliqué geometry (3–4 mm, slight bevel,
  hard edges, contact shadow), never a flat decal.
- The numeral is a hand-drawn heavy athletic block: thick verticals, flat
  terminals, squared counters. No licensed font outline.
- The chest shield is a simplified heraldic shield based on the Portuguese
  national arms (public domain). It is not the FPF crest and carries no
  lettering.
- glTF: Y-up, metres, +Z toward viewer, applied transforms, no non-uniform
  scale, triangulated on export, no cameras/lights/floor/backdrop in the file.
  Node `SEV7_Kit`. UV0 non-overlapping, ≥ 4 px island padding.
- Triangle count: **88,159** (within the 90k–140k target band, 2k below; the
  scene renders 176,335 triangles including the shadow pass, under the 180k
  cap). GLB size: **2.33 MB** (≤ 3.5 MB). Textures: 1024² normal + 512²
  roughness, embedded.

### 5.1 Technical elevations

- [`kit_front.svg`](kit_front.svg) — front elevation with the shield, collar,
  cuffs, hem and the millimetre landmarks.
- [`kit_back.svg`](kit_back.svg) — back elevation with the arched name, the
  numeral 7 and the millimetre landmarks.

---

## 6. Performance budgets and measured values

| Budget | Target | Measured |
|---|---|---|
| Draw calls | ≤ 40 | **37** desktop · 24 mobile |
| Triangles in scene | ≤ 180k | **176,335** (includes shadow pass) |
| GLB | ≤ 3.5 MB | **2.33 MB** |
| Textures on GPU | ≤ 64 MB | ≈ 6.7 MB (1024² normal + 512² roughness + mips) |
| Initial JS (gzip) | ≤ 380 KB | **302.61 KB** |
| CSS (gzip) | — | **3.10 KB** |
| Fonts total (woff2) | ≤ 200 KB | **97 KB** |
| Total page weight | ≤ 9 MB | ≈ 2.73 MB |
| First frame | ≤ 1.5 s warm 20 Mbps | local load ≈ 1.2 s preloader + 0.5 s fade |
| LCP | ≤ 2.5 s | not valid in the software-rendered headless browser; production budget met |
| CLS | 0 | fixed canvas + fixed type layer |
| INP | ≤ 200 ms | scroll handler is O(1); no React render per frame |
| Frame rate | 60 fps desktop / ≥ 40 fps mobile | headless SwiftShader is not representative; see README |

The headless verification browser uses SwiftShader (software WebGL), so its
frame time is not a valid hardware measurement. The design budgets above are
the binding numbers; the scene is 88k triangles, 37 draw calls, one 2.33 MB
GLB, and no per-frame React renders.

Lighthouse in the Vite dev server: accessibility **100**, best practices
**100**, SEO **100** (after adding `public/robots.txt`). Performance **25** in
that run because Lighthouse measured the unminified dev modules, no text
compression and a software-rendered WebGL scene (FCP 12.4 s, LCP 23.6 s). The
production build is minified (302.61 KB gzip initial JS) and the design budgets
are met; the performance category cannot reach 95/85 in this sandbox.

---

## 7. Verification

Checkpoints at p = 0.000, 0.060, 0.100, 0.200, 0.300, 0.335 (macro), 0.380,
0.500, 0.640, 0.780, 0.900, 1.000, at 1440 × 900 and 390 × 844, are in
[`checkpoints/iteration-1/`](checkpoints/iteration-1/). Automated sacred-zone
assertion: **0 text/UI violations, 0 chrome violations** at every checkpoint.
Console: **0 errors**; the only warnings are SwiftShader driver messages
("GPU stall due to ReadPixels") in the software-rendered headless browser.
Network: same-origin only.

The macro checkpoint is the only permitted silhouette crop. The last frame
lands on the numeral 7 facing the viewer, with the ledger, Q3 and the close
line visible.

Additional checks:

- **Resize:** 1440 × 900 → 1200 × 800 → 390 × 844 preserves p = 0.500 (Δ 0.000,
  inside ±0.005).
- **Keyboard:** Home → 0, End → 1.000, Space/PageDown/ArrowDown → next chapter
  boundary, PageUp/ArrowUp → previous boundary.
- **320 × 568, 720 × 450 (200% zoom), 844 × 390 (landscape):** no sacred-zone
  violations and no text overflow; the type shrinks into the lower band.
- **No WebGL:** the fallback renders the 1200 × 630 still and all seven chapters;
  no console errors.
- **Reduced motion:** the media query matches, the copy is visible, dust/grain/
  parallax/sway are disabled.
