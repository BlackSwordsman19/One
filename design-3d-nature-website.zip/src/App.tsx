import { useCallback, useEffect, useRef, useState } from "react";
import { World } from "./world/World";

interface Layer {
  id: string;
  layer: string;
  side: "left" | "right";
  title: string;
  body: string;
}

const LAYERS: Layer[] = [
  { id: "crown", layer: "Emergent layer", side: "left", title: "Everything beneath the tallest tree", body: "Scroll down 116 metres of redwood forest, from the crown to the fungus below." },
  { id: "fog", layer: "Fog line", side: "right", title: "Redwoods drink the fog", body: "Along the California coast, summer fog can supply up to a third of a redwood’s water. The needles take it in directly." },
  { id: "canopy", layer: "Canopy", side: "left", title: "A salamander that never touches ground", body: "Soil piles up on the high branches. Wandering salamanders can spend their whole lives in it, sixty metres up." },
  { id: "trunk", layer: "Trunk zone", side: "right", title: "Bark a foot thick", body: "Tannin-rich bark, up to 30 centimetres deep, lets old redwoods survive fires that kill other trees." },
  { id: "floor", layer: "Forest floor", side: "left", title: "A dead log raises the next forest", body: "Fallen redwoods rot slowly and carry seedlings on their backs. Around a stump, a ring of clones can sprout." },
  { id: "roots", layer: "Root zone", side: "right", title: "Shallow roots, held together", body: "Redwood roots rarely run deeper than three metres. They spread thirty metres wide and graft onto their neighbours’." },
  { id: "network", layer: "Mycelium", side: "left", title: "Kilometres of thread in a teaspoon", body: "Fungal threads trade minerals for sugar between roots. A few wood-rotting species glow in the dark." },
  { id: "whole", layer: "The whole forest", side: "left", title: "The largest organism is a fungus", body: "One honey fungus in Oregon’s Blue Mountains covers about 965 hectares, and has been spreading for thousands of years." },
];

const formatDepth = (y: number) => {
  const v = Math.round(y);
  return v < 0 ? `\u2212${Math.abs(v)}` : `${v}`;
};

export default function App() {
  const sectionRefs = useRef<(HTMLElement | null)[]>([]);
  const depthRef = useRef<HTMLSpanElement>(null);
  const [active, setActive] = useState(0);
  const [gl, setGl] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const activeRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const n = LAYERS.length;
    let centers: number[] = [];
    let vh = window.innerHeight;

    const getTarget = () => {
      vh = window.innerHeight;
      centers = sectionRefs.current.map((el) => {
        if (!el) return 0;
        const r = el.getBoundingClientRect();
        return r.top + r.height / 2;
      });
      const mid = vh / 2;
      if (centers[0] >= mid) return 0;
      for (let i = 0; i < n - 1; i++) {
        if (centers[i + 1] > mid) return i + (mid - centers[i]) / (centers[i + 1] - centers[i]);
      }
      return n - 1;
    };

    let world: World;
    try {
      world = new World(canvas, {
        getTarget,
        reduced,
        still: new URLSearchParams(window.location.search).has("still") ? Number(new URLSearchParams(window.location.search).get("still")) : null,
        onFrame: (y, s) => {
          if (depthRef.current) depthRef.current.textContent = formatDepth(y);
          const idx = Math.max(0, Math.min(n - 1, Math.round(s)));
          if (idx !== activeRef.current) {
            activeRef.current = idx;
            setActive(idx);
          }
          if (!reduced) {
            sectionRefs.current.forEach((el, i) => {
              if (!el) return;
              const d = Math.abs(centers[i] - vh / 2) / vh;
              const o = 1 - Math.min(1, Math.max(0, (d - 0.3) / 0.22));
              const panel = el.firstElementChild as HTMLElement | null;
              if (panel) panel.style.opacity = String(0.0 + o * o * (3 - 2 * o));
            });
          }
        },
      });
    } catch {
      setGl(false);
      return;
    }
    world.start();
    document.documentElement.classList.add("has-world", "js");
    return () => {
      world.dispose();
      document.documentElement.classList.remove("has-world", "js");
    };
  }, []);

  const jump = useCallback((i: number) => {
    const el = sectionRefs.current[i];
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const top = el.getBoundingClientRect().top + window.scrollY + el.offsetHeight / 2 - window.innerHeight / 2;
    window.scrollTo({ top: Math.max(0, top), behavior: reduced ? "auto" : "smooth" });
  }, []);

  const side = LAYERS[active].side;
  const current = LAYERS[active];

  return (
    <div className={gl ? "page" : "page page--static"}>
      <canvas ref={canvasRef} className="world" aria-hidden="true" />
      <div className={`scrim scrim--left ${side === "left" ? "is-on" : ""}`} aria-hidden="true" />
      <div className={`scrim scrim--right ${side === "right" ? "is-on" : ""}`} aria-hidden="true" />

      <header className="bar">
        <a className="wordmark" href="#crown" onClick={(e) => { e.preventDefault(); jump(0); }}>Sempervirens</a>
      </header>

      <div className="depth" aria-hidden="true">
        <p className="depth__num"><span ref={depthRef} className="figure">116</span><span className="depth__unit">m</span></p>
        <p className="depth__name">{current.layer}</p>
      </div>

      <nav className="rail" aria-label="Layers of the forest">
        <ol>
          {LAYERS.map((l, i) => (
            <li key={l.id}>
              <button type="button" className="rail__btn" aria-current={i === active ? "step" : undefined} onClick={() => jump(i)}>
                <span className="rail__label">{l.layer}</span>
                <span className="rail__tick" aria-hidden="true" />
              </button>
            </li>
          ))}
        </ol>
      </nav>

      <main>
        {LAYERS.map((l, i) => (
          <section
            key={l.id}
            id={l.id}
            ref={(el) => { sectionRefs.current[i] = el; }}
            className={`stage ${i === 0 ? "stage--hero" : ""}`}
            aria-labelledby={`${l.id}-h`}
          >
            <div className={`panel panel--${l.side} ${i === 0 ? "panel--hero" : ""}`}>
              {i === 0 ? <h1 id={`${l.id}-h`}>{l.title}</h1> : <h2 id={`${l.id}-h`}>{l.title}</h2>}
              <p className="lead">{l.body}</p>
              {i === 0 && (
                <button type="button" className="btn" onClick={() => jump(1)}>
                  Begin the descent
                </button>
              )}
              {i === LAYERS.length - 1 && (
                <button type="button" className="btn btn--quiet" onClick={() => jump(0)}>
                  Return to the crown
                </button>
              )}
            </div>
          </section>
        ))}
      </main>

      <footer className="foot">
        <div className="foot__inner">
          <p className="foot__mark">Sempervirens</p>
          <p className="foot__note">
            A descent through a coast redwood forest, drawn live in your browser. The tallest tree is Hyperion, at 116 metres.
            Facts from Save the Redwoods League, the U.S. Forest Service and Dawson’s 1998 study of fog and redwood water use.
          </p>
        </div>
      </footer>
    </div>
  );
}
