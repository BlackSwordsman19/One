import {
  AnimatePresence,
  motion,
  useMotionValueEvent,
  useReducedMotion,
  useScroll,
  useTransform,
} from "framer-motion";
import { ArrowRight, Leaf, Menu, X } from "lucide-react";
import { useRef, useState, type KeyboardEvent } from "react";
import ForestScene from "./ForestScene";

const forestImages = {
  fanal: "/images/fanal-madeira-portugal-lorbeerwald-2025-1546-1920.jpg",
  path: "/images/slezske-beskydy-rytirska-stezka-cesta-nydek-velka-cantoryje-1920.jpg",
  falls: "/images/beech-forest-au-great-otway-national-park-beauchamp-falls-20-1920.jpg",
  lake: "/images/herbert-lake-beim-icefields-parkway-1920.jpg",
};

const chapters = [
  {
    label: "The path",
    title: "Every path enters a living world.",
    body: "Trees turn light, rain and shelter into places to live.",
    image: forestImages.path,
    imageAlt: "A quiet track winding through tall beech trees in morning light.",
    imagePosition: "50% 54%",
  },
  {
    label: "The understory",
    title: "The forest keeps a second world.",
    body: "Moss and fallen leaves hold the beginning of what grows next.",
    image: forestImages.fanal,
    imageAlt: "Moss-covered laurel branches emerging through mist in Fanal.",
    imagePosition: "63% 50%",
  },
  {
    label: "The watershed",
    title: "Water carries the story outward.",
    body: "A forest stream links this place to the wider land.",
    image: forestImages.falls,
    imageAlt: "Water falling through ferns and beech forest into a rocky stream.",
    imagePosition: "55% 48%",
  },
];

const fieldNotes = [
  {
    name: "Canopy",
    teaser: "Where life meets the light",
    title: "Where light meets the crown.",
    body: "Mosses and lichens find a foothold high in the branches.",
    image: forestImages.fanal,
    alt: "A mossy laurel trunk and its branches fading into fog.",
    location: "Fanal forest, Madeira",
    subject: "Laurel canopy",
  },
  {
    name: "Understory",
    teaser: "The quiet work below",
    title: "Life gathers close to the ground.",
    body: "Leaf litter shelters the slow work of decay and return.",
    image: forestImages.path,
    alt: "A leaf-covered path beneath tall trees in the Silesian Beskids.",
    location: "Silesian Beskids",
    subject: "Beech woodland",
  },
  {
    name: "Watershed",
    teaser: "Where rain finds a route",
    title: "Rain takes the forest further.",
    body: "A woodland stream carries water into the land beyond the trees.",
    image: forestImages.falls,
    alt: "A waterfall surrounded by ferns and mossy rocks in beech forest.",
    location: "Great Otway National Park",
    subject: "Forest stream",
  },
];

function SiteHeader() {
  const navLinks = (
    <>
      <a href="#journey">The descent</a>
      <a href="#field-notes">Field notes</a>
      <a href="#close">Beyond the trees</a>
    </>
  );

  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <header className="site-header">
        <div className="site-header__inner container">
          <a className="wordmark" href="#top" aria-label="Mori, home">
            <Leaf aria-hidden="true" size={20} strokeWidth={1.5} />
            <span>MORI</span>
          </a>
          <nav className="desktop-nav" aria-label="Main navigation">
            {navLinks}
          </nav>
          <details className="mobile-nav">
            <summary aria-label="Navigation menu">
              <span>Menu</span>
              <Menu className="mobile-nav__menu" aria-hidden="true" size={20} />
              <X className="mobile-nav__close" aria-hidden="true" size={20} />
            </summary>
            <nav aria-label="Main navigation">{navLinks}</nav>
          </details>
          <a className="site-header__action" href="#field-notes">
            Look closer
          </a>
        </div>
      </header>
    </>
  );
}

function JourneyChapter({
  chapter,
  index,
  progress,
  active,
}: {
  chapter: (typeof chapters)[number];
  index: number;
  progress: ReturnType<typeof useScroll>["scrollYProgress"];
  active: boolean;
}) {
  const ranges = [
    [0, 0.08, 0.25, 0.38],
    [0.28, 0.38, 0.58, 0.7],
    [0.6, 0.72, 1],
  ][index];
  const opacity = useTransform(
    progress,
    ranges,
    index === 0 ? [1, 1, 1, 0] : index === 1 ? [0, 1, 1, 0] : [0, 1, 1],
  );
  const y = useTransform(
    progress,
    ranges,
    index === 0 ? [0, 0, 0, -14] : index === 1 ? [16, 0, 0, -14] : [16, 0, 0],
  );

  return (
    <motion.article
      className="journey-copy"
      style={{ opacity, y }}
      aria-hidden={!active}
    >
      <p className="journey-copy__place">{chapter.label}</p>
      <h2>{chapter.title}</h2>
      <p className="journey-copy__body">{chapter.body}</p>
    </motion.article>
  );
}

function StillJourney() {
  return (
    <section
      className="journey-still"
      id="journey"
      aria-label="A journey through three layers of the forest"
    >
      <div className="journey-still__layout container">
        <figure className="journey-still__figure">
          <img
            src={chapters[0].image}
            alt={chapters[0].imageAlt}
            width="1920"
            height="1280"
            fetchPriority="high"
            style={{ objectPosition: chapters[0].imagePosition }}
          />
          <figcaption>A forest track beneath the beech canopy.</figcaption>
        </figure>
        <div className="journey-still__chapters">
          {chapters.map((chapter) => (
            <article className="journey-still__chapter" key={chapter.label}>
              <p className="journey-copy__place">{chapter.label}</p>
              <h2>{chapter.title}</h2>
              <p className="journey-copy__body">{chapter.body}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}

function ForestJourney() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start start", "end end"],
  });
  const [activeChapter, setActiveChapter] = useState(0);
  const pathOpacity = useTransform(scrollYProgress, [0, 0.18, 0.34, 0.43], [1, 1, 0, 0]);
  const trunkOpacity = useTransform(scrollYProgress, [0.28, 0.39, 0.6, 0.72], [0, 1, 1, 0]);
  const fallsOpacity = useTransform(scrollYProgress, [0.58, 0.7, 1], [0, 1, 1]);
  const imageScale = useTransform(scrollYProgress, [0, 1], [1.04, 1.12]);
  const progressScale = useTransform(scrollYProgress, [0, 1], [0, 1]);

  useMotionValueEvent(scrollYProgress, "change", (value) => {
    setActiveChapter(value < 0.33 ? 0 : value < 0.68 ? 1 : 2);
  });

  if (reduceMotion) return <StillJourney />;

  return (
    <section
      className="journey"
      id="journey"
      ref={sectionRef}
      aria-label="A three-dimensional journey through the forest"
    >
      <div className="journey-pin">
        <div className="journey-backdrops" aria-hidden="true">
          <motion.img
            className="journey-backdrop"
            src={chapters[0].image}
            alt=""
            width="1920"
            height="1280"
            loading="lazy"
            style={{ opacity: pathOpacity, scale: imageScale, objectPosition: chapters[0].imagePosition }}
          />
          <motion.img
            className="journey-backdrop"
            src={chapters[1].image}
            alt=""
            width="1920"
            height="1280"
            loading="lazy"
            style={{ opacity: trunkOpacity, scale: imageScale, objectPosition: chapters[1].imagePosition }}
          />
          <motion.img
            className="journey-backdrop"
            src={chapters[2].image}
            alt=""
            width="1920"
            height="1280"
            loading="lazy"
            style={{ opacity: fallsOpacity, scale: imageScale, objectPosition: chapters[2].imagePosition }}
          />
        </div>
        <div className="journey-shade" aria-hidden="true" />
        <ForestScene progress={scrollYProgress} />
        <div className="journey-content container">
          {chapters.map((chapter, index) => (
            <JourneyChapter
              key={chapter.label}
              chapter={chapter}
              index={index}
              progress={scrollYProgress}
              active={activeChapter === index}
            />
          ))}
        </div>
        <motion.div
          className="journey-progress"
          style={{ scaleX: progressScale }}
          aria-hidden="true"
        />
      </div>
    </section>
  );
}

function FieldNotes() {
  const [activeIndex, setActiveIndex] = useState(0);
  const tabRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const reduceMotion = useReducedMotion();
  const note = fieldNotes[activeIndex];

  function selectNote(index: number, moveFocus = false) {
    setActiveIndex(index);
    if (moveFocus) tabRefs.current[index]?.focus();
  }

  function handleTabKeyDown(event: KeyboardEvent<HTMLButtonElement>, index: number) {
    let nextIndex = index;
    if (event.key === "ArrowRight" || event.key === "ArrowDown") {
      nextIndex = (index + 1) % fieldNotes.length;
    } else if (event.key === "ArrowLeft" || event.key === "ArrowUp") {
      nextIndex = (index - 1 + fieldNotes.length) % fieldNotes.length;
    } else if (event.key === "Home") {
      nextIndex = 0;
    } else if (event.key === "End") {
      nextIndex = fieldNotes.length - 1;
    } else {
      return;
    }
    event.preventDefault();
    selectNote(nextIndex, true);
  }

  return (
    <section className="field-notes" id="field-notes" aria-labelledby="notes-title">
      <div className="container">
        <div className="section-heading">
          <h2 id="notes-title">A forest has many addresses.</h2>
          <p>Choose a layer to open its field note.</p>
        </div>

        <div className="field-notes__layout">
          <div className="field-notes__index">
            <div className="notes-tabs" role="tablist" aria-label="Forest layers">
              {fieldNotes.map((item, index) => (
                <button
                  className="notes-tab"
                  type="button"
                  role="tab"
                  id={`note-tab-${index}`}
                  aria-selected={activeIndex === index}
                  aria-controls="field-note-panel"
                  tabIndex={activeIndex === index ? 0 : -1}
                  key={item.name}
                  ref={(node) => {
                    tabRefs.current[index] = node;
                  }}
                  onClick={() => selectNote(index)}
                  onKeyDown={(event) => handleTabKeyDown(event, index)}
                >
                  <span className="notes-tab__text">
                    <span className="notes-tab__name">{item.name}</span>
                    <span className="notes-tab__teaser">{item.teaser}</span>
                  </span>
                  <ArrowRight aria-hidden="true" size={20} />
                </button>
              ))}
            </div>

            <div
              className="field-note-panel"
              role="tabpanel"
              id="field-note-panel"
              aria-labelledby={`note-tab-${activeIndex}`}
              tabIndex={0}
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  className="field-note-panel__copy"
                  key={note.name}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{
                    duration: reduceMotion ? 0 : 0.42,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                >
                  <h3>{note.title}</h3>
                  <p>{note.body}</p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>

          <figure className="field-notes__figure">
            <div className="field-notes__image">
              <AnimatePresence initial={false} mode="sync">
                <motion.img
                  key={note.image}
                  src={note.image}
                  alt={note.alt}
                  width="1920"
                  height="1280"
                  loading="lazy"
                  initial={{ opacity: 0, scale: 1.025 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{
                    duration: reduceMotion ? 0 : 0.65,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                />
              </AnimatePresence>
            </div>
            <figcaption>
              <span>{note.location}</span>
              <span>{note.subject}</span>
            </figcaption>
          </figure>
        </div>
      </div>
    </section>
  );
}

function FooterCredits() {
  return (
    <p className="photo-credits" data-credits>
      Photographs: <a href="https://commons.wikimedia.org/wiki/File:Fanal_(Madeira,_Portugal),_Lorbeerwald_--_2025_--_1546.jpg" target="_blank" rel="noreferrer">Dietmar Rabich</a> (CC BY-SA 4.0), <a href="https://commons.wikimedia.org/wiki/File:Slezsk%C3%A9_Beskydy_-_Ryt%C3%AD%C5%99sk%C3%A1_stezka_(cesta_N%C3%BDdek_-_Velk%C3%A1_%C4%8Cantoryje).JPG" target="_blank" rel="noreferrer">Pudelek (Marcin Szala)</a> (CC BY-SA 4.0), <a href="https://commons.wikimedia.org/wiki/File:Beech_Forest_(AU),_Great_Otway_National_Park,_Beauchamp_Falls_--_2019_--_1271.jpg" target="_blank" rel="noreferrer">Dietmar Rabich</a> (CC BY-SA 4.0), and <a href="https://commons.wikimedia.org/wiki/File:Herbert_Lake_beim_Icefields_Parkway.jpg" target="_blank" rel="noreferrer">Florian Fuchs</a> (CC BY 3.0), via Wikimedia Commons.
    </p>
  );
}

export default function App() {
  return (
    <div className="site-shell">
      <SiteHeader />
      <main id="main">
        <section className="hero" id="top" aria-labelledby="hero-title">
          <img
            className="hero__image"
            src={forestImages.fanal}
            alt="Moss-covered laurel branches rising through morning mist in Fanal, Madeira."
            width="1920"
            height="1280"
            fetchPriority="high"
          />
          <div className="hero__shade" aria-hidden="true" />
          <div className="hero__content container">
            <div className="hero__brand" aria-hidden="true">MORI</div>
            <h1 id="hero-title">The forest, in every layer.</h1>
            <p className="hero__intro">
              A living atlas of the places, patterns and lives that grow together.
            </p>
            <div className="hero__actions">
              <a className="button button--primary" href="#journey">
                Enter the forest
              </a>
              <a className="text-link" href="#field-notes">
                Browse field notes
              </a>
            </div>
          </div>
        </section>

        <ForestJourney />

        <section className="statement" aria-labelledby="statement-title">
          <div className="statement__inner container">
            <h2 id="statement-title">Nothing in a forest lives alone.</h2>
            <div className="statement__aside">
              <p>
                Light becomes shelter. Rain becomes a route. Fallen leaves become
                ground for what comes next.
              </p>
              <a className="text-link" href="#field-notes">
                Read the field notes
              </a>
            </div>
          </div>
        </section>

        <FieldNotes />

        <section className="closing" id="close" aria-labelledby="closing-title">
          <img
            className="closing__image"
            src={forestImages.lake}
            alt="A still lake reflecting a pine forest and mountain ridgeline."
            width="1920"
            height="1280"
            loading="lazy"
          />
          <div className="closing__shade" aria-hidden="true" />
          <div className="closing__content container">
            <h2 id="closing-title">Life moves beyond the tree line.</h2>
            <p>Follow water, weather and life into the wider landscape.</p>
            <a className="button button--primary" href="#field-notes">
              Keep exploring
            </a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container">
          <div className="site-footer__mast">
            <a className="site-footer__wordmark" href="#top" aria-label="Mori, back to top">
              MORI
            </a>
            <p>A field atlas for looking closer at the living world.</p>
          </div>
          <div className="site-footer__bottom">
            <nav aria-label="Footer navigation">
              <a href="#journey">The descent</a>
              <a href="#field-notes">Field notes</a>
              <a href="#top">Back to top</a>
            </nav>
            <FooterCredits />
          </div>
        </div>
      </footer>
    </div>
  );
}