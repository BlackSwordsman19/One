import React, { useEffect, useRef, useState } from 'react';
import { natureAudio, type StemLevels } from './audio/natureAudio';
import { ForestTerrain3D, type ShaderLayer } from './components/ForestTerrain3D';
import { FanalStageShowDemo } from './components/FanalStageShowDemo';

interface StationRecord {
  id: string;
  name: string;
  elevation: string;
  stratum: string;
  dripRate: string;
  dominantBand: string;
  preset: StemLevels;
  defaultLayer: ShaderLayer;
}

const STATIONS: StationRecord[] = [
  {
    id: 'fanal-north',
    name: 'Fanal Ridge North',
    elevation: '1,150 m',
    stratum: 'Cloud canopy',
    dripRate: '4.20 mm/hr',
    dominantBand: '420 Hz foliar mist',
    preset: { rain: 68, wind: 42, stream: 24 },
    defaultLayer: 'canopy',
  },
  {
    id: 'laurel-hollow',
    name: 'Ribeira da Janela Hollow',
    elevation: '840 m',
    stratum: 'Epiphyte understory',
    dripRate: '5.40 mm/hr',
    dominantBand: '610 Hz canopy drip',
    preset: { rain: 82, wind: 28, stream: 52 },
    defaultLayer: 'canopy',
  },
  {
    id: 'paul-basin',
    name: 'Paul da Serra Basin',
    elevation: '1,390 m',
    stratum: 'Trade-wind crest',
    dripRate: '3.10 mm/hr',
    dominantBand: '195 Hz ridge gale',
    preset: { rain: 36, wind: 86, stream: 18 },
    defaultLayer: 'watershed',
  },
  {
    id: 'cedros-levada',
    name: 'Levada dos Cedros',
    elevation: '920 m',
    stratum: 'Basalt ravine',
    dripRate: '4.85 mm/hr',
    dominantBand: '540 Hz chute flow',
    preset: { rain: 54, wind: 30, stream: 88 },
    defaultLayer: 'watershed',
  },
  {
    id: 'ruivo-aquifer',
    name: 'Pico Ruivo Basal Spring',
    elevation: '640 m',
    stratum: 'Volcanic aquifer',
    dripRate: '6.10 mm/hr',
    dominantBand: '160 Hz basalt spring',
    preset: { rain: 25, wind: 18, stream: 94 },
    defaultLayer: 'subsoil',
  },
];

interface WeatherCycle {
  id: string;
  label: string;
  summary: string;
  curveRain: string;
  curveWind: string;
  curveStream: string;
  rows: { title: string; note: string; figure: string }[];
}

const WEATHER_CYCLES: WeatherCycle[] = [
  {
    id: 'trade-fog',
    label: 'Trade-wind fog',
    summary: 'Atlantic cloud banks ground against the 1,150 m laurel ridge from midnight until dawn.',
    curveRain: 'M 0 88 C 140 82, 260 28, 420 22 C 560 18, 680 54, 800 76',
    curveWind: 'M 0 96 C 160 74, 300 58, 460 52 C 600 48, 700 82, 800 94',
    curveStream: 'M 0 118 C 180 112, 340 86, 520 64 C 660 58, 740 70, 800 78',
    rows: [
      {
        title: 'Canopy rain',
        note: 'Horizontal fog combing through Ocotea foetens leaves.',
        figure: '68',
      },
      {
        title: 'Ridge wind',
        note: 'Steady north-east trade flow across twisted trunks.',
        figure: '42',
      },
      {
        title: 'Granite stream',
        note: 'Delayed percolation reaching the basal basalt channels.',
        figure: '24',
      },
    ],
  },
  {
    id: 'atlantic-front',
    label: 'Winter squall',
    summary: 'Low-pressure cells drive heavy orographic rain across the northern amphitheatre.',
    curveRain: 'M 0 38 C 140 18, 280 14, 440 20 C 580 28, 700 42, 800 56',
    curveWind: 'M 0 44 C 160 22, 310 16, 480 28 C 620 40, 720 58, 800 66',
    curveStream: 'M 0 84 C 180 58, 340 32, 520 24 C 660 22, 740 30, 800 36',
    rows: [
      {
        title: 'Canopy rain',
        note: 'Direct rainfall saturating epiphyte mats within twenty minutes.',
        figure: '92',
      },
      {
        title: 'Ridge wind',
        note: 'Gust fronts cresting Paul da Serra at forty knots.',
        figure: '78',
      },
      {
        title: 'Granite stream',
        note: 'Rapid runoff filling the Ribeira da Janela gorge.',
        figure: '85',
      },
    ],
  },
  {
    id: 'summer-inversion',
    label: 'Dry inversion',
    summary: 'Warm air above 1,200 m traps cool moisture inside the moss floor while the ridge stays still.',
    curveRain: 'M 0 112 C 140 108, 280 96, 440 88 C 580 94, 700 110, 800 118',
    curveWind: 'M 0 122 C 160 118, 310 114, 480 110 C 620 116, 720 120, 800 124',
    curveStream: 'M 0 92 C 180 94, 340 96, 520 98 C 660 100, 740 102, 800 104',
    rows: [
      {
        title: 'Canopy rain',
        note: 'Light dewfall condensing on lichen tips before sunrise.',
        figure: '19',
      },
      {
        title: 'Ridge wind',
        note: 'Near-silent thermal drift between hollow and crest.',
        figure: '14',
      },
      {
        title: 'Granite stream',
        note: 'Deep basalt springs holding steady baseflow all night.',
        figure: '64',
      },
    ],
  },
];

const STRATA_CHAPTERS = [
  {
    index: 0,
    heading: 'Cloud canopy at 1,150 metres',
    elevation: '1,150 m',
    metric: '4.2 mm/hr foliar drip',
    body: 'Ancient stink-laurel crowns comb liquid water straight from passing Atlantic cloud banks, doubling annual precipitation beneath the boughs.',
    layer: 'canopy' as ShaderLayer,
  },
  {
    index: 1,
    heading: 'Epiphyte cushion at 980 metres',
    elevation: '980 m',
    metric: '380% moss water retention',
    body: 'Beard lichens and bryophyte sleeves wrap every branch, buffering sudden squalls and releasing cool mist over twelve hours.',
    layer: 'canopy' as ShaderLayer,
  },
  {
    index: 2,
    heading: 'Basalt humus at 640 metres',
    elevation: '640 m',
    metric: '11.4 °C soil horizon',
    body: 'Saprotrophic mycelium threads bind volcanic ash and fallen laurel leaves, filtering rainwater before it reaches the rock.',
    layer: 'subsoil' as ShaderLayer,
  },
  {
    index: 3,
    heading: 'Volcanic aquifer at 310 metres',
    elevation: '310 m',
    metric: '68 L/s basal spring flow',
    body: 'Percolated mist emerges through fractured basalt dykes, feeding cold gravity channels across the northern valleys.',
    layer: 'watershed' as ShaderLayer,
  },
];

export function App() {
  const [levels, setLevels] = useState<StemLevels>({ rain: 68, wind: 42, stream: 24 });
  const [decayMinutes, setDecayMinutes] = useState<number>(45);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [shaderLayer, setShaderLayer] = useState<ShaderLayer>('canopy');
  const [activeStratum, setActiveStratum] = useState<number>(0);
  const [selectedStation, setSelectedStation] = useState<number>(0);
  const [activeCycle, setActiveCycle] = useState<number>(0);
  const [scrollProgress, setScrollProgress] = useState<number>(0);
  const [lasDownloaded, setLasDownloaded] = useState<boolean>(false);

  const stratumRefs = useRef<(HTMLElement | null)[]>([]);
  const draggingFaderRef = useRef<{ key: keyof StemLevels | null; rect: DOMRect | null }>({
    key: null,
    rect: null,
  });

  // Reveal observer (craft.md § 5 + patterns.md)
  useEffect(() => {
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-in');
            io.unobserve(entry.target);
          }
        });
      },
      { rootMargin: '0px 0px -10% 0px' }
    );
    document.querySelectorAll('[data-reveal]').forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  // Scroll listener for 3D stratum transect and global progress
  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      requestAnimationFrame(() => {
        const docH = document.documentElement.scrollHeight - window.innerHeight;
        const p = docH > 0 ? Math.max(0, Math.min(1, window.scrollY / docH)) : 0;
        setScrollProgress(p);

        // Check which stratum card is closest to viewport center
        const midY = window.innerHeight * 0.45;
        let bestIdx = 0;
        let bestDist = Infinity;
        stratumRefs.current.forEach((el, idx) => {
          if (!el) return;
          const r = el.getBoundingClientRect();
          const center = r.top + r.height / 2;
          const dist = Math.abs(center - midY);
          if (dist < bestDist) {
            bestDist = dist;
            bestIdx = idx;
          }
        });
        if (bestDist < window.innerHeight * 0.7) {
          setActiveStratum(bestIdx);
        }
        ticking = false;
      });
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  // Esc key stops audio per ribbon.md Controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isPlaying) {
        natureAudio.stop();
        setIsPlaying(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [isPlaying]);

  const toggleAudio = () => {
    if (isPlaying) {
      natureAudio.stop();
      setIsPlaying(false);
    } else {
      const ok = natureAudio.start(levels);
      setIsPlaying(ok);
    }
  };

  const updateStem = (key: keyof StemLevels, nextVal: number) => {
    const clamped = Math.max(0, Math.min(100, Math.round(nextVal)));
    setLevels((prev) => {
      const updated = { ...prev, [key]: clamped };
      if (isPlaying) natureAudio.setLevels(updated);
      return updated;
    });
  };

  const handleFaderPointerDown = (key: keyof StemLevels, e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    draggingFaderRef.current = { key, rect };
    e.currentTarget.setPointerCapture(e.pointerId);
    const ratio = 1 - (e.clientY - rect.top) / rect.height;
    updateStem(key, ratio * 100);
  };

  const handleFaderPointerMove = (key: keyof StemLevels, e: React.PointerEvent<HTMLDivElement>) => {
    const d = draggingFaderRef.current;
    if (d.key !== key || !d.rect) return;
    const ratio = 1 - (e.clientY - d.rect.top) / d.rect.height;
    updateStem(key, ratio * 100);
  };

  const handleFaderPointerUp = () => {
    draggingFaderRef.current = { key: null, rect: null };
  };

  const handleFaderKeyDown = (key: keyof StemLevels, e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowUp' || e.key === 'ArrowRight') {
      e.preventDefault();
      updateStem(key, levels[key] + 5);
    } else if (e.key === 'ArrowDown' || e.key === 'ArrowLeft') {
      e.preventDefault();
      updateStem(key, levels[key] - 5);
    } else if (e.key === 'Home') {
      e.preventDefault();
      updateStem(key, 0);
    } else if (e.key === 'End') {
      e.preventDefault();
      updateStem(key, 100);
    }
  };

  const handleSelectStation = (idx: number) => {
    const st = STATIONS[idx];
    if (!st) return;
    setSelectedStation(idx);
    setLevels(st.preset);
    setShaderLayer(st.defaultLayer);
    if (isPlaying) {
      natureAudio.setLevels(st.preset);
    }
  };

  const handleDownloadLasPack = () => {
    const st = STATIONS[selectedStation] || STATIONS[0];
    const sampleGeo = {
      observatory: 'Sylva Fanal 3D Field Observatory',
      station: st.name,
      elevation: st.elevation,
      stratum: st.stratum,
      dripRate: st.dripRate,
      stems: levels,
      coordinates: { lat: 32.8084, lon: -17.1419, crs: 'EPSG:4326' },
    };
    const blob = new Blob([JSON.stringify(sampleGeo, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${st.id}-lidar-telemetry.json`;
    a.click();
    URL.revokeObjectURL(url);
    setLasDownloaded(true);
  };

  const currentCycle = WEATHER_CYCLES[activeCycle] || WEATHER_CYCLES[0];

  return (
    <div>
      <a className="skip" href="#main">
        Skip to content
      </a>

      {/* Masthead Navigation (layout.md § 7) */}
      <header className="masthead">
        <div className="container masthead__inner">
          <a href="#top" className="masthead__brand" aria-label="Sylva home">
            Sylva
          </a>
          <nav aria-label="Primary">
            <ul className="masthead__links">
              <li>
                <a className="masthead__link" href="#transect">
                  3D strata
                </a>
              </li>
              <li>
                <a className="masthead__link" href="#telemetry">
                  Telemetry
                </a>
              </li>
              <li>
                <a className="masthead__link" href="#horizon">
                  Night curve
                </a>
              </li>
              <li>
                <a className="masthead__link" href="#stations">
                  Stations
                </a>
              </li>
              <li>
                <button
                  type="button"
                  className="btn btn--quiet"
                  onClick={toggleAudio}
                  aria-pressed={isPlaying}
                >
                  {isPlaying ? 'Stop audio' : 'Listen live'}
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </header>

      <main id="main">
        {/* SECTION 1: Hero (Stage posture, layout.md § 6) */}
        <section id="top" className="hero-section">
          <div className="container hero-grid">
            <div className="hero-copy" data-reveal style={{ '--i': 0 } as React.CSSProperties}>
              <h1>Listen to the mountain after dark.</h1>
              <p className="lead">
                Live 3D lidar topography and field hydrophones from Fanal Forest, streamed hourly.
              </p>
              <div className="hero-actions">
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={toggleAudio}
                  aria-pressed={isPlaying}
                >
                  {isPlaying ? 'Stop soundscape' : 'Listen live'}
                </button>
                <a className="btn" href="#transect">
                  Explore the ridge
                </a>
              </div>
            </div>

            {/* Hero Stage Slot: Interactive 3D LiDAR Ridge + Machined 3-Stem Mixer */}
            <div
              className="hero-stage-slot"
              data-slot="hero"
              data-kind="product"
              data-alt="Interactive 3D LiDAR point cloud of Fanal Ridge with machined three-channel acoustic faders"
              data-reveal
              style={{ '--i': 1 } as React.CSSProperties}
            >
              {/* Top Instrument Header & 3D Shader Mode Switcher */}
              <div
                className="flex flex-wrap items-center justify-between"
                style={{ gap: 'var(--space-sm)' }}
              >
                <div className="flex items-center" style={{ gap: 'var(--space-sm)' }}>
                  <span style={{ fontWeight: 500, color: 'var(--color-ink)' }}>Tonight</span>
                  <span className="meta-label">
                    {STATIONS[selectedStation]?.name}, {STATIONS[selectedStation]?.elevation}
                  </span>
                </div>
                <div className="seg" role="group" aria-label="3D terrain shader layer">
                  {(['canopy', 'watershed', 'subsoil'] as ShaderLayer[]).map((m) => (
                    <button
                      key={m}
                      type="button"
                      aria-selected={shaderLayer === m}
                      onClick={() => setShaderLayer(m)}
                      style={{ minHeight: '36px', padding: '0 var(--space-sm)' }}
                    >
                      {m === 'canopy' ? 'Canopy' : m === 'watershed' ? 'Watershed' : 'Subsoil'}
                    </button>
                  ))}
                </div>
              </div>

              {/* Live Three.js 3D Viewport */}
              <ForestTerrain3D
                variant="hero"
                levels={levels}
                layer={shaderLayer}
                activeStratum={activeStratum}
                stationIndex={selectedStation}
                scrollProgress={scrollProgress}
              />

              {/* Machined Vertical Faders + Decay Envelope Curve (ribbon.md Surfaces) */}
              <div
                className="grid"
                style={{
                  gridTemplateColumns: 'minmax(0, 7fr) minmax(0, 5fr)',
                  gap: 'var(--space-md)',
                  alignItems: 'stretch',
                }}
              >
                <div className="recessed-bed fader-grid">
                  {(
                    [
                      { key: 'rain', label: 'Canopy rain' },
                      { key: 'wind', label: 'Ridge wind' },
                      { key: 'stream', label: 'Granite stream' },
                    ] as const
                  ).map(({ key, label }) => {
                    const val = levels[key];
                    const capBottom = `calc(${val}% - 11px)`;
                    return (
                      <div key={key} className="fader-channel">
                        <span className="code-token">{val}</span>
                        <div
                          className="fader-track"
                          role="slider"
                          tabIndex={0}
                          aria-label={label}
                          aria-valuemin={0}
                          aria-valuemax={100}
                          aria-valuenow={val}
                          onPointerDown={(e) => handleFaderPointerDown(key, e)}
                          onPointerMove={(e) => handleFaderPointerMove(key, e)}
                          onPointerUp={handleFaderPointerUp}
                          onPointerCancel={handleFaderPointerUp}
                          onKeyDown={(e) => handleFaderKeyDown(key, e)}
                        >
                          <div className="fader-fill" style={{ height: `${val}%` }} />
                          <div className="fader-cap" style={{ bottom: capBottom }}>
                            <span className="fader-cap__index" />
                          </div>
                        </div>
                        <span className="meta-label">{label}</span>
                      </div>
                    );
                  })}
                </div>

                {/* Draggable Envelope Decay & Listen Trigger */}
                <div
                  className="recessed-bed flex flex-col justify-between"
                  style={{ padding: 'var(--space-sm) var(--space-md)', gap: 'var(--space-xs)' }}
                >
                  <div className="flex items-center justify-between">
                    <span className="meta-label">Fade out</span>
                    <span className="code-token">in {decayMinutes} min</span>
                  </div>

                  <svg
                    className="chart-diagram w-full"
                    aria-label="Soundscape fade envelope curve"
                    viewBox="0 0 200 58"
                    style={{ height: '58px' }}
                  >
                    <line
                      x1="0"
                      y1="48"
                      x2="200"
                      y2="48"
                      stroke="var(--color-rule)"
                      strokeWidth="1"
                    />
                    <path
                      d={`M 0 14 L ${Math.round((decayMinutes / 90) * 110)} 14 C ${Math.round(
                        (decayMinutes / 90) * 145
                      )} 14, ${Math.round((decayMinutes / 90) * 155)} 46, ${Math.round(
                        (decayMinutes / 90) * 185
                      )} 46 L 200 46`}
                      fill="none"
                      stroke="var(--color-accent)"
                      strokeWidth="1.75"
                    />
                    <circle
                      cx={Math.round((decayMinutes / 90) * 150)}
                      cy="30"
                      r="5"
                      fill="var(--metal-hi)"
                      stroke="var(--color-accent)"
                      strokeWidth="1.5"
                    />
                    <text x="4" y="42" fill="var(--color-muted)" fontSize="10">
                      Now
                    </text>
                    <text x="164" y="42" fill="var(--color-muted)" fontSize="10">
                      90 min
                    </text>
                  </svg>

                  <div className="flex items-center justify-between" style={{ gap: 'var(--space-xs)' }}>
                    {[30, 45, 90].map((mins) => (
                      <button
                        key={mins}
                        type="button"
                        className="btn btn--quiet"
                        onClick={() => setDecayMinutes(mins)}
                        aria-pressed={decayMinutes === mins}
                        style={{
                          minHeight: '34px',
                          padding: '0 var(--space-sm)',
                          fontSize: 'var(--text-xs)',
                          flex: 1,
                        }}
                      >
                        {mins}&nbsp;m
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 2: Scroll-Driven 3D Elevation Transect (Sticky Diptych, scroll-choreography.md § 4) */}
        <section id="transect" className="section-block--wide">
          <div className="container">
            <div className="head-block">
              <h2>Four strata from cloud to basalt.</h2>
              <p className="lead">
                Scroll down the ridge profile to slice the 3D point cloud from the 1,150 m canopy down to the volcanic springs.
              </p>
            </div>

            <div className="sticky-stack">
              {/* Left Sticky 3D Core */}
              <div className="pane-sticky">
                <div
                  className="panel"
                  style={{
                    padding: 'var(--space-lg)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--space-md)',
                  }}
                >
                  <div
                    className="flex flex-wrap items-center justify-between"
                    style={{ gap: 'var(--space-sm)' }}
                  >
                    <span style={{ fontWeight: 500, color: 'var(--color-ink)' }}>
                      Vertical lidar transect
                    </span>
                    <div className="seg" role="tablist" aria-label="Select forest elevation stratum">
                      {STRATA_CHAPTERS.map((ch) => (
                        <button
                          key={ch.index}
                          type="button"
                          role="tab"
                          aria-selected={activeStratum === ch.index}
                          onClick={() => {
                            setActiveStratum(ch.index);
                            setShaderLayer(ch.layer);
                          }}
                          style={{ minHeight: '36px', padding: '0 var(--space-sm)' }}
                        >
                          {ch.elevation}
                        </button>
                      ))}
                    </div>
                  </div>

                  <ForestTerrain3D
                    variant="transect"
                    levels={levels}
                    layer={STRATA_CHAPTERS[activeStratum]?.layer || shaderLayer}
                    activeStratum={activeStratum}
                    stationIndex={selectedStation}
                    scrollProgress={scrollProgress}
                  />
                </div>
              </div>

              {/* Right Scrolling Strata Chapters + Verified Library Photograph */}
              <div className="pane-scroll">
                {STRATA_CHAPTERS.map((ch) => (
                  <article
                    key={ch.index}
                    ref={(el) => {
                      stratumRefs.current[ch.index] = el;
                    }}
                    className="stratum-card"
                    data-active={activeStratum === ch.index}
                    onClick={() => {
                      setActiveStratum(ch.index);
                      setShaderLayer(ch.layer);
                    }}
                  >
                    <h3>{ch.heading}</h3>
                    <p>{ch.body}</p>
                    <div
                      className="flex flex-wrap items-center justify-between"
                      style={{
                        paddingTop: 'var(--space-sm)',
                        borderTop: 'var(--rule-hair) solid var(--color-rule)',
                        gap: 'var(--space-sm)',
                      }}
                    >
                      <span className="display-figure display-figure--accent" style={{ fontSize: 'var(--text-xl)' }}>
                        {ch.elevation}
                      </span>
                      <span className="meta-label">{ch.metric}</span>
                    </div>
                  </article>
                ))}

                {/* Verified Wikimedia Commons Photograph 1 (theme.mjs photos) */}
                <div>
                  <figure
                    className="photo"
                    data-slot="photo-fanal"
                    data-alt="Raindrops condensing on the observatory glass above the dark laurel ridge"
                  >
                    <img
                      src="https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Bokeh_raindrops_on_a_window_1.jpg/1280px-Bokeh_raindrops_on_a_window_1.jpg"
                      srcSet="https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Bokeh_raindrops_on_a_window_1.jpg/960px-Bokeh_raindrops_on_a_window_1.jpg 960w, https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Bokeh_raindrops_on_a_window_1.jpg/1280px-Bokeh_raindrops_on_a_window_1.jpg 1280w, https://upload.wikimedia.org/wikipedia/commons/thumb/0/01/Bokeh_raindrops_on_a_window_1.jpg/1920px-Bokeh_raindrops_on_a_window_1.jpg 1920w"
                      sizes="(min-width: 60rem) 42vw, 100vw"
                      width={3283}
                      height={4385}
                      alt="Out of focus raindrops on a window glowing with warm night lights"
                      loading="lazy"
                    />
                  </figure>
                  <p className="caption">
                    Trade-wind condensation recorded at the 1,150 metre ridge shelter after midnight.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SECTION 3: StageShow Choreographed Field Telemetry Demo (Split Studio, benjitaylor/skills) */}
        <section id="telemetry" className="section-band">
          <div className="container split-row">
            <div className="flex flex-col" style={{ gap: 'var(--space-lg)' }}>
              <h2>Scrub the overnight condensation curve.</h2>
              <p className="lead">
                Every ridge sensor logs foliar drip and acoustic spectra in fifteen-minute frames.
              </p>
              <p>
                Watch the field workbench isolate the 03:00 UTC trade-wind burst at Laurel Hollow and tag the hydrophone packet for export.
              </p>
            </div>

            <FanalStageShowDemo />
          </div>
        </section>

        {/* SECTION 4: Switcher & Drawn Curve over Ruled Rows (layout.md § 5 Switcher + Rows, ribbon.md Range) */}
        <section id="horizon" className="section-block">
          <div className="container">
            <div className="head-block">
              <div>
                <h2>Three stems across the dark hours.</h2>
                <p className="lead" style={{ marginTop: 'var(--space-md)' }}>
                  Each weather state shifts how rain, wind, and basal water share the acoustic spectrum.
                </p>
              </div>
              <div className="flex justify-start md:justify-end">
                <div className="seg" role="tablist" aria-label="Weather state">
                  {WEATHER_CYCLES.map((wc, idx) => (
                    <button
                      key={wc.id}
                      type="button"
                      role="tab"
                      aria-selected={activeCycle === idx}
                      onClick={() => setActiveCycle(idx)}
                    >
                      {wc.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Time as a drawn curve (ribbon.md Range) */}
            <div
              className="panel"
              style={{
                padding: 'var(--space-xl)',
                marginBottom: 'var(--space-2xl)',
                display: 'flex',
                flexDirection: 'column',
                gap: 'var(--space-md)',
              }}
            >
              <p style={{ color: 'var(--color-ink)' }}>{currentCycle.summary}</p>
              <svg
                className="chart-diagram w-full"
                aria-label="Twelve-hour acoustic stem curve across the night"
                viewBox="0 0 800 148"
                style={{ height: '164px' }}
              >
                <line x1="0" y1="132" x2="800" y2="132" stroke="var(--color-rule)" strokeWidth="1" />
                <line x1="200" y1="12" x2="200" y2="132" stroke="var(--color-rule-2)" strokeWidth="1" />
                <line x1="400" y1="12" x2="400" y2="132" stroke="var(--color-rule-2)" strokeWidth="1" />
                <line x1="600" y1="12" x2="600" y2="132" stroke="var(--color-rule-2)" strokeWidth="1" />

                <path
                  d={currentCycle.curveRain}
                  fill="none"
                  stroke="var(--color-accent)"
                  strokeWidth="2.2"
                />
                <path
                  d={currentCycle.curveWind}
                  fill="none"
                  stroke="var(--color-canopy)"
                  strokeWidth="1.6"
                />
                <path
                  d={currentCycle.curveStream}
                  fill="none"
                  stroke="var(--color-water)"
                  strokeWidth="1.6"
                />

                <text x="8" y="144" fill="var(--color-muted)" fontSize="11">
                  20:00 UTC
                </text>
                <text x="208" y="144" fill="var(--color-muted)" fontSize="11">
                  23:00 UTC
                </text>
                <text x="408" y="144" fill="var(--color-muted)" fontSize="11">
                  02:00 UTC
                </text>
                <text x="608" y="144" fill="var(--color-muted)" fontSize="11">
                  05:00 UTC
                </text>
                <text x="740" y="144" fill="var(--color-muted)" fontSize="11">
                  08:00 UTC
                </text>
              </svg>
            </div>

            {/* Ruled Rows of Stem Levels (ribbon.md Range) */}
            <div className="level-rows">
              {currentCycle.rows.map((r) => (
                <div key={r.title} className="level-row">
                  <h3>{r.title}</h3>
                  <p>{r.note}</p>
                  <div className="flex md:justify-end">
                    <span
                      className="display-figure display-figure--accent"
                      style={{ fontSize: 'var(--text-3xl)' }}
                    >
                      {r.figure}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* SECTION 5: Showcase Photograph (layout.md § 5 Showcase + imagery.md § 2) */}
        <section className="section-block--tight">
          <div className="container">
            <div className="head-stack">
              <h2>Waterfalls cut the basalt ravines.</h2>
              <p className="lead">
                Subsurface hydrophones sit thirty centimetres below the plunge pools to record low-frequency stone resonance.
              </p>
            </div>

            <figure
              className="photo--wide"
              data-slot="photo-falls"
              data-alt="River in morning fog with reeds and soft trees along the bank"
            >
              <img
                src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Desna_river_Vinn_meadow_2016_G9.jpg/1280px-Desna_river_Vinn_meadow_2016_G9.jpg"
                srcSet="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Desna_river_Vinn_meadow_2016_G9.jpg/960px-Desna_river_Vinn_meadow_2016_G9.jpg 960w, https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Desna_river_Vinn_meadow_2016_G9.jpg/1280px-Desna_river_Vinn_meadow_2016_G9.jpg 1280w, https://upload.wikimedia.org/wikipedia/commons/thumb/c/c9/Desna_river_Vinn_meadow_2016_G9.jpg/1920px-Desna_river_Vinn_meadow_2016_G9.jpg 1920w"
                sizes="100vw"
                width={6000}
                height={3850}
                alt="River in morning fog with reeds and soft trees along the bank"
                loading="lazy"
              />
            </figure>
            <p className="caption">
              Subsurface hydrophones capture 160 Hz to 880 Hz water resonance as mist settles into the valley basin.
            </p>
          </div>
        </section>

        {/* SECTION 6: Full-width Station Table & Open-Data Close (layout.md § 5 Table + anatomy.md § try) */}
        <section id="stations" className="section-block">
          <div className="container">
            <div className="head-block">
              <h2>Five ridge stations streaming tonight.</h2>
              <p className="lead">
                Load any station into the 3D observatory or download its raw lidar and hydrophone packet.
              </p>
            </div>

            <div className="station-table-wrap">
              <table className="station-table">
                <thead>
                  <tr>
                    <th scope="col">Station</th>
                    <th scope="col">Elevation</th>
                    <th scope="col">Stratum</th>
                    <th scope="col">Foliar drip</th>
                    <th scope="col">Acoustic band</th>
                    <th scope="col">Observatory</th>
                  </tr>
                </thead>
                <tbody>
                  {STATIONS.map((st, idx) => {
                    const isSel = selectedStation === idx;
                    return (
                      <tr key={st.id} data-selected={isSel}>
                        <td>{st.name}</td>
                        <td className="num">{st.elevation}</td>
                        <td>{st.stratum}</td>
                        <td className="num">{st.dripRate}</td>
                        <td>{st.dominantBand}</td>
                        <td>
                          <button
                            type="button"
                            className="btn btn--quiet"
                            onClick={() => {
                              handleSelectStation(idx);
                              window.scrollTo({ top: 0, behavior: 'smooth' });
                            }}
                          >
                            {isSel ? 'Loaded in 3D' : 'Load station'}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Close on the job's action: download the 3D LiDAR + telemetry pack (anatomy.md § try) */}
            <div
              className="panel"
              style={{
                marginTop: 'var(--space-3xl)',
                padding: 'var(--space-xl)',
                display: 'flex',
                flexWrap: 'wrap',
                alignItems: 'center',
                justifyContent: 'space-between',
                gap: 'var(--space-lg)',
              }}
            >
              <div className="flex flex-col" style={{ gap: 'var(--space-xs)' }}>
                <h3>Take the raw Fanal ridge packet offline.</h3>
                <p>
                  Includes the 1,150 m point cloud coordinates and calibrated stem levels for{' '}
                  {STATIONS[selectedStation]?.name}.
                </p>
              </div>
              <div className="flex flex-wrap items-center" style={{ gap: 'var(--space-md)' }}>
                <button
                  type="button"
                  className="btn btn--primary"
                  onClick={handleDownloadLasPack}
                >
                  {lasDownloaded ? 'Packet downloaded' : 'Download telemetry JSON'}
                </button>
                <button type="button" className="btn" onClick={toggleAudio}>
                  {isPlaying ? 'Stop audio' : 'Listen live'}
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Colophon Footer (layout.md § 7 + imagery.md § 2 credits) */}
      <footer className="colophon">
        <div className="container colophon__grid">
          <div className="flex flex-col" style={{ gap: 'var(--space-sm)' }}>
            <a href="#top" className="masthead__brand">
              Sylva
            </a>
            <p className="meta-label">
              Fanal Forest 3D LiDAR and acoustic biosphere observatory, Madeira Archipelago (32.8084° N, 17.1419° W). Next on-site hydrophone calibration:{' '}
              <span className="fill" data-fill="calibration-date">
                autumn calibration date to be announced
              </span>
              .
            </p>
            <p className="meta-label" data-credits>
              Photographs:{' '}
              <a href="https://commons.wikimedia.org/wiki/File:Bokeh_raindrops_on_a_window_1.jpg">
                W.carter
              </a>{' '}
              (CC0, Wikimedia Commons),{' '}
              <a href="https://commons.wikimedia.org/wiki/File:Desna_river_Vinn_meadow_2016_G9.jpg">
                George Chernilevsky
              </a>{' '}
              (Public domain, Wikimedia Commons).
            </p>
          </div>

          <div
            className="flex flex-wrap md:justify-end"
            style={{ gap: 'var(--space-lg)' }}
          >
            <a className="masthead__link" href="#top">
              Observatory
            </a>
            <a className="masthead__link" href="#transect">
              3D strata
            </a>
            <a className="masthead__link" href="#telemetry">
              Telemetry
            </a>
            <a className="masthead__link" href="#stations">
              Stations
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
