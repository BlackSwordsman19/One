import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import type { StemLevels } from '../audio/natureAudio';

export type ShaderLayer = 'canopy' | 'watershed' | 'subsoil';

export interface ForestTerrain3DProps {
  variant: 'hero' | 'transect';
  levels: StemLevels;
  layer: ShaderLayer;
  activeStratum: number; // 0..3
  stationIndex: number;  // 0..4
  scrollProgress?: number; // 0..1
  onSelectStratum?: (idx: number) => void;
}

const STATION_SEEDS = [
  { name: 'Fanal Ridge North', elev: '1,150 m', freq: '420 Hz', ridgeScale: 1.0, valleyDepth: 0.55 },
  { name: 'Ribeira da Janela', elev: '840 m', freq: '610 Hz', ridgeScale: 1.22, valleyDepth: 0.85 },
  { name: 'Paul da Serra Basin', elev: '1,390 m', freq: '195 Hz', ridgeScale: 0.68, valleyDepth: 0.25 },
  { name: 'Levada dos Cedros', elev: '920 m', freq: '540 Hz', ridgeScale: 1.1, valleyDepth: 0.7 },
  { name: 'Pico Ruivo Crest', elev: '1,862 m', freq: '160 Hz', ridgeScale: 1.45, valleyDepth: 0.4 },
];

const STRATA_META = [
  { id: 0, title: '1,150 m Cloud Canopy', metric: '4.2 mm/hr foliar drip', ySlice: 0.9 },
  { id: 1, title: '980 m Epiphyte Understory', metric: '380% bryophyte saturation', ySlice: 0.35 },
  { id: 2, title: '640 m Basalt Litter', metric: '11.4 °C hyphal soil horizon', ySlice: -0.2 },
  { id: 3, title: '310 m Volcanic Aquifer', metric: '68 L/s levada spring discharge', ySlice: -0.75 },
];

function computeElevation(x: number, z: number, ridgeScale: number, valleyDepth: number): number {
  const r1 = Math.sin(x * 0.65) * Math.cos(z * 0.55) * 0.85 * ridgeScale;
  const r2 = Math.sin(x * 1.45 + z * 0.9) * 0.32 * ridgeScale;
  const r3 = Math.cos(Math.sqrt(x * x + z * z) * 1.2) * 0.28;
  const gully = -Math.exp(-(x * x * 0.45)) * valleyDepth;
  return r1 + r2 + r3 + gully;
}

export const ForestTerrain3D: React.FC<ForestTerrain3DProps> = ({
  variant,
  levels,
  layer,
  activeStratum,
  stationIndex,
  scrollProgress = 0,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [paused, setPaused] = useState<boolean>(() =>
    typeof window !== 'undefined' ? window.matchMedia('(prefers-reduced-motion: reduce)').matches : false
  );
  const [webglReady, setWebglReady] = useState<boolean>(true);
  const [yawPitch, setYawPitch] = useState<{ yaw: number; pitch: number }>({ yaw: 0.42, pitch: 0.52 });
  const dragRef = useRef<{ active: boolean; startX: number; startY: number; baseYaw: number; basePitch: number }>({
    active: false,
    startX: 0,
    startY: 0,
    baseYaw: 0.42,
    basePitch: 0.52,
  });

  const stateRef = useRef({
    levels,
    layer,
    activeStratum,
    stationIndex,
    scrollProgress,
    paused,
    yawPitch,
  });

  useEffect(() => {
    stateRef.current = {
      levels,
      layer,
      activeStratum,
      stationIndex,
      scrollProgress,
      paused,
      yawPitch,
    };
  }, [levels, layer, activeStratum, stationIndex, scrollProgress, paused, yawPitch]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch {
      setWebglReady(false);
      return;
    }

    const width = Math.max(300, container.clientWidth);
    const height = Math.max(240, container.clientHeight);
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    container.innerHTML = '';
    renderer.domElement.setAttribute('aria-label', 'Interactive 3D LiDAR elevation model of Fanal Laurel Forest');
    renderer.domElement.setAttribute('role', 'img');
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(38, width / height, 0.1, 100);
    camera.position.set(3.2, 2.5, 4.4);
    camera.lookAt(0, 0, 0);

    // Subtle directional + ambient lighting
    const ambient = new THREE.AmbientLight(new THREE.Color().setHSL(0.6, 0.25, 0.55), 0.9);
    scene.add(ambient);

    const sunLight = new THREE.DirectionalLight(new THREE.Color().setHSL(0.1, 0.75, 0.78), 1.6);
    sunLight.position.set(4, 6, 3);
    scene.add(sunLight);

    // 1. Topographic Wireframe & Shaded Ridge Mesh
    const segs = variant === 'hero' ? 64 : 56;
    const planeGeo = new THREE.PlaneGeometry(5.2, 5.2, segs, segs);
    planeGeo.rotateX(-Math.PI / 2);

    const posAttr = planeGeo.attributes.position;
    const colors: number[] = [];
    for (let i = 0; i < posAttr.count; i++) {
      colors.push(0.85, 0.72, 0.45);
    }
    planeGeo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const surfaceMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      roughness: 0.78,
      metalness: 0.12,
      transparent: true,
      opacity: 0.86,
      side: THREE.DoubleSide,
    });
    const terrainMesh = new THREE.Mesh(planeGeo, surfaceMat);
    scene.add(terrainMesh);

    const wireMat = new THREE.MeshBasicMaterial({
      vertexColors: true,
      wireframe: true,
      transparent: true,
      opacity: 0.36,
    });
    const wireMesh = new THREE.Mesh(planeGeo, wireMat);
    wireMesh.position.y = 0.006;
    scene.add(wireMesh);

    // 2. LiDAR Canopy Point Cloud (Laurel trees clustered along upper ridges)
    const canopyCount = 650;
    const canopyPositions = new Float32Array(canopyCount * 3);
    const canopyColors = new Float32Array(canopyCount * 3);
    const canopySeeds = new Float32Array(canopyCount * 3);

    for (let i = 0; i < canopyCount; i++) {
      const rx = (Math.random() - 0.5) * 4.6;
      const rz = (Math.random() - 0.5) * 4.6;
      const crownOffset = 0.12 + Math.random() * 0.38;
      canopySeeds[i * 3] = rx;
      canopySeeds[i * 3 + 1] = crownOffset;
      canopySeeds[i * 3 + 2] = rz;

      canopyPositions[i * 3] = rx;
      canopyPositions[i * 3 + 1] = crownOffset;
      canopyPositions[i * 3 + 2] = rz;

      canopyColors[i * 3] = 0.88;
      canopyColors[i * 3 + 1] = 0.74;
      canopyColors[i * 3 + 2] = 0.46;
    }

    const canopyGeo = new THREE.BufferGeometry();
    canopyGeo.setAttribute('position', new THREE.BufferAttribute(canopyPositions, 3));
    canopyGeo.setAttribute('color', new THREE.BufferAttribute(canopyColors, 3));

    const canopyMat = new THREE.PointsMaterial({
      size: 0.055,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
    });
    const canopyPoints = new THREE.Points(canopyGeo, canopyMat);
    scene.add(canopyPoints);

    // 3. Atmospheric Rain / Mist Particles driven by Rain + Wind faders
    const rainCount = 320;
    const rainPos = new Float32Array(rainCount * 3);
    for (let i = 0; i < rainCount; i++) {
      rainPos[i * 3] = (Math.random() - 0.5) * 5.0;
      rainPos[i * 3 + 1] = -0.5 + Math.random() * 2.8;
      rainPos[i * 3 + 2] = (Math.random() - 0.5) * 5.0;
    }
    const rainGeo = new THREE.BufferGeometry();
    rainGeo.setAttribute('position', new THREE.BufferAttribute(rainPos, 3));
    const rainMat = new THREE.PointsMaterial({
      color: new THREE.Color().setHSL(0.11, 0.55, 0.78),
      size: 0.032,
      transparent: true,
      opacity: 0.55,
    });
    const rainSystem = new THREE.Points(rainGeo, rainMat);
    scene.add(rainSystem);

    // 4. Horizontal Stratum Slice Ring (for scroll-driven transect inspection)
    const sliceRingGeo = new THREE.RingGeometry(2.25, 2.32, 64);
    sliceRingGeo.rotateX(-Math.PI / 2);
    const sliceRingMat = new THREE.MeshBasicMaterial({
      color: new THREE.Color().setHSL(0.1, 0.72, 0.72),
      side: THREE.DoubleSide,
      transparent: true,
      opacity: variant === 'transect' ? 0.75 : 0.28,
    });
    const sliceRing = new THREE.Mesh(sliceRingGeo, sliceRingMat);
    scene.add(sliceRing);

    const updateGeometry = (time: number) => {
      const st = stateRef.current;
      const station = STATION_SEEDS[st.stationIndex] || STATION_SEEDS[0];
      const windAmp = (st.levels.wind / 100) * 0.14;
      const streamGlow = st.levels.stream / 100;
      const pos = planeGeo.attributes.position as THREE.BufferAttribute;
      const col = planeGeo.attributes.color as THREE.BufferAttribute;

      const targetSliceY =
        variant === 'transect'
          ? STRATA_META[st.activeStratum]?.ySlice ?? 0.35
          : 0.35 - st.scrollProgress * 0.8;

      sliceRing.position.y = THREE.MathUtils.lerp(sliceRing.position.y, targetSliceY, 0.1);

      for (let i = 0; i < pos.count; i++) {
        const x = pos.getX(i);
        const z = pos.getZ(i);
        const baseH = computeElevation(x, z, station.ridgeScale, station.valleyDepth);
        const ripple = Math.sin(x * 2.2 + time * 1.4) * Math.cos(z * 1.8 + time * 1.1) * windAmp;
        const y = baseH + ripple;
        pos.setY(i, y);

        // Compute vertex color based on layer mode and proximity to active stratum slice
        const distToSlice = Math.abs(y - sliceRing.position.y);
        const sliceHighlight = Math.max(0, 1 - distToSlice * 3.8);

        if (st.layer === 'canopy') {
          const hNorm = THREE.MathUtils.clamp((y + 1.1) / 2.2, 0, 1);
          const r = 0.16 + hNorm * 0.42 + sliceHighlight * 0.34;
          const g = 0.28 + hNorm * 0.44 + sliceHighlight * 0.22;
          const b = 0.26 + hNorm * 0.18;
          col.setXYZ(i, r, g, b);
        } else if (st.layer === 'watershed') {
          const valleyFactor = THREE.MathUtils.clamp(1 - Math.abs(x) * 0.75, 0, 1) * (0.4 + streamGlow * 0.6);
          const r = 0.14 + valleyFactor * 0.35 + sliceHighlight * 0.38;
          const g = 0.28 + valleyFactor * 0.48 + sliceHighlight * 0.25;
          const b = 0.38 + valleyFactor * 0.48;
          col.setXYZ(i, r, g, b);
        } else {
          // subsoil / mycelium network
          const rootPulse = 0.5 + 0.5 * Math.sin(x * 3.5 + z * 3.5 - time * 1.6);
          const r = 0.26 + rootPulse * 0.46 + sliceHighlight * 0.25;
          const g = 0.20 + rootPulse * 0.32 + sliceHighlight * 0.2;
          const b = 0.18 + rootPulse * 0.12;
          col.setXYZ(i, r, g, b);
        }
      }
      pos.needsUpdate = true;
      col.needsUpdate = true;
      planeGeo.computeVertexNormals();

      // Update Canopy LiDAR points
      const cPos = canopyGeo.attributes.position as THREE.BufferAttribute;
      const cCol = canopyGeo.attributes.color as THREE.BufferAttribute;
      for (let i = 0; i < canopyCount; i++) {
        const sx = canopySeeds[i * 3];
        const syOff = canopySeeds[i * 3 + 1];
        const sz = canopySeeds[i * 3 + 2];
        const groundY = computeElevation(sx, sz, station.ridgeScale, station.valleyDepth);
        const sway = Math.sin(time * 1.8 + sx * 2.0) * windAmp * 1.4;
        const py = groundY + syOff * (groundY > -0.15 ? 1.15 : 0.35);
        cPos.setXYZ(i, sx + sway, py, sz);

        const highlight = Math.max(0, 1 - Math.abs(py - sliceRing.position.y) * 2.6);
        cCol.setXYZ(
          i,
          0.62 + highlight * 0.35,
          0.68 + highlight * 0.18,
          0.42 + (1 - highlight) * 0.18
        );
      }
      cPos.needsUpdate = true;
      cCol.needsUpdate = true;

      // Update Rain particles
      const rPos = rainGeo.attributes.position as THREE.BufferAttribute;
      const rainSpeed = 0.015 + (st.levels.rain / 100) * 0.055;
      const windDrift = (st.levels.wind / 100) * 0.022;
      rainMat.opacity = 0.12 + (st.levels.rain / 100) * 0.68;
      for (let i = 0; i < rainCount; i++) {
        let rx = rPos.getX(i) + windDrift;
        let ry = rPos.getY(i) - rainSpeed;
        const rz = rPos.getZ(i);
        if (ry < -1.1) {
          ry = 2.1;
          rx = (Math.random() - 0.5) * 5.0;
        }
        if (rx > 2.5) rx = -2.5;
        rPos.setXYZ(i, rx, ry, rz);
      }
      rPos.needsUpdate = true;
    };

    let rafId = 0;
    let clockTime = 0;
    updateGeometry(0);

    const renderLoop = () => {
      const st = stateRef.current;
      if (!st.paused) {
        clockTime += 0.016;
        updateGeometry(clockTime);
      }

      const radius = variant === 'hero' ? 5.15 : 4.75;
      const scrollAngleOffset = variant === 'transect' ? st.activeStratum * 0.42 : st.scrollProgress * 0.65;
      const autoSpin = st.paused ? 0 : clockTime * 0.08;
      const yaw = st.yawPitch.yaw + scrollAngleOffset + autoSpin;
      const pitch =
        variant === 'transect'
          ? THREE.MathUtils.lerp(0.68, 0.22, st.activeStratum / 3)
          : st.yawPitch.pitch;

      camera.position.x = Math.sin(yaw) * Math.cos(pitch) * radius;
      camera.position.z = Math.cos(yaw) * Math.cos(pitch) * radius;
      camera.position.y = Math.sin(pitch) * radius;
      camera.lookAt(0, variant === 'transect' ? sliceRing.position.y * 0.35 : 0, 0);

      renderer.render(scene, camera);
      rafId = requestAnimationFrame(renderLoop);
    };

    rafId = requestAnimationFrame(renderLoop);

    const onResize = () => {
      if (!container) return;
      const w = Math.max(300, container.clientWidth);
      const h = Math.max(240, container.clientHeight);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      planeGeo.dispose();
      surfaceMat.dispose();
      wireMat.dispose();
      canopyGeo.dispose();
      canopyMat.dispose();
      rainGeo.dispose();
      rainMat.dispose();
      sliceRingGeo.dispose();
      sliceRingMat.dispose();
    };
  }, [variant]);

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    dragRef.current = {
      active: true,
      startX: e.clientX,
      startY: e.clientY,
      baseYaw: yawPitch.yaw,
      basePitch: yawPitch.pitch,
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    if (!dragRef.current.active) return;
    const dx = (e.clientX - dragRef.current.startX) * 0.007;
    const dy = (e.clientY - dragRef.current.startY) * 0.005;
    setYawPitch({
      yaw: dragRef.current.baseYaw - dx,
      pitch: Math.max(0.16, Math.min(1.15, dragRef.current.basePitch + dy)),
    });
  };

  const handlePointerUp = () => {
    dragRef.current.active = false;
  };

  const activeStation = STATION_SEEDS[stationIndex] || STATION_SEEDS[0];
  const currentStratum = STRATA_META[activeStratum] || STRATA_META[0];

  return (
    <figure
      className={`recessed-bed relative overflow-hidden m-0 ${paused ? '' : 'is-running'}`}
      data-loop
      style={{ minHeight: variant === 'hero' ? '296px' : '420px' }}
    >
      {/* Top HUD Telemetry Bar inside 3D Viewport */}
      <div
        className="relative flex flex-wrap items-center justify-between"
        style={{
          zIndex: 'var(--z-raised)',
          padding: 'var(--space-sm) var(--space-md)',
          borderBottom: 'var(--rule-hair) solid var(--color-rule-2)',
          background: 'var(--color-scrim)',
          gap: 'var(--space-sm)',
        }}
      >
        <div className="flex items-center" style={{ gap: 'var(--space-sm)' }}>
          <span className="code-token">{activeStation.name}</span>
          <span className="meta-label">({activeStation.elev})</span>
        </div>
        <div className="flex items-center" style={{ gap: 'var(--space-sm)' }}>
          <span className="code-token">{currentStratum.title}</span>
          <button
            type="button"
            className="btn btn--quiet"
            data-loop-toggle
            onClick={() => setPaused((p) => !p)}
            style={{ minHeight: '36px', padding: '0 var(--space-sm)', fontSize: 'var(--text-xs)' }}
          >
            {paused ? 'Play 3D' : 'Pause 3D'}
          </button>
        </div>
      </div>

      {/* 3D WebGL Canvas or Static Topographic Fallback */}
      {webglReady ? (
        <div
          ref={mountRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full cursor-grab active:cursor-grabbing"
          style={{ height: variant === 'hero' ? '248px' : '348px' }}
          title="Drag to orbit 3D LiDAR ridge topography"
        />
      ) : (
        <svg
          className="chart-diagram w-full"
          aria-label="Topographic contour chart of Fanal Laurel Forest"
          viewBox="0 0 600 260"
          style={{ height: variant === 'hero' ? '248px' : '348px' }}
        >
          <path
            d="M 20 190 Q 150 90 300 140 T 580 110"
            fill="none"
            stroke="var(--color-accent)"
            strokeWidth="1.5"
          />
          <path
            d="M 20 215 Q 160 130 310 168 T 580 145"
            fill="none"
            stroke="var(--color-canopy)"
            strokeWidth="1"
          />
          <text x="32" y="48" fill="var(--color-ink)" fontSize="13">
            {activeStation.name} ({activeStation.elev})
          </text>
          <text x="32" y="72" fill="var(--color-muted)" fontSize="12">
            {currentStratum.metric}
          </text>
        </svg>
      )}

      {/* Bottom Viewport Readout Strip */}
      <figcaption
        className="flex flex-wrap items-center justify-between"
        style={{
          padding: 'var(--space-xs) var(--space-md)',
          borderTop: 'var(--rule-hair) solid var(--color-rule-2)',
          background: 'var(--color-scrim)',
          gap: 'var(--space-sm)',
        }}
      >
        <span className="meta-label">Drag ridge to orbit 3D point cloud</span>
        <span className="code-token">{currentStratum.metric}</span>
      </figcaption>
    </figure>
  );
};
