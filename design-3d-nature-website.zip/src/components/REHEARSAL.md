# Rehearsal: FanalStageShowDemo
Gold: `chart-scrub` (kept the single-stroke `a.move` scrub path, `yOnPath` SVG curve tracking, `<Roll stagger={25}>` headline value readout, and `crosshair` cursor over `data-target="plot"`; changed the look to Ribbon `two-in-the-morning` tokens via `.look-sylva`, added a 2-station `Row` sidebar with `Bar` filler rows and a morphing `<Button>` + right-margin satellite record).
Beats: 1 select `Laurel Hollow` station row -> 2 move onto condensation curve at `21:00 UTC` -> 3 scrub in one eased stroke to `03:00 UTC` fog peak (`5.40 mm/hr`) -> 4 click `Log fog burst` button (morphs in place to `Logged to archive` and opens `Burst 04-B recorded` satellite card), hold payoff 2.2s -> 5 clean state reset, loop ~6.5s.
Captured: widths 720 (wide) and 358 (compact below 560px), dark look mapped to Ribbon OKLCH tokens, reduced-motion poster (`POSTER_STATE`).
Gate: verified static & structural alignment (no headless Chrome binary installed in sandbox container).
Film: compact layout drops the left station sidebar and narrows `PLOT_W` from 420 to 276 so no control or label is sliced by the crop.
Review: checked word count budget (6 real strings on stage, `Bar` placeholders for non-acted station rows), button morphs on the same `<Button>` instance, satellite straddles quiet bottom-right margin clear of the curve peak.
Assumptions: Fanal Laurel Hollow foliar drip values (`1.80` to `5.40 mm/hr`) are sample telemetry inside `data-slot="demo-telemetry"` (`data-kind="product"`).
Unresolved: none.
Not checked: live Playwright `film.mjs` contact sheet capture (no Chromium binary in container).
