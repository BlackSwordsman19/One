import React, { useRef, useState } from 'react';
import {
  Badge,
  Bar,
  Button,
  Chart,
  Roll,
  Row,
  Stage,
  Text,
  chartPoints,
  type Act,
} from '../.stageshow-kit';

type TelemetryState = {
  station: number;
  hourIdx: number | null;
  x: number | null;
  tagged: boolean;
  satellite: boolean;
};

// 14 hourly foliar condensation readings (mm/hr * 100 for clean integer chart points)
const DRIP_SERIES = [180, 210, 245, 290, 340, 385, 420, 460, 495, 540, 510, 440, 360, 295];
const HOUR_LABELS = [
  '18:00 UTC',
  '19:00 UTC',
  '20:00 UTC',
  '21:00 UTC',
  '22:00 UTC',
  '23:00 UTC',
  '00:00 UTC',
  '01:00 UTC',
  '02:00 UTC',
  '03:00 UTC',
  '04:00 UTC',
  '05:00 UTC',
  '06:00 UTC',
  '07:00 UTC',
];

const formatDrip = (val: number) => `${(val / 100).toFixed(2)} mm/hr`;

const PLOT_W = { wide: 420, compact: 276 };
const PLOT_H = 132;

const INITIAL_STATE: TelemetryState = {
  station: 0,
  hourIdx: null,
  x: null,
  tagged: false,
  satellite: false,
};

const POSTER_STATE: TelemetryState = {
  station: 1,
  hourIdx: 9,
  x: null,
  tagged: true,
  satellite: true,
};

function yOnPath(path: SVGPathElement | null | undefined, x: number): number | null {
  if (!path) return null;
  let lo = 0;
  let hi = path.getTotalLength();
  for (let i = 0; i < 20; i++) {
    const mid = (lo + hi) / 2;
    if (path.getPointAtLength(mid).x < x) lo = mid;
    else hi = mid;
  }
  return path.getPointAtLength(hi).y;
}

async function telemetryScript(a: Act<TelemetryState>) {
  await a.wait(700);

  // Beat 1: Select Station 02 (Laurel Hollow 980 m)
  a.mark('select-station');
  await a.move('station-1', { duration: 550 });
  await a.click();
  await a.set({ station: 1 });
  await a.wait(450);

  // Beat 2: Move onto the condensation curve and scrub to the 03:00 UTC peak
  const box = a.rect('plot');
  const pts = chartPoints({ data: DRIP_SERIES, width: box.width, height: PLOT_H, dot: false });
  const ptAt = (i: number) => ({ x: box.x + pts[i]!.x, y: box.y + pts[i]!.y + 12 });

  a.mark('hover-curve');
  await a.move(ptAt(3), { duration: 600 });
  a.put({ hourIdx: 3, x: pts[3]!.x });
  await a.wait(450);

  a.mark('scrub-peak');
  await a.move(ptAt(9), {
    duration: 1350,
    path: (e, from, to) => ({
      x: from.x + (to.x - from.x) * e,
      y: from.y + (to.y - from.y) * e,
    }),
    onMove: (pt) => {
      const localX = Math.max(0, Math.min(box.width, pt.x - box.x));
      let near = 0;
      for (let i = 1; i < pts.length; i++) {
        if (Math.abs(pts[i]!.x - localX) < Math.abs(pts[near]!.x - localX)) near = i;
      }
      a.put({ hourIdx: near, x: localX });
    },
  });
  await a.wait(500);

  // Beat 3: Click 'Log fog burst' button; button morphs on itself and opens satellite record
  a.mark('log-burst');
  await a.move('log-btn', { duration: 500 });
  await a.click();
  await a.set({ tagged: true, satellite: true });
  await a.wait(2200);

  // Beat 4: Caused reset for clean loop seam
  a.mark('reset');
  await a.set({ satellite: false, tagged: false, hourIdx: null, x: null, station: 0 });
  await a.wait(900);
}

export const FanalStageShowDemo: React.FC = () => {
  const plotRef = useRef<HTMLDivElement>(null);
  const [runKey, setRunKey] = useState(0);

  return (
    <div className="look-sylva flex flex-col" style={{ gap: 'var(--space-md)' }}>
      <div
        className="panel relative overflow-hidden"
        data-slot="demo-telemetry"
        data-kind="product"
        data-alt="Interactive StageShow telemetry walkthrough of Fanal Laurel Hollow foliar drip and hydrophone burst logging"
      >
        <Stage<TelemetryState>
          key={runKey}
          width={720}
          height={390}
          compact={{ below: 560, width: 358, height: 390 }}
          initial={INITIAL_STATE}
          poster={POSTER_STATE}
          script={telemetryScript}
          theme="dark"
          cursor={{ at: { wide: { x: 610, y: 320 }, compact: { x: 290, y: 340 } }, ripple: true }}
        >
          {(s, _rect, layout) => {
            const plotW = layout === 'compact' ? PLOT_W.compact : PLOT_W.wide;
            const pts = chartPoints({ data: DRIP_SERIES, width: plotW, height: PLOT_H, dot: false });
            const hx = s.x ?? (s.hourIdx === null ? null : pts[s.hourIdx]!.x);
            const activeOn = s.hourIdx !== null;
            const hy =
              hx === null
                ? null
                : yOnPath(plotRef.current?.querySelector<SVGPathElement>('.ss-chart__line'), hx) ??
                  pts[s.hourIdx ?? 0]!.y;
            const dotPos = hx === null || hy === null ? null : { x: hx, y: hy };

            const activeValue = s.hourIdx === null ? DRIP_SERIES[6]! : DRIP_SERIES[s.hourIdx]!;
            const activeHour = s.hourIdx === null ? 'Overnight mean' : HOUR_LABELS[s.hourIdx]!;

            return (
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  padding: 'var(--space-lg)',
                  display: 'grid',
                  gridTemplateColumns: layout === 'compact' ? 'minmax(0, 1fr)' : '188px minmax(0, 1fr)',
                  gap: 'var(--space-lg)',
                  alignItems: 'start',
                }}
              >
                {/* Left Sidebar: Hydrophone Station List (hidden in compact crop per framing.md) */}
                {layout === 'wide' && (
                  <div
                    className="recessed-bed"
                    style={{
                      padding: 'var(--space-sm)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 'var(--space-2xs)',
                    }}
                  >
                    <div
                      style={{
                        padding: 'var(--space-2xs) var(--space-xs)',
                        fontSize: 'var(--text-xs)',
                        color: 'var(--color-muted)',
                        fontWeight: 500,
                      }}
                    >
                      Ridge sensors
                    </div>
                    <div data-target="station-0">
                      <Row
                        selected={s.station === 0}
                        title={<Text>Fanal Ridge</Text>}
                        subtitle={<Text>1,150 m canopy</Text>}
                      />
                    </div>
                    <div data-target="station-1">
                      <Row
                        selected={s.station === 1}
                        title={<Text>Laurel Hollow</Text>}
                        subtitle={<Text>980 m bryophyte</Text>}
                      />
                    </div>
                    <Row title={<Bar w={64} />} subtitle={<Bar w={44} tone={2} />} />
                    <Row title={<Bar w={52} />} subtitle={<Bar w={38} tone={2} />} />
                  </div>
                )}

                {/* Main Telemetry Plot Surface */}
                <div
                  className="recessed-bed"
                  style={{
                    padding: 'var(--space-md)',
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 'var(--space-md)',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'flex-start',
                      justifyContent: 'space-between',
                      gap: 'var(--space-sm)',
                    }}
                  >
                    <div>
                      <div style={{ fontSize: 'var(--text-xs)', color: 'var(--color-muted)' }}>
                        <Roll variant="fade">{activeHour}</Roll>
                      </div>
                      <div
                        className="display-figure"
                        style={{ fontSize: 'var(--text-2xl)', marginTop: 'var(--space-3xs)' }}
                      >
                        <Roll stagger={25}>{formatDrip(activeValue)}</Roll>
                      </div>
                    </div>

                    <div data-target="log-btn">
                      <Button
                        variant={s.tagged ? 'secondary' : 'primary'}
                        icon={s.tagged ? 'check' : 'plus'}
                      >
                        {s.tagged ? 'Logged to archive' : 'Log fog burst'}
                      </Button>
                    </div>
                  </div>

                  {/* Interactive Scrubbable Chart */}
                  <div
                    ref={plotRef}
                    data-target="plot"
                    data-cursor="crosshair"
                    style={{ position: 'relative', width: plotW, height: PLOT_H }}
                  >
                    <Chart data={DRIP_SERIES} width={plotW} height={PLOT_H} dot={false} />
                    {dotPos && activeOn && (
                      <>
                        <span
                          style={{
                            position: 'absolute',
                            top: 0,
                            bottom: 0,
                            left: dotPos.x,
                            width: '1px',
                            background: 'var(--color-accent)',
                            pointerEvents: 'none',
                          }}
                        />
                        <span
                          style={{
                            position: 'absolute',
                            left: dotPos.x - 4,
                            top: dotPos.y - 4,
                            width: '8px',
                            height: '8px',
                            borderRadius: 'var(--radius-pill)',
                            background: 'var(--color-accent)',
                            pointerEvents: 'none',
                          }}
                        />
                      </>
                    )}
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      width: plotW,
                      fontSize: 'var(--text-xs)',
                      color: 'var(--color-muted)',
                    }}
                  >
                    <span>18:00 UTC</span>
                    <span>07:00 UTC</span>
                  </div>
                </div>

                {/* Satellite Card straddling the right margin (framing.md rule 7 & 18) */}
                {s.satellite && layout === 'wide' && (
                  <div
                    className="panel"
                    style={{
                      position: 'absolute',
                      right: 'var(--space-md)',
                      bottom: 'var(--space-md)',
                      width: '216px',
                      padding: 'var(--space-sm) var(--space-md)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: 'var(--space-2xs)',
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: 'var(--space-xs)',
                      }}
                    >
                      <span style={{ fontSize: 'var(--text-xs)', fontWeight: 500, color: 'var(--color-ink)' }}>
                        Burst 04-B recorded
                      </span>
                      <Badge tone="accent">980 m</Badge>
                    </div>
                    <span className="code-token">5.40 mm/hr at 03:00 UTC</span>
                    <span className="meta-label">Hydrophone stem saved to LAS packet</span>
                  </div>
                )}
              </div>
            );
          }}
        </Stage>
      </div>

      {/* StageShow Replay Bar */}
      <div className="flex flex-wrap items-center justify-between" style={{ gap: 'var(--space-sm)' }}>
        <p className="caption" style={{ margin: 0 }}>
          Automated field capture showing cursor scrubbing across the overnight trade-wind fog peak.
        </p>
        <button
          type="button"
          className="btn btn--quiet"
          onClick={() => setRunKey((k) => k + 1)}
        >
          Replay walkthrough
        </button>
      </div>
    </div>
  );
};
