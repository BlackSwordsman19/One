import * as THREE from "three";
import { mergeGeometries } from "three/examples/jsm/utils/BufferGeometryUtils.js";
import { oklch } from "./oklch";
import { sample } from "./keyframes";
import * as S from "./shaders";

/* ───────────── helpers ───────────── */
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** A tapered tube along a polyline (roots). */
function tube(points: THREE.Vector3[], r0: number, r1: number, radial = 5): THREE.BufferGeometry {
  const n = points.length;
  const pos: number[] = [];
  const nor: number[] = [];
  const idx: number[] = [];
  let prevN = new THREE.Vector3(0, 1, 0);
  for (let i = 0; i < n; i++) {
    const p = points[i];
    const tan = (points[Math.min(i + 1, n - 1)].clone().sub(points[Math.max(i - 1, 0)])).normalize();
    let nn = prevN.clone().sub(tan.clone().multiplyScalar(prevN.dot(tan)));
    if (nn.lengthSq() < 1e-6) nn = new THREE.Vector3(1, 0, 0).cross(tan);
    nn.normalize();
    prevN = nn;
    const bb = tan.clone().cross(nn).normalize();
    const r = r0 + (r1 - r0) * (i / (n - 1));
    for (let j = 0; j < radial; j++) {
      const a = (j / radial) * Math.PI * 2;
      const dir = nn.clone().multiplyScalar(Math.cos(a)).add(bb.clone().multiplyScalar(Math.sin(a)));
      pos.push(p.x + dir.x * r, p.y + dir.y * r, p.z + dir.z * r);
      nor.push(dir.x, dir.y, dir.z);
    }
  }
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < radial; j++) {
      const a = i * radial + j;
      const b = i * radial + ((j + 1) % radial);
      const c = (i + 1) * radial + j;
      const d = (i + 1) * radial + ((j + 1) % radial);
      idx.push(a, c, b, b, c, d);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute("normal", new THREE.Float32BufferAttribute(nor, 3));
  g.setIndex(idx);
  return g;
}

interface Tree { x: number; z: number; h: number; r: number; seed: number; lean: number }

export interface WorldOptions {
  getTarget: () => number;
  reduced: boolean;
  onFrame: (y: number, s: number) => void;
  still?: number | null;
}

export class World {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(52, 1, 0.1, 1800);
  private raf = 0;
  private cur = 0;
  private last = 0;
  private sky!: THREE.Mesh;
  private fog = new THREE.Color();
  private moteColor = new THREE.Color();
  private disposables: { dispose(): void }[] = [];
  private seaMats: THREE.ShaderMaterial[] = [];
  private moteMat!: THREE.ShaderMaterial;
  private onResize = () => this.resize();

  private U: Record<string, THREE.IUniform> = {
    uTime: { value: 0 },
    uFogColor: { value: new THREE.Color() },
    uFogDensity: { value: 0.003 },
    uSunDir: { value: new THREE.Vector3(-0.45, 0.62, -0.64).normalize() },
    uSunColor: { value: oklch(0.88, 0.12, 78) },
    uSunAmt: { value: 1 },
    uShaft: { value: 0 },
    uMyc: { value: 0 },
    uAccent: { value: oklch(0.88, 0.18, 158) },
    uPx: { value: 1 },
  };

  private trees: Tree[] = [];

  constructor(private canvas: HTMLCanvasElement, private opts: WorldOptions) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
    this.U.uPx.value = this.renderer.getPixelRatio();
    this.camera.filmGauge = 35;

    this.buildSky();
    this.buildTrees();
    this.buildGround();
    this.buildUnderstory();
    this.buildRoots();
    this.buildMycelium();
    this.buildShafts();
    this.buildFogSea();
    this.buildMotes();

    this.resize();
    window.addEventListener("resize", this.onResize);
  }

  private mat(vert: string, frag: string, extra: Record<string, unknown> = {}, params: THREE.ShaderMaterialParameters = {}) {
    const uniforms: Record<string, THREE.IUniform> = { ...this.U };
    for (const [k, v] of Object.entries(extra)) uniforms[k] = { value: v };
    const m = new THREE.ShaderMaterial({ vertexShader: vert, fragmentShader: frag, uniforms, ...params });
    this.disposables.push(m);
    return m;
  }

  private add<T extends THREE.Object3D>(o: T): T {
    o.frustumCulled = false;
    this.scene.add(o);
    return o;
  }

  /* ───────────── sky ───────────── */
  private buildSky() {
    const geo = new THREE.SphereGeometry(900, 32, 16);
    const mat = this.mat(S.skyVert, S.skyFrag, {
      uSkyTop: oklch(0.2, 0.04, 218),
      uSkyHor: oklch(0.52, 0.06, 150),
      uGlow: oklch(0.82, 0.12, 62),
      uSky: 1,
    }, { side: THREE.BackSide, depthWrite: false });
    this.sky = this.add(new THREE.Mesh(geo, mat));
    this.sky.renderOrder = -10;
    this.disposables.push(geo);
  }

  /* ───────────── trees ───────────── */
  private buildTrees() {
    const r = rng(7);
    const trees: Tree[] = [];
    trees.push({ x: 0, z: 0, h: 116, r: 3.3, seed: 0.5, lean: 0 });
    // the ring: a fairy ring of old trees around the clearing
    const ringN = 9;
    for (let i = 0; i < ringN; i++) {
      const a = (i / ringN) * Math.PI * 2 + (r() - 0.5) * 0.3;
      const rad = 21 + r() * 3;
      trees.push({ x: Math.cos(a) * rad, z: Math.sin(a) * rad, h: 88 + r() * 18, r: 2.1 + r() * 0.7, seed: r(), lean: (r() - 0.5) * 2 });
    }
    let guard = 0;
    while (trees.length < 205 && guard++ < 4000) {
      const rad = 29 + 150 * Math.sqrt(r());
      const a = r() * Math.PI * 2;
      const x = Math.cos(a) * rad;
      const z = Math.sin(a) * rad;
      if (trees.some((t) => Math.hypot(t.x - x, t.z - z) < 8)) continue;
      const h = 60 + 48 * Math.pow(r(), 0.8);
      trees.push({ x, z, h, r: 1.3 + h * 0.016 + r() * 0.5, seed: r(), lean: (r() - 0.5) * 3 });
    }
    this.trees = trees;

    // trunks
    const g = new THREE.CylinderGeometry(1, 1, 1, 14, 46, true);
    g.translate(0, 0.5, 0);
    const aTree = new Float32Array(trees.length * 4);
    trees.forEach((t, i) => aTree.set([t.h, t.r, t.seed, t.lean], i * 4));
    g.setAttribute("aTree", new THREE.InstancedBufferAttribute(aTree, 4));
    const trunkMat = this.mat(S.trunkVert, S.trunkFrag, {
      uBarkA: oklch(0.2, 0.05, 38),
      uBarkB: oklch(0.46, 0.115, 42),
      uMoss: oklch(0.36, 0.08, 140),
    });
    const trunks = this.add(new THREE.InstancedMesh(g, trunkMat, trees.length));
    const m4 = new THREE.Matrix4();
    trees.forEach((t, i) => trunks.setMatrixAt(i, m4.makeTranslation(t.x, 0, t.z)));
    this.disposables.push(g);

    // crowns
    const clumps: { p: THREE.Vector3; s: THREE.Vector3; seed: number; rot: THREE.Euler }[] = [];
    trees.forEach((t, ti) => {
      const hero = ti === 0;
      const count = hero ? 190 : 38;
      const rMax = t.h * (hero ? 0.062 : 0.052);
      for (let i = 0; i < count; i++) {
        const f = Math.pow(r(), 0.85); // 0 low in the crown, 1 at the tip
        const env = Math.pow(1 - f, 0.9) * rMax + 0.35;
        const a = r() * Math.PI * 2;
        const d = Math.sqrt(r()) * env;
        const y = t.h * (0.56 + 0.44 * f) - d * 0.25;
        const sz = (1.5 + r() * 1.8) * (t.h / 100) * (0.55 + 0.7 * (1 - f)) * (hero ? 1.1 : 1);
        clumps.push({
          p: new THREE.Vector3(t.x + Math.cos(a) * d + t.lean * f, y, t.z + Math.sin(a) * d),
          s: new THREE.Vector3(sz * 1.15, sz * 0.5, sz * 1.15),
          seed: r(),
          rot: new THREE.Euler((r() - 0.5) * 0.5, r() * 6, (r() - 0.5) * 0.5),
        });
      }
      // a spire at the very top
      clumps.push({ p: new THREE.Vector3(t.x + t.lean, t.h - 1.2, t.z), s: new THREE.Vector3(0.9, 3.4, 0.9), seed: r(), rot: new THREE.Euler() });
    });
    const cg = new THREE.IcosahedronGeometry(1, 1);
    cg.setAttribute("aSeed", new THREE.InstancedBufferAttribute(new Float32Array(clumps.map((c) => c.seed)), 1));
    const leafUniforms = { uLeafA: oklch(0.33, 0.075, 165), uLeafB: oklch(0.68, 0.13, 125) };
    const crownMat = this.mat(S.crownVert, S.crownFrag, leafUniforms);
    const crowns = this.add(new THREE.InstancedMesh(cg, crownMat, clumps.length));
    const q = new THREE.Quaternion();
    clumps.forEach((c, i) => {
      q.setFromEuler(c.rot);
      crowns.setMatrixAt(i, m4.compose(c.p, q, c.s));
    });
    this.disposables.push(cg);
  }

  /* ───────────── ground ───────────── */
  private buildGround() {
    const g = new THREE.CircleGeometry(520, 72);
    g.rotateX(-Math.PI / 2);
    const m = this.mat(S.groundVert, S.groundFrag, {
      uLoamA: oklch(0.2, 0.04, 55),
      uLoamB: oklch(0.34, 0.06, 62),
      uMoss: oklch(0.34, 0.1, 140),
      uSoil: oklch(0.2, 0.03, 52),
    }, { side: THREE.DoubleSide });
    this.add(new THREE.Mesh(g, m));
    this.disposables.push(g);
  }

  /* ───────────── ferns, mushrooms, the nurse log ───────────── */
  private buildUnderstory() {
    const r = rng(21);
    const m4 = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const up = new THREE.Vector3(0, 1, 0);

    // fern texture
    const cv = document.createElement("canvas");
    cv.width = 128; cv.height = 256;
    const cx = cv.getContext("2d")!;
    cx.lineCap = "round";
    cx.strokeStyle = "#fff";
    cx.lineWidth = 4;
    cx.beginPath(); cx.moveTo(64, 256); cx.lineTo(64, 4); cx.stroke();
    for (let y = 246; y > 10; y -= 11) {
      const prog = 1 - y / 256;
      const L = 58 * Math.sin(Math.PI * Math.min(prog * 0.95 + 0.06, 1)) + 5;
      const tilt = 26;
      cx.lineWidth = 8 - prog * 4;
      for (const sgn of [-1, 1]) {
        const shade = 190 + Math.floor(r() * 65);
        cx.strokeStyle = `rgb(${shade},${shade},${shade})`;
        cx.beginPath(); cx.moveTo(64, y); cx.lineTo(64 + sgn * L, y - tilt * (L / 58)); cx.stroke();
      }
    }
    const tex = new THREE.CanvasTexture(cv);
    tex.anisotropy = 4;
    this.disposables.push(tex);

    const fronds: THREE.BufferGeometry[] = [];
    const F = 7;
    for (let f = 0; f < F; f++) {
      const yaw = (f / F) * Math.PI * 2 + (r() - 0.5) * 0.5;
      const len = 0.85 + r() * 0.35;
      const pos: number[] = [], uv: number[] = [], idx: number[] = [];
      const segs = 7;
      for (let i = 0; i <= segs; i++) {
        const s = i / segs;
        const d = Math.sin(s * Math.PI * 0.52) * len;
        const h = 0.1 + Math.sin(s * Math.PI * 0.85) * len * 0.5;
        const w = 0.17 * len;
        const cxp = Math.cos(yaw), czp = Math.sin(yaw);
        const px = cxp * d, pz = czp * d;
        const nx = -czp * w, nz = cxp * w;
        pos.push(px - nx, h, pz - nz, px + nx, h, pz + nz);
        uv.push(0, s, 1, s);
        if (i < segs) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
      g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
      g.setIndex(idx);
      fronds.push(g);
    }
    const fernGeo = mergeGeometries(fronds)!;
    const camTheta0 = THREE.MathUtils.degToRad(300);
    const fernMat = this.mat(S.fernVert, S.fernFrag, { uTex: tex, uFernA: oklch(0.3, 0.1, 150), uFernB: oklch(0.6, 0.14, 130) }, { side: THREE.DoubleSide });
    const fernN = 1700;
    const ferns = this.add(new THREE.InstancedMesh(fernGeo, fernMat, fernN));
    for (let i = 0; i < fernN; i++) {
      const near = i > 1300;
      const rad = near ? 8 + r() * 5 : 4.2 + 44 * Math.pow(r(), 1.5);
      const a = near ? camTheta0 + (r() - 0.5) * 1.6 : r() * Math.PI * 2;
      const sc = 0.7 + r() * 1.2;
      q.setFromAxisAngle(up, r() * 6.28);
      ferns.setMatrixAt(i, m4.compose(new THREE.Vector3(Math.cos(a) * rad, 0, Math.sin(a) * rad), q, new THREE.Vector3(sc, sc * (0.8 + r() * 0.5), sc)));
    }
    this.disposables.push(fernGeo);

    // mushrooms
    const shroomGeo = (cap: THREE.Color) => {
      const stem = new THREE.CylinderGeometry(0.055, 0.085, 0.5, 8, 1).toNonIndexed();
      stem.translate(0, 0.25, 0);
      const capG = new THREE.LatheGeometry(
        [new THREE.Vector2(0.0, 0.7), new THREE.Vector2(0.13, 0.68), new THREE.Vector2(0.26, 0.6), new THREE.Vector2(0.33, 0.5), new THREE.Vector2(0.32, 0.46), new THREE.Vector2(0.09, 0.49)],
        12,
      ).toNonIndexed();
      const bone = oklch(0.82, 0.03, 95);
      const paint = (g: THREE.BufferGeometry, c: THREE.Color, flag: number) => {
        const n = g.attributes.position.count;
        const col = new Float32Array(n * 3);
        const f = new Float32Array(n).fill(flag);
        for (let i = 0; i < n; i++) col.set([c.r, c.g, c.b], i * 3);
        g.setAttribute("aCol", new THREE.BufferAttribute(col, 3));
        g.setAttribute("aCap", new THREE.BufferAttribute(f, 1));
        g.deleteAttribute("uv");
      };
      paint(stem, bone, 0);
      paint(capG, cap, 1);
      return mergeGeometries([stem, capG])!;
    };
    const shroomMat = this.mat(S.shroomVert, S.shroomFrag, {}, { side: THREE.DoubleSide });
    const camTheta = THREE.MathUtils.degToRad(300);
    const mk = (cap: THREE.Color, n: number, sector: boolean) => {
      const geo = shroomGeo(cap);
      const mesh = this.add(new THREE.InstancedMesh(geo, shroomMat, n));
      for (let i = 0; i < n; i++) {
        const rad = sector ? 9 + r() * 1.8 : 5 + r() * 30;
        const a = sector ? camTheta + (r() - 0.35) * 0.7 : r() * 6.28;
        const sc = sector ? 0.3 + Math.pow(r(), 2) * 0.8 : 0.25 + r() * 0.5;
        q.setFromAxisAngle(up, r() * 6.28);
        mesh.setMatrixAt(i, m4.compose(new THREE.Vector3(Math.cos(a) * rad, 0, Math.sin(a) * rad), q, new THREE.Vector3(sc, sc * (0.8 + r() * 0.6), sc)));
      }
      this.disposables.push(geo);
    };
    mk(oklch(0.5, 0.21, 28), 26, true);
    mk(oklch(0.46, 0.09, 62), 30, true);
    mk(oklch(0.5, 0.2, 30), 40, false);
    mk(oklch(0.5, 0.09, 70), 60, false);

    // the nurse log, with seedlings on its back
    const logA = THREE.MathUtils.degToRad(318);
    const lr = 8.6;
    const logGeo = new THREE.CylinderGeometry(0.95, 1.12, 15, 20, 6);
    logGeo.rotateZ(Math.PI / 2);
    const logMat = this.mat(S.logVert, S.logFrag, { uBarkA: oklch(0.2, 0.04, 40), uBarkB: oklch(0.4, 0.08, 48), uMoss: oklch(0.38, 0.11, 140) });
    const log = this.add(new THREE.Mesh(logGeo, logMat));
    log.position.set(Math.cos(logA) * lr, 0.62, Math.sin(logA) * lr);
    log.rotation.y = -(logA + Math.PI / 2);
    log.rotation.z = 0.04;
    this.disposables.push(logGeo);

    const cone = new THREE.ConeGeometry(0.28, 1, 7);
    cone.translate(0, 0.5, 0);
    const seedN = 11;
    cone.setAttribute("aSeed", new THREE.InstancedBufferAttribute(new Float32Array(Array.from({ length: seedN }, () => r())), 1));
    const seedMat = this.mat(S.crownVert, S.crownFrag, { uLeafA: oklch(0.3, 0.08, 150), uLeafB: oklch(0.62, 0.14, 130) });
    const seedlings = this.add(new THREE.InstancedMesh(cone, seedMat, seedN));
    const tangent = new THREE.Vector3(-Math.sin(logA), 0, Math.cos(logA));
    for (let i = 0; i < seedN; i++) {
      const along = (i / (seedN - 1) - 0.5) * 13 + (r() - 0.5) * 0.8;
      const p = log.position.clone().addScaledVector(tangent, along);
      p.y = 1.45;
      const sc = 0.35 + r() * 0.6;
      q.setFromAxisAngle(up, r() * 6.28);
      seedlings.setMatrixAt(i, m4.compose(p, q, new THREE.Vector3(sc, sc * 1.5, sc)));
    }
    this.disposables.push(cone);
  }

  /* ───────────── roots ───────────── */
  private buildRoots() {
    const r = rng(33);
    const geos: THREE.BufferGeometry[] = [];
    const grow = (start: THREE.Vector3, dir: THREE.Vector3, len: number, r0: number, level: number) => {
      const pts = [start.clone()];
      const p = start.clone();
      const d = dir.clone().normalize();
      const step = 1.25 - level * 0.35;
      const n = Math.max(4, Math.floor(len / step));
      for (let i = 0; i < n; i++) {
        d.x += (r() - 0.5) * 0.55; d.z += (r() - 0.5) * 0.55;
        d.y += (r() - 0.5) * 0.3 + (-1.5 - p.y) * 0.07;
        d.normalize();
        p.addScaledVector(d, step);
        p.y = Math.min(-0.15, Math.max(-3.3, p.y));
        pts.push(p.clone());
        if (level < 2 && i > 1 && r() < (level === 0 ? 0.3 : 0.2)) {
          const cd = d.clone();
          cd.x += (r() - 0.5) * 2; cd.z += (r() - 0.5) * 2; cd.y += (r() - 0.5) * 0.4;
          grow(p, cd, len * (0.35 + r() * 0.35), r0 * 0.5, level + 1);
        }
      }
      geos.push(tube(pts, r0, Math.max(r0 * 0.2, 0.025), level === 0 ? 7 : 5));
    };
    for (const [ti, t] of this.trees.slice(0, 10).entries()) {
      const count = ti === 0 ? 26 : 7;
      const rad = ti === 0 ? 2.6 : t.r * 0.9;
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2 + r() * 0.4;
        const dir = new THREE.Vector3(Math.cos(a), -0.12, Math.sin(a));
        const start = new THREE.Vector3(t.x + Math.cos(a) * rad, -0.1, t.z + Math.sin(a) * rad);
        grow(start, dir, (ti === 0 ? 26 : 13) + r() * (ti === 0 ? 14 : 6), ti === 0 ? 0.42 + r() * 0.2 : 0.22, 0);
      }
    }
    const merged = mergeGeometries(geos)!;
    const mat = this.mat(S.rootVert, S.rootFrag, { uRootA: oklch(0.42, 0.1, 45), uRootB: oklch(0.66, 0.12, 58) });
    this.add(new THREE.Mesh(merged, mat));
    geos.forEach((g) => g.dispose());
    this.disposables.push(merged);
  }

  /* ───────────── mycelium: the network between the trees ───────────── */
  private buildMycelium() {
    const r = rng(91);
    const linePos: number[] = [], lineT: number[] = [], lineId: number[] = [], lineSpd: number[] = [];
    const ptPos: number[] = [], ptT: number[] = [], ptId: number[] = [], ptSpd: number[] = [], ptSize: number[] = [];

    const strand = (pts: THREE.Vector3[], id: number, spd: number, dots: number) => {
      for (let i = 0; i < pts.length - 1; i++) {
        const a = pts[i], b = pts[i + 1];
        linePos.push(a.x, a.y, a.z, b.x, b.y, b.z);
        lineT.push(i / (pts.length - 1), (i + 1) / (pts.length - 1));
        lineId.push(id, id);
        lineSpd.push(spd, spd);
      }
      for (let i = 0; i < pts.length; i += dots) {
        const p = pts[i];
        ptPos.push(p.x, p.y, p.z);
        ptT.push(i / (pts.length - 1)); ptId.push(id); ptSpd.push(spd); ptSize.push(0.7 + r() * 1.3);
      }
    };

    const branch = (from: THREE.Vector3, depth: number) => {
      const steps = 8 + Math.floor(r() * 16);
      const pts = [from.clone()];
      const d = new THREE.Vector3(r() - 0.5, (r() - 0.5) * 0.5, r() - 0.5).normalize();
      const p = from.clone();
      for (let i = 0; i < steps; i++) {
        d.x += (r() - 0.5) * 0.35; d.y += (r() - 0.5) * 0.2; d.z += (r() - 0.5) * 0.35;
        d.normalize();
        p.addScaledVector(d, 0.5);
        p.y = Math.min(-0.5, Math.max(-9, p.y));
        pts.push(p.clone());
      }
      strand(pts, r(), r() * 0.8, 2);
      if (depth < 2 && r() < 0.5) branch(pts[Math.floor(pts.length / 2)], depth + 1);
    };

    const nodes: THREE.Vector3[] = this.trees.slice(0, 10).map((t) => new THREE.Vector3(t.x, -1.4, t.z));
    const outer = this.trees.slice(10).filter((t) => Math.hypot(t.x, t.z) < 72).map((t) => new THREE.Vector3(t.x, -1.6, t.z));
    const all = [...nodes, ...outer];

    const edge = (A: THREE.Vector3, B: THREE.Vector3, bundle: number) => {
      const dist = A.distanceTo(B);
      for (let k = 0; k < bundle; k++) {
        const ctrl = [A.clone()];
        for (let j = 1; j <= 3; j++) {
          const f = j / 4;
          const p = A.clone().lerp(B, f);
          p.x += (r() - 0.5) * dist * 0.25; p.z += (r() - 0.5) * dist * 0.25;
          p.y = -1.5 - r() * 5.5;
          ctrl.push(p);
        }
        ctrl.push(B.clone());
        const curve = new THREE.CatmullRomCurve3(ctrl);
        const pts = curve.getPoints(Math.min(70, Math.max(16, Math.floor(dist * 1.2))));
        strand(pts, r(), r() * 0.9, 2);
        if (r() < 0.6) branch(pts[Math.floor(r() * pts.length)], 0);
      }
    };
    // hyperion to every ring tree, ring neighbours to each other
    for (let i = 1; i < 10; i++) {
      edge(nodes[0], nodes[i], 9);
      edge(nodes[i], nodes[i === 9 ? 1 : i + 1], 6);
    }
    // outer trees reach for their two nearest neighbours
    all.slice(10).forEach((n) => {
      const nearest = all.filter((o) => o !== n).sort((a, b) => a.distanceTo(n) - b.distanceTo(n)).slice(0, 2);
      nearest.forEach((o) => edge(n, o, 4));
    });
    // a dense fuzz around the central tree
    for (let i = 0; i < 520; i++) {
      const a = r() * 6.28, rad = 1.5 + r() * 22;
      branch(new THREE.Vector3(Math.cos(a) * rad, -1 - r() * 4, Math.sin(a) * rad), 0);
    }

    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.Float32BufferAttribute(linePos, 3));
    lg.setAttribute("aT", new THREE.Float32BufferAttribute(lineT, 1));
    lg.setAttribute("aId", new THREE.Float32BufferAttribute(lineId, 1));
    lg.setAttribute("aSpd", new THREE.Float32BufferAttribute(lineSpd, 1));
    const blend = { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending } as const;
    const lines = this.add(new THREE.LineSegments(lg, this.mat(S.mycLineVert, S.mycLineFrag, {}, blend)));
    lines.renderOrder = 3;

    const pg = new THREE.BufferGeometry();
    pg.setAttribute("position", new THREE.Float32BufferAttribute(ptPos, 3));
    pg.setAttribute("aT", new THREE.Float32BufferAttribute(ptT, 1));
    pg.setAttribute("aId", new THREE.Float32BufferAttribute(ptId, 1));
    pg.setAttribute("aSpd", new THREE.Float32BufferAttribute(ptSpd, 1));
    pg.setAttribute("aSize", new THREE.Float32BufferAttribute(ptSize, 1));
    const pts = this.add(new THREE.Points(pg, this.mat(S.mycPointVert, S.mycPointFrag, {}, blend)));
    pts.renderOrder = 4;
    this.disposables.push(lg, pg);
  }

  /* ───────────── shafts of light ───────────── */
  private buildShafts() {
    const r = rng(5);
    const sun = this.U.uSunDir.value as THREE.Vector3;
    const quat = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), sun);
    const mat = this.mat(S.shaftVert, S.shaftFrag, {}, { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
    const len = 90;
    for (let i = 0; i < 12; i++) {
      const rad = 9 + r() * 24;
      const a = r() * Math.PI * 2;
      const w = 1.6 + r() * 2.6;
      const g = new THREE.CylinderGeometry(w * 0.7, w, len, 14, 1, true);
      const m = this.add(new THREE.Mesh(g, mat));
      m.quaternion.copy(quat);
      const base = new THREE.Vector3(Math.cos(a) * rad, 0, Math.sin(a) * rad);
      m.position.copy(base).addScaledVector(sun, len / 2 - 4);
      m.renderOrder = 2;
      this.disposables.push(g);
    }
  }

  /* ───────────── the sea of fog ───────────── */
  private buildFogSea() {
    const g = new THREE.PlaneGeometry(1100, 1100);
    g.rotateX(-Math.PI / 2);
    this.disposables.push(g);
    for (let i = 0; i < 5; i++) {
      const m = this.mat(S.seaVert, S.seaFrag, { uSea: 1, uLayer: i, uSeaLight: oklch(0.86, 0.045, 85), uSeaDark: oklch(0.5, 0.045, 195) }, { transparent: true, depthWrite: false, side: THREE.DoubleSide });
      const mesh = this.add(new THREE.Mesh(g, m));
      mesh.position.y = 77 + i * 3.4;
      mesh.renderOrder = 1;
      this.seaMats.push(m);
    }
  }

  /* ───────────── motes ───────────── */
  private buildMotes() {
    const r = rng(77);
    const n = 1800;
    const pos = new Float32Array(n * 3), size = new Float32Array(n), seed = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      pos.set([(r() - 0.5) * 60, (r() - 0.5) * 50, (r() - 0.5) * 60], i * 3);
      size[i] = 0.4 + r() * 1.1; seed[i] = r();
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setAttribute("aSize", new THREE.BufferAttribute(size, 1));
    g.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
    const m = this.mat(S.moteVert, S.moteFrag, { uBox: new THREE.Vector3(60, 50, 60), uMoteColor: new THREE.Color(), uMote: 1 }, { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    this.moteMat = m;
    const pts = this.add(new THREE.Points(g, m));
    pts.renderOrder = 5;
    this.disposables.push(g);
  }

  /* ───────────── loop ───────────── */
  resize() {
    const w = this.canvas.clientWidth || window.innerWidth;
    const h = this.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  }

  start() {
    this.last = performance.now();
    let n = 0;
    let running = true;
    const tick = (now: number) => {
      if (this.opts.still == null || n++ < 3) this.raf = requestAnimationFrame(tick);
      else running = false;
      const dt = Math.min(0.1, (now - this.last) / 1000);
      this.last = now;
      this.frame(now / 1000, dt);
    };
    this.raf = requestAnimationFrame(tick);
    if (this.opts.still != null) {
      window.addEventListener("scroll", () => {
        n = 0;
        if (!running) { running = true; this.raf = requestAnimationFrame(tick); }
      });
    }
  }

  private frame(time: number, dt: number) {
    const scrolled = this.opts.getTarget();
    const target = this.opts.still ?? scrolled;
    this.cur = this.opts.reduced || this.opts.still != null ? target : this.cur + (target - this.cur) * (1 - Math.exp(-dt * 5.5));
    const f = sample(this.cur, this.fog, this.moteColor);

    const U = this.U;
    U.uTime.value = this.opts.reduced ? 0 : time;
    (U.uFogColor.value as THREE.Color).copy(this.fog);
    U.uFogDensity.value = f.density;
    U.uSunAmt.value = f.sun;
    U.uShaft.value = f.shaft;
    U.uMyc.value = f.myc;

    const th = THREE.MathUtils.degToRad(f.theta);
    const cam = this.camera;
    const aspect = cam.aspect;
    const narrow = aspect < 0.95;
    const r = f.r * (narrow ? 1.35 : 1);
    cam.position.set(Math.cos(th) * r, f.y, Math.sin(th) * r);
    cam.lookAt(0, f.y + f.lookDy, 0);
    cam.fov = narrow ? 62 : 52;
    cam.filmOffset = narrow ? 0 : -f.film * 9;
    cam.updateProjectionMatrix();

    this.sky.position.copy(cam.position);
    (this.sky.material as THREE.ShaderMaterial).uniforms.uSky.value = f.sky;
    this.seaMats.forEach((m) => (m.uniforms.uSea.value = f.sea));
    this.moteMat.uniforms.uMote.value = f.mote;
    (this.moteMat.uniforms.uMoteColor.value as THREE.Color).copy(this.moteColor);

    this.renderer.render(this.scene, cam);
    this.opts.onFrame(f.y, this.cur);
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener("resize", this.onResize);
    this.disposables.forEach((d) => d.dispose());
    this.renderer.dispose();
  }
}
