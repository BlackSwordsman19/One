import { Color } from "three";

/** OKLCH -> linear sRGB THREE.Color, so the 3D world shares the stylesheet's palette. */
export function oklch(l: number, c: number, h: number): Color {
  const hr = (h * Math.PI) / 180;
  const a = c * Math.cos(hr);
  const b = c * Math.sin(hr);
  const l_ = l + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = l - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = l - 0.0894841775 * a - 1.291485548 * b;
  const L = l_ ** 3;
  const M = m_ ** 3;
  const S = s_ ** 3;
  const r = 4.0767416621 * L - 3.3077115913 * M + 0.2309699292 * S;
  const g = -1.2684380046 * L + 2.6097574011 * M - 0.3413193965 * S;
  const bl = -0.0041960863 * L - 0.7034186147 * M + 1.707614701 * S;
  const cl = (x: number) => Math.min(1, Math.max(0, x));
  // THREE.Color holds linear values when ColorManagement is on; these are already linear.
  const col = new Color();
  col.setRGB(cl(r), cl(g), cl(bl), "srgb-linear");
  return col;
}
