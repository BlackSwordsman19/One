/** GLSL for the forest. Every material shares one fog + light block so the whole descent dims as one. */

export const COMMON = /* glsl */ `
uniform float uTime;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform vec3 uSunDir;
uniform vec3 uSunColor;
uniform float uSunAmt;
uniform float uShaft;
uniform float uMyc;

float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p){
  vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x), mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++) { s += a * vnoise(p); p *= 2.03; a *= 0.5; } return s; }
vec3 applyFog(vec3 c, float d){
  float f = 1.0 - exp(-pow(uFogDensity * d, 2.0));
  return mix(c, uFogColor, clamp(f, 0.0, 1.0));
}
`;

const FRAG_END = /* glsl */ `
  #include <colorspace_fragment>
`;

/* ───────────── trunks ───────────── */
export const trunkVert = /* glsl */ `
attribute vec4 aTree; // x: height, y: base radius, z: seed, w: lean
varying vec3 vW; varying vec3 vN; varying float vAng; varying float vSeed;
uniform float uTime;
void main(){
  float t = position.y;
  vec2 d = position.xz;
  float ang = atan(d.y, d.x);
  float h = aTree.x;
  float taper = pow(1.0 - t, 0.8) * 0.9 + 0.1;
  float flare = 1.0 + 1.5 * exp(-t * h / 2.4);
  float flute = 1.0 + 0.06 * sin(ang * 11.0 + aTree.z * 9.0) + 0.035 * sin(ang * 23.0 + t * 4.0 + aTree.z);
  float r = aTree.y * taper * flare * flute;
  vec3 p = vec3(d.x * r, t * h, d.y * r);
  p.x += aTree.w * t * t * h * 0.02;
  p.xz += vec2(sin(uTime * 0.35 + aTree.z * 7.0), cos(uTime * 0.31 + aTree.z * 5.0)) * 0.35 * t * t;
  vec4 wp = instanceMatrix * vec4(p, 1.0);
  vW = wp.xyz;
  vN = normalize(vec3(d.x, 0.12, d.y));
  vAng = ang; vSeed = aTree.z;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
export const trunkFrag = /* glsl */ `
${COMMON}
uniform vec3 uBarkA; uniform vec3 uBarkB; uniform vec3 uMoss;
varying vec3 vW; varying vec3 vN; varying float vAng; varying float vSeed;
void main(){
  float r1 = vnoise(vec2(vAng * 8.0 + vSeed * 20.0, vW.y * 0.16));
  float r2 = vnoise(vec2(vAng * 31.0 + vSeed * 5.0, vW.y * 0.7));
  float crack = smoothstep(0.35, 0.62, r2);
  vec3 bark = mix(uBarkA, uBarkB, r1 * 0.65 + crack * 0.45);
  bark = mix(bark, uMoss, smoothstep(9.0, 0.0, vW.y) * smoothstep(0.35, 0.8, vnoise(vec2(vAng * 3.0 + vSeed * 9.0, vW.y * 0.35))) * 0.8);
  vec3 N = normalize(vN);
  float diff = max(dot(N, uSunDir), 0.0);
  float wrap = 0.5 + 0.5 * dot(N, uSunDir);
  vec3 light = uFogColor * (0.55 + 0.35 * wrap) + uSunColor * diff * uSunAmt * 1.15;
  vec3 col = bark * light;
  float dist = length(vW - cameraPosition);
  col = applyFog(col, dist);
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── crowns, seedlings (instanced blobs) ───────────── */
export const crownVert = /* glsl */ `
attribute float aSeed;
varying vec3 vW; varying vec3 vN; varying vec3 vL; varying float vSeed;
uniform float uTime;
void main(){
  vec3 p = position;
  float n = sin(p.x * 2.1 + aSeed * 40.0) * sin(p.y * 2.7 + p.z * 1.7) ;
  p += normal * n * 0.18;
  vec4 wp = instanceMatrix * vec4(p, 1.0);
  wp.xz += vec2(sin(uTime * 0.5 + aSeed * 30.0), cos(uTime * 0.43 + aSeed * 21.0)) * 0.12;
  vW = wp.xyz; vL = p; vSeed = aSeed;
  vN = normalize(mat3(instanceMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
export const crownFrag = /* glsl */ `
${COMMON}
uniform vec3 uLeafA; uniform vec3 uLeafB;
varying vec3 vW; varying vec3 vN; varying vec3 vL; varying float vSeed;
void main(){
  vec3 N = normalize(vN);
  float needles = vnoise(vW.xz * 1.7 + vW.y * 0.9) * 0.6 + vnoise(vL.xy * 5.0 + vSeed * 9.0) * 0.4;
  vec3 base = mix(uLeafA, uLeafB, smoothstep(0.1, 0.9, N.y * 0.5 + 0.5) * needles);
  float diff = max(dot(N, uSunDir), 0.0);
  float wrap = 0.5 + 0.5 * dot(N, uSunDir);
  vec3 V = normalize(cameraPosition - vW);
  float rim = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  vec3 light = uFogColor * (1.5 + 1.2 * wrap) + uSunColor * (diff * 1.25 + rim * 0.9) * uSunAmt;
  vec3 col = base * light * (0.65 + 0.7 * needles);
  col = applyFog(col, length(vW - cameraPosition));
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── ground ───────────── */
export const groundVert = /* glsl */ `
varying vec3 vW;
void main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vW = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }`;
export const groundFrag = /* glsl */ `
${COMMON}
uniform vec3 uLoamA; uniform vec3 uLoamB; uniform vec3 uMoss; uniform vec3 uSoil;
varying vec3 vW;
void main(){
  vec2 p = vW.xz;
  float n = fbm(p * 0.3);
  float needles = vnoise(vec2(p.x * 9.0 + p.y * 3.0, p.y * 9.0 - p.x * 2.0));
  vec3 col = mix(uLoamA, uLoamB, n) * (0.7 + 0.5 * needles);
  float moss = smoothstep(0.5, 0.7, fbm(p * 0.11 + 7.0));
  col = mix(col, uMoss * (0.8 + 0.4 * needles), moss * 0.85);
  float dap = smoothstep(0.52, 0.8, fbm(p * 0.2 + vec2(uTime * 0.012, 0.0))) * uShaft;
  col = col * (uFogColor * 2.4 + 0.3) + uSunColor * (dap * 0.6 + 0.04) * uSunAmt;
  float dist = length(vW - cameraPosition);
  if (!gl_FrontFacing) {
    float strata = vnoise(vec2(p.x * 0.4, p.y * 0.4)) * 0.5 + vnoise(p * 3.0) * 0.5;
    col = uSoil * (0.7 + 1.1 * strata) * (0.5 + 1.5 * exp(-dist * 0.05));
  }
  col = applyFog(col, dist);
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── ferns ───────────── */
export const fernVert = /* glsl */ `
varying vec3 vW; varying vec2 vUv; varying float vSeed;
uniform float uTime;
void main(){
  vec4 wp = instanceMatrix * vec4(position, 1.0);
  float seed = hash11(instanceMatrix[3].x * 0.37 + instanceMatrix[3].z * 0.71);
  wp.xz += vec2(sin(uTime * 0.9 + seed * 20.0), cos(uTime * 0.8 + seed * 17.0)) * 0.05 * uv.y;
  vW = wp.xyz; vUv = uv; vSeed = seed;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`.replace("void main", "float hash11(float p){ p = fract(p * .1031); p *= p + 33.33; p *= p + p; return fract(p); }\nvoid main");
export const fernFrag = /* glsl */ `
${COMMON}
uniform sampler2D uTex; uniform vec3 uFernA; uniform vec3 uFernB;
varying vec3 vW; varying vec2 vUv; varying float vSeed;
void main(){
  vec4 t = texture2D(uTex, vUv);
  if (t.a < 0.45) discard;
  vec3 base = mix(uFernA, uFernB, vUv.y * 0.8 + vSeed * 0.3);
  float dap = smoothstep(0.5, 0.78, fbm(vW.xz * 0.22 + vec2(uTime * 0.012, 0.0))) * uShaft;
  vec3 light = uFogColor * (2.6 + 1.6 * vUv.y) + 0.1 + uSunColor * (dap * 1.4 + 0.12) * uSunAmt;
  vec3 col = base * light * (0.7 + 0.5 * t.r);
  col = applyFog(col, length(vW - cameraPosition));
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── mushrooms and logs ───────────── */
export const shroomVert = /* glsl */ `
attribute vec3 aCol; attribute float aCap;
varying vec3 vW; varying vec3 vN; varying vec3 vC; varying float vCap; varying vec3 vL;
void main(){
  vec4 wp = instanceMatrix * vec4(position, 1.0);
  vW = wp.xyz; vN = normalize(mat3(instanceMatrix) * normal); vC = aCol; vCap = aCap; vL = position;
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
export const shroomFrag = /* glsl */ `
${COMMON}
varying vec3 vW; varying vec3 vN; varying vec3 vC; varying float vCap; varying vec3 vL;
void main(){
  vec3 N = normalize(vN);
  float spot = vCap * step(0.8, vnoise(vL.xz * 26.0 + vL.y * 6.0)) * step(0.0, N.y);
  vec3 base = mix(vC, vec3(0.78, 0.74, 0.62), spot);
  float diff = max(dot(N, uSunDir), 0.0);
  vec3 light = uFogColor * (2.6 + 1.0 * N.y) + 0.18 + uSunColor * diff * uSunAmt * 1.0;
  vec3 col = base * light;
  col = applyFog(col, length(vW - cameraPosition));
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

export const logVert = /* glsl */ `
varying vec3 vW; varying vec3 vN; varying vec3 vL;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vW = wp.xyz; vL = position; vN = normalize(mat3(modelMatrix) * normal);
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
export const logFrag = /* glsl */ `
${COMMON}
uniform vec3 uBarkA; uniform vec3 uBarkB; uniform vec3 uMoss; uniform vec3 uAccent;
varying vec3 vW; varying vec3 vN; varying vec3 vL;
void main(){
  vec3 N = normalize(vN);
  float ang = atan(vL.z, vL.x);
  float r1 = vnoise(vec2(ang * 7.0, vL.y * 0.9));
  float r2 = vnoise(vec2(ang * 26.0, vL.y * 3.5));
  vec3 bark = mix(uBarkA, uBarkB, r1 * 0.6 + r2 * 0.5) * 0.8;
  float mossAmt = smoothstep(0.1, 0.7, N.y) * smoothstep(0.3, 0.7, fbm(vW.xz * 1.6 + vW.y));
  bark = mix(bark, uMoss * (0.7 + 0.6 * r2), mossAmt);
  float diff = max(dot(N, uSunDir), 0.0);
  vec3 light = uFogColor * (2.2 + 1.2 * N.y) + 0.12 + uSunColor * diff * uSunAmt * 0.9;
  vec3 col = bark * light;
  // foxfire: a few cells on the shaded flank glow faintly
  float cell = step(0.86, vnoise(vL.xz * 5.0 + vL.y * 7.0)) * smoothstep(0.1, -0.4, N.y);
  col += uAccent * cell * 0.22;
  col = applyFog(col, length(vW - cameraPosition));
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── roots (lit by the glow of the network) ───────────── */
export const rootVert = /* glsl */ `
varying vec3 vW; varying vec3 vN;
void main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vW = wp.xyz; vN = normalize(mat3(modelMatrix) * normal); gl_Position = projectionMatrix * viewMatrix * wp; }`;
export const rootFrag = /* glsl */ `
${COMMON}
uniform vec3 uRootA; uniform vec3 uRootB; uniform vec3 uAccent;
varying vec3 vW; varying vec3 vN;
void main(){
  vec3 N = normalize(vN);
  vec3 V = normalize(cameraPosition - vW);
  float dist = length(vW - cameraPosition);
  float grain = vnoise(vW.xz * 9.0 + vW.y * 11.0);
  vec3 base = mix(uRootA, uRootB, grain);
  float lantern = exp(-dist * 0.04);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 2.5);
  float nv = max(dot(N, V), 0.0);
  vec3 col = base * (0.22 + 0.95 * nv) * lantern * 1.6;
  col += uAccent * fres * 0.1 * uMyc * lantern;
  // above ground this layer is hidden by the soil plane; fade it with the fog anyway
  col = applyFog(col, dist);
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── mycelium network ───────────── */
export const mycLineVert = /* glsl */ `
attribute float aT; attribute float aId; attribute float aSpd;
varying float vT; varying float vId; varying float vSpd; varying float vD;
void main(){
  vT = aT; vId = aId; vSpd = aSpd;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vD = -mv.z;
  gl_Position = projectionMatrix * mv;
}`;
export const mycLineFrag = /* glsl */ `
${COMMON}
uniform vec3 uAccent;
varying float vT; varying float vId; varying float vSpd; varying float vD;
void main(){
  float pulse = pow(0.5 + 0.5 * sin(vT * 38.0 - uTime * (0.8 + vSpd) * 1.6 + vId * 6.283), 8.0);
  float a = (0.2 + pulse * 1.2) * uMyc * exp(-pow(vD * uFogDensity * 0.8, 2.0));
  gl_FragColor = vec4(uAccent * a, a);
  ${FRAG_END}
}`;
export const mycPointVert = /* glsl */ `
attribute float aT; attribute float aId; attribute float aSpd; attribute float aSize;
uniform float uPx;
varying float vT; varying float vId; varying float vSpd; varying float vD;
void main(){
  vT = aT; vId = aId; vSpd = aSpd;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  vD = -mv.z;
  gl_PointSize = clamp(aSize * uPx * 22.0 / vD, 1.5, 26.0);
  gl_Position = projectionMatrix * mv;
}`;
export const mycPointFrag = /* glsl */ `
${COMMON}
uniform vec3 uAccent;
varying float vT; varying float vId; varying float vSpd; varying float vD;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float s = smoothstep(0.5, 0.0, d);
  float pulse = pow(0.5 + 0.5 * sin(vT * 38.0 - uTime * (0.8 + vSpd) * 1.6 + vId * 6.283), 8.0);
  float a = s * s * (0.35 + pulse * 1.4) * uMyc * exp(-pow(vD * uFogDensity * 0.8, 2.0));
  gl_FragColor = vec4(uAccent * a, a);
  ${FRAG_END}
}`;

/* ───────────── light shafts ───────────── */
export const shaftVert = /* glsl */ `
varying vec3 vW; varying vec3 vN; varying float vY; varying float vAng;
void main(){
  vec4 wp = modelMatrix * vec4(position, 1.0);
  vW = wp.xyz; vN = normalize(mat3(modelMatrix) * normal); vY = position.y + 0.5; vAng = atan(position.z, position.x);
  gl_Position = projectionMatrix * viewMatrix * wp;
}`;
export const shaftFrag = /* glsl */ `
${COMMON}
varying vec3 vW; varying vec3 vN; varying float vY; varying float vAng;
void main(){
  vec3 V = normalize(cameraPosition - vW);
  float facing = pow(abs(dot(normalize(vN), V)), 1.6);
  float along = smoothstep(0.0, 0.18, vY) * (1.0 - smoothstep(0.7, 1.0, vY));
  float n = 0.55 + 0.6 * fbm(vec2(vY * 5.0 - uTime * 0.04, vAng * 2.0 + vW.x * 0.02));
  float dist = length(vW - cameraPosition);
  float a = facing * along * n * uShaft * exp(-pow(dist * 0.013, 2.0)) * smoothstep(1.5, 9.0, dist);
  gl_FragColor = vec4(uSunColor * a * 1.1, a * 0.9);
  ${FRAG_END}
}`;

/* ───────────── fog sea ───────────── */
export const seaVert = /* glsl */ `
varying vec3 vW;
void main(){ vec4 wp = modelMatrix * vec4(position, 1.0); vW = wp.xyz; gl_Position = projectionMatrix * viewMatrix * wp; }`;
export const seaFrag = /* glsl */ `
${COMMON}
uniform float uSea; uniform float uLayer; uniform vec3 uSeaLight; uniform vec3 uSeaDark;
varying vec3 vW;
void main(){
  vec2 p = vW.xz * 0.0105 + uLayer * 11.3 + vec2(uTime * 0.0035 * (1.0 + uLayer * 0.3), uTime * 0.0021);
  float n = fbm(p);
  float m = smoothstep(0.22, 0.58, n);
  float dy = abs(cameraPosition.y - vW.y);
  float near = smoothstep(1.0, 16.0, dy);
  float dist = length(vW - cameraPosition);
  float lit = fbm(p * 1.9 + 3.0 + uSunDir.xz * 0.5);
  vec3 col = mix(uSeaDark, uSeaLight, smoothstep(0.25, 0.8, lit));
  float a = m * near * uSea * 0.8 * (1.0 - smoothstep(180.0, 420.0, dist));
  gl_FragColor = vec4(col, a);
  ${FRAG_END}
}`;

/* ───────────── sky ───────────── */
export const skyVert = /* glsl */ `
varying vec3 vDir;
void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0); gl_Position = p.xyww; }`;
export const skyFrag = /* glsl */ `
${COMMON}
uniform vec3 uSkyTop; uniform vec3 uSkyHor; uniform float uSky; uniform vec3 uGlow;
varying vec3 vDir;
void main(){
  vec3 d = normalize(vDir);
  float h = d.y;
  vec3 sky = mix(uSkyHor, uSkyTop, smoothstep(-0.02, 0.55, h));
  vec3 glowDir = normalize(vec3(uSunDir.x, 0.07, uSunDir.z));
  float sd = max(dot(d, glowDir), 0.0);
  float low = 1.0 - smoothstep(0.0, 0.5, h);
  sky += uGlow * (pow(sd, 40.0) * 1.2 + pow(sd, 7.0) * 0.45 + pow(sd, 2.0) * 0.1) * low;
  float band = fbm(vec2(atan(d.z, d.x) * 6.0, h * 14.0));
  sky += uGlow * 0.04 * band * low;
  sky = mix(uFogColor, sky, smoothstep(-0.3, 0.0, h));
  vec3 col = mix(uFogColor, sky, uSky);
  gl_FragColor = vec4(col, 1.0);
  ${FRAG_END}
}`;

/* ───────────── motes (pollen, fog drops, spores) ───────────── */
export const moteVert = /* glsl */ `
attribute float aSize; attribute float aSeed;
uniform float uTime; uniform vec3 uBox; uniform float uPx;
varying float vD; varying float vSeed;
void main(){
  vec3 p = position + vec3(sin(uTime * 0.2 + aSeed * 30.0) * 1.5, -uTime * (0.25 + aSeed * 0.3), cos(uTime * 0.17 + aSeed * 20.0) * 1.5);
  vec3 rel = mod(p - cameraPosition + 0.5 * uBox, uBox) - 0.5 * uBox;
  vec4 mv = viewMatrix * vec4(cameraPosition + rel, 1.0);
  vD = -mv.z; vSeed = aSeed;
  gl_PointSize = clamp(aSize * uPx * 26.0 / max(vD, 0.5), 1.0, 12.0);
  gl_Position = projectionMatrix * mv;
}`;
export const moteFrag = /* glsl */ `
${COMMON}
uniform vec3 uMoteColor; uniform float uMote;
varying float vD; varying float vSeed;
void main(){
  float d = length(gl_PointCoord - 0.5);
  float s = smoothstep(0.5, 0.05, d);
  float tw = 0.55 + 0.45 * sin(uTime * (0.6 + vSeed) + vSeed * 40.0);
  float a = s * uMote * tw * smoothstep(0.5, 4.0, vD) * exp(-pow(vD * 0.03, 2.0));
  gl_FragColor = vec4(uMoteColor * a, a);
  ${FRAG_END}
}`;
