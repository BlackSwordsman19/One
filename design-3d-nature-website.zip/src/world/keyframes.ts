import { Color } from "three";
import { oklch } from "./oklch";

/**
 * One keyframe per section of the page. The camera spirals down one axis
 * (the tallest tree), and the whole atmosphere is interpolated between these.
 */
export interface Key {
  y: number; // camera height in metres
  r: number; // orbit radius around the trunk
  theta: number; // orbit angle, degrees
  lookDy: number; // target height relative to camera (metres)
  film: number; // horizontal framing shift: where the tree sits against the copy
  fog: Color;
  density: number;
  sun: number; // direct light 0..1
  shaft: number; // light-shaft strength
  sky: number; // how much sky shows through
  sea: number; // fog-sea layers
  mote: number;
  moteColor: Color;
  myc: number; // mycelium glow
  ground: number;
}

const k = (o: Omit<Key, "fog" | "moteColor"> & { fog: [number, number, number]; moteColor: [number, number, number] }): Key => ({
  ...o,
  fog: oklch(...o.fog),
  moteColor: oklch(...o.moteColor),
});

export const KEYS: Key[] = [
  // 0 · above the fog, the crown in dawn light
  k({ y: 116, r: 44, theta: 36, lookDy: -9, film: 1, fog: [0.5, 0.045, 195], density: 0.0032, sun: 1, shaft: 0, sky: 1, sea: 1, mote: 0.5, moteColor: [0.9, 0.09, 80], myc: 0, ground: 0 }),
  // 1 · sinking into the fog line
  k({ y: 93, r: 20, theta: 96, lookDy: -4, film: -1, fog: [0.56, 0.04, 192], density: 0.021, sun: 0.9, shaft: 0, sky: 0.4, sea: 1, mote: 0.9, moteColor: [0.92, 0.05, 150], myc: 0, ground: 0 }),
  // 2 · among the crowns
  k({ y: 74, r: 24, theta: 168, lookDy: 0, film: 1, fog: [0.44, 0.05, 182], density: 0.009, sun: 1, shaft: 0.3, sky: 0, sea: 0.5, mote: 0.8, moteColor: [0.9, 0.1, 100], myc: 0, ground: 0 }),
  // 3 · the long bare trunk
  k({ y: 30, r: 12, theta: 238, lookDy: 14, film: -1, fog: [0.36, 0.05, 172], density: 0.0095, sun: 1, shaft: 1, sky: 0, sea: 0, mote: 0.9, moteColor: [0.9, 0.1, 95], myc: 0, ground: 0 }),
  // 4 · the forest floor
  k({ y: 2.4, r: 12, theta: 300, lookDy: -0.7, film: 1, fog: [0.3, 0.05, 165], density: 0.016, sun: 0.9, shaft: 1, sky: 0, sea: 0, mote: 1, moteColor: [0.9, 0.1, 100], myc: 0.15, ground: 1 }),
  // 5 · inside the root zone
  k({ y: -2.4, r: 9, theta: 372, lookDy: -0.4, film: -1, fog: [0.17, 0.03, 60], density: 0.04, sun: 0, shaft: 0, sky: 0, sea: 0, mote: 0.7, moteColor: [0.9, 0.12, 155], myc: 0.7, ground: 1 }),
  // 6 · the network
  k({ y: -4.4, r: 16, theta: 440, lookDy: 0.5, film: 1, fog: [0.13, 0.025, 70], density: 0.026, sun: 0, shaft: 0, sky: 0, sea: 0, mote: 0.8, moteColor: [0.92, 0.14, 158], myc: 1, ground: 1 }),
  // 7 · the whole forest, seen from just under the soil
  k({ y: -0.9, r: 46, theta: 520, lookDy: -3.2, film: 0, fog: [0.13, 0.025, 75], density: 0.009, sun: 0, shaft: 0, sky: 0, sea: 0, mote: 0.6, moteColor: [0.92, 0.14, 158], myc: 1.2, ground: 1 }),
];

const smooth = (t: number) => t * t * (3 - 2 * t);
const ease = (t: number) => 0.4 * t + 0.6 * smooth(t); // mostly eased: the camera lingers at each section

export interface Frame {
  y: number; r: number; theta: number; lookDy: number; film: number;
  density: number; sun: number; shaft: number; sky: number; sea: number; mote: number; myc: number; ground: number;
}

export function sample(s: number, fog: Color, moteColor: Color): Frame {
  const n = KEYS.length - 1;
  const c = Math.min(Math.max(s, 0), n);
  const i = Math.min(Math.floor(c), n - 1);
  const t = ease(c - i);
  const a = KEYS[i];
  const b = KEYS[i + 1];
  const m = (x: number, y: number) => x + (y - x) * t;
  fog.copy(a.fog).lerp(b.fog, t);
  moteColor.copy(a.moteColor).lerp(b.moteColor, t);
  return {
    y: m(a.y, b.y), r: m(a.r, b.r), theta: m(a.theta, b.theta), lookDy: m(a.lookDy, b.lookDy), film: m(a.film, b.film),
    density: m(a.density, b.density), sun: m(a.sun, b.sun), shaft: m(a.shaft, b.shaft), sky: m(a.sky, b.sky),
    sea: m(a.sea, b.sea), mote: m(a.mote, b.mote), myc: m(a.myc, b.myc), ground: m(a.ground, b.ground),
  };
}
