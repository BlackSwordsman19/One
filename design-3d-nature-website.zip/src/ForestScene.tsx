import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useMotionValueEvent, type MotionValue } from "framer-motion";
import { useLayoutEffect, useMemo, useRef } from "react";
import * as THREE from "three";

type ForestSceneProps = {
  progress: MotionValue<number>;
};

const seeded = (seed: number) => {
  const value = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return value - Math.floor(value);
};

function ScrollCamera({ progress }: ForestSceneProps) {
  const invalidate = useThree((state) => state.invalidate);

  useMotionValueEvent(progress, "change", () => invalidate());

  useFrame(({ camera }) => {
    const amount = progress.get();
    const z = 9 - amount * 18;
    const x = Math.sin(amount * Math.PI * 1.1) * 0.42;
    const y = 0.08 + Math.sin(amount * Math.PI) * 0.28;

    camera.position.set(x, y, z);
    camera.lookAt(Math.sin(amount * Math.PI) * 0.34, -0.18 + amount * 0.12, z - 11);
  });

  return null;
}

function TreeTrunks() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => new THREE.CylinderGeometry(0.13, 0.32, 14, 7), []);
  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        vertexColors: true,
        roughness: 1,
        transparent: true,
        opacity: 0.36,
        depthWrite: false,
      }),
    [],
  );
  const trees = useMemo(
    () =>
      Array.from({ length: 20 }, (_, index) => {
        const row = Math.floor(index / 4);
        const lane = index % 4;
        const side = lane < 2 ? -1 : 1;
        return {
          x: side * (4.1 + seeded(index + 1) * 4.6),
          z: 6 - row * 6.1 - seeded(index + 21) * 2.2,
          height: 13 + seeded(index + 42) * 5,
          lean: (seeded(index + 70) - 0.5) * 0.16,
          width: 0.78 + seeded(index + 90) * 0.6,
        };
      }),
    [],
  );

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;

    const transform = new THREE.Object3D();
    trees.forEach((tree, index) => {
      transform.position.set(tree.x, 0, tree.z);
      transform.rotation.set(0, 0, tree.lean);
      transform.scale.set(tree.width, tree.height / 14, tree.width);
      transform.updateMatrix();
      mesh.setMatrixAt(index, transform.matrix);
      mesh.setColorAt(
        index,
        new THREE.Color().setHSL(0.34, 0.12 + seeded(index + 110) * 0.08, 0.15 + seeded(index + 130) * 0.1),
      );
    });

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [trees]);

  return <instancedMesh ref={meshRef} args={[geometry, material, trees.length]} frustumCulled={false} />;
}

function LeafCanopy() {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const geometry = useMemo(() => new THREE.SphereGeometry(1, 8, 6), []);
  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: 0xffffff,
        vertexColors: true,
        roughness: 1,
        transparent: true,
        opacity: 0.62,
        depthWrite: false,
      }),
    [],
  );
  const leaves = useMemo(
    () =>
      Array.from({ length: 88 }, (_, index) => {
        const edge = index % 4;
        const r1 = seeded(index + 180);
        const r2 = seeded(index + 280);
        let x = -8 + r1 * 16;
        let y = -4.8 + r2 * 9.6;

        if (edge === 0) {
          x = -8.2 + r1 * 2.5;
          y = -3.8 + r2 * 8;
        } else if (edge === 1) {
          x = 5.6 + r1 * 2.8;
          y = -4.5 + r2 * 8.5;
        } else if (edge === 2) {
          y = 3.7 + r2 * 2.4;
        } else {
          y = -5.1 - r2 * 0.9;
          if (x < 1.1) x += 3.5;
        }

        return {
          x,
          y,
          z: 4 - r1 * 24,
          size: 0.1 + r2 * 0.13,
          rotation: (r1 - 0.5) * 2.4,
          hue: 0.28 + seeded(index + 390) * 0.08,
          lightness: 0.29 + seeded(index + 420) * 0.17,
        };
      }),
    [],
  );

  useLayoutEffect(() => {
    const mesh = meshRef.current;
    if (!mesh) return;

    const transform = new THREE.Object3D();
    leaves.forEach((leaf, index) => {
      transform.position.set(leaf.x, leaf.y, leaf.z);
      transform.rotation.set(leaf.rotation * 0.24, leaf.rotation * 0.18, leaf.rotation);
      transform.scale.set(leaf.size * 1.8, leaf.size * 0.42, leaf.size * 0.13);
      transform.updateMatrix();
      mesh.setMatrixAt(index, transform.matrix);
      mesh.setColorAt(index, new THREE.Color().setHSL(leaf.hue, 0.3, leaf.lightness));
    });

    mesh.instanceMatrix.needsUpdate = true;
    if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  }, [leaves]);

  return <instancedMesh ref={meshRef} args={[geometry, material, leaves.length]} frustumCulled={false} />;
}

function RootNetwork() {
  const paths = useMemo(() => {
    const rootPaths: Array<Array<[number, number, number]>> = [
      [
        [-8, -5, -14],
        [-5.5, -4.3, -15],
        [-2.4, -5.3, -16],
        [0.3, -4.6, -17],
        [3.6, -5.5, -18],
        [8, -4.6, -19],
      ],
      [
        [-5, -6.5, -15.5],
        [-2.8, -5.6, -16.5],
        [-1.2, -6.4, -17.3],
        [1.2, -5, -18.2],
        [4.8, -6.2, -19.5],
      ],
      [
        [7, -6.2, -15],
        [4.5, -5.4, -16],
        [2.1, -6.1, -17.1],
        [-0.4, -5.2, -18.4],
        [-3.8, -6.3, -19.2],
      ],
    ];

    return rootPaths.map((path) =>
      new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3(path.map(([x, y, z]) => new THREE.Vector3(x, y, z))),
        44,
        0.045,
        5,
        false,
      ),
    );
  }, []);
  const materials = useMemo(
    () => [
      new THREE.MeshBasicMaterial({ color: 0x829568, transparent: true, opacity: 0.42, depthWrite: false }),
      new THREE.MeshBasicMaterial({ color: 0x6b8059, transparent: true, opacity: 0.35, depthWrite: false }),
      new THREE.MeshBasicMaterial({ color: 0x9cae73, transparent: true, opacity: 0.3, depthWrite: false }),
    ],
    [],
  );

  return (
    <group>
      {paths.map((geometry, index) => (
        <mesh key={index} geometry={geometry} material={materials[index]} />
      ))}
    </group>
  );
}

function FloatingPollen() {
  const geometry = useMemo(() => {
    const positions = new Float32Array(210 * 3);
    for (let index = 0; index < 210; index += 1) {
      positions[index * 3] = -8 + seeded(index + 500) * 16;
      positions[index * 3 + 1] = -4.5 + seeded(index + 710) * 9;
      positions[index * 3 + 2] = 4 - seeded(index + 920) * 25;
    }
    const buffer = new THREE.BufferGeometry();
    buffer.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    return buffer;
  }, []);
  const glow = useMemo(() => {
    const size = 32;
    const pixels = new Uint8Array(size * size * 4);
    for (let y = 0; y < size; y += 1) {
      for (let x = 0; x < size; x += 1) {
        const distance = Math.hypot(x - size / 2, y - size / 2);
        const alpha = Math.max(0, Math.min(255, Math.round((1 - distance / 15) * 255)));
        const offset = (y * size + x) * 4;
        pixels[offset] = 255;
        pixels[offset + 1] = 255;
        pixels[offset + 2] = 255;
        pixels[offset + 3] = alpha;
      }
    }
    const texture = new THREE.DataTexture(pixels, size, size, THREE.RGBAFormat);
    texture.minFilter = THREE.LinearFilter;
    texture.magFilter = THREE.LinearFilter;
    texture.needsUpdate = true;
    return texture;
  }, []);
  const material = useMemo(
    () =>
      new THREE.PointsMaterial({
        color: 0xd9e4a0,
        map: glow,
        size: 0.042,
        sizeAttenuation: true,
        transparent: true,
        alphaTest: 0.04,
        opacity: 0.56,
        depthWrite: false,
      }),
    [glow],
  );

  return <points geometry={geometry} material={material} frustumCulled={false} />;
}

function ForestForms({ progress }: ForestSceneProps) {
  const movementRef = useRef<THREE.Group>(null);

  useFrame(() => {
    const amount = progress.get();
    if (!movementRef.current) return;
    movementRef.current.rotation.y = Math.sin(amount * Math.PI) * 0.035;
    movementRef.current.rotation.z = Math.sin(amount * Math.PI * 1.4) * 0.012;
  });

  return (
    <group ref={movementRef}>
      <TreeTrunks />
      <LeafCanopy />
      <RootNetwork />
      <FloatingPollen />
    </group>
  );
}

export default function ForestScene({ progress }: ForestSceneProps) {
  return (
    <div className="journey-canvas" aria-hidden="true">
      <Canvas
        camera={{ position: [0, 0, 9], fov: 52, near: 0.1, far: 60 }}
        dpr={[1, 1.35]}
        frameloop="demand"
        gl={{ alpha: true, antialias: true, powerPreference: "low-power" }}
      >
        <ambientLight intensity={1.15} />
        <directionalLight position={[-4, 8, 6]} intensity={1.1} />
        <ScrollCamera progress={progress} />
        <ForestForms progress={progress} />
      </Canvas>
    </div>
  );
}