// Real-time procedural Web Audio API soundscape engine for Sylva (Fanal Laurel Forest)
// Stems: Canopy rain (foliar drip + mist noise), Ridge wind (resonant bandpass sweep), Granite stream (filtered water murmur)

export interface StemLevels {
  rain: number;   // 0..100
  wind: number;   // 0..100
  stream: number; // 0..100
}

class NatureAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private rainGain: GainNode | null = null;
  private windGain: GainNode | null = null;
  private streamGain: GainNode | null = null;
  private windFilter: BiquadFilterNode | null = null;
  private running = false;
  private lfoTimer: number | null = null;

  public start(levels: StemLevels): boolean {
    try {
      if (!this.ctx) {
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AudioCtx();
      }
      if (this.ctx.state === 'suspended') {
        this.ctx.resume();
      }
      if (this.running) {
        this.setLevels(levels);
        return true;
      }

      const ctx = this.ctx;
      this.masterGain = ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.01, ctx.currentTime);
      this.masterGain.gain.exponentialRampToValueAtTime(0.45, ctx.currentTime + 0.6);
      this.masterGain.connect(ctx.destination);

      // Shared 4-second pink/brown noise buffer
      const bufferSize = ctx.sampleRate * 4;
      const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        output[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.04;
        b6 = white * 0.115926;
      }

      // 1. Canopy Rain Stem (high-shelf + bandpass foliar mist)
      const rainSource = ctx.createBufferSource();
      rainSource.buffer = noiseBuffer;
      rainSource.loop = true;
      const rainFilter = ctx.createBiquadFilter();
      rainFilter.type = 'bandpass';
      rainFilter.frequency.value = 1350;
      rainFilter.Q.value = 0.7;
      this.rainGain = ctx.createGain();
      this.rainGain.gain.value = (levels.rain / 100) * 0.65;
      rainSource.connect(rainFilter);
      rainFilter.connect(this.rainGain);
      this.rainGain.connect(this.masterGain);
      rainSource.start(0);

      // 2. Ridge Wind Stem (slow modulated low bandpass)
      const windSource = ctx.createBufferSource();
      windSource.buffer = noiseBuffer;
      windSource.loop = true;
      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = 'bandpass';
      this.windFilter.frequency.value = 240;
      this.windFilter.Q.value = 2.8;
      this.windGain = ctx.createGain();
      this.windGain.gain.value = (levels.wind / 100) * 0.8;
      windSource.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.masterGain);
      windSource.start(0.5);

      // 3. Granite Stream Stem (warm lowpass + resonant ripple)
      const streamSource = ctx.createBufferSource();
      streamSource.buffer = noiseBuffer;
      streamSource.loop = true;
      const streamFilter = ctx.createBiquadFilter();
      streamFilter.type = 'lowpass';
      streamFilter.frequency.value = 520;
      streamFilter.Q.value = 1.6;
      this.streamGain = ctx.createGain();
      this.streamGain.gain.value = (levels.stream / 100) * 0.7;
      streamSource.connect(streamFilter);
      streamFilter.connect(this.streamGain);
      this.streamGain.connect(this.masterGain);
      streamSource.start(1.2);

      // Gentle breathing modulation for wind frequency
      let phase = 0;
      this.lfoTimer = window.setInterval(() => {
        if (!this.ctx || !this.windFilter || !this.running) return;
        phase += 0.18;
        const targetFreq = 210 + Math.sin(phase) * 75 + Math.cos(phase * 0.43) * 35;
        this.windFilter.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.35);
      }, 250);

      this.running = true;
      return true;
    } catch {
      return false;
    }
  }

  public setLevels(levels: StemLevels) {
    if (!this.ctx || !this.running) return;
    const now = this.ctx.currentTime;
    if (this.rainGain) {
      this.rainGain.gain.setTargetAtTime((levels.rain / 100) * 0.65, now, 0.08);
    }
    if (this.windGain) {
      this.windGain.gain.setTargetAtTime((levels.wind / 100) * 0.8, now, 0.08);
    }
    if (this.streamGain) {
      this.streamGain.gain.setTargetAtTime((levels.stream / 100) * 0.7, now, 0.08);
    }
  }

  public stop() {
    if (this.lfoTimer !== null) {
      clearInterval(this.lfoTimer);
      this.lfoTimer = null;
    }
    if (this.ctx && this.masterGain && this.running) {
      try {
        this.masterGain.gain.setTargetAtTime(0.0001, this.ctx.currentTime, 0.12);
        setTimeout(() => {
          if (this.ctx && this.ctx.state === 'running') {
            this.ctx.suspend();
          }
        }, 220);
      } catch {
        // ignore cleanup error
      }
    }
    this.running = false;
  }

  public isRunning(): boolean {
    return this.running;
  }
}

export const natureAudio = new NatureAudioEngine();
