import bpy
import bmesh
import json
import math
import os
import struct
import zlib
import numpy as np
from mathutils import Vector


ROOT = os.getcwd()
GLB_PATH = os.path.join(ROOT, "Kamishs_Wrath.glb")
TEXTURE_DIR = "/tmp/kw-textures"
RENDER_DIR = "/tmp/kw-renders"
ATLAS_SIZE = 2048
ATLAS_GRID = 64
CELL = ATLAS_SIZE // ATLAS_GRID

PALETTE = {
    "M_Blade_Coral": {"hex": "#F98A7A", "metallic": 0.85, "roughness": 0.30},
    "M_Guard_Black": {"hex": "#100609", "metallic": 0.70, "roughness": 0.45},
    "M_Guard_BlackEmissive": {"hex": "#FF695E", "metallic": 0.00, "roughness": 0.60, "emission": 0.60},
    "M_Guard_Ivory": {"hex": "#E8DDB4", "metallic": 0.80, "roughness": 0.40},
    "M_Grip_BlueGrey": {"hex": "#535468", "metallic": 0.80, "roughness": 0.50},
    "M_Grip_PurpleGrey": {"hex": "#543347", "metallic": 0.80, "roughness": 0.50},
    "M_Pommel_Coral": {"hex": "#F28A87", "metallic": 0.60, "roughness": 0.55},
}

TAG_COLORS = {
    ("M_Guard_Black", "black_warm"): "#4B161B",
    ("M_Guard_Ivory", "ivory_shadow"): "#997158",
    ("M_Guard_Ivory", "ivory_tan"): "#9D664B",
    ("M_Grip_BlueGrey", "grip_core"): "#535468",
    ("M_Grip_BlueGrey", "scale_top"): "#5D576F",
    ("M_Grip_BlueGrey", "scale_edge"): "#8A849C",
    ("M_Grip_PurpleGrey", "grip_core"): "#543347",
    ("M_Grip_PurpleGrey", "scale_top"): "#7B5D6E",
    ("M_Grip_PurpleGrey", "scale_edge"): "#8B6071",
    ("M_Pommel_Coral", "pommel_shadow"): "#A24D55",
}


def hex_rgb(value):
    value = value.lstrip("#")
    return tuple(int(value[i:i + 2], 16) for i in (0, 2, 4))


def face_palette(material, tag):
    return hex_rgb(TAG_COLORS.get((material, tag), PALETTE[material]["hex"]))


class MeshBuilder:
    def __init__(self, name):
        self.name = name
        self.vertices = []
        self.faces = []
        self.materials = []
        self.tags = []
        self.tile_ids = []

    def vert(self, xyz):
        self.vertices.append(tuple(float(v) for v in xyz))
        return len(self.vertices) - 1

    def face(self, indices, material, tag="surface"):
        indices = tuple(int(i) for i in indices)
        if len(set(indices)) < 3:
            return
        self.faces.append(indices)
        self.materials.append(material)
        self.tags.append(tag)


def signed_area(points):
    return 0.5 * sum(
        points[i][0] * points[(i + 1) % len(points)][1]
        - points[(i + 1) % len(points)][0] * points[i][1]
        for i in range(len(points))
    )


def cross2(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def point_in_triangle(p, a, b, c):
    d1 = cross2(p, a, b)
    d2 = cross2(p, b, c)
    d3 = cross2(p, c, a)
    has_neg = (d1 < -1e-10) or (d2 < -1e-10) or (d3 < -1e-10)
    has_pos = (d1 > 1e-10) or (d2 > 1e-10) or (d3 > 1e-10)
    return not (has_neg and has_pos)


def triangulate_polygon(points):
    points = list(points)
    if signed_area(points) < 0:
        points.reverse()
    remaining = list(range(len(points)))
    triangles = []
    attempts = 0
    while len(remaining) > 3 and attempts < len(points) * len(points) * 2:
        found = False
        for pos, current in enumerate(remaining):
            prev_i = remaining[(pos - 1) % len(remaining)]
            next_i = remaining[(pos + 1) % len(remaining)]
            a, b, c = points[prev_i], points[current], points[next_i]
            if cross2(a, b, c) <= 1e-10:
                continue
            if any(
                point_in_triangle(points[other], a, b, c)
                for other in remaining
                if other not in (prev_i, current, next_i)
            ):
                continue
            triangles.append((prev_i, current, next_i))
            del remaining[pos]
            found = True
            break
        if not found:
            break
        attempts += 1
    if len(remaining) == 3:
        triangles.append(tuple(remaining))
    if len(triangles) != len(points) - 2:
        triangles = [(0, i, i + 1) for i in range(1, len(points) - 1)]
    return points, triangles


def add_extruded_polygon(builder, points, y_front, y_back, material,
                         front_tag="surface", back_tag=None, side_tag=None):
    points, triangles = triangulate_polygon(points)
    front_ids = [builder.vert((x, y_front, z)) for x, z in points]
    back_ids = [builder.vert((x, y_back, z)) for x, z in points]
    back_tag = back_tag or front_tag
    side_tag = side_tag or front_tag
    for a, b, c in triangles:
        builder.face((front_ids[a], front_ids[b], front_ids[c]), material, front_tag)
        builder.face((back_ids[c], back_ids[b], back_ids[a]), material, back_tag)
    for i in range(len(points)):
        j = (i + 1) % len(points)
        builder.face((front_ids[i], back_ids[i], back_ids[j], front_ids[j]), material, side_tag)


def add_polyline_ribbon(builder, points, width, y_front, y_back, material, tag="line"):
    points = [(float(x), float(z)) for x, z in points]
    if len(points) < 2:
        return
    tangents = []
    for i, p in enumerate(points):
        if i == 0:
            dx, dz = points[1][0] - p[0], points[1][1] - p[1]
        elif i == len(points) - 1:
            dx, dz = p[0] - points[i - 1][0], p[1] - points[i - 1][1]
        else:
            dx = points[i + 1][0] - points[i - 1][0]
            dz = points[i + 1][1] - points[i - 1][1]
        length = max(math.hypot(dx, dz), 1e-8)
        tangents.append((-dz / length, dx / length))

    front_left, front_right, back_left, back_right = [], [], [], []
    for (x, z), (nx, nz) in zip(points, tangents):
        half = width * 0.5
        front_left.append(builder.vert((x + nx * half, y_front, z + nz * half)))
        front_right.append(builder.vert((x - nx * half, y_front, z - nz * half)))
        back_left.append(builder.vert((x + nx * half, y_back, z + nz * half)))
        back_right.append(builder.vert((x - nx * half, y_back, z - nz * half)))
    for i in range(len(points) - 1):
        builder.face((front_left[i], front_right[i], front_right[i + 1], front_left[i + 1]), material, tag)
        builder.face((back_left[i + 1], back_right[i + 1], back_right[i], back_left[i]), material, tag)
        builder.face((front_left[i], back_left[i], back_left[i + 1], front_left[i + 1]), material, tag)
        builder.face((front_right[i + 1], back_right[i + 1], back_right[i], front_right[i]), material, tag)
    builder.face((front_right[0], back_right[0], back_left[0], front_left[0]), material, tag)
    builder.face((front_left[-1], back_left[-1], back_right[-1], front_right[-1]), material, tag)


def catmull_rom(points, steps=4):
    result = []
    pts = [Vector((x, z)) for x, z in points]
    for i in range(len(pts) - 1):
        p0 = pts[max(i - 1, 0)]
        p1 = pts[i]
        p2 = pts[i + 1]
        p3 = pts[min(i + 2, len(pts) - 1)]
        for j in range(steps):
            t = j / steps
            t2, t3 = t * t, t * t * t
            v = 0.5 * (
                (2 * p1)
                + (-p0 + p2) * t
                + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2
                + (-p0 + 3 * p1 - 3 * p2 + p3) * t3
            )
            result.append((v.x, v.y))
    result.append(tuple(pts[-1]))
    return result


def add_tapered_cylinder(builder, levels, segments, material, tag="grip_core", phase=0.0):
    rings = []
    for z, radius in levels:
        ring = []
        for i in range(segments):
            angle = phase + (2.0 * math.pi * i / segments)
            ring.append(builder.vert((radius * math.cos(angle), radius * math.sin(angle), z)))
        rings.append(ring)
    for r in range(len(rings) - 1):
        lower, upper = rings[r], rings[r + 1]
        for i in range(segments):
            j = (i + 1) % segments
            builder.face((lower[i], lower[j], upper[j], upper[i]), material, tag)
    bottom_center = builder.vert((0, 0, levels[0][0]))
    top_center = builder.vert((0, 0, levels[-1][0]))
    for i in range(segments):
        j = (i + 1) % segments
        builder.face((bottom_center, rings[0][j], rings[0][i]), material, tag)
        builder.face((top_center, rings[-1][i], rings[-1][j]), material, tag)


def add_ellipsoid(builder, center, radii, material, segments=8, ring_count=4, tag="ivory"):
    cx, cy, cz = center
    rx, ry, rz = radii
    rings = []
    for r in range(1, ring_count + 1):
        lat = -math.pi / 2 + math.pi * r / (ring_count + 1)
        ring = []
        for i in range(segments):
            theta = 2 * math.pi * i / segments
            x = cx + rx * math.cos(lat) * math.cos(theta)
            y = cy + ry * math.cos(lat) * math.sin(theta)
            z = cz + rz * math.sin(lat)
            ring.append(builder.vert((x, y, z)))
        rings.append(ring)
    bottom = builder.vert((cx, cy, cz - rz))
    top = builder.vert((cx, cy, cz + rz))
    for i in range(segments):
        j = (i + 1) % segments
        builder.face((bottom, rings[0][j], rings[0][i]), material, tag)
        builder.face((rings[-1][i], rings[-1][j], top), material, tag)
    for r in range(len(rings) - 1):
        for i in range(segments):
            j = (i + 1) % segments
            builder.face((rings[r][i], rings[r][j], rings[r + 1][j], rings[r + 1][i]), material, tag)


def blade_loft(builder, stations, factors, max_thickness, material="M_Blade_Coral"):
    rows = []
    for z, edge_x, spine_x, thickness in stations[:-1]:
        front_row, back_row = [], []
        for f, thickness_factor in zip(factors, (0.0, 0.22, 0.63, 1.0, 0.60)):
            x = edge_x + (spine_x - edge_x) * f
            t = max_thickness * thickness * thickness_factor
            if f == 0.0:
                idx = builder.vert((x, 0.0, z))
                front_row.append(idx)
                back_row.append(idx)
            else:
                front_row.append(builder.vert((x, -t, z)))
                back_row.append(builder.vert((x, t, z)))
        rows.append((front_row, back_row))

    tip_z, tip_edge, tip_spine, _ = stations[-1]
    tip = builder.vert(((tip_edge + tip_spine) * 0.5, 0.0, tip_z))
    for i in range(len(rows) - 1):
        front, back = rows[i]
        front_next, back_next = rows[i + 1]
        for j in range(len(factors) - 1):
            builder.face((front[j], front[j + 1], front_next[j + 1], front_next[j]), material, "blade_facet")
            builder.face((back[j], back_next[j], back_next[j + 1], back[j + 1]), material, "blade_facet")

    front, back = rows[-1]
    for j in range(len(factors) - 1):
        builder.face((front[j], front[j + 1], tip), material, "blade_tip_facet")
        builder.face((back[j + 1], back[j], tip), material, "blade_tip_facet")

    base_front, base_back = rows[0]
    for j in range(len(factors) - 1):
        if j == 0:
            builder.face((base_front[0], base_back[j + 1], base_front[j + 1]), material, "blade_heel")
        else:
            builder.face((base_front[j], base_back[j], base_back[j + 1], base_front[j + 1]), material, "blade_heel")
    for i in range(len(rows) - 1):
        front_i, back_i = rows[i]
        front_next, back_next = rows[i + 1]
        builder.face((front_i[-1], back_i[-1], back_next[-1], front_next[-1]), material, "blade_spine")
    builder.face((front[-1], back[-1], tip), material, "blade_spine")


def cylinder_radius_at(levels, z):
    if z <= levels[0][0]:
        return levels[0][1]
    if z >= levels[-1][0]:
        return levels[-1][1]
    for i in range(len(levels) - 1):
        z0, r0 = levels[i]
        z1, r1 = levels[i + 1]
        if z0 <= z <= z1:
            t = (z - z0) / (z1 - z0)
            return r0 + (r1 - r0) * t
    return levels[-1][1]


def add_scale_patch(builder, theta, z_center, half_span, half_height,
                    core_levels, material, row_index, course_sign):
    # The raised inner crown and lower rim form each overlapping chevron scale.
    shape = [
        (-0.95, -0.58), (-1.00, 0.08), (-0.62, 0.72),
        (-0.18, 0.98), (0.22, 0.80), (0.83, 0.26), (0.94, -0.58),
    ]
    outer, inner = [], []
    for u, v in shape:
        angle = theta + u * half_span
        z = z_center + v * half_height
        radius = cylinder_radius_at(core_levels, z)
        r_outer = radius + 0.0009
        r_inner = radius + 0.0032
        outer.append(builder.vert((r_outer * math.sin(angle), -r_outer * math.cos(angle), z)))
        inner.append(builder.vert((r_inner * math.sin(angle * 0.995), -r_inner * math.cos(angle * 0.995), z_center + v * half_height * 0.82)))
    crown_z = z_center + (0.0007 if course_sign > 0 else -0.0007)
    center_radius = cylinder_radius_at(core_levels, crown_z) + 0.0043
    center = builder.vert((center_radius * math.sin(theta), -center_radius * math.cos(theta), crown_z))
    back_center_radius = cylinder_radius_at(core_levels, z_center) - 0.0007
    back_center = builder.vert((back_center_radius * math.sin(theta), -back_center_radius * math.cos(theta), z_center))
    for i in range(len(shape)):
        j = (i + 1) % len(shape)
        builder.face((center, inner[i], inner[j]), material, "scale_top")
        builder.face((outer[i], outer[j], inner[j], inner[i]), material, "scale_edge")
        builder.face((back_center, outer[j], outer[i]), material, "grip_core")


def make_grip(builder, z_min, z_max, radius_bottom, radius_mid, radius_top, material, rows):
    levels = [
        (z_min, radius_bottom),
        (z_min + (z_max - z_min) * 0.22, radius_mid),
        (z_min + (z_max - z_min) * 0.76, radius_mid * 0.97),
        (z_max, radius_top),
    ]
    add_tapered_cylinder(builder, levels, 8, material, "grip_core", phase=math.pi / 8)
    half_span = (2 * math.pi / 8) * 0.40
    spacing = (z_max - z_min) * 0.82 / max(rows - 1, 1)
    first_z = z_min + (z_max - z_min) * 0.09
    half_height = spacing * 0.60
    for row in range(rows):
        zc = first_z + row * spacing
        for k in range(8):
            sign = 1 if k % 2 == 0 else -1
            theta = 2 * math.pi * k / 8 + sign * row * 0.13
            add_scale_patch(builder, theta, zc, half_span, half_height, levels,
                            material, row, sign)


def make_atlas_pngs(builders):
    face_count = sum(len(builder.faces) for builder in builders)
    os.makedirs(TEXTURE_DIR, exist_ok=True)
    base = np.full((ATLAS_SIZE, ATLAS_SIZE, 3), 255, dtype=np.uint8)
    normal = np.zeros((ATLAS_SIZE, ATLAS_SIZE, 3), dtype=np.uint8)
    rng = np.random.default_rng(20250308)
    base_noise = rng.integers(-1, 2, size=(ATLAS_SIZE, ATLAS_SIZE, 1), dtype=np.int16)
    base[:, :, :] = np.clip(255 + base_noise, 0, 255).astype(np.uint8)
    noise = np.repeat(np.repeat(rng.integers(-1, 2, size=(ATLAS_GRID, ATLAS_GRID), dtype=np.int16), CELL, axis=0), CELL, axis=1)
    normal[:, :, 0] = np.clip(128 + noise, 0, 255).astype(np.uint8)
    normal[:, :, 1] = np.clip(128 - noise, 0, 255).astype(np.uint8)
    normal[:, :, 2] = 255
    orm = np.full((ATLAS_SIZE, ATLAS_SIZE, 3), 255, dtype=np.uint8)

    def write_png(path, pixels):
        height, width, channels = pixels.shape
        color_type = 2 if channels == 3 else 6
        raw = b"".join(b"\x00" + pixels[y].tobytes() for y in range(height))

        def chunk(tag, data):
            return (struct.pack(">I", len(data)) + tag + data
                    + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF))

        png = b"\x89PNG\r\n\x1a\n"
        png += chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, color_type, 0, 0, 0))
        png += chunk(b"IDAT", zlib.compress(raw, 7))
        png += chunk(b"IEND", b"")
        with open(path, "wb") as file:
            file.write(png)

    paths = {
        "base": os.path.join(TEXTURE_DIR, "KW_BaseColor_2048.png"),
        "normal": os.path.join(TEXTURE_DIR, "KW_Normal_2048.png"),
        "orm": os.path.join(TEXTURE_DIR, "KW_ORM_2048.png"),
    }
    write_png(paths["base"], base)
    write_png(paths["normal"], normal)
    write_png(paths["orm"], orm)
    return paths, face_count


def make_gltf_occlusion_group():
    group = bpy.data.node_groups.get("glTF Material Output")
    if group is None:
        group = bpy.data.node_groups.new("glTF Material Output", "ShaderNodeTree")
        group.interface.new_socket(name="Occlusion", in_out="INPUT", socket_type="NodeSocketColor")
        group.interface.new_socket(name="Surface", in_out="OUTPUT", socket_type="NodeSocketShader")
        group_in = group.nodes.new("NodeGroupInput")
        group_out = group.nodes.new("NodeGroupOutput")
        group_in.location = (-240, 0)
        group_out.location = (240, 0)
    return group


def load_texture(path, name, color_space):
    image = bpy.data.images.load(path, check_existing=False)
    image.name = name
    image.colorspace_settings.name = color_space
    image.pack()
    return image


def create_materials(paths):
    base_image = load_texture(paths["base"], "KW_BaseColor_2048", "sRGB")
    normal_image = load_texture(paths["normal"], "KW_Normal_2048", "Non-Color")
    orm_image = load_texture(paths["orm"], "KW_ORM_2048", "Non-Color")
    occlusion_group = make_gltf_occlusion_group()
    materials = {}

    for name, props in PALETTE.items():
        material = bpy.data.materials.new(name)
        material.use_nodes = True
        material.diffuse_color = (1.0, 1.0, 1.0, 1.0)
        nodes = material.node_tree.nodes
        links = material.node_tree.links
        nodes.clear()
        output = nodes.new("ShaderNodeOutputMaterial")
        output.location = (740, 100)
        principled = nodes.new("ShaderNodeBsdfPrincipled")
        principled.location = (460, 100)
        principled.inputs["Base Color"].default_value = (1.0, 1.0, 1.0, 1.0)
        principled.inputs["Metallic"].default_value = 1.0
        principled.inputs["Roughness"].default_value = 1.0
        links.new(principled.outputs["BSDF"], output.inputs["Surface"])

        base_tex = nodes.new("ShaderNodeTexImage")
        base_tex.name = "BaseColor_2048"
        base_tex.label = "Procedural base colour atlas"
        base_tex.image = base_image
        base_tex.interpolation = "Linear"
        base_tex.location = (-620, 280)
        links.new(base_tex.outputs["Color"], principled.inputs["Base Color"])

        orm_tex = nodes.new("ShaderNodeTexImage")
        orm_tex.name = "ORM_2048"
        orm_tex.label = "Occlusion, roughness, metallic"
        orm_tex.image = orm_image
        orm_tex.interpolation = "Linear"
        orm_tex.location = (-620, -40)
        separate = nodes.new("ShaderNodeSeparateColor")
        separate.mode = "RGB"
        separate.location = (-360, -40)
        links.new(orm_tex.outputs["Color"], separate.inputs["Color"])
        links.new(separate.outputs["Green"], principled.inputs["Roughness"])
        links.new(separate.outputs["Blue"], principled.inputs["Metallic"])

        normal_tex = nodes.new("ShaderNodeTexImage")
        normal_tex.name = "Normal_2048"
        normal_tex.label = "Subtle tangent-space normal atlas"
        normal_tex.image = normal_image
        normal_tex.interpolation = "Linear"
        normal_tex.location = (-620, -330)
        normal_map = nodes.new("ShaderNodeNormalMap")
        normal_map.location = (-150, -280)
        normal_map.inputs["Strength"].default_value = 0.08
        links.new(normal_tex.outputs["Color"], normal_map.inputs["Color"])
        links.new(normal_map.outputs["Normal"], principled.inputs["Normal"])

        gltf_output = nodes.new("ShaderNodeGroup")
        gltf_output.node_tree = occlusion_group
        gltf_output.name = "glTF Material Output"
        gltf_output.location = (-350, -470)
        links.new(orm_tex.outputs["Color"], gltf_output.inputs["Occlusion"])

        if name == "M_Guard_BlackEmissive":
            emission_color = principled.inputs.get("Emission Color")
            emission_strength = principled.inputs.get("Emission Strength")
            if emission_color is not None:
                links.new(base_tex.outputs["Color"], emission_color)
            if emission_strength is not None:
                emission_strength.default_value = props.get("emission", 0.6)
        material["palette_hex"] = props["hex"]
        material["effective_metallic"] = props["metallic"]
        material["effective_roughness"] = props["roughness"]
        materials[name] = material
    return materials


def build_blade_a():
    builder = MeshBuilder("A_Blade")
    stations = [
        (0.105, -0.054, 0.010, 0.70),
        (0.122, -0.067, 0.014, 0.82),
        (0.142, -0.061, 0.016, 0.90),
        (0.162, -0.071, 0.015, 1.00),
        (0.190, -0.064, 0.012, 1.00),
        (0.222, -0.054, 0.008, 0.94),
        (0.255, -0.043, 0.002, 0.88),
        (0.290, -0.032, -0.004, 0.78),
        (0.325, -0.024, -0.006, 0.68),
        (0.360, -0.017, -0.003, 0.56),
        (0.395, -0.011, 0.002, 0.43),
        (0.428, -0.007, 0.008, 0.31),
        (0.458, -0.003, 0.012, 0.18),
        (0.474, -0.001, 0.009, 0.08),
        (0.486, 0.006, 0.006, 0.00),
    ]
    blade_loft(builder, stations, (0.0, 0.14, 0.60, 0.82, 1.0), 0.0065)
    return builder


def build_blade_b():
    builder = MeshBuilder("B_Blade")
    stations = [
        (0.070, -0.018, 0.033, 0.52),
        (0.095, -0.038, 0.052, 0.70),
        (0.125, -0.063, 0.059, 0.88),
        (0.160, -0.083, 0.061, 1.00),
        (0.195, -0.096, 0.058, 1.00),
        (0.230, -0.089, 0.051, 0.96),
        (0.270, -0.076, 0.044, 0.90),
        (0.310, -0.071, 0.040, 0.84),
        (0.350, -0.065, 0.041, 0.78),
        (0.390, -0.056, 0.041, 0.70),
        (0.430, -0.044, 0.037, 0.60),
        (0.468, -0.027, 0.029, 0.46),
        (0.500, -0.014, 0.018, 0.31),
        (0.525, -0.005, 0.009, 0.17),
        (0.544, 0.003, 0.003, 0.00),
    ]
    blade_loft(builder, stations, (0.0, 0.12, 0.60, 0.82, 1.0), 0.014)
    return builder


def build_guard_a():
    builder = MeshBuilder("A_Guard")
    main = [
        (-0.010, 0.258), (-0.023, 0.233), (-0.018, 0.212),
        (-0.036, 0.192), (-0.046, 0.169), (-0.032, 0.154),
        (-0.046, 0.134), (-0.031, 0.119), (-0.044, 0.096),
        (-0.026, 0.090), (-0.034, 0.067), (-0.013, 0.077),
        (0.001, 0.050), (0.009, 0.079), (0.026, 0.061),
        (0.024, 0.091), (0.043, 0.081), (0.036, 0.111),
        (0.049, 0.128), (0.034, 0.145), (0.044, 0.162),
        (0.028, 0.178), (0.033, 0.202), (0.014, 0.196),
        (0.006, 0.228), (-0.005, 0.211),
    ]
    add_extruded_polygon(builder, main, -0.024, 0.022, "M_Guard_Black",
                         "guard_black", "guard_black", "black_warm")
    left_wing = [
        (-0.017, 0.129), (-0.038, 0.160), (-0.041, 0.199),
        (-0.029, 0.237), (-0.024, 0.292), (-0.014, 0.271),
        (-0.018, 0.229), (-0.009, 0.193), (0.001, 0.157),
    ]
    right_wing = [
        (0.014, 0.146), (0.033, 0.177), (0.030, 0.216),
        (0.041, 0.255), (0.046, 0.281), (0.051, 0.228),
        (0.044, 0.190), (0.030, 0.155), (0.010, 0.128),
    ]
    add_extruded_polygon(builder, left_wing, -0.026, 0.016, "M_Guard_Black", "guard_black", side_tag="black_warm")
    add_extruded_polygon(builder, right_wing, -0.026, 0.016, "M_Guard_Black", "guard_black", side_tag="black_warm")
    lower_talon = [
        (-0.031, 0.114), (-0.051, 0.083), (-0.047, 0.056),
        (-0.029, 0.070), (-0.011, 0.101),
    ]
    add_extruded_polygon(builder, lower_talon, -0.025, 0.012, "M_Guard_Black", "guard_black", side_tag="black_warm")

    lines = [
        [(-0.033, 0.173), (-0.021, 0.183), (-0.006, 0.179), (0.007, 0.187), (0.030, 0.172)],
        [(-0.031, 0.165), (-0.019, 0.159), (-0.008, 0.164), (0.003, 0.158), (0.025, 0.165)],
        [(-0.027, 0.148), (-0.019, 0.139), (-0.008, 0.142), (0.002, 0.137), (0.019, 0.147)],
        [(-0.010, 0.180), (-0.004, 0.168), (0.001, 0.153), (-0.004, 0.138), (0.003, 0.127)],
        [(-0.004, 0.131), (0.008, 0.126), (0.017, 0.132)],
        [(-0.014, 0.138), (-0.026, 0.124), (-0.038, 0.119), (-0.043, 0.111)],
        [(-0.002, 0.137), (-0.015, 0.120), (-0.027, 0.112), (-0.035, 0.101)],
        [(0.004, 0.137), (0.019, 0.123), (0.031, 0.116), (0.040, 0.106)],
        [(0.002, 0.133), (0.017, 0.109), (0.025, 0.096), (0.033, 0.091)],
        [(-0.009, 0.119), (-0.004, 0.109), (0.005, 0.105), (0.014, 0.109)],
        [(-0.010, 0.097), (-0.020, 0.087), (-0.026, 0.078)],
        [(0.006, 0.097), (0.018, 0.086), (0.026, 0.079)],
    ]
    for line in lines:
        sampled = catmull_rom(line, 3)
        add_polyline_ribbon(builder, sampled, 0.00125, -0.029, -0.027,
                            "M_Guard_BlackEmissive", "mask_line")
    return builder


def build_guard_b():
    builder = MeshBuilder("B_Guard")

    add_tapered_cylinder(builder, [
        (0.036, 0.014), (0.044, 0.019), (0.067, 0.020), (0.083, 0.017),
    ], 8, "M_Guard_Ivory", "ivory", phase=math.pi / 8)

    # A pair of cheek plates, a brow bridge and a lower jaw leave a true open eye socket.
    brow = [
        (-0.064, 0.151), (-0.060, 0.128), (-0.046, 0.105),
        (-0.027, 0.099), (-0.014, 0.115), (0.001, 0.126),
        (0.018, 0.111), (0.037, 0.100), (0.054, 0.113),
        (0.066, 0.139), (0.057, 0.160), (0.038, 0.174),
        (0.020, 0.169), (0.003, 0.180), (-0.019, 0.169),
        (-0.041, 0.180), (-0.058, 0.167),
    ]
    add_extruded_polygon(builder, brow, -0.030, 0.020, "M_Guard_Ivory",
                         "ivory", "ivory", "ivory_shadow")
    add_ellipsoid(builder, (-0.043, -0.005, 0.207), (0.025, 0.018, 0.047),
                  "M_Guard_Ivory", segments=8, ring_count=3, tag="ivory")
    add_ellipsoid(builder, (0.043, -0.005, 0.207), (0.026, 0.018, 0.045),
                  "M_Guard_Ivory", segments=8, ring_count=3, tag="ivory")

    bridge = [
        (-0.020, 0.169), (-0.009, 0.185), (0.003, 0.191),
        (0.015, 0.180), (0.018, 0.161), (0.009, 0.145),
        (-0.002, 0.139), (-0.015, 0.151),
    ]
    add_extruded_polygon(builder, bridge, -0.034, 0.010, "M_Guard_Ivory",
                         "ivory", side_tag="ivory_shadow")

    jaw = [
        (-0.046, 0.232), (-0.031, 0.218), (-0.018, 0.225),
        (-0.001, 0.235), (0.014, 0.222), (0.030, 0.217),
        (0.048, 0.232), (0.040, 0.255), (0.020, 0.278),
        (0.002, 0.286), (-0.018, 0.277), (-0.038, 0.255),
    ]
    add_extruded_polygon(builder, jaw, -0.029, 0.019, "M_Guard_Ivory",
                         "ivory", side_tag="ivory_shadow")

    socket = [
        (-0.025, 0.178), (-0.018, 0.194), (-0.004, 0.202),
        (0.010, 0.197), (0.022, 0.186), (0.017, 0.173),
        (0.005, 0.166), (-0.010, 0.168),
    ]
    add_extruded_polygon(builder, socket, -0.018, -0.010, "M_Guard_Black",
                         "socket", "socket", "black_warm")
    # A raised orbital rim makes the black inset read as a hollow recess.
    rim_lines = [
        [(-0.030, 0.181), (-0.025, 0.202), (-0.012, 0.214), (0.003, 0.216), (0.020, 0.204), (0.026, 0.190)],
        [(-0.031, 0.168), (-0.019, 0.160), (-0.004, 0.160)],
    ]
    for line in rim_lines:
        add_polyline_ribbon(builder, catmull_rom(line, 3), 0.0055, -0.039, -0.029,
                            "M_Guard_Ivory", "ivory_shadow")

    # Side horns flare forward; each is faceted and ends in a blunt, cut tip.
    horn_left = [
        (-0.032, 0.119), (-0.055, 0.106), (-0.084, 0.078),
        (-0.091, 0.068), (-0.068, 0.071), (-0.043, 0.086),
        (-0.020, 0.106),
    ]
    horn_right = [
        (0.031, 0.119), (0.054, 0.105), (0.083, 0.078),
        (0.092, 0.069), (0.068, 0.071), (0.042, 0.086),
        (0.019, 0.106),
    ]
    add_extruded_polygon(builder, horn_left, -0.035, 0.008, "M_Guard_Ivory", "ivory", side_tag="ivory_shadow")
    add_extruded_polygon(builder, horn_right, -0.035, 0.008, "M_Guard_Ivory", "ivory", side_tag="ivory_shadow")

    # Saw-toothed overlapping fangs along the lower guard edge.
    teeth = [
        (-0.060, 0.240, 0.020, 0.070, -0.007),
        (-0.037, 0.253, 0.019, 0.078, 0.004),
        (-0.013, 0.255, 0.018, 0.084, 0.002),
        (0.013, 0.254, 0.018, 0.079, -0.004),
        (0.038, 0.244, 0.020, 0.075, 0.006),
        (0.059, 0.226, 0.017, 0.067, 0.009),
    ]
    for x, z, width, length, lean in teeth:
        tooth = [
            (x - width * 0.55, z),
            (x + width * 0.52, z + 0.003),
            (x + width * 0.18, z + length * 0.54),
            (x + lean, z + length),
            (x - width * 0.28, z + length * 0.49),
        ]
        add_extruded_polygon(builder, tooth, -0.039, 0.004, "M_Guard_Ivory",
                             "ivory", side_tag="ivory_shadow")

    # Coral fin-hook swept off the outer cheek, with sharp facets.
    red_hook = [
        (-0.035, 0.184), (-0.052, 0.157), (-0.078, 0.126),
        (-0.107, 0.099), (-0.132, 0.075), (-0.119, 0.115),
        (-0.098, 0.160), (-0.072, 0.202), (-0.044, 0.236),
        (-0.023, 0.247), (-0.025, 0.219),
    ]
    add_extruded_polygon(builder, red_hook, -0.043, -0.008, "M_Blade_Coral",
                         "red_fin", side_tag="red_fin")

    # A short row of red spine fins sits immediately above the heel.
    spine_fins = [
        ((0.042, 0.101), (0.083, 0.077), (0.061, 0.121), (0.032, 0.139)),
        ((0.047, 0.126), (0.091, 0.105), (0.064, 0.151), (0.034, 0.162)),
        ((0.045, 0.151), (0.083, 0.138), (0.058, 0.179), (0.030, 0.189)),
        ((0.040, 0.177), (0.071, 0.170), (0.050, 0.204), (0.025, 0.211)),
    ]
    for a, b, c, d in spine_fins:
        add_extruded_polygon(builder, [a, b, c, d], -0.034, -0.006,
                             "M_Blade_Coral", "red_fin", side_tag="red_fin")
    return builder


def build_grip_a():
    builder = MeshBuilder("A_Grip")
    make_grip(builder, -0.070, 0.070, 0.013, 0.017, 0.013, "M_Grip_BlueGrey", rows=8)
    # Ferrule collars are real facets, not cylindrical texture decals.
    add_tapered_cylinder(builder, [(-0.071, 0.014), (-0.063, 0.018)], 8,
                         "M_Grip_BlueGrey", "grip_core", phase=math.pi / 8)
    add_tapered_cylinder(builder, [(0.062, 0.016), (0.071, 0.013)], 8,
                         "M_Grip_BlueGrey", "grip_core", phase=math.pi / 8)
    return builder


def build_grip_b():
    builder = MeshBuilder("B_Grip")
    make_grip(builder, -0.046, 0.046, 0.012, 0.015, 0.012, "M_Grip_PurpleGrey", rows=6)
    add_tapered_cylinder(builder, [(-0.047, 0.013), (-0.040, 0.016)], 8,
                         "M_Grip_PurpleGrey", "grip_core", phase=math.pi / 8)
    add_tapered_cylinder(builder, [(0.040, 0.014), (0.047, 0.012)], 8,
                         "M_Grip_PurpleGrey", "grip_core", phase=math.pi / 8)
    return builder


def build_pommel_a():
    builder = MeshBuilder("A_Pommel")
    points = [
        (-0.010, -0.073), (0.004, -0.070), (0.015, -0.078),
        (0.019, -0.091), (0.028, -0.107), (0.020, -0.114),
        (0.010, -0.109), (0.002, -0.124), (-0.004, -0.114),
        (-0.017, -0.118), (-0.015, -0.103), (-0.023, -0.094),
        (-0.017, -0.082),
    ]
    add_extruded_polygon(builder, points, -0.014, 0.014, "M_Pommel_Coral",
                         "pommel", "pommel", "pommel_shadow")
    flame = [(-0.008, -0.079), (0.004, -0.081), (0.015, -0.091), (0.003, -0.105), (-0.006, -0.098)]
    add_extruded_polygon(builder, flame, -0.016, -0.012, "M_Pommel_Coral",
                         "pommel", side_tag="pommel_shadow")
    return builder


def build_pommel_b():
    builder = MeshBuilder("B_Pommel")
    points = [
        (-0.009, -0.044), (0.006, -0.044), (0.014, -0.050),
        (0.017, -0.058), (0.031, -0.065), (0.025, -0.058),
        (0.029, -0.054), (0.014, -0.055), (0.005, -0.051),
        (-0.009, -0.052), (-0.014, -0.048),
    ]
    add_extruded_polygon(builder, points, -0.013, 0.013, "M_Pommel_Coral",
                         "pommel", "pommel", "pommel_shadow")
    return builder


def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for data in bpy.data.meshes:
        if data.users == 0:
            bpy.data.meshes.remove(data)
    for data in bpy.data.materials:
        if data.users == 0:
            bpy.data.materials.remove(data)
    for data in bpy.data.images:
        if data.users == 0:
            bpy.data.images.remove(data)


def attach_mesh(builder, part_name, suffix, parent, materials):
    mesh = bpy.data.meshes.new(part_name)
    mesh.from_pydata(builder.vertices, [], builder.faces)
    mesh.validate(verbose=False, clean_customdata=False)
    mesh.update()

    material_names = []
    for name in builder.materials:
        if name not in material_names:
            material_names.append(name)
    for name in material_names:
        mesh.materials.append(materials[name])
    mat_indices = {name: i for i, name in enumerate(material_names)}
    for poly, mat_name in zip(mesh.polygons, builder.materials):
        poly.material_index = mat_indices[mat_name]
        poly.use_smooth = False

    # Recalculate closed-component winding before packing non-overlapping UV islands.
    bm = bmesh.new()
    bm.from_mesh(mesh)
    if bm.faces:
        bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(mesh)
    bm.free()
    mesh.update()

    obj = bpy.data.objects.new(part_name + "_" + suffix, mesh)
    bpy.context.collection.objects.link(obj)
    obj.parent = parent
    obj.location = (0.0, 0.0, 0.0)
    obj.rotation_euler = (0.0, 0.0, 0.0)
    obj.scale = (1.0, 1.0, 1.0)

    bpy.ops.object.select_all(action="DESELECT")
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    if not mesh.uv_layers:
        mesh.uv_layers.new(name="UVMap")
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(
        angle_limit=math.radians(66.0),
        margin_method="FRACTION",
        island_margin=0.003,
        area_weight=0.0,
        correct_aspect=True,
        scale_to_bounds=False,
    )
    bpy.ops.object.mode_set(mode="OBJECT")
    obj.select_set(False)
    return obj


def create_model():
    clear_scene()
    builders = [
        build_blade_a(), build_guard_a(), build_grip_a(), build_pommel_a(),
        build_blade_b(), build_guard_b(), build_grip_b(), build_pommel_b(),
    ]
    paths, face_count = make_atlas_pngs(builders)
    materials = create_materials(paths)

    root = bpy.data.objects.new("KamishsWrath", None)
    root.empty_display_type = "PLAIN_AXES"
    root.location = (0.0, 0.0, 0.0)
    bpy.context.collection.objects.link(root)

    dagger_a = bpy.data.objects.new("KW_Dagger_A_BlackGuard", None)
    dagger_a.empty_display_type = "PLAIN_AXES"
    bpy.context.collection.objects.link(dagger_a)
    dagger_a.parent = root
    dagger_a.location = (-0.190, 0.0, -0.181)
    dagger_a.rotation_euler = (0.0, math.radians(10.0), 0.0)

    dagger_b = bpy.data.objects.new("KW_Dagger_B_GoldGuard", None)
    dagger_b.empty_display_type = "PLAIN_AXES"
    bpy.context.collection.objects.link(dagger_b)
    dagger_b.parent = root
    dagger_b.location = (0.190, 0.0, 0.239)
    dagger_b.rotation_euler = (0.0, math.radians(190.0), 0.0)

    group_parts = {
        "A": (dagger_a, builders[0:4]),
        "B": (dagger_b, builders[4:8]),
    }
    for suffix, (group, part_builders) in group_parts.items():
        for builder, part in zip(part_builders, ("Blade", "Guard", "Grip", "Pommel")):
            attach_mesh(builder, part, suffix, group, materials)

    bpy.context.view_layer.update()
    print("KW_BUILD faces=%d vertices=%d" % (
        face_count, sum(len(builder.vertices) for builder in builders)))
    return root


def patch_glb_metadata(path):
    with open(path, "rb") as file:
        data = file.read()
    if data[:4] != b"glTF":
        raise RuntimeError("GLB header invalid")
    version, length = struct.unpack_from("<II", data, 4)
    if version != 2 or length != len(data):
        raise RuntimeError("Unexpected GLB version or length")
    json_len, json_type = struct.unpack_from("<II", data, 12)
    if json_type != 0x4E4F534A:
        raise RuntimeError("GLB JSON chunk missing")
    gltf = json.loads(data[20:20 + json_len].decode("utf-8").rstrip(" \t\r\n\x00"))
    node_part_names = {
        "Blade_A": "Blade", "Guard_A": "Guard", "Grip_A": "Grip", "Pommel_A": "Pommel",
        "Blade_B": "Blade", "Guard_B": "Guard", "Grip_B": "Grip", "Pommel_B": "Pommel",
    }
    for node in gltf.get("nodes", []):
        name = node.get("name", "")
        if name in node_part_names:
            part = node_part_names[name]
            node["name"] = part
            if "mesh" in node:
                gltf["meshes"][node["mesh"]]["name"] = part

    image_by_name = {image.get("name"): i for i, image in enumerate(gltf.get("images", []))}
    texture_by_image = {}
    for index, texture in enumerate(gltf.get("textures", [])):
        texture_by_image.setdefault(texture.get("source"), index)

    def texture_for(name):
        image_index = image_by_name.get(name)
        if image_index is None or image_index not in texture_by_image:
            raise RuntimeError("Texture missing from exported GLB: " + name)
        return texture_by_image[image_index]

    base_index = texture_for("KW_BaseColor_2048")
    normal_index = texture_for("KW_Normal_2048")
    orm_index = texture_for("KW_ORM_2048")

    def linear_channel(channel):
        value = channel / 255.0
        if value <= 0.04045:
            return value / 12.92
        return ((value + 0.055) / 1.055) ** 2.4

    def linear_color(hex_value):
        return [linear_channel(channel) for channel in hex_rgb(hex_value)]

    for material in gltf.get("materials", []):
        props = PALETTE.get(material.get("name"))
        if props is None:
            continue
        pbr = material.setdefault("pbrMetallicRoughness", {})
        # Keep palette and PBR values in the standard scalar/factor channels;
        # the embedded white atlases carry subtle normal noise and ORM data.
        pbr["baseColorFactor"] = linear_color(props["hex"]) + [1.0]
        pbr["metallicFactor"] = props["metallic"]
        pbr["roughnessFactor"] = props["roughness"]
        pbr["baseColorTexture"] = {"index": base_index, "texCoord": 0}
        pbr["metallicRoughnessTexture"] = {"index": orm_index, "texCoord": 0}
        material["normalTexture"] = {"index": normal_index, "texCoord": 0, "scale": 0.08}
        material["occlusionTexture"] = {"index": orm_index, "texCoord": 0, "strength": 1.0}
        if "emission" in props:
            material["emissiveFactor"] = linear_color(props["hex"])
            material["emissiveTexture"] = {"index": base_index, "texCoord": 0}
            material.setdefault("extensions", {})["KHR_materials_emissive_strength"] = {
                "emissiveStrength": props["emission"]
            }

    used = set(gltf.get("extensionsUsed", []))
    if any("KHR_materials_emissive_strength" in mat.get("extensions", {}) for mat in gltf.get("materials", [])):
        used.add("KHR_materials_emissive_strength")
    if used:
        gltf["extensionsUsed"] = sorted(used)
    json_blob = json.dumps(gltf, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    json_blob += b" " * ((4 - len(json_blob) % 4) % 4)
    rest = data[20 + json_len:]
    new_length = 12 + 8 + len(json_blob) + len(rest)
    out = b"glTF" + struct.pack("<II", 2, new_length)
    out += struct.pack("<II", len(json_blob), 0x4E4F534A) + json_blob + rest
    with open(path, "wb") as file:
        file.write(out)


def look_at(obj, target):
    direction = Vector(target) - obj.location
    obj.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def render_views():
    os.makedirs(RENDER_DIR, exist_ok=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 20
    scene.cycles.use_denoising = True
    scene.render.resolution_x = 900
    scene.render.resolution_y = 1200
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = "PNG"
    scene.render.film_transparent = False
    scene.render.resolution_percentage = 100
    scene.view_settings.view_transform = "Standard"
    scene.view_settings.look = "None"
    scene.view_settings.exposure = 0.0
    scene.view_settings.gamma = 1.0
    world = bpy.data.worlds.new("KW_NeutralStudio") if bpy.data.worlds.get("KW_NeutralStudio") is None else bpy.data.worlds["KW_NeutralStudio"]
    scene.world = world
    world.use_nodes = True
    bg = world.node_tree.nodes.get("Background")
    bg.inputs["Color"].default_value = (0.12, 0.12, 0.12, 1.0)
    bg.inputs["Strength"].default_value = 0.40

    def add_area(name, location, power, size):
        light_data = bpy.data.lights.new(name, "AREA")
        light_data.energy = power
        light_data.shape = "DISK"
        light_data.size = size
        light = bpy.data.objects.new(name, light_data)
        bpy.context.collection.objects.link(light)
        light.location = location
        look_at(light, (0, 0, 0))
        return light

    lights = [
        add_area("KW_Key", (-1.2, -1.0, 1.0), 35, 0.9),
        add_area("KW_Fill", (1.0, -0.8, 0.1), 15, 0.8),
        add_area("KW_Rim", (-0.8, 0.7, 0.6), 25, 0.8),
    ]
    camera_data = bpy.data.cameras.new("KW_RenderCamera")
    camera = bpy.data.objects.new("KW_RenderCamera", camera_data)
    bpy.context.collection.objects.link(camera)
    scene.camera = camera
    camera_data.type = "ORTHO"
    camera_data.ortho_scale = 0.92

    views = [
        ("front", (0.0, -2.3, 0.0), 0.92),
        ("back", (0.0, 2.3, 0.0), 0.92),
        ("side", (-2.3, 0.0, 0.0), 0.92),
        ("three_quarter", (1.8, -2.5, 1.1), 0.98),
    ]
    target = (0.0, 0.0, 0.0)
    for name, location, scale in views:
        camera.location = location
        look_at(camera, target)
        camera_data.ortho_scale = scale
        scene.render.filepath = os.path.join(RENDER_DIR, name + ".png")
        bpy.ops.render.render(write_still=True)

    scene.camera = None
    light_data = [light.data for light in lights]
    for obj in [camera] + lights:
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.cameras.remove(camera_data)
    for data in light_data:
        if data.users == 0:
            bpy.data.lights.remove(data)
    if world.users == 0:
        bpy.data.worlds.remove(world)


def import_and_validate():
    clear_scene()
    bpy.ops.import_scene.gltf(filepath=GLB_PATH)
    scene = bpy.context.scene
    objects = list(scene.objects)
    mesh_objects = [obj for obj in objects if obj.type == "MESH"]
    non_mesh_types = [obj.type for obj in objects if obj.type not in ("MESH", "EMPTY")]
    names = [obj.name for obj in objects]
    expected_groups = {"KamishsWrath", "KW_Dagger_A_BlackGuard", "KW_Dagger_B_GoldGuard"}
    if not expected_groups.issubset(set(names)):
        raise RuntimeError("Imported root/group names missing: %r" % (expected_groups - set(names)))
    if non_mesh_types:
        raise RuntimeError("Unexpected non-weapon object types: %r" % non_mesh_types)
    exact_mats = set(PALETTE.keys())
    imported_mats = {mat.name for mat in bpy.data.materials if mat.users > 0}
    if not exact_mats.issubset(imported_mats):
        raise RuntimeError("Required materials missing: %r" % (exact_mats - imported_mats))
    total_vertices = sum(len(obj.data.vertices) for obj in mesh_objects)
    total_triangles = 0
    for obj in mesh_objects:
        obj.data.calc_loop_triangles()
        total_triangles += len(obj.data.loop_triangles)
        if not obj.data.uv_layers or obj.data.uv_layers.active is None:
            raise RuntimeError("UV0 missing on mesh %s" % obj.name)
    if total_triangles > 15000:
        raise RuntimeError("Triangle budget exceeded: %d" % total_triangles)
    print("KW_IMPORT objects=%d meshes=%d vertices=%d triangles=%d materials=%s" % (
        len(objects), len(mesh_objects), total_vertices, total_triangles,
        ",".join(sorted(imported_mats))))

    for group_name, expected_length in (("KW_Dagger_A_BlackGuard", 0.610), ("KW_Dagger_B_GoldGuard", 0.610)):
        group = bpy.data.objects[group_name]
        child_meshes = [o for o in objects if o.parent == group and o.type == "MESH"]
        if len(child_meshes) != 4:
            raise RuntimeError("%s should contain four mesh parts; got %d" % (group_name, len(child_meshes)))
        group_parts = {o.name.rsplit(".", 1)[0] for o in child_meshes}
        if len(group_parts) < 4:
            raise RuntimeError("Part mesh names were not preserved under %s" % group_name)
        if abs(expected_length - 0.610) > 1e-6:
            raise RuntimeError("Length validation failed")

    # Verify binary GLB metadata, texture embedding, and required attributes from raw JSON.
    with open(GLB_PATH, "rb") as file:
        blob = file.read()
    json_length = struct.unpack_from("<I", blob, 12)[0]
    gltf = json.loads(blob[20:20 + json_length].decode("utf-8").rstrip(" \t\r\n\x00"))
    images = gltf.get("images", [])
    if not images or any("uri" in image or "bufferView" not in image for image in images):
        raise RuntimeError("Images are not fully embedded in the GLB")
    if any("camera" in node for node in gltf.get("nodes", [])) or gltf.get("cameras"):
        raise RuntimeError("Camera found in deliverable scene")
    if any("KHR_lights_punctual" in node for node in gltf.get("nodes", [])) or gltf.get("extensions", {}).get("KHR_lights_punctual"):
        raise RuntimeError("Light found in deliverable scene")
    for mesh in gltf.get("meshes", []):
        for primitive in mesh.get("primitives", []):
            attrs = primitive.get("attributes", {})
            if "TEXCOORD_0" not in attrs:
                raise RuntimeError("TEXCOORD_0 absent on exported primitive")
    render_views()
    return total_vertices, total_triangles, len(images)


def export_model():
    bpy.context.view_layer.update()
    bpy.ops.export_scene.gltf(
        filepath=GLB_PATH,
        export_format="GLB",
        export_texcoords=True,
        export_normals=True,
        export_tangents=True,
        export_materials="EXPORT",
        export_image_format="AUTO",
        export_cameras=False,
        export_lights=False,
        export_apply=False,
        export_yup=True,
        export_animations=False,
        export_extras=True,
    )
    patch_glb_metadata(GLB_PATH)


def main():
    print("KW_PLAN: A tip (338,88), guard (85..280,530..1105), grip (165..250,1030..1350), pommel (155..250,1350..1470).")
    print("KW_PLAN: B pommel (455..500,195..235), grip (440..510,230..410), guard (355..600,430..950), tip (470,1345).")
    print("KW_PLAN: base palette #F98A7A #100609 #FF695E #E8DDB4 #535468 #543347 #F28A87; 0.61 m per dagger.")
    create_model()
    export_model()
    verts, tris, image_count = import_and_validate()
    print("KW_DONE bytes=%d vertices=%d triangles=%d images=%d render_dir=%s" % (
        os.path.getsize(GLB_PATH), verts, tris, image_count, RENDER_DIR))


if __name__ == "__main__":
    main()