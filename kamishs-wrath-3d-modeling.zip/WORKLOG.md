# Kamish's Wrath — autonomous work log

## Source read and scale decision
- The supplied 720 × 1499 artwork is the only visual source. No third-party model or texture is used.
- Dagger A landmarks used: tip (338,88), edge spur (160,455), black-guard envelope x85–295/y530–1105, grip centre (205,1190), grip y1030–1350, pommel bottom y1470.
- Dagger B landmarks used: pommel y195–235, grip centre (477,320), grip y230–410, ivory-guard envelope x355–600/y430–950, red upper hook toward (640,455), blade spine wave through (370,650)/(400,800)/(380,1100), tip (470,1345).
- Dominant authored albedos: coral blade #F98A7A, near-black guard #100609, red mask #FF695E, ivory guard #E8DDB4, blue-grey grip #535468/#5D576F, purple-grey grip #543347/#7B5D6E, coral pommel #F28A87.
- One shared scale is used for both image tracings: 0.61 / 1382 m per pixel. This preserves their relative proportions and makes A 0.610 m and B approximately 0.508 m overall. The 1.3 m alternative was not used.

## Build plan
1. A: five-sided blade loft, shared single vertex on the cutting edge, stepped spine, forward spur and heel scallops; two concave black talons plus a separate mask mass; inlaid emissive mask ribbons; long tapered grip; split coral flame pommel.
2. B: broader five-sided blade loft with a deeper spine wave and greater spine thickness; independent upper coral hook and spine spikes; ivory skull assembled from concave masses, ridged horns/cheeks, an explicit recessed orbital cup, and separate sharp fangs; shorter grip; hooked coral cap.
3. Both grips: 12-sided cores and two opposing spiral families of closed-rim chevron scale patches. All scale relief is geometry.
4. UVs: smart-projected, triangulated islands in eight dedicated atlas regions with explicit gutters. One procedural 2048² base-colour, tangent-normal and ORM PNG set, packed into the GLB.
5. Export with applied transforms and no studio objects; parse the binary for structural checks; re-import it; render neutral front/back/side/three-quarter views; inspect and iterate.
6. Ship the unchanged binary beside a plain HTML anchor, then run a real browser download/byte-comparison check if Chromium can be installed.

## Iterations
1. **Toolchain and first build:** installed bpy 4.2.0, NumPy and Pillow. Because system APT was unprivileged, downloaded Debian runtime packages into a project-local sysroot. Replaced a fragile native tessellation/bmesh-attribute path with explicit triangles and deterministic ear clipping. Completed GLB export, tangent checks, clean re-import and four renders.
2. **Placement/material/skull correction:** fixed A's grip-origin Z offset; corrected UV-to-image atlas row orientation; replaced a destructive whole-guard boolean with an explicit concave eye-socket cup and rim. Restored the full ivory guard and the black/red material read.
3. **Artwork comparison:** opened the coral channel between A's black talons, corrected B's blade-down rotation so its detailed face is visible without mirroring the spine/edge design, added orbital and nasal relief, and reduced neutral studio light levels to prevent coral washing to peach.
4. **Sharp-tip and landmark audit:** made blade/pommel primitives double-sided so the zero-thickness terminal triangles remain visible; verified front, back, side and three-quarter renders. Projected the supplied landmark coordinates independently onto `renders/landmark_overlay.png` and inspected their alignment.
5. **Final material/export audit:** represented mask emission as #FF695E plus `KHR_materials_emissive_strength` 0.6. Re-exported and repeated binary inspection, re-import, packing checks and all renders successfully.
6. **Budget/normal optimization:** smoothed only the rounded grip cores and scale patches, leaving every blade/guard/horn/fang facet flat. This reduced exported accessor vertices from 13,225 to 8,512 and removed 226,224 bytes without changing the 4,980-triangle silhouette. Repeated all export/re-import/render/UV checks.

## Final automated checks
- Delivered binary: 6,472,856 bytes; SHA-256 `0a7321d2f76d4411367ed894f1442be94fb93ecef0ae116c78754083f0e36677`.
- 4,980 triangles; 3,507 authored welded vertices; 8,512 glTF accessor vertices after UV/tangent splits and flat weapon-facet normals.
- All eight parts have UV0, normals and tangents. UV triangle checks report zero zero-area UVs and zero interior overlap pairs. Eight dedicated atlas regions include 12 px outer gutters and smart-project island margins.
- Three embedded 2048 × 2048 PNG images: base colour, normal and ORM. No external buffer or image URI. Clean re-import produced eight mesh objects and three packed images.
- Root and dagger names, four part names per dagger, seven material names, identity/applied node transforms, no cameras, no lights and no background objects all passed binary assertions.
- A = 0.610000 m; B = 0.507598 m. Shared source scale 0.00044138929088277857 m/artwork pixel.
- Final Playwright Chromium 1.52.0 headless test passed against the production `dist` page. The browser's suggested filename was `Kamishs_Wrath.glb`; source, built and downloaded files were each 6,472,856 bytes with identical SHA-256 `0a7321d2f76d4411367ed894f1442be94fb93ecef0ae116c78754083f0e36677`.
- Browser DOM audit: one body child, one visible `A` element, label `Download .glb`, exact relative href and download attributes, zero scripts, zero stylesheets, zero images/canvas/controls. Root and built `index.html` are each 312 bytes. Full result: `build/download-validation.json`.
- Final `npm run build` succeeded. `dist` contains only `index.html` and `Kamishs_Wrath.glb`.
