import { chromium } from 'playwright-chromium';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const dist = path.join(root, 'dist');
const original = path.join(root, 'Kamishs_Wrath.glb');
const downloaded = path.join(root, 'build', 'browser-download.glb');
const reportPath = path.join(root, 'build', 'download-validation.json');
const sha = data => crypto.createHash('sha256').update(data).digest('hex');
const types = { '.html': 'text/html; charset=utf-8', '.glb': 'model/gltf-binary' };

function ensureChromiumRuntime() {
  const builder = path.join(root, 'tools', 'kw-builder');
  const sysroot = path.join(builder, 'sysroot');
  const libdirs = [
    path.join(sysroot, 'usr', 'lib', 'x86_64-linux-gnu'),
    path.join(sysroot, 'lib', 'x86_64-linux-gnu')
  ];
  process.env.LD_LIBRARY_PATH = [...libdirs, process.env.LD_LIBRARY_PATH || ''].join(':');
  const marker = path.join(here, '.browser-runtime-ready');
  if (fs.existsSync(marker)) return;
  const packages = [
    'libnss3', 'libnspr4', 'libdbus-1-3', 'libatk1.0-0', 'libatk-bridge2.0-0',
    'libatspi2.0-0', 'libxcomposite1', 'libxdamage1', 'libxfixes3', 'libxrandr2',
    'libgbm1', 'libxkbcommon0', 'libasound2', 'libcups2', 'libdrm2', 'libxshmfence1',
    'libwayland-server0', 'libwayland-client0'
  ];
  const fetch = spawnSync('python3', [
    path.join(builder, 'fetch_runtime.py'), path.join(builder, 'apt-state'),
    path.join(builder, 'debs'), ...packages
  ], { stdio: 'inherit' });
  if (fetch.status !== 0) throw new Error('Could not fetch local Chromium runtime packages');
  for (const file of fs.readdirSync(path.join(builder, 'debs')).filter(f => f.endsWith('.deb'))) {
    const extracted = spawnSync('dpkg-deb', ['-x', path.join(builder, 'debs', file), sysroot], { stdio: 'inherit' });
    if (extracted.status !== 0) throw new Error(`Could not extract ${file}`);
  }
  fs.writeFileSync(marker, 'ok\n');
}
ensureChromiumRuntime();
const requests = [];
const server = http.createServer((req, res) => {
  const pathname = new URL(req.url, 'http://localhost').pathname;
  const relative = pathname === '/' ? 'index.html' : decodeURIComponent(pathname.slice(1));
  const file = path.resolve(dist, relative);
  if (!file.startsWith(dist + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404); res.end('Not found'); return;
  }
  const bytes = fs.readFileSync(file);
  res.writeHead(200, {
    'Content-Type': types[path.extname(file)] || 'application/octet-stream',
    'Content-Length': bytes.length,
    'Cache-Control': 'no-store'
  });
  res.end(bytes);
});
let browser;
try {
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;
  browser = await chromium.launch({ headless: true, args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage({ acceptDownloads: true });
  page.on('request', req => requests.push(req.url()));
  const response = await page.goto(`http://127.0.0.1:${port}/index.html`, { waitUntil: 'load' });
  if (!response || response.status() !== 200) throw new Error(`Document HTTP status ${response?.status()}`);
  const structure = await page.evaluate(() => {
    const body = document.body;
    const visible = [...body.querySelectorAll('*')].filter(el => {
      const s = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      return s.display !== 'none' && s.visibility !== 'hidden' && r.width > 0 && r.height > 0;
    });
    const a = body.querySelector('a');
    return {
      bodyChildCount: body.children.length,
      bodyFirstTag: body.firstElementChild?.tagName,
      visibleElements: visible.map(el => el.tagName),
      text: a?.textContent,
      href: a?.getAttribute('href'),
      download: a?.getAttribute('download'),
      scripts: document.scripts.length,
      stylesheets: document.querySelectorAll('link[rel="stylesheet"],style').length,
      imagesCanvasControls: document.querySelectorAll('img,canvas,video,button,input,select,textarea,svg').length
    };
  });
  const expected = {
    bodyChildCount: 1, bodyFirstTag: 'A', visibleElements: ['A'], text: 'Download .glb',
    href: 'Kamishs_Wrath.glb', download: 'Kamishs_Wrath.glb', scripts: 0,
    stylesheets: 0, imagesCanvasControls: 0
  };
  if (JSON.stringify(structure) !== JSON.stringify(expected)) {
    throw new Error(`Plain-page assertion failed: ${JSON.stringify(structure)}`);
  }
  const [download] = await Promise.all([
    page.waitForEvent('download', { timeout: 60000 }),
    page.click('a')
  ]);
  if (download.suggestedFilename() !== 'Kamishs_Wrath.glb') {
    throw new Error(`Wrong downloaded filename: ${download.suggestedFilename()}`);
  }
  const failure = await download.failure();
  if (failure) throw new Error(`Browser download failed: ${failure}`);
  await download.saveAs(downloaded);
  const sourceBytes = fs.readFileSync(original);
  const distBytes = fs.readFileSync(path.join(dist, 'Kamishs_Wrath.glb'));
  const downloadBytes = fs.readFileSync(downloaded);
  const report = {
    browser: 'Playwright Chromium 1.52.0 headless',
    pageUrl: `http://127.0.0.1:${port}/index.html`,
    structure,
    suggestedFilename: download.suggestedFilename(),
    sourceBytes: sourceBytes.length,
    builtBytes: distBytes.length,
    downloadedBytes: downloadBytes.length,
    indexBytes: fs.statSync(path.join(root, 'index.html')).size,
    builtIndexBytes: fs.statSync(path.join(dist, 'index.html')).size,
    sourceSha256: sha(sourceBytes),
    builtSha256: sha(distBytes),
    downloadedSha256: sha(downloadBytes),
    downloadedMatchesSource: downloadBytes.equals(sourceBytes),
    builtMatchesSource: distBytes.equals(sourceBytes),
    requests
  };
  if (!report.downloadedMatchesSource || !report.builtMatchesSource) throw new Error('Downloaded bytes differ from delivered GLB');
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log('[kw-download] PASS', JSON.stringify(report, null, 2));
} catch (error) {
  fs.writeFileSync(reportPath, JSON.stringify({ passed: false, error: String(error), requests }, null, 2));
  throw error;
} finally {
  if (browser) await browser.close();
  await new Promise(resolve => server.close(resolve));
}
