import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import path from 'node:path';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '../..');
const sysroot = path.join(here, 'sysroot');
const aptState = path.join(here, 'apt-state');
const aptCache = path.join(here, 'apt-cache');
const debDir = path.join(here, 'debs');
for (const p of [sysroot, path.join(aptState, 'partial'), path.join(aptCache, 'archives', 'partial'), debDir]) {
  fs.mkdirSync(p, { recursive: true });
}
const libPaths = [
  path.join(sysroot, 'usr', 'lib', 'x86_64-linux-gnu'),
  path.join(sysroot, 'lib', 'x86_64-linux-gnu'),
  path.join(sysroot, 'usr', 'lib'),
  path.join(sysroot, 'lib'),
];
const env = { ...process.env, LD_LIBRARY_PATH: [...libPaths, process.env.LD_LIBRARY_PATH || ''].join(':') };
function execute(cmd, args, options = {}) {
  console.log(`\n[kw-builder] $ ${cmd} ${args.join(' ')}`);
  return spawnSync(cmd, args, { cwd: root, stdio: 'inherit', env, ...options });
}
function run(cmd, args, options = {}) {
  const result = execute(cmd, args, options);
  if (result.status !== 0) throw new Error(`${cmd} exited with ${result.status}`);
  return result;
}
function probe() {
  return spawnSync('python3', ['-c', 'import bpy, numpy, PIL; print(bpy.app.version_string)'], {
    cwd: root, encoding: 'utf8', env
  });
}
function localRuntime() {
  if (fs.existsSync(path.join(here, '.runtime-ready'))) return;
  console.log('[kw-builder] Preparing unprivileged project-local X11 runtime.');
  const opts = [
    '-o', `Dir::State::Lists=${aptState}`,
    '-o', `Dir::Cache=${aptCache}`,
    '-o', 'APT::Get::List-Cleanup=0',
    '-o', 'APT::Sandbox::User=root'
  ];
  run('apt-get', [...opts, 'update']);
  const packages = ['libxrender1', 'libxfixes3', 'libxi6', 'libxkbcommon0', 'libgl1', 'libegl1', 'libglvnd0', 'libglx0', 'libopengl0', 'libx11-6', 'libxext6', 'libxcb1', 'libxau6', 'libxdmcp6', 'libsm6', 'libice6', 'libxxf86vm1'];
  const lz = execute('python3', ['-c', 'import lz4.frame']);
  if (lz.status !== 0) run('python3', ['-m', 'pip', 'install', '--break-system-packages', 'lz4']);
  run('python3', [path.join(here, 'fetch_runtime.py'), aptState, debDir, ...packages]);
  for (const file of fs.readdirSync(debDir).filter(f => f.endsWith('.deb'))) {
    run('dpkg-deb', ['-x', path.join(debDir, file), sysroot]);
  }
  fs.writeFileSync(path.join(here, '.runtime-ready'), 'ok\n');
}
let check = probe();
if (check.status !== 0) {
  console.log('[kw-builder] Initial bpy probe failed:', (check.stderr || '').trim());
  localRuntime();
  check = probe();
}
if (check.status !== 0) {
  console.log('[kw-builder] Installing pinned Blender 4.2 Python toolchain.');
  const pip = execute('python3', ['-m', 'pip', 'install', '--break-system-packages', 'bpy==4.2.0', 'numpy', 'Pillow']);
  if (pip.status !== 0) run('python3', ['-m', 'pip', 'install', 'bpy==4.2.0', 'numpy', 'Pillow']);
  check = probe();
}
if (check.status !== 0) throw new Error(`Blender import still fails: ${check.stderr}`);
console.log(`[kw-builder] Using bpy ${check.stdout.trim()}`);
run('python3', ['-u', path.join(here, 'generate.py')]);
