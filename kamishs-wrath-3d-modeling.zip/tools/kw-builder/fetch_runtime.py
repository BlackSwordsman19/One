import sys
from pathlib import Path
from urllib.request import urlopen
import lz4.frame

state = Path(sys.argv[1])
out = Path(sys.argv[2])
wanted = set(sys.argv[3:])
found = {}
for index in state.glob('*_Packages.lz4'):
    text = lz4.frame.decompress(index.read_bytes()).decode('utf-8')
    for paragraph in text.split('\n\n'):
        fields = {}
        for line in paragraph.splitlines():
            if ': ' in line and not line.startswith(' '):
                key, value = line.split(': ', 1)
                fields[key] = value
        name = fields.get('Package')
        if name in wanted and 'Filename' in fields:
            found[name] = fields['Filename']
missing = wanted - set(found)
if missing:
    raise RuntimeError(f'Packages absent from local indices: {sorted(missing)}')
for name, filename in sorted(found.items()):
    url = 'http://deb.debian.org/debian/' + filename
    target = out / Path(filename).name
    print(f'[kw-runtime] {name}: {url}', flush=True)
    with urlopen(url) as response:
        target.write_bytes(response.read())
