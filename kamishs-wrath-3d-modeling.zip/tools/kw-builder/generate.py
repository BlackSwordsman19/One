import bpy
import bmesh
import math
import os
import json
import struct
import shutil
import hashlib
import random
import sys
from pathlib import Path
from collections import defaultdict
from mathutils import Vector, Matrix
from mathutils.geometry import tessellate_polygon
from bpy_extras.object_utils import world_to_camera_view
import numpy as np
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'Kamishs_Wrath.glb'
PUBLIC = ROOT / 'public'
BUILD = ROOT / 'build'
RENDERS = ROOT / 'renders'
for p in (PUBLIC, BUILD, RENDERS):
    p.mkdir(parents=True, exist_ok=True)

S = 0.61 / 1382.0
ATLAS = 2048
EPS = 1e-9
random.seed(19)

PALETTE = {
    'M_Blade_Coral': {'base': '#F98A7A', 'metallic': 0.85, 'roughness': 0.30},
    'M_Guard_Black': {'base': '#100609', 'metallic': 0.70, 'roughness': 0.45},
    'M_Guard_BlackEmissive': {'base': '#FF695E', 'metallic': 0.0, 'roughness': 0.60},
    'M_Guard_Ivory': {'base': '#E8DDB4', 'metallic': 0.80, 'roughness': 0.40},
    'M_Grip_BlueGrey': {'base': '#535468', 'metallic': 0.80, 'roughness': 0.50},
    'M_Grip_PurpleGrey': {'base': '#543347', 'metallic': 0.80, 'roughness': 0.50},
    'M_Pommel_Coral': {'base': '#F28A87', 'metallic': 0.60, 'roughness': 0.55},
}
MATS = list(PALETTE)
FACE_COLORS = {}

def rgb(hex_color):
    h = hex_color.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def rgba01(hex_color):
    c = rgb(hex_color)
    return (c[0]/255, c[1]/255, c[2]/255, 1.0)

def lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def linear_rgba(hex_color):
    c = rgba01(hex_color)
    return (lin(c[0]), lin(c[1]), lin(c[2]), 1)

def map_a(x, y):
    return Vector(((x - 205.0) * S, 0, (1190.0 - y) * S))

def map_b(x, y):
    # Local X is pre-mirrored because the final blade-down placement rotates about Y.
    # This preserves the artwork's left-spine/right-edge read and the detailed front face.
    return Vector((-(x - 477.0) * S, 0, (y - 320.0) * S))

def ear_clip_indices(points):
    """Deterministic triangulation of a simple CCW polygon in the X/Z plane."""
    remaining = list(range(len(points)))
    result = []
    guard = 0
    def cross(a,b,c):
        return (b.x-a.x)*(c.z-a.z) - (b.z-a.z)*(c.x-a.x)
    def inside(p,a,b,c):
        c1,c2,c3 = cross(a,b,p),cross(b,c,p),cross(c,a,p)
        return c1 >= -1e-11 and c2 >= -1e-11 and c3 >= -1e-11
    while len(remaining) > 3 and guard < 1000:
        guard += 1
        clipped = False
        for k in range(len(remaining)):
            ia,ib,ic = remaining[k-1],remaining[k],remaining[(k+1)%len(remaining)]
            a,b,c = points[ia],points[ib],points[ic]
            if cross(a,b,c) <= 1e-12:
                continue
            if any(inside(points[j],a,b,c) for j in remaining if j not in (ia,ib,ic)):
                continue
            result.append((ia,ib,ic))
            del remaining[k]
            clipped = True
            break
        if not clipped:
            raise ValueError('Guard polygon is self-intersecting or degenerate')
    if len(remaining) == 3:
        result.append(tuple(remaining))
    return result


class MeshBuilder:
    def __init__(self):
        self.verts = []
        self.faces = []
        self.face_mats = []
        self.face_colors = []

    def add_v(self, v):
        self.verts.append(tuple(float(c) for c in v))
        return len(self.verts) - 1

    def add_f(self, indices, mat, color=None):
        indices = tuple(indices)
        # Explicit triangles avoid exporter/operator-dependent ngon triangulation.
        for k in range(1, len(indices)-1):
            self.faces.append((indices[0], indices[k], indices[k+1]))
            self.face_mats.append(mat)
            self.face_colors.append(color or PALETTE[mat]['base'])

    def prism(self, pts, mapper, depth, mat, y=0.0, color=None):
        vv = [mapper(x, z) for x, z in pts]
        area = sum(vv[i].x * vv[(i+1) % len(vv)].z - vv[(i+1) % len(vv)].x * vv[i].z for i in range(len(vv)))
        if area < 0:
            vv.reverse()
        n = len(vv)
        front, back = [], []
        lookup = {}
        for v in vv:
            a = Vector((v.x, y-depth/2, v.z))
            b = Vector((v.x, y+depth/2, v.z))
            front.append(self.add_v(a))
            back.append(self.add_v(b))
            lookup[tuple(round(c, 10) for c in v)] = (front[-1], back[-1])
        triangles = ear_clip_indices(vv)
        for tri in triangles:
            ids = [(front[v], back[v]) for v in tri]
            self.add_f([q[0] for q in ids], mat, color)
            self.add_f([q[1] for q in reversed(ids)], mat, color)
        for i in range(n):
            j = (i+1) % n
            self.add_f((front[i], back[i], back[j], front[j]), mat, color)

    def ridged(self, pts, mapper, depth, mat, y=0.0, color=None, ridge=0.70):
        vv = [mapper(x, z) for x, z in pts]
        area = sum(vv[i].x * vv[(i+1) % len(vv)].z - vv[(i+1) % len(vv)].x * vv[i].z for i in range(len(vv)))
        if area < 0:
            vv.reverse()
        n = len(vv)
        front = [self.add_v((v.x, y-depth/2, v.z)) for v in vv]
        back = [self.add_v((v.x, y+depth/2, v.z)) for v in vv]
        center = sum(vv, Vector((0, 0, 0))) / n
        fc = self.add_v((center.x, y-depth*ridge, center.z))
        bc = self.add_v((center.x, y+depth*ridge, center.z))
        for i in range(n):
            j = (i+1) % n
            self.add_f((front[i], front[j], fc), mat, color)
            self.add_f((back[j], back[i], bc), mat, color)
            self.add_f((front[i], back[i], back[j], front[j]), mat, color)

    def spike(self, base_a, base_b, tip, mapper, depth, mat, y=0.0, color=None):
        a, b, t = mapper(*base_a), mapper(*base_b), mapper(*tip)
        ids = [
            self.add_v((a.x, y-depth/2, a.z)), self.add_v((a.x, y+depth/2, a.z)),
            self.add_v((b.x, y-depth/2, b.z)), self.add_v((b.x, y+depth/2, b.z)),
            self.add_v((t.x, y, t.z)),
        ]
        for f in ((0, 2, 4), (3, 1, 4), (0, 4, 1), (2, 3, 4), (0, 1, 3), (0, 3, 2)):
            self.add_f([ids[i] for i in f], mat, color)

    def ribbon(self, pts, mapper, width, y, mat, color=None):
        for a, b in zip(pts[:-1], pts[1:]):
            va, vb = mapper(*a), mapper(*b)
            d = Vector((vb.x-va.x, 0, vb.z-va.z))
            if d.length < EPS:
                continue
            d.normalize()
            p = Vector((-d.z, 0, d.x)) * width * 0.5
            ids = [
                self.add_v((va.x+p.x, y, va.z+p.z)), self.add_v((va.x-p.x, y, va.z-p.z)),
                self.add_v((vb.x-p.x, y, vb.z-p.z)), self.add_v((vb.x+p.x, y, vb.z+p.z)),
            ]
            self.add_f(ids, mat, color)

    def socket(self, center, rx, rz, mapper):
        """A real eight-sided recessed orbital cup with a forward sharp rim."""
        loops = []
        for scale,y in ((1.32,-0.0255),(1.0,-0.0245),(0.42,-0.0142)):
            loop = []
            for i in range(8):
                a = 2*math.pi*i/8 + math.pi/8
                v = mapper(center[0]+math.cos(a)*rx*scale,center[1]+math.sin(a)*rz*scale)
                loop.append(self.add_v((v.x,y,v.z)))
            loops.append(loop)
        for ring in range(2):
            for i in range(8):
                j=(i+1)%8
                color = '#E8DDB4' if ring == 0 else '#9D664B'
                self.add_f((loops[ring][i],loops[ring][j],loops[ring+1][j],loops[ring+1][i]),'M_Guard_Ivory',color)
        cv=mapper(*center)
        cid=self.add_v((cv.x,-0.0141,cv.z))
        for i in range(8):
            self.add_f((loops[2][i],loops[2][(i+1)%8],cid),'M_Guard_Ivory','#9D664B')


def blade_loft(profile, mapper, thickness, mat='M_Blade_Coral'):
    """Profile rows are image (y, cutting-x, spine-x); the edge is one shared vertex."""
    mb = MeshBuilder()
    rows = []
    for py, edge, spine in profile:
        pe, ps = mapper(edge, py), mapper(spine, py)
        rows.append((pe.z, pe.x, ps.x, py))
    rows.sort(key=lambda r: r[0])
    rings = []
    for k, (z, xe, xs, py) in enumerate(rows[:-1]):
        u = k / max(1, len(rows)-2)
        w = abs(xs-xe)
        taper = min(1.0, max(0.12, w / (0.035 if mapper == map_a else 0.050)))
        t = thickness * (0.55 + 0.45 * math.sin(math.pi*u)) * taper
        xm = xe + (xs-xe)*0.55
        rings.append([
            mb.add_v((xe, 0, z)),
            mb.add_v((xm, -t*0.46, z)),
            mb.add_v((xs, -t, z)),
            mb.add_v((xs, t, z)),
            mb.add_v((xm, t*0.46, z)),
        ])
    for r0, r1 in zip(rings[:-1], rings[1:]):
        for j in range(5):
            mb.add_f((r0[j], r0[(j+1)%5], r1[(j+1)%5], r1[j]), mat)
    mb.add_f(tuple(reversed(rings[0])), mat)
    # The actual needle point is the row having greatest authored +Z.
    tip_row = max((mapper((r[1]+r[2])*0.5, r[0]) for r in profile), key=lambda v: v.z)
    tip_id = mb.add_v((tip_row.x, 0, tip_row.z))
    for j in range(5):
        mb.add_f((rings[-1][j], rings[-1][(j+1)%5], tip_id), mat)
    return mb


def grip_mesh(mapper, length, radius_top, radius_bottom, rows, around, mat, core_color, scale_color, edge_color):
    mb = MeshBuilder()
    sides = 12
    zs = [-length/2 + length*i/7 for i in range(8)]
    rings = []
    for z in zs:
        u = (z + length/2) / length
        r = radius_bottom*(1-u) + radius_top*u
        ring = []
        for j in range(sides):
            a = 2*math.pi*j/sides
            ring.append(mb.add_v((r*math.cos(a), r*math.sin(a), z)))
        rings.append(ring)
    for r0, r1 in zip(rings[:-1], rings[1:]):
        for j in range(sides):
            mb.add_f((r0[j], r0[(j+1)%sides], r1[(j+1)%sides], r1[j]), mat, core_color)
    mb.add_f(tuple(reversed(rings[0])), mat, core_color)
    mb.add_f(rings[-1], mat, core_color)

    # Six-sided concave chevron plates. Each has a raised centre and a real rim.
    shape = [(-0.50, 0.27), (0.0, 0.02), (0.50, 0.27), (0.40, -0.22), (0.0, -0.55), (-0.40, -0.22)]
    step = length / rows
    for hand in (-1, 1):
        for row in range(rows):
            zc = -length/2 + (row+0.52)*step
            u = (zc+length/2)/length
            base_r = radius_bottom*(1-u) + radius_top*u
            for j in range(around):
                angle = 2*math.pi*(j + 0.5*(hand+1))/around + hand*row*0.29
                da = 2*math.pi/around
                # Opposing spirals also oppose the chevron cant.
                cant = hand * 0.18
                top_ids, bottom_ids = [], []
                for tx, tz in shape:
                    zz = zc + (tz + cant*tx)*step*1.28
                    uu = max(0, min(1, (zz+length/2)/length))
                    rr = radius_bottom*(1-uu) + radius_top*uu + 0.00075
                    aa = angle + tx*da*0.92
                    top_ids.append(mb.add_v((rr*math.cos(aa), rr*math.sin(aa), zz)))
                    rr0 = rr - 0.00115
                    bottom_ids.append(mb.add_v((rr0*math.cos(aa), rr0*math.sin(aa), zz)))
                ridge_r = base_r + 0.00215
                center_id = mb.add_v((ridge_r*math.cos(angle), ridge_r*math.sin(angle), zc-step*0.05))
                for k in range(6):
                    mb.add_f((top_ids[k], top_ids[(k+1)%6], center_id), mat, scale_color)
                    mb.add_f((top_ids[k], bottom_ids[k], bottom_ids[(k+1)%6], top_ids[(k+1)%6]), mat, edge_color)
    return mb


def create_object(name, mb, parent, part, dagger):
    print('[kw] create', name, len(mb.verts), 'verts', len(mb.faces), 'faces', flush=True)
    mesh = bpy.data.meshes.new(name + '_Mesh')
    mesh.from_pydata(mb.verts, [], mb.faces)
    print('[kw] from_pydata complete', name, flush=True)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)
    obj.parent = parent
    obj['kw_part'] = part
    obj['kw_dagger'] = dagger
    for m in MATS:
        mesh.materials.append(bpy.data.materials[m])
    FACE_COLORS[name] = list(mb.face_colors)
    for i, p in enumerate(mesh.polygons):
        p.material_index = MATS.index(mb.face_mats[i])
        p.use_smooth = (part == 'Grip')
    print('[kw] triangle/material assignment complete; rounded grip normals' if part == 'Grip' else '[kw] flat faceted normals', name, flush=True)
    return obj


def make_materials():
    for name, spec in PALETTE.items():
        mat = bpy.data.materials.new(name)
        mat.use_nodes = True
        mat.diffuse_color = linear_rgba(spec['base'])
        mat.use_backface_culling = name not in {'M_Guard_Ivory', 'M_Guard_BlackEmissive', 'M_Blade_Coral', 'M_Pommel_Coral'}
        bsdf = mat.node_tree.nodes.get('Principled BSDF')
        bsdf.inputs['Base Color'].default_value = linear_rgba(spec['base'])
        bsdf.inputs['Metallic'].default_value = spec['metallic']
        bsdf.inputs['Roughness'].default_value = spec['roughness']
        if name == 'M_Guard_BlackEmissive':
            bsdf.inputs['Emission Color'].default_value = linear_rgba(spec['base'])
            bsdf.inputs['Emission Strength'].default_value = 0.6


def a_blade():
    # Needle to heel; abrupt left-edge offsets are the spur and shallow scallops.
    return [
        (88,338,338),(120,300,350),(140,282,352),(190,255,318),(230,228,300),
        (270,215,270),(330,197,250),(360,185,235),(430,170,215),
        (455,154,208),(490,160,202),(520,168,195),(560,160,191),
        (590,171,185),(630,158,183),(680,170,180),(720,151,186),
        (760,165,189),(810,156,194),(850,172,198),(900,158,202),
        (940,176,207),(980,160,213),(1030,150,228),
    ]


def b_blade():
    return [
        (500,480,400),(560,610,375),(650,640,370),(720,610,390),
        (800,590,400),(900,560,395),(1000,555,390),(1100,520,380),
        (1200,490,385),(1260,482,410),(1310,476,445),(1345,470,470),
    ]


def build_geometry():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.cameras, bpy.data.lights):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)
    make_materials()
    root = bpy.data.objects.new('KamishsWrath', None)
    bpy.context.collection.objects.link(root)
    root['asset'] = "Kamish's Wrath"
    root['units'] = 'metres; authored local +Z pommel-to-tip before applied placement'
    root['pixel_scale_m'] = S
    da = bpy.data.objects.new('KW_Dagger_A_BlackGuard', None)
    db = bpy.data.objects.new('KW_Dagger_B_GoldGuard', None)
    bpy.context.collection.objects.link(da)
    bpy.context.collection.objects.link(db)
    da.parent = root
    db.parent = root
    da['overall_length_m'] = 0.61
    db['overall_length_m'] = 1150*S
    da['design'] = 'slim recurved fang; black talon guard; blue-grey chevron grip'
    db['design'] = 'broad waved fang; ivory skull guard; purple-grey chevron grip'
    objects = {}

    # A — coral blade, two long black talons, central mask, grip and split flame.
    objects['A_Blade'] = create_object('A_Blade', blade_loft(a_blade(), map_a, 0.0052), da, 'Blade', 'A')
    g = MeshBuilder()
    left_wing = [(188,530),(169,590),(155,650),(141,710),(128,770),(108,825),(118,865),(98,915),(106,955),(88,1015),(85,1070),(102,1105),(120,1065),(141,1020),(150,970),(166,918),(174,860),(166,800),(181,735),(177,670),(188,605),(198,555)]
    right_wing = [(198,535),(230,595),(238,650),(232,700),(252,755),(263,810),(278,855),(265,900),(284,945),(295,995),(274,987),(263,1030),(250,1105),(232,1060),(224,1005),(216,952),(220,890),(229,830),(219,765),(224,690),(213,620)]
    mask = [(184,780),(158,815),(125,835),(135,870),(110,910),(140,930),(126,970),(160,960),(151,1002),(181,985),(204,1032),(229,990),(257,1000),(246,960),(277,971),(263,932),(288,912),(258,886),(272,850),(232,838),(212,800)]
    g.prism(left_wing, map_a, 0.013, 'M_Guard_Black')
    g.prism(right_wing, map_a, 0.014, 'M_Guard_Black')
    g.prism(mask, map_a, 0.022, 'M_Guard_Black')
    # Sharp overlapping brow and cheek plates give the black mass real faceted relief.
    g.ridged([(130,855),(174,832),(191,858),(159,884)], map_a, 0.011, 'M_Guard_Black', y=-0.009)
    g.ridged([(213,854),(235,832),(273,860),(246,885)], map_a, 0.011, 'M_Guard_Black', y=-0.009)
    g.spike((132,930),(157,944),(121,1005), map_a, 0.010, 'M_Guard_Black', y=-0.008)
    g.spike((247,943),(270,928),(280,994), map_a, 0.010, 'M_Guard_Black', y=-0.008)
    lines = [
        [(202,823),(190,844),(202,860),(214,844),(202,823)],
        [(132,877),(155,855),(181,868),(195,850)],
        [(209,850),(229,868),(254,854),(274,879)],
        [(148,896),(169,883),(190,899),(170,916),(148,896)],
        [(213,899),(234,883),(257,896),(236,916),(213,899)],
        [(202,876),(194,913),(207,934),(196,951),(210,966)],
        [(190,930),(163,928),(143,948),(127,979)],
        [(214,931),(239,928),(258,947),(273,976)],
        [(165,960),(181,982),(201,970),(221,984),(240,960)],
        [(177,1000),(191,988),(203,1008),(216,989),(231,1001)],
    ]
    for pts in lines:
        g.ribbon(pts, map_a, 1.65*S, -0.01135, 'M_Guard_BlackEmissive')
        g.ribbon(pts, map_a, 1.65*S, 0.01135, 'M_Guard_BlackEmissive')
    objects['A_Guard'] = create_object('A_Guard', g, da, 'Guard', 'A')
    objects['A_Grip'] = create_object('A_Grip', grip_mesh(map_a, 320*S, 0.0172, 0.0148, 10, 5, 'M_Grip_BlueGrey', '#535468', '#5D576F', '#8A849C'), da, 'Grip', 'A')
    p = MeshBuilder()
    p.prism([(177,1337),(207,1338),(226,1360),(230,1392),(219,1420),(240,1452),(216,1443),(204,1470),(190,1440),(171,1460),(176,1424),(157,1395),(164,1365)], map_a, 0.018, 'M_Pommel_Coral')
    p.ridged([(180,1350),(204,1346),(216,1380),(205,1430),(185,1402)], map_a, 0.012, 'M_Pommel_Coral', y=-0.006)
    p.spike((188,1420),(204,1434),(187,1463), map_a, 0.007, 'M_Pommel_Coral', y=-0.004)
    objects['A_Pommel'] = create_object('A_Pommel', p, da, 'Pommel', 'A')

    # B — broad waved blade, separate upper hook and spine fins.
    objects['B_Blade'] = create_object('B_Blade', blade_loft(b_blade(), map_b, 0.0088), db, 'Blade', 'B')
    g = MeshBuilder()
    # Coral upper hook belongs to the guard assembly in the artwork.
    g.prism([(455,525),(510,505),(574,458),(640,400),(631,468),(652,523),(642,570),(610,614),(551,655),(488,686),(454,646),(480,596)], map_b, 0.014, 'M_Blade_Coral')
    for tri in [((382,515),(399,548),(356,500)),((375,560),(395,590),(348,548)),((371,607),(394,635),(347,590)),((374,655),(397,680),(354,646)),((386,700),(404,722),(365,696))]:
        g.spike(tri[0], tri[1], tri[2], map_b, 0.009, 'M_Blade_Coral')
    # Concave skull foundation: the deep lower saw-tooth silhouette is real outline geometry.
    skull = [(468,445),(507,430),(530,490),(522,540),(558,566),(586,604),(577,650),(600,686),(582,720),(590,750),(563,765),(572,790),(548,791),(553,824),(529,809),(529,850),(505,830),(501,877),(480,850),(463,910),(448,867),(426,925),(421,873),(397,895),(405,850),(380,857),(392,815),(373,785),(386,754),(366,718),(382,683),(371,645),(398,603),(407,556),(439,530),(451,485)]
    g.prism(skull, map_b, 0.027, 'M_Guard_Ivory')
    # Blunt forward horns and rounded cheek lobes, all flat-shaded ridged solids.
    g.ridged([(462,548),(472,455),(480,385),(501,405),(511,461),(500,524),(487,565)], map_b, 0.025, 'M_Guard_Ivory', y=-0.004, ridge=0.78)
    g.ridged([(407,580),(385,625),(365,690),(396,677),(429,637),(447,590)], map_b, 0.024, 'M_Guard_Ivory', y=-0.006, ridge=0.76)
    g.ridged([(526,663),(562,649),(600,638),(588,684),(558,717),(526,710)], map_b, 0.022, 'M_Guard_Ivory', y=-0.008, ridge=0.76)
    g.ridged([(413,666),(450,627),(486,648),(481,705),(448,745),(408,718)], map_b, 0.026, 'M_Guard_Ivory', y=-0.009, ridge=0.80)
    g.ridged([(506,722),(543,697),(575,725),(563,774),(530,800),(497,774)], map_b, 0.024, 'M_Guard_Ivory', y=-0.010, ridge=0.78)
    g.ridged([(423,755),(456,735),(485,768),(477,817),(448,844),(416,810)], map_b, 0.022, 'M_Guard_Ivory', y=-0.008, ridge=0.75)
    # Separate overlapping fangs with single-vertex razor points.
    fangs = [((389,770),(410,779),(391,838)),((417,794),(441,800),(421,874)),((450,812),(475,817),(453,891)),((486,812),(510,807),(501,875)),((520,791),(544,781),(540,848)),((551,755),(574,746),(565,812))]
    for a,b,t in fangs:
        g.spike(a,b,t,map_b,0.018,'M_Guard_Ivory',y=-0.012)
    g.ridged([(477,652),(505,627),(540,638),(557,665),(529,678),(493,674)], map_b, 0.018, 'M_Guard_Ivory', y=-0.015, ridge=0.80)
    g.ridged([(479,720),(508,711),(530,752),(517,791),(500,823),(477,782)], map_b, 0.020, 'M_Guard_Ivory', y=-0.014, ridge=0.82)
    g.socket((513,690),22,29,map_b)
    objects['B_Guard'] = create_object('B_Guard', g, db, 'Guard', 'B')
    objects['B_Grip'] = create_object('B_Grip', grip_mesh(map_b, 180*S, 0.0175, 0.0158, 8, 5, 'M_Grip_PurpleGrey', '#543347', '#7B5D6E', '#8B6071'), db, 'Grip', 'B')
    p = MeshBuilder()
    p.ridged([(454,195),(476,191),(497,210),(501,233),(481,244),(462,230)], map_b, 0.018, 'M_Pommel_Coral', ridge=0.75)
    p.spike((460,204),(472,216),(447,184), map_b, 0.009, 'M_Pommel_Coral')
    p.spike((490,215),(499,228),(514,212), map_b, 0.007, 'M_Pommel_Coral')
    objects['B_Pommel'] = create_object('B_Pommel', p, db, 'Pommel', 'B')

    # Final artwork-inspired floating placement. Every mesh transform is then applied.
    da.rotation_euler = (0, math.radians(9), 0)
    da.location = (-0.105, 0, (749.5-1190)*S)
    db.rotation_euler = (0, math.pi-math.radians(9), 0)
    db.location = (0.090, 0, (749.5-320)*S)
    bpy.context.view_layer.update()
    for obj in objects.values():
        world = obj.matrix_world.copy()
        obj.parent = None
        obj.matrix_world = world
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    da.matrix_world = Matrix.Identity(4)
    db.matrix_world = Matrix.Identity(4)
    root.matrix_world = Matrix.Identity(4)
    for key, obj in objects.items():
        obj.parent = da if key.startswith('A_') else db
        obj.matrix_parent_inverse = Matrix.Identity(4)
        obj.matrix_basis = Matrix.Identity(4)
    return root, da, db, objects


def unwrap_and_validate_uvs(objects):
    uv_report = {}
    for idx, (key, obj) in enumerate(objects.items()):
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        if any(len(p.vertices) > 3 for p in obj.data.polygons):
            bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
        bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.018, area_weight=0.0, correct_aspect=True, scale_to_bounds=True)
        bpy.ops.object.mode_set(mode='OBJECT')
        mesh = obj.data
        uv = mesh.uv_layers.active
        coords = [tuple(l.uv) for l in uv.data]
        minx,maxx = min(x for x,y in coords),max(x for x,y in coords)
        miny,maxy = min(y for x,y in coords),max(y for x,y in coords)
        # Eight independent 512 × 1024 atlas regions; 12 px outside gutters.
        col, row = idx % 4, idx // 4
        tw, th = 0.25, 0.5
        gx, gy = 12/ATLAS, 12/ATLAS
        sx = (tw-2*gx)/max(EPS,maxx-minx)
        sy = (th-2*gy)/max(EPS,maxy-miny)
        for loop in uv.data:
            u,v = loop.uv
            loop.uv = (col*tw+gx+(u-minx)*sx, row*th+gy+(v-miny)*sy)
        zero = 0
        tris = []
        for poly in mesh.polygons:
            pts = [tuple(uv.data[li].uv) for li in poly.loop_indices]
            if len(pts) != 3:
                continue
            area = abs((pts[1][0]-pts[0][0])*(pts[2][1]-pts[0][1])-(pts[1][1]-pts[0][1])*(pts[2][0]-pts[0][0]))*0.5
            if area < 1e-12:
                zero += 1
            tris.append(pts)
        # Exact triangle interior overlap test with a broad-phase grid.
        grid = defaultdict(list)
        cells = 72
        for i,t in enumerate(tris):
            xs,ys = [p[0] for p in t],[p[1] for p in t]
            x0,x1 = max(0,int(min(xs)*cells)),min(cells-1,int(max(xs)*cells))
            y0,y1 = max(0,int(min(ys)*cells)),min(cells-1,int(max(ys)*cells))
            for yy in range(y0,y1+1):
                for xx in range(x0,x1+1):
                    grid[(xx,yy)].append(i)
        pairs = set()
        for ids in grid.values():
            if len(ids) > 1:
                for a in range(len(ids)):
                    for b in range(a+1,len(ids)):
                        pairs.add((ids[a],ids[b]))
        def overlap(a,b):
            for tri in (a,b):
                for i in range(3):
                    p,q = tri[i],tri[(i+1)%3]
                    ax,ay = -(q[1]-p[1]),q[0]-p[0]
                    pa = [ax*x+ay*y for x,y in a]
                    pb = [ax*x+ay*y for x,y in b]
                    if max(pa) <= min(pb)+1e-11 or max(pb) <= min(pa)+1e-11:
                        return False
            return True
        overlaps = sum(1 for i,j in pairs if overlap(tris[i],tris[j]))
        uv_report[key] = {'triangles':len(tris),'zero_area_uv':zero,'overlap_pairs':overlaps,'candidate_pairs':len(pairs)}
        print('[kw] UV',key,uv_report[key])
    return uv_report


def make_atlas(objects):
    base = Image.new('RGB',(ATLAS,ATLAS),(128,128,128))
    normal = Image.new('RGB',(ATLAS,ATLAS),(128,128,255))
    orm = Image.new('RGB',(ATLAS,ATLAS),(255,128,0))
    bd,nd,od = ImageDraw.Draw(base),ImageDraw.Draw(normal),ImageDraw.Draw(orm)
    for idx,(key,obj) in enumerate(objects.items()):
        mesh = obj.data
        uv = mesh.uv_layers.active
        authored_colors = FACE_COLORS.get(key, [])
        use_authored_colors = len(authored_colors) == len(mesh.polygons)
        col,row = idx%4,idx//4
        default = PALETTE[mesh.materials[mesh.polygons[0].material_index].name]['base']
        # Image rows are top-down, whereas UV V is bottom-up.
        image_row = 1-row
        bd.rectangle((col*512,image_row*1024,(col+1)*512-1,(image_row+1)*1024-1),fill=rgb(default))
        od.rectangle((col*512,image_row*1024,(col+1)*512-1,(image_row+1)*1024-1),fill=(255,int(PALETTE[mesh.materials[mesh.polygons[0].material_index].name]['roughness']*255+0.5),int(PALETTE[mesh.materials[mesh.polygons[0].material_index].name]['metallic']*255+0.5)))
        for poly in mesh.polygons:
            mat_name = mesh.materials[poly.material_index].name
            spec = PALETTE[mat_name]
            c = rgba01(spec['base'])
            if use_authored_colors:
                c = rgba01(authored_colors[poly.index])
            color8 = tuple(max(0,min(255,int(v*255+0.5))) for v in c[:3])
            pts = [(uv.data[li].uv.x*(ATLAS-1),(1-uv.data[li].uv.y)*(ATLAS-1)) for li in poly.loop_indices]
            if len(pts) < 3:
                continue
            bd.polygon(pts,fill=color8)
            bd.line(pts+[pts[0]],fill=color8,width=3)
            rough = int(spec['roughness']*255+0.5)
            metal = int(spec['metallic']*255+0.5)
            od.polygon(pts,fill=(255,rough,metal))
            od.line(pts+[pts[0]],fill=(255,rough,metal),width=3)
    # Subtle non-directional surface grain; all broad colour fields remain flat.
    arr = np.asarray(base).astype(np.int16)
    rng = np.random.default_rng(41)
    noise = rng.choice(np.array([-2,-1,0,0,0,1,2],dtype=np.int16),size=(ATLAS,ATLAS,1))
    arr = np.clip(arr+noise,0,255).astype(np.uint8)
    base = Image.fromarray(arr,'RGB')
    narr = np.zeros((ATLAS,ATLAS,3),dtype=np.uint8)
    narr[:,:,0] = np.clip(128+rng.integers(-2,3,(ATLAS,ATLAS)),0,255)
    narr[:,:,1] = np.clip(128+rng.integers(-2,3,(ATLAS,ATLAS)),0,255)
    narr[:,:,2] = 255
    normal = Image.fromarray(narr,'RGB')
    paths = {}
    for name,img in [('BaseColor',base),('Normal',normal),('ORM',orm)]:
        path = BUILD / f'KW_{name}.png'
        img.save(path,optimize=True)
        paths[name] = path
    return paths


def wire_textures(paths):
    images = {}
    for key,path in paths.items():
        img = bpy.data.images.load(str(path),check_existing=True)
        img.name = f'KW_{key}_2048'
        if key != 'BaseColor':
            img.colorspace_settings.name = 'Non-Color'
        img.pack()
        images[key] = img
    occlusion_group = bpy.data.node_groups.new('glTF Material Output','ShaderNodeTree')
    occlusion_group.interface.new_socket(name='Occlusion',in_out='INPUT',socket_type='NodeSocketFloat')
    for name in MATS:
        mat = bpy.data.materials[name]
        nt = mat.node_tree
        bsdf = nt.nodes.get('Principled BSDF')
        nt.links.remove(bsdf.inputs['Base Color'].links[0]) if bsdf.inputs['Base Color'].links else None
        base_node = nt.nodes.new('ShaderNodeTexImage'); base_node.image = images['BaseColor']; base_node.label = 'Embedded 2048 base colour'
        base_node.location = (-650,350)
        nt.links.new(base_node.outputs['Color'],bsdf.inputs['Base Color'])
        orm_node = nt.nodes.new('ShaderNodeTexImage'); orm_node.image = images['ORM']; orm_node.label = 'R=AO G=roughness B=metallic'
        orm_node.location = (-650,0)
        sep = nt.nodes.new('ShaderNodeSeparateColor'); sep.mode = 'RGB'; sep.location = (-380,0)
        nt.links.new(orm_node.outputs['Color'],sep.inputs['Color'])
        nt.links.new(sep.outputs['Green'],bsdf.inputs['Roughness'])
        nt.links.new(sep.outputs['Blue'],bsdf.inputs['Metallic'])
        group = nt.nodes.new('ShaderNodeGroup'); group.node_tree = occlusion_group; group.location = (-100,-220)
        nt.links.new(sep.outputs['Red'],group.inputs['Occlusion'])
        normal_node = nt.nodes.new('ShaderNodeTexImage'); normal_node.image = images['Normal']; normal_node.location = (-650,-350)
        normal_map = nt.nodes.new('ShaderNodeNormalMap'); normal_map.location = (-340,-330)
        normal_map.inputs['Strength'].default_value = 0.22
        nt.links.new(normal_node.outputs['Color'],normal_map.inputs['Color'])
        nt.links.new(normal_map.outputs['Normal'],bsdf.inputs['Normal'])


def export_glb(root,da,db,objects):
    bpy.ops.object.select_all(action='DESELECT')
    for o in [root,da,db,*objects.values()]:
        o.select_set(True)
    bpy.context.view_layer.objects.active = root
    bpy.ops.export_scene.gltf(
        filepath=str(OUT),export_format='GLB',use_selection=True,
        export_apply=True,export_texcoords=True,export_normals=True,export_tangents=True,
        export_materials='EXPORT',export_image_format='AUTO',export_cameras=False,export_lights=False,
        export_extras=True,export_yup=True,export_animations=False,export_skins=False,
        export_morph=False,export_force_sampling=True,
    )


def patch_glb(path):
    raw = path.read_bytes()
    magic,version,total = struct.unpack_from('<4sII',raw,0)
    assert magic == b'glTF' and version == 2 and total == len(raw)
    jlen,jtype = struct.unpack_from('<II',raw,12)
    assert jtype == 0x4E4F534A
    doc = json.loads(raw[20:20+jlen].decode('utf-8'))
    rest = raw[20+jlen:]
    for node in doc.get('nodes',[]):
        extras = node.get('extras',{})
        if 'kw_part' in extras:
            node['name'] = extras['kw_part']
        if 'mesh' in node:
            mesh = doc['meshes'][node['mesh']]
            if 'kw_part' in extras:
                mesh['name'] = extras['kw_part']
    for material in doc.get('materials',[]):
        if material.get('name') == 'M_Guard_BlackEmissive':
            material['emissiveFactor'] = list(linear_rgba('#FF695E')[:3])
            material.setdefault('extensions',{})['KHR_materials_emissive_strength'] = {'emissiveStrength':0.6}
    used = doc.setdefault('extensionsUsed',[])
    if 'KHR_materials_emissive_strength' not in used:
        used.append('KHR_materials_emissive_strength')
    doc.setdefault('asset',{})['extras'] = {
        'title': "Kamish's Wrath",
        'source': 'Procedurally modelled solely from the supplied artwork landmarks',
        'scale': '0.61 m Dagger A; shared image scale; metres; glTF Y-up',
        'localAuthoringAxis': '+Z pommel to tip before final applied placement',
    }
    payload = json.dumps(doc,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    payload += b' ' * ((-len(payload)) % 4)
    result = struct.pack('<4sII',b'glTF',2,12+8+len(payload)+len(rest)) + struct.pack('<II',len(payload),0x4E4F534A) + payload + rest
    path.write_bytes(result)
    return doc


def inspect_glb(path):
    raw = path.read_bytes()
    jlen = struct.unpack_from('<I',raw,12)[0]
    doc = json.loads(raw[20:20+jlen].decode('utf-8'))
    bin_start = 20+jlen+8
    bin_data = raw[bin_start:]
    prim_vertices = prim_triangles = 0
    missing = []
    for mesh in doc.get('meshes',[]):
        for p in mesh['primitives']:
            attrs = p['attributes']
            prim_vertices += doc['accessors'][attrs['POSITION']]['count']
            prim_triangles += doc['accessors'][p['indices']]['count']//3 if 'indices' in p else doc['accessors'][attrs['POSITION']]['count']//3
            for req in ('POSITION','NORMAL','TEXCOORD_0','TANGENT'):
                if req not in attrs:
                    missing.append(f"{mesh.get('name')}:{req}")
    external = [b['uri'] for b in doc.get('buffers',[]) if 'uri' in b]
    external += [i['uri'] for i in doc.get('images',[]) if 'uri' in i]
    texture_info = []
    for image in doc.get('images',[]):
        if 'bufferView' in image:
            bv = doc['bufferViews'][image['bufferView']]
            offset = bv.get('byteOffset',0)
            data = bin_data[offset:offset+bv['byteLength']]
            import io
            im = Image.open(io.BytesIO(data))
            texture_info.append({'name':image.get('name'),'size':list(im.size),'format':im.format,'mime':image.get('mimeType')})
    root_nodes = [n for n in doc.get('nodes',[]) if n.get('name') == 'KamishsWrath']
    hierarchy = []
    if root_nodes:
        root_idx = doc['nodes'].index(root_nodes[0])
        for ci in root_nodes[0].get('children',[]):
            child = doc['nodes'][ci]
            hierarchy.append({'name':child.get('name'),'parts':[doc['nodes'][p].get('name') for p in child.get('children',[])]})
    report = {
        'file':path.name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),
        'generator':doc.get('asset',{}).get('generator'),'vertices_glb_accessors':prim_vertices,'triangles':prim_triangles,
        'materials':[m['name'] for m in doc.get('materials',[])],
        'material_details':doc.get('materials',[]),
        'hierarchy':hierarchy,'scenes':doc.get('scenes'),'cameras':len(doc.get('cameras',[])),
        'lights_extension':doc.get('extensions',{}).get('KHR_lights_punctual'),
        'external_resources':external,'missing_attributes':missing,'textures':texture_info,
        'nodes':[{'name':n.get('name'),'translation':n.get('translation'),'rotation':n.get('rotation'),'scale':n.get('scale'),'matrix':n.get('matrix')} for n in doc.get('nodes',[])],
    }
    assert not external, external
    assert not missing, missing
    assert prim_triangles <= 15000, prim_triangles
    assert set(report['materials']) == set(MATS), report['materials']
    assert report['cameras'] == 0 and not report['lights_extension']
    assert len(hierarchy) == 2
    assert [h['name'] for h in hierarchy] == ['KW_Dagger_A_BlackGuard','KW_Dagger_B_GoldGuard']
    assert all(set(h['parts']) == {'Blade','Guard','Grip','Pommel'} and len(h['parts']) == 4 for h in hierarchy), hierarchy
    return report


def render_reimport(path):
    # The renders below are made from a clean import of the actual delivered binary.
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.gltf(filepath=str(path))
    imported_meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    image_states = [{'name':im.name,'packed':bool(im.packed_file),'size':list(im.size)} for im in bpy.data.images if im.source != 'VIEWER']
    scene = bpy.context.scene
    scene.render.engine = 'CYCLES'
    scene.cycles.samples = 32
    scene.cycles.use_denoising = True
    scene.render.resolution_x = 700
    scene.render.resolution_y = 900
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'PNG'
    scene.render.film_transparent = False
    scene.world = bpy.data.worlds.new('Neutral grey studio')
    scene.world.use_nodes = True
    bg = scene.world.node_tree.nodes.get('Background')
    bg.inputs['Color'].default_value = (0.24,0.24,0.24,1)
    bg.inputs['Strength'].default_value = 0.35
    def area(name,loc,power,size):
        data = bpy.data.lights.new(name,'AREA')
        data.energy = power
        data.shape = 'DISK'
        data.size = size
        ob = bpy.data.objects.new(name,data)
        scene.collection.objects.link(ob)
        ob.location = loc
        ob.rotation_euler = (Vector((0,0,0))-ob.location).to_track_quat('-Z','Y').to_euler()
    area('Studio key',(-0.55,-0.75,0.85),25,0.65)
    area('Studio fill',(0.65,-0.45,0.15),12,0.55)
    area('Studio top',(0.1,0.55,0.8),20,0.50)
    data = bpy.data.cameras.new('Inspection camera')
    cam = bpy.data.objects.new('Inspection camera',data)
    scene.collection.objects.link(cam)
    data.type = 'ORTHO'
    data.ortho_scale = 0.78
    scene.camera = cam
    views = {
        'front':(0,-1.55,0),
        'back':(0,1.55,0),
        'side':(1.55,0,0.02),
        'three_quarter':(0.88,-1.35,0.38),
    }
    for name,loc in views.items():
        cam.location = loc
        cam.rotation_euler = (Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
        scene.render.filepath = str(RENDERS / f'{name}.png')
        bpy.ops.render.render(write_still=True)
    # Independent landmark audit: project the supplied artwork coordinates, not mesh vertices.
    cam.location = views['front']
    cam.rotation_euler = (Vector((0,0,0))-cam.location).to_track_quat('-Z','Y').to_euler()
    bpy.context.view_layer.update()
    overlay = Image.open(RENDERS/'front.png').convert('RGB')
    draw = ImageDraw.Draw(overlay)
    ma = Matrix.Translation((-0.105,0,(749.5-1190)*S)) @ Matrix.Rotation(math.radians(9),4,'Y')
    mb = Matrix.Translation((0.090,0,(749.5-320)*S)) @ Matrix.Rotation(math.pi-math.radians(9),4,'Y')
    landmarks = [
        ('A tip',(338,88),map_a,ma),('A spur',(160,455),map_a,ma),('A guard L',(85,1070),map_a,ma),
        ('A guard R',(295,995),map_a,ma),('A grip top',(205,1030),map_a,ma),('A grip end',(205,1350),map_a,ma),
        ('A pommel',(204,1470),map_a,ma),('B pommel',(455,195),map_b,mb),('B hook',(640,455),map_b,mb),
        ('B spine',(370,650),map_b,mb),('B wave',(400,800),map_b,mb),('B edge',(555,1000),map_b,mb),
        ('B guard L',(365,690),map_b,mb),('B guard R',(600,686),map_b,mb),('B tip',(470,1345),map_b,mb),
    ]
    for label,pt,mapper,mat in landmarks:
        projected = world_to_camera_view(scene,cam,mat @ mapper(*pt))
        x,y = projected.x*overlay.width,(1-projected.y)*overlay.height
        draw.ellipse((x-4,y-4,x+4,y+4),outline=(60,240,220),width=2)
        draw.text((x+6,y-5),label,fill=(235,255,250))
    overlay.save(RENDERS/'landmark_overlay.png')
    return {'imported_mesh_objects':len(imported_meshes),'imported_images':image_states,'render_views':list(views),'landmark_overlay':'landmark_overlay.png'}


def main():
    print('[kw] Blender',bpy.app.version_string,'scale',S)
    root,da,db,objects = build_geometry()
    source_counts = {k:{'vertices':len(o.data.vertices),'polygons_pre_triangulation':len(o.data.polygons)} for k,o in objects.items()}
    uv_report = unwrap_and_validate_uvs(objects)
    paths = make_atlas(objects)
    wire_textures(paths)
    export_glb(root,da,db,objects)
    patch_glb(OUT)
    report = inspect_glb(OUT)
    report['scale_m_per_artwork_pixel'] = S
    report['overall_length_m'] = {'KW_Dagger_A_BlackGuard':0.61,'KW_Dagger_B_GoldGuard':1150*S}
    report['source_counts'] = source_counts
    report['vertices_authored_welded'] = sum(v['vertices'] for v in source_counts.values())
    report['uv_validation'] = uv_report
    report['palette'] = PALETTE
    report['blender_version'] = bpy.app.version_string
    # Ship the exact validated bytes to the web-served public directory as well.
    shutil.copy2(OUT,PUBLIC / OUT.name)
    assert hashlib.sha256(OUT.read_bytes()).hexdigest() == hashlib.sha256((PUBLIC/OUT.name).read_bytes()).hexdigest()
    report['reimport'] = render_reimport(OUT)
    (BUILD / 'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('[kw] FINAL VALIDATION',json.dumps({k:report[k] for k in ('bytes','vertices_glb_accessors','triangles','textures','hierarchy')},indent=2))
    print('[kw] Wrote',OUT,'and',PUBLIC/OUT.name,flush=True)
    # Some bpy wheel builds crash in native module destructors after a successful run.
    # All deliverables and validation data are complete and flushed at this point.
    sys.stdout.flush(); sys.stderr.flush()
    os._exit(0)

if __name__ == '__main__':
    main()
