import {useEffect, useRef, useState} from 'react';
import * as THREE from 'three';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {RectAreaLightUniformsLib} from 'three/addons/lights/RectAreaLightUniformsLib.js';
import {
  computeResponsiveCameraDistanceScale,
  evaluateScrollPose,
} from '../scene/choreography';
import {buildF1Car, F1CarRig} from '../scene/f1CarBuilder';
import {createF1Materials} from '../scene/materials';

interface F1CanvasStageProps {
  scrollProgress: number;
  reducedMotion: boolean;
  activeChapterId: string;
  forceFallback?: boolean;
}

const _targetCamPos = new THREE.Vector3();
const _targetLookAt = new THREE.Vector3();
const _currentLookAt = new THREE.Vector3(0, 0.42, 0.1);

function detectSoftwareWebGL(): boolean {
  try {
    const probeCanvas = document.createElement('canvas');
    const gl = probeCanvas.getContext('webgl2') || probeCanvas.getContext('webgl');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param) ?? '');
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function F1CanvasStage({
  scrollProgress,
  reducedMotion,
  activeChapterId,
  forceFallback = false,
}: F1CanvasStageProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const progressRef = useRef(scrollProgress);
  const reducedMotionRef = useRef(reducedMotion);
  const requestRenderRef = useRef<(() => void) | null>(null);

  const [webglFailed, setWebglFailed] = useState(forceFallback);

  useEffect(() => {
    progressRef.current = scrollProgress;
    requestRenderRef.current?.();
  }, [scrollProgress]);

  useEffect(() => {
    reducedMotionRef.current = reducedMotion;
    requestRenderRef.current?.();
  }, [reducedMotion]);

  useEffect(() => {
    if (forceFallback) {
      setWebglFailed(true);
      return;
    }

    const container = containerRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    let renderer: THREE.WebGLRenderer;

    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        powerPreference: 'high-performance',
        alpha: false,
        preserveDrawingBuffer: true,
      });
    } catch {
      setWebglFailed(true);
      return;
    }

    const canvas = renderer.domElement;
    canvas.style.display = 'block';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.setAttribute('aria-label', 'Interactive 3D Formula 1 race car');
    container.appendChild(canvas);

    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(
      isSoftwareGl ? 1 : Math.min(window.devicePixelRatio || 1, 2),
    );
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x08080a);
    scene.fog = new THREE.FogExp2(0x08080a, 0.048);

    const width = Math.max(container.clientWidth, 1);
    const height = Math.max(container.clientHeight, 1);
    const camera = new THREE.PerspectiveCamera(36, width / height, 0.1, 80);

    // Mandatory studio environment reflection map on all devices
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const roomEnv = new RoomEnvironment();
    const envTarget = pmremGenerator.fromScene(roomEnv, 0.04);
    scene.environment = envTarget.texture;
    roomEnv.dispose();
    pmremGenerator.dispose();

    // Balanced 3-point lighting with warm key & cool hemisphere fill
    const hemiLight = new THREE.HemisphereLight(0xa3c2f0, 0x181316, 0.9);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xfff1de, 2.7);
    keyLight.position.set(5.5, 7.5, 5.5);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.set(1024, 1024);
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 22;
    const d = 4.5;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLightCool = new THREE.DirectionalLight(0xc7dcff, 1.35);
    rimLightCool.position.set(-5.5, 4.2, -5.0);
    scene.add(rimLightCool);

    const rimLightRed = new THREE.SpotLight(0xe10600, 12, 18, Math.PI / 4, 0.7, 1.5);
    rimLightRed.position.set(-3.2, 2.6, -4.4);
    scene.add(rimLightRed);

    if (!isSoftwareGl) {
      RectAreaLightUniformsLib.init();
      const overheadSoftbox = new THREE.RectAreaLight(0xffffff, 2.6, 6.5, 2.2);
      overheadSoftbox.position.set(0, 4.2, 0.4);
      overheadSoftbox.lookAt(0, 0.4, 0);
      scene.add(overheadSoftbox);
    }

    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const materials = createF1Materials(maxAniso);
    const carRig: F1CarRig = buildF1Car(materials);
    scene.add(carRig.root);

    // Grounded studio turntable & contact shadow (alpha-faded plane melts seamlessly into background)
    const floorGeo = new THREE.PlaneGeometry(11.5, 11.5);
    floorGeo.rotateX(-Math.PI / 2);
    const floorMesh = new THREE.Mesh(floorGeo, materials.floorSurface);
    floorMesh.position.y = 0;
    floorMesh.receiveShadow = true;
    scene.add(floorMesh);

    const contactGeo = new THREE.PlaneGeometry(3.4, 6.2);
    contactGeo.rotateX(-Math.PI / 2);
    const contactMesh = new THREE.Mesh(contactGeo, materials.contactShadow);
    contactMesh.position.set(0, 0.012, 0.04);
    scene.add(contactMesh);

    // Initialize starting pose immediately so first frame is crisp
    const initialPose = evaluateScrollPose(
      progressRef.current,
      reducedMotionRef.current,
    );
    const initDistScale = computeResponsiveCameraDistanceScale(width / height);
    let currentYaw = initialPose.carYaw;
    let currentPitch = initialPose.carPitch;
    let currentWheelAngle = initialPose.wheelAngle;
    let currentBrakeGlow = initialPose.brakeGlow;
    let currentRainLight = initialPose.rainLightIntensity;
    let currentExhaustGlow = initialPose.exhaustGlow;
    let currentDrs = initialPose.drsOpen;
    let dragYawOffset = 0;
    let isDragging = false;
    let lastPointerX = 0;

    camera.position.set(
      initialPose.cameraPos.x * initDistScale,
      initialPose.cameraPos.y * (initDistScale > 1 ? 1.08 : 1),
      initialPose.cameraPos.z * initDistScale,
    );
    _currentLookAt.set(
      initialPose.cameraTarget.x,
      initialPose.cameraTarget.y,
      initialPose.cameraTarget.z,
    );
    camera.lookAt(_currentLookAt);

    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    renderer.setSize(width, height, false);

    let frameId = 0;
    let renderBusy = false;
    let renderDirty = false;
    let lastTime = performance.now();
    let disposed = false;

    const applyRigState = () => {
      carRig.root.rotation.y = currentYaw + dragYawOffset;
      carRig.root.rotation.x = currentPitch;
      for (const w of carRig.wheels) {
        w.rotation.x = currentWheelAngle;
      }
      carRig.drsFlapPivot.rotation.x = -currentDrs * 0.42;
      carRig.brakeMaterials.disc.emissiveIntensity = 0.06 + currentBrakeGlow * 0.9;
      carRig.brakeMaterials.caliper.emissiveIntensity = 0.04 + currentBrakeGlow * 0.35;
      carRig.rainLightMaterial.emissiveIntensity = 0.2 + currentRainLight * 0.85;
      carRig.exhaustMaterial.emissiveIntensity = 0.08 + currentExhaustGlow * 0.85;
    };

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      if (typeof gl.fenceSync === 'function') {
        const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      } else {
        frameId = window.setTimeout(cb, 80);
      }
    };

    const requestRender = () => {
      if (disposed) return;
      if (renderBusy) {
        renderDirty = true;
        return;
      }
      renderBusy = true;
      frameId = requestAnimationFrame(() => {
        if (disposed) return;
        renderDirty = false;

        const now = performance.now();
        const dt = Math.min((now - lastTime) / 1000, 0.05);
        lastTime = now;

        const pose = evaluateScrollPose(
          progressRef.current,
          reducedMotionRef.current,
        );
        const aspect = Math.max(container.clientWidth, 1) / Math.max(container.clientHeight, 1);
        const distScale = computeResponsiveCameraDistanceScale(aspect);

        _targetCamPos.set(
          pose.cameraPos.x * distScale,
          pose.cameraPos.y * (distScale > 1 ? 1.08 : 1),
          pose.cameraPos.z * distScale,
        );
        _targetLookAt.set(
          pose.cameraTarget.x,
          pose.cameraTarget.y,
          pose.cameraTarget.z,
        );

        const lambda = reducedMotionRef.current ? 40 : 9.5;
        if (reducedMotionRef.current) {
          currentYaw = pose.carYaw;
          currentPitch = pose.carPitch;
          currentWheelAngle = pose.wheelAngle;
          currentBrakeGlow = pose.brakeGlow;
          currentRainLight = pose.rainLightIntensity;
          currentExhaustGlow = pose.exhaustGlow;
          currentDrs = pose.drsOpen;
          if (!isDragging) dragYawOffset = 0;
          camera.position.copy(_targetCamPos);
          _currentLookAt.copy(_targetLookAt);
        } else {
          currentYaw = THREE.MathUtils.damp(currentYaw, pose.carYaw, lambda, dt);
          currentPitch = THREE.MathUtils.damp(currentPitch, pose.carPitch, lambda, dt);
          currentWheelAngle = THREE.MathUtils.damp(
            currentWheelAngle,
            pose.wheelAngle,
            lambda,
            dt,
          );
          currentBrakeGlow = THREE.MathUtils.damp(
            currentBrakeGlow,
            pose.brakeGlow,
            lambda,
            dt,
          );
          currentRainLight = THREE.MathUtils.damp(
            currentRainLight,
            pose.rainLightIntensity,
            lambda,
            dt,
          );
          currentExhaustGlow = THREE.MathUtils.damp(
            currentExhaustGlow,
            pose.exhaustGlow,
            lambda,
            dt,
          );
          currentDrs = THREE.MathUtils.damp(currentDrs, pose.drsOpen, lambda, dt);
          if (!isDragging) {
            dragYawOffset = THREE.MathUtils.damp(dragYawOffset, 0, 4.5, dt);
          }

          camera.position.x = THREE.MathUtils.damp(
            camera.position.x,
            _targetCamPos.x,
            lambda,
            dt,
          );
          camera.position.y = THREE.MathUtils.damp(
            camera.position.y,
            _targetCamPos.y,
            lambda,
            dt,
          );
          camera.position.z = THREE.MathUtils.damp(
            camera.position.z,
            _targetCamPos.z,
            lambda,
            dt,
          );
          _currentLookAt.x = THREE.MathUtils.damp(
            _currentLookAt.x,
            _targetLookAt.x,
            lambda,
            dt,
          );
          _currentLookAt.y = THREE.MathUtils.damp(
            _currentLookAt.y,
            _targetLookAt.y,
            lambda,
            dt,
          );
          _currentLookAt.z = THREE.MathUtils.damp(
            _currentLookAt.z,
            _targetLookAt.z,
            lambda,
            dt,
          );
        }

        camera.lookAt(_currentLookAt);
        applyRigState();
        renderer.render(scene, camera);

        const settled =
          reducedMotionRef.current ||
          (Math.abs(currentYaw - pose.carYaw) < 0.001 &&
            Math.abs(currentWheelAngle - pose.wheelAngle) < 0.002 &&
            Math.abs(dragYawOffset) < 0.001 &&
            camera.position.distanceTo(_targetCamPos) < 0.003);

        const done = () => {
          renderBusy = false;
          if (!settled || renderDirty) {
            requestRender();
          }
        };

        if (isSoftwareGl) {
          afterDraw(done);
        } else {
          done();
        }
      });
    };

    requestRenderRef.current = requestRender;

    // Draw initial frame synchronously so first paint is never blank
    applyRigState();
    renderer.render(scene, camera);

    const handleResize = () => {
      if (!container || disposed) return;
      const w = Math.max(container.clientWidth, 1);
      const h = Math.max(container.clientHeight, 1);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h, false);
      if (!renderBusy) {
        renderer.render(scene, camera);
      } else {
        requestRender();
      }
    };

    const resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    const handlePointerDown = (e: PointerEvent) => {
      if (reducedMotionRef.current) return;
      isDragging = true;
      lastPointerX = e.clientX;
    };
    const handlePointerMove = (e: PointerEvent) => {
      if (!isDragging) return;
      const dx = e.clientX - lastPointerX;
      lastPointerX = e.clientX;
      dragYawOffset = THREE.MathUtils.clamp(dragYawOffset + dx * 0.006, -0.75, 0.75);
      requestRender();
    };
    const handlePointerUp = () => {
      if (!isDragging) return;
      isDragging = false;
      requestRender();
    };

    canvas.addEventListener('pointerdown', handlePointerDown);
    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);

    const onContextLost = (e: Event) => {
      e.preventDefault();
      setWebglFailed(true);
    };
    const onContextRestored = () => {
      setWebglFailed(false);
      requestRender();
    };
    canvas.addEventListener('webglcontextlost', onContextLost);
    canvas.addEventListener('webglcontextrestored', onContextRestored);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      canvas.removeEventListener('pointerdown', handlePointerDown);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      canvas.removeEventListener('webglcontextlost', onContextLost);
      canvas.removeEventListener('webglcontextrestored', onContextRestored);
      carRig.dispose();
      floorGeo.dispose();
      contactGeo.dispose();
      materials.dispose();
      envTarget.dispose();
      renderer.dispose();
      if (canvas.parentNode === container) {
        container.removeChild(canvas);
      }
      requestRenderRef.current = null;
    };
  }, [forceFallback]);

  return (
    <div
      data-testid="f1-canvas-stage"
      data-chapter={activeChapterId}
      data-progress={scrollProgress.toFixed(3)}
      data-webgl-status={webglFailed ? 'fallback' : 'active'}
      className="relative w-full h-full bg-[#08080A] overflow-hidden select-none"
    >
      {/* Subtle 4-corner viewport registration marks at outer margin, never touching car */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-4 z-10 border border-white/[0.04]"
      >
        <span className="absolute -top-px -left-px h-3 w-3 border-t border-l border-white/25" />
        <span className="absolute -top-px -right-px h-3 w-3 border-t border-r border-white/25" />
        <span className="absolute -bottom-px -left-px h-3 w-3 border-b border-l border-white/25" />
        <span className="absolute -bottom-px -right-px h-3 w-3 border-b border-r border-white/25" />
      </div>

      {webglFailed ? (
        <div
          data-testid="f1-fallback-view"
          className="relative w-full h-full flex flex-col items-center justify-center p-6 text-center bg-[#0C0D10]"
        >
          <img
            src="/src/assets/images/f1_windtunnel_aero_1795724576343.jpg"
            alt="Formula 1 aerodynamic chassis fallback render"
            referrerPolicy="no-referrer"
            className="w-full max-w-xl aspect-video object-cover border border-white/10 opacity-85"
          />
          <p className="mt-4 text-xs tracking-wider text-[#9CA3AF]">
            3D WebGL viewport unavailable on this device · Showing wind-tunnel reference frame
          </p>
        </div>
      ) : (
        <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      )}
    </div>
  );
}
