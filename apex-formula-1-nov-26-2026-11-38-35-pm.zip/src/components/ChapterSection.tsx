import {useState} from 'react';
import {ArrowDown} from 'lucide-react';
import {ChapterData} from '../data/chapters';

interface ChapterSectionProps {
  chapter: ChapterData;
  isFirst: boolean;
  isLast: boolean;
  isActive: boolean;
  onExploreNext?: () => void;
  onReturnTop?: () => void;
}

export function ChapterSection({
  chapter,
  isFirst,
  isLast,
  isActive,
  onExploreNext,
  onReturnTop,
}: ChapterSectionProps) {
  const [imageError, setImageError] = useState(false);

  return (
    <section
      id={chapter.id}
      aria-labelledby={`${chapter.id}-heading`}
      data-chapter-section={chapter.id}
      data-active={isActive ? 'true' : 'false'}
      className={`relative py-10 lg:py-12 lg:min-h-[84vh] flex flex-col justify-center ${
        isFirst ? 'pt-6 lg:pt-8' : ''
      } ${!isLast ? 'border-b border-white/10' : ''}`}
    >
      {/* Editorial Chapter Index & Eyebrow (unboxed text, zero pills) */}
      <div className="flex items-center gap-2.5 text-xs font-medium tracking-wide text-[#9CA3AF]">
        <span className="font-mono-tabular text-[#E10600] font-medium">
          {chapter.indexLabel}.
        </span>
        <span aria-hidden="true">·</span>
        <span>{chapter.eyebrow}</span>
      </div>

      {/* Display Headline */}
      <h1
        id={`${chapter.id}-heading`}
        className="mt-2.5 font-display text-[clamp(2.2rem,3.4vw,3.3rem)] font-bold leading-[0.98] tracking-tight text-[#F4F4F6] text-balance"
      >
        {chapter.title}
      </h1>

      {/* Lead + Concise Editorial Prose */}
      <p className="mt-4 text-[15px] font-medium leading-relaxed text-[#E5E7EB]">
        {chapter.lead}
      </p>
      <p className="mt-2.5 text-sm leading-relaxed text-[#9CA3AF]">
        {chapter.body}
      </p>

      {/* Engineering Metrics Strip (Tabular numerals, hairline dividers) */}
      <dl className="mt-5 grid grid-cols-3 gap-4 border-y border-white/10 py-3.5">
        {chapter.metrics.map((metric) => (
          <div key={metric.label}>
            <dt className="text-[11px] font-medium text-[#9CA3AF] whitespace-nowrap truncate">
              {metric.label}
            </dt>
            <dd className="mt-0.5 flex items-baseline gap-1 font-display text-2xl sm:text-[1.75rem] font-bold text-[#F4F4F6] tabular-nums">
              <span>{metric.value}</span>
              <span className="font-sans text-xs font-medium text-[#9CA3AF]">
                {metric.unit}
              </span>
            </dd>
          </div>
        ))}
      </dl>

      {/* Atmospheric Track / Engineering Imagery */}
      <figure className="mt-5">
        <div className="relative aspect-[16/9] max-h-[245px] w-full overflow-hidden border border-white/10 bg-[#131418]">
          {imageError ? (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-[#131418] via-[#1B1D24] to-[#29090B] px-6 text-center">
              <span className="text-xs font-medium text-[#9CA3AF]">
                {chapter.imageCaption}
              </span>
            </div>
          ) : (
            <img
              src={chapter.imageSrc}
              alt={chapter.imageAlt}
              referrerPolicy="no-referrer"
              loading={isFirst ? 'eager' : 'lazy'}
              onError={() => setImageError(true)}
              className="h-full w-full object-cover"
            />
          )}
          <div
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/15 to-transparent"
          />
          <figcaption className="absolute bottom-3 left-3.5 right-3.5 text-xs font-medium text-[#E5E7EB]">
            {chapter.imageCaption}
          </figcaption>
        </div>
      </figure>

      {/* Chapter Focus Caption + Scroll Cue / Return Action */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4">
        <p className="text-xs text-[#9CA3AF]">
          <span className="text-[#C8CDD5] font-medium">3D View:</span>{' '}
          {chapter.focusCallout}
        </p>

        {isFirst && onExploreNext && (
          <button
            type="button"
            onClick={onExploreNext}
            className="inline-flex min-h-[44px] items-center gap-2 bg-[#E10600] px-5 py-2.5 text-xs font-semibold tracking-wide text-white transition-colors duration-150 hover:bg-[#c80500] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E10600]"
          >
            <span>Scroll to Explore</span>
            <ArrowDown className="h-3.5 w-3.5" aria-hidden="true" />
          </button>
        )}

        {isLast && onReturnTop && (
          <button
            type="button"
            onClick={onReturnTop}
            className="inline-flex min-h-[44px] items-center gap-2 border border-white/20 bg-[#131418] px-5 py-2.5 text-xs font-semibold tracking-wide text-[#F4F4F6] transition-colors duration-150 hover:border-white/40 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E10600]"
          >
            <span>Back to Front Profile</span>
          </button>
        )}
      </div>
    </section>
  );
}
