import {ChapterData} from '../data/chapters';

interface HeaderNavProps {
  chapters: ChapterData[];
  activeIndex: number;
  reducedMotion: boolean;
  onToggleReducedMotion: () => void;
  onSelectChapter: (id: string) => void;
}

export function HeaderNav({
  chapters,
  activeIndex,
  reducedMotion,
  onToggleReducedMotion,
  onSelectChapter,
}: HeaderNavProps) {
  return (
    <header className="sticky top-0 z-30 h-14 bg-[#08080A] border-b border-white/10">
      <div className="mx-auto flex h-full max-w-[1440px] items-center justify-between gap-4 px-5 lg:gap-8 lg:px-10">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="#introduction"
          onClick={(e) => {
            e.preventDefault();
            onSelectChapter('introduction');
          }}
          className="font-display text-2xl font-bold tracking-tight text-[#F4F4F6] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E10600]"
        >
          Apex
        </a>

        {/* Zone 2: 4 concise single-line text nav links */}
        <nav
          aria-label="Story chapters"
          className="hidden md:flex items-center gap-7"
        >
          {chapters.map((chapter, idx) => {
            const isActive = idx === activeIndex;
            return (
              <a
                key={chapter.id}
                href={`#${chapter.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  onSelectChapter(chapter.id);
                }}
                aria-current={isActive ? 'step' : undefined}
                className={`relative py-1 text-sm font-medium transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#E10600] ${
                  isActive
                    ? 'text-[#F4F4F6]'
                    : 'text-[#9CA3AF] hover:text-[#F4F4F6]'
                }`}
              >
                {chapter.navLabel}
                <span
                  aria-hidden="true"
                  className={`absolute left-0 right-0 -bottom-0.5 h-[2px] bg-[#E10600] transition-opacity duration-150 ${
                    isActive ? 'opacity-100' : 'opacity-0'
                  }`}
                />
              </a>
            );
          })}
        </nav>

        {/* Zone 3: 1 primary action (Accessible motion preference toggle) */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onToggleReducedMotion}
            aria-pressed={reducedMotion}
            className={`min-h-[40px] px-4 py-2 text-xs font-medium tracking-wide border transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#E10600] ${
              reducedMotion
                ? 'bg-[#E10600] border-[#E10600] text-white hover:bg-[#c80500]'
                : 'bg-[#131418] border-white/15 text-[#F4F4F6] hover:border-white/35'
            }`}
          >
            {reducedMotion ? 'Reduced Motion: On' : 'Reduce Motion'}
          </button>
        </div>
      </div>
    </header>
  );
}
