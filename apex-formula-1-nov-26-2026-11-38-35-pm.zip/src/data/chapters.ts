export interface SpecMetric {
  label: string;
  value: string;
  unit: string;
}

export interface ChapterData {
  id: string;
  indexLabel: string;
  navLabel: string;
  eyebrow: string;
  title: string;
  lead: string;
  body: string;
  imageSrc: string;
  imageAlt: string;
  imageCaption: string;
  metrics: SpecMetric[];
  focusCallout: string;
}

export const CHAPTERS: ChapterData[] = [
  {
    id: 'introduction',
    indexLabel: '01',
    navLabel: 'Introduction',
    eyebrow: 'Formula 1 · Ground-Effect Era',
    title: 'Sculpted by air, anchored to the apex.',
    lead: 'Every millimeter of a modern Grand Prix chassis exists to bend airflow into pure mechanical grip.',
    body: 'At 300 kilometers per hour, a Formula 1 car generates more vertical load than its own 798-kilogram mass—allowing it to corner at over five times the pull of gravity while slicing through dirty wake with surgical stability.',
    imageSrc: '/src/assets/images/f1_pitlane_twilight_1795724576999.jpg',
    imageAlt: 'Formula 1 pit lane at twilight with wet asphalt reflecting garage lights',
    imageCaption: 'Pit lane preparation at dusk · Parc fermé inspection',
    metrics: [
      {label: 'Minimum Mass', value: '798', unit: 'kg'},
      {label: 'Peak Lateral', value: '5.5', unit: 'G'},
      {label: 'Top Velocity', value: '352', unit: 'km/h'},
    ],
    focusCallout: 'Front three-quarter chassis profile & titanium Halo',
  },
  {
    id: 'aerodynamics',
    indexLabel: '02',
    navLabel: 'Aerodynamics',
    eyebrow: 'Venturi Tunnels · Active Wing',
    title: 'Invisible wings carved beneath the floor.',
    lead: 'Instead of relying on turbulent upper bodywork, twin underfloor Venturi channels accelerate air to pull the car downward.',
    body: 'A four-element front wing conditions high-energy vortices around the 18-inch front tires, sealing the undercut sidepods and feeding clean pressure into the rear diffuser strakes. Opening the DRS flap sheds drag in milliseconds down the straight.',
    imageSrc: '/src/assets/images/f1_windtunnel_aero_1795724576343.jpg',
    imageAlt: 'Carbon fiber Formula 1 aerodynamic wing and floor in a dark wind tunnel with white smoke streamlines',
    imageCaption: 'Wind-tunnel flow visualization · Carbon floor & wing cascade',
    metrics: [
      {label: 'Peak Downforce', value: '1,180', unit: 'kg'},
      {label: 'Floor Share', value: '58', unit: '%'},
      {label: 'DRS Stall Gain', value: '+18', unit: 'km/h'},
    ],
    focusCallout: 'Low-angle front cascade, undercut sidepods & Venturi edge',
  },
  {
    id: 'power-unit',
    indexLabel: '03',
    navLabel: 'Power Unit',
    eyebrow: '1.6L V6 Hybrid · Energy Recovery',
    title: 'Thermal violence harnessed at 15,000 RPM.',
    lead: 'The most thermally efficient combustion engine ever raced pairs a single-turbo V6 with dual electric motor-generators.',
    body: 'Exhaust gases spin the MGU-H turbine past 100,000 rpm while the MGU-K harvests braking energy off carbon-ceramic discs glowing past 900 degrees Celsius—deploying 120 kilowatts of instant electric torque straight to the rear axle.',
    imageSrc: '/src/assets/images/f1_powerunit_detail_1795724576920.jpg',
    imageAlt: 'Formula 1 hybrid turbocharger and glowing heat-tinted titanium exhaust manifolds on a dyno',
    imageCaption: 'Dyno test cell · Heat-tinted titanium collector & turbo housing',
    metrics: [
      {label: 'System Output', value: '1,000+', unit: 'bhp'},
      {label: 'Thermal Efficiency', value: '52.4', unit: '%'},
      {label: 'MGU-K Deploy', value: '120', unit: 'kW'},
    ],
    focusCallout: 'Side-rear engine cover, glowing brake discs & titanium exhaust',
  },
  {
    id: 'pursuit',
    indexLabel: '04',
    navLabel: 'The Pursuit',
    eyebrow: 'Rear Diffuser · Qualifying Lap',
    title: 'Two hundredths separate legend from the field.',
    lead: 'When fuel burns low and soft rubber bites the dusk tarmac, engineering becomes instinct.',
    body: 'Rear diffuser strakes expand low-pressure air upward behind the glowing FIA rain light, balancing every kerb strike and late-braking lunge. Across twenty-four circuits and five continents, the pursuit of a cleaner lap never stops.',
    imageSrc: '/src/assets/images/f1_track_apex_1795724577264.jpg',
    imageAlt: 'Empty Grand Prix circuit apex and red-and-white curbs at twilight',
    imageCaption: 'Twilight apex · Rubbered racing line & FIA kerbs',
    metrics: [
      {label: 'Zero to 200 km/h', value: '4.4', unit: 'sec'},
      {label: 'Pit Stop Window', value: '1.9', unit: 'sec'},
      {label: 'Gear Shifts / Lap', value: '52', unit: 'shifts'},
    ],
    focusCallout: 'Rear three-quarter diffuser, swan-neck wing & FIA rain light',
  },
];
