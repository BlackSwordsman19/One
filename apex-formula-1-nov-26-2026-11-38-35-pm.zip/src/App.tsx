import {useCallback, useEffect, useMemo, useState} from 'react';
import {ChapterSection} from './components/ChapterSection';
import {F1CanvasStage} from './components/F1CanvasStage';
import {HeaderNav} from './components/HeaderNav';
import {CHAPTERS} from './data/chapters';
import {clamp01, getActiveChapterIndex} from './scene/choreography';

export default function App() {
  const [scrollProgress, setScrollProgress] = useState(0);
  const [reducedMotion, setReducedMotion] = useState(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false;
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  const forceFallback = useMemo(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('fallback') === '1';
  }, []);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = (e: MediaQueryListEvent) => setReducedMotion(e.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  useEffect(() => {
    let rafId = 0;

    const updateProgress = () => {
      rafId = 0;
      const doc = document.documentElement;
      const maxScroll = Math.max(doc.scrollHeight - window.innerHeight, 1);
      const next = clamp01(window.scrollY / maxScroll);
      setScrollProgress((prev) => (Math.abs(prev - next) > 0.0005 ? next : prev));
    };

    const onScroll = () => {
      if (rafId) return;
      rafId = requestAnimationFrame(updateProgress);
    };

    updateProgress();
    window.addEventListener('scroll', onScroll, {passive: true});
    window.addEventListener('resize', onScroll, {passive: true});

    return () => {
      if (rafId) cancelAnimationFrame(rafId);
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
    };
  }, []);

  const activeChapterIndex = getActiveChapterIndex(scrollProgress, CHAPTERS.length);
  const activeChapter = CHAPTERS[activeChapterIndex];

  const scrollToChapter = useCallback(
    (id: string) => {
      const el = document.getElementById(id);
      if (!el) return;
      const headerOffset = 56;
      const mobileStageOffset = window.innerWidth < 1024 ? window.innerHeight * 0.38 : 0;
      const targetY =
        el.getBoundingClientRect().top +
        window.scrollY -
        headerOffset -
        mobileStageOffset;
      window.scrollTo({
        top: Math.max(0, targetY),
        behavior: reducedMotion ? 'auto' : 'smooth',
      });
    },
    [reducedMotion],
  );

  const returnToTop = useCallback(() => {
    window.scrollTo({
      top: 0,
      behavior: reducedMotion ? 'auto' : 'smooth',
    });
  }, [reducedMotion]);

  return (
    <div className="min-h-screen bg-[#08080A] text-[#F4F4F6]">
      <a
        href="#editorial-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:bg-[#E10600] focus:px-4 focus:py-2 focus:text-xs focus:font-semibold focus:text-white"
      >
        Skip to editorial content
      </a>

      <HeaderNav
        chapters={CHAPTERS}
        activeIndex={activeChapterIndex}
        reducedMotion={reducedMotion}
        onToggleReducedMotion={() => setReducedMotion((v) => !v)}
        onSelectChapter={scrollToChapter}
      />

      {/* Scroll Progress Hairline directly beneath header */}
      <div
        aria-hidden="true"
        className="fixed top-14 left-0 right-0 z-30 h-[2px] bg-white/[0.06] pointer-events-none"
      >
        <div
          className="h-full bg-[#E10600] origin-left transition-transform duration-75"
          style={{transform: `scaleX(${scrollProgress})`}}
        />
      </div>

      <main
        data-scroll-progress={scrollProgress.toFixed(3)}
        data-active-chapter={activeChapter.id}
        data-reduced-motion={reducedMotion ? 'true' : 'false'}
        className="mx-auto max-w-[1440px] lg:grid lg:grid-cols-12"
      >
        {/* Dedicated Unobstructed 3D Stage:
            - Mobile: Sticky upper stage below header (opaque background so lower text passes cleanly underneath)
            - Desktop (lg): Sticky right 7-column viewport (58% width), completely isolated from left editorial column */}
        <div className="sticky top-14 z-20 h-[38vh] w-full border-b border-white/10 bg-[#08080A] lg:order-2 lg:col-span-7 lg:h-[calc(100vh-3.5rem)] lg:border-b-0 lg:border-l lg:border-white/10">
          <F1CanvasStage
            scrollProgress={scrollProgress}
            reducedMotion={reducedMotion}
            activeChapterId={activeChapter.id}
            forceFallback={forceFallback}
          />
        </div>

        {/* Dedicated Editorial Narrative Column */}
        <div
          id="editorial-content"
          className="relative z-10 px-5 sm:px-8 lg:order-1 lg:col-span-5 lg:px-10 xl:px-14"
        >
          {CHAPTERS.map((chapter, idx) => (
            <ChapterSection
              key={chapter.id}
              chapter={chapter}
              isFirst={idx === 0}
              isLast={idx === CHAPTERS.length - 1}
              isActive={idx === activeChapterIndex}
              onExploreNext={
                idx === 0 ? () => scrollToChapter(CHAPTERS[1].id) : undefined
              }
              onReturnTop={idx === CHAPTERS.length - 1 ? returnToTop : undefined}
            />
          ))}

          {/* Understated Editorial Footer */}
          <footer className="border-t border-white/10 py-10 text-xs text-[#9CA3AF]">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="font-display text-sm font-semibold tracking-wide text-[#F4F4F6]">
                Apex Formula 1 Editorial
              </span>
              <span>
                Procedural 3D Chassis · Studio Pit-Lane Photography
              </span>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}
