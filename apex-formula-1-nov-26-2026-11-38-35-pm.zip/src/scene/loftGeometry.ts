import * as THREE from 'three';

export interface LoftStation {
  z: number;
  centerX?: number;
  centerY: number;
  rx: number;
  ryTop: number;
  ryBottom: number;
  topPower?: number;
  bottomPower?: number;
  /** Optional waterslide concave depression on upper surface (0..0.4) */
  topTrough?: number;
}

interface SampledStation {
  z: number;
  centerX: number;
  centerY: number;
  rx: number;
  ryTop: number;
  ryBottom: number;
  topPower: number;
  bottomPower: number;
  topTrough: number;
}

function catmullRom1D(p0: number, p1: number, p2: number, p3: number, t: number): number {
  const t2 = t * t;
  const t3 = t2 * t;
  return (
    0.5 *
    (2 * p1 +
      (-p0 + p2) * t +
      (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
      (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
  );
}

export function sampleStationsSmooth(
  stations: LoftStation[],
  subdivisionsPerSpan = 4,
): SampledStation[] {
  const normalized: SampledStation[] = stations.map((s) => ({
    z: s.z,
    centerX: s.centerX ?? 0,
    centerY: s.centerY,
    rx: Math.max(0.004, s.rx),
    ryTop: Math.max(0.004, s.ryTop),
    ryBottom: Math.max(0.004, s.ryBottom),
    topPower: s.topPower ?? 2.0,
    bottomPower: s.bottomPower ?? 2.4,
    topTrough: s.topTrough ?? 0,
  }));

  if (normalized.length < 2 || subdivisionsPerSpan <= 1) {
    return normalized;
  }

  const out: SampledStation[] = [];
  const n = normalized.length;

  for (let i = 0; i < n - 1; i++) {
    const p0 = normalized[Math.max(0, i - 1)];
    const p1 = normalized[i];
    const p2 = normalized[i + 1];
    const p3 = normalized[Math.min(n - 1, i + 2)];

    const steps = i === n - 2 ? subdivisionsPerSpan + 1 : subdivisionsPerSpan;
    for (let s = 0; s < steps; s++) {
      const t = s / subdivisionsPerSpan;
      out.push({
        z: catmullRom1D(p0.z, p1.z, p2.z, p3.z, t),
        centerX: catmullRom1D(p0.centerX, p1.centerX, p2.centerX, p3.centerX, t),
        centerY: catmullRom1D(p0.centerY, p1.centerY, p2.centerY, p3.centerY, t),
        rx: Math.max(0.004, catmullRom1D(p0.rx, p1.rx, p2.rx, p3.rx, t)),
        ryTop: Math.max(0.004, catmullRom1D(p0.ryTop, p1.ryTop, p2.ryTop, p3.ryTop, t)),
        ryBottom: Math.max(
          0.004,
          catmullRom1D(p0.ryBottom, p1.ryBottom, p2.ryBottom, p3.ryBottom, t),
        ),
        topPower: Math.max(1.1, catmullRom1D(p0.topPower, p1.topPower, p2.topPower, p3.topPower, t)),
        bottomPower: Math.max(
          1.1,
          catmullRom1D(p0.bottomPower, p1.bottomPower, p2.bottomPower, p3.bottomPower, t),
        ),
        topTrough: Math.max(0, catmullRom1D(p0.topTrough, p1.topTrough, p2.topTrough, p3.topTrough, t)),
      });
    }
  }

  return out;
}

/**
 * Builds a watertight, smoothly shaded lofted BufferGeometry from front (+Z) to rear (-Z)
 * using super-ellipse cross-sections and Catmull-Rom longitudinal fairing.
 */
export function createLoftedHull(
  stations: LoftStation[],
  radialSegments = 36,
  subdivisionsPerSpan = 4,
): THREE.BufferGeometry {
  const rings = sampleStationsSmooth(stations, subdivisionsPerSpan);
  const ringCount = rings.length;
  const cols = radialSegments + 1;

  const vertexCount = ringCount * cols + 2; // +2 for front/rear cap centers
  const positions = new Float32Array(vertexCount * 3);
  const uvs = new Float32Array(vertexCount * 2);

  const zStart = rings[0].z;
  const zEnd = rings[ringCount - 1].z;
  const zSpan = Math.max(Math.abs(zStart - zEnd), 0.001);

  for (let i = 0; i < ringCount; i++) {
    const st = rings[i];
    const vCoord = Math.abs(zStart - st.z) / zSpan;

    for (let j = 0; j < cols; j++) {
      const uFrac = (j % radialSegments) / radialSegments;
      const theta = uFrac * Math.PI * 2;
      const c = Math.cos(theta);
      const s = Math.sin(theta);

      let x: number;
      let y: number;
      if (s >= 0) {
        const exp = 2 / st.topPower;
        x = st.centerX + Math.sign(c) * Math.pow(Math.abs(c), exp) * st.rx;
        let yOffset = Math.pow(s, exp) * st.ryTop;
        if (st.topTrough > 0) {
          // Smooth waterslide channel depression across mid-upper surface
          const troughMask = Math.pow(Math.max(0, 1 - Math.abs(c) * 1.15), 2);
          yOffset *= 1 - st.topTrough * troughMask;
        }
        y = st.centerY + yOffset;
      } else {
        const exp = 2 / st.bottomPower;
        x = st.centerX + Math.sign(c) * Math.pow(Math.abs(c), exp) * st.rx;
        y = st.centerY - Math.pow(Math.abs(s), exp) * st.ryBottom;
      }

      const idx = i * cols + j;
      positions[idx * 3] = x;
      positions[idx * 3 + 1] = y;
      positions[idx * 3 + 2] = st.z;

      uvs[idx * 2] = j / radialSegments;
      uvs[idx * 2 + 1] = vCoord;
    }
  }

  // Front & rear cap center vertices
  const frontCapIdx = ringCount * cols;
  positions[frontCapIdx * 3] = rings[0].centerX;
  positions[frontCapIdx * 3 + 1] = rings[0].centerY;
  positions[frontCapIdx * 3 + 2] = rings[0].z + 0.015;
  uvs[frontCapIdx * 2] = 0.5;
  uvs[frontCapIdx * 2 + 1] = 0;

  const rearCapIdx = frontCapIdx + 1;
  const last = rings[ringCount - 1];
  positions[rearCapIdx * 3] = last.centerX;
  positions[rearCapIdx * 3 + 1] = last.centerY;
  positions[rearCapIdx * 3 + 2] = last.z - 0.01;
  uvs[rearCapIdx * 2] = 0.5;
  uvs[rearCapIdx * 2 + 1] = 1;

  const indices: number[] = [];

  // Quad strips between longitudinal rings (CCW outward winding when stations move +Z -> -Z)
  for (let i = 0; i < ringCount - 1; i++) {
    for (let j = 0; j < radialSegments; j++) {
      const a = i * cols + j;
      const b = (i + 1) * cols + j;
      const c = i * cols + (j + 1);
      const d = (i + 1) * cols + (j + 1);
      indices.push(a, b, c);
      indices.push(b, d, c);
    }
  }

  // Front cap (+Z normal)
  for (let j = 0; j < radialSegments; j++) {
    indices.push(frontCapIdx, j, j + 1);
  }

  // Rear cap (-Z normal)
  const lastRingOffset = (ringCount - 1) * cols;
  for (let j = 0; j < radialSegments; j++) {
    indices.push(rearCapIdx, lastRingOffset + j + 1, lastRingOffset + j);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

export interface WingBladeOptions {
  span: number;
  centerChord: number;
  tipChord: number;
  thickness: number;
  sweepBack: number;
  /** Positive = arched upward at center, negative = gull-wing dip at center */
  centerArchY: number;
  camber: number;
  pitchRad: number;
  spanSegments?: number;
  chordSegments?: number;
}

/**
 * Generates a swept, cambered airfoil wing blade along the X axis (-span/2 .. +span/2).
 */
export function createCamberedWingBlade(opts: WingBladeOptions): THREE.BufferGeometry {
  const spanSegs = opts.spanSegments ?? 28;
  const chordSegs = opts.chordSegments ?? 14;
  const halfSpan = opts.span / 2;

  const loopPts = chordSegs * 2; // closed airfoil loop around chord
  const cols = loopPts + 1;
  const rows = spanSegs + 1;

  const vertexCount = rows * cols + 2;
  const positions = new Float32Array(vertexCount * 3);
  const uvs = new Float32Array(vertexCount * 2);

  const cosP = Math.cos(opts.pitchRad);
  const sinP = Math.sin(opts.pitchRad);

  for (let i = 0; i < rows; i++) {
    const uSpan = i / spanSegs; // 0 (-X) -> 1 (+X)
    const normX = uSpan * 2 - 1; // -1 .. +1
    const absX = Math.abs(normX);
    const x = normX * halfSpan;

    const chord =
      opts.centerChord + (opts.tipChord - opts.centerChord) * Math.pow(absX, 1.4);
    const zSweep = -opts.sweepBack * Math.pow(absX, 1.5);
    const yArch = opts.centerArchY * (1 - absX * absX);

    for (let j = 0; j < cols; j++) {
      const k = j % loopPts;
      // 0..chordSegs = upper surface leading->trailing (+Z -> -Z)
      // chordSegs..2*chordSegs = lower surface trailing->leading (-Z -> +Z)
      const isUpper = k <= chordSegs;
      const tChord = isUpper
        ? k / chordSegs
        : 1 - (k - chordSegs) / chordSegs;

      // NACA-style airfoil thickness & camber distribution
      const halfThick =
        5 *
        opts.thickness *
        (0.2969 * Math.sqrt(tChord) -
          0.126 * tChord -
          0.3516 * tChord * tChord +
          0.2843 * tChord * tChord * tChord -
          0.1015 * tChord * tChord * tChord * tChord);
      const meanCamber = opts.camber * 4 * tChord * (1 - tChord);

      const localZ = (0.5 - tChord) * chord; // +chord/2 leading, -chord/2 trailing
      const localY = meanCamber + (isUpper ? halfThick : -halfThick * 0.7);

      // Apply pitch around X
      const rotY = localY * cosP + localZ * sinP;
      const rotZ = localZ * cosP - localY * sinP;

      const idx = i * cols + j;
      positions[idx * 3] = x;
      positions[idx * 3 + 1] = yArch + rotY;
      positions[idx * 3 + 2] = zSweep + rotZ;
      uvs[idx * 2] = uSpan;
      uvs[idx * 2 + 1] = tChord;
    }
  }

  const leftCapIdx = rows * cols;
  positions[leftCapIdx * 3] = -halfSpan;
  positions[leftCapIdx * 3 + 1] = 0;
  positions[leftCapIdx * 3 + 2] = -opts.sweepBack;

  const rightCapIdx = leftCapIdx + 1;
  positions[rightCapIdx * 3] = halfSpan;
  positions[rightCapIdx * 3 + 1] = 0;
  positions[rightCapIdx * 3 + 2] = -opts.sweepBack;

  const indices: number[] = [];
  for (let i = 0; i < rows - 1; i++) {
    for (let j = 0; j < loopPts; j++) {
      const a = i * cols + j;
      const b = (i + 1) * cols + j;
      const c = i * cols + (j + 1);
      const d = (i + 1) * cols + (j + 1);
      // Verify winding: i goes -X -> +X, j goes +Z -> +Y -> -Z -> -Y (around -X axis)
      // (b-a) = +X, (c-a) at top (+Y) is -Z => +X x -Z = +Y (OUTWARD!)
      indices.push(a, b, c);
      indices.push(b, d, c);
    }
  }

  for (let j = 0; j < loopPts; j++) {
    indices.push(leftCapIdx, j + 1, j);
    const lastRow = (rows - 1) * cols;
    indices.push(rightCapIdx, lastRow + j, lastRow + j + 1);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}
