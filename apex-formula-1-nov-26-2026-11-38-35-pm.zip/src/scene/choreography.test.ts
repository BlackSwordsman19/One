import test from 'node:test';
import assert from 'node:assert/strict';
import {
  clamp01,
  computeResponsiveCameraDistanceScale,
  evaluateScrollPose,
  getActiveChapterIndex,
} from './choreography';

test('clamp01 handles bounds and non-finite inputs', () => {
  assert.equal(clamp01(-0.5), 0);
  assert.equal(clamp01(1.8), 1);
  assert.equal(clamp01(0.42), 0.42);
  assert.equal(clamp01(Number.NaN), 0);
});

test('evaluateScrollPose reveals front, side, and rear angles across scroll', () => {
  const front = evaluateScrollPose(0);
  const side = evaluateScrollPose(0.34);
  const power = evaluateScrollPose(0.68);
  const rear = evaluateScrollPose(1.0);

  // Car rotates smoothly across front, side, and rear 3/4 views (> 150 degrees)
  assert.ok(front.carYaw > side.carYaw);
  assert.ok(side.carYaw > power.carYaw);
  assert.ok(power.carYaw > rear.carYaw);
  assert.ok(Math.abs(rear.carYaw - front.carYaw) > Math.PI * 0.85);

  // Peak brake and exhaust glow occur in Power Unit section
  assert.ok(power.brakeGlow > front.brakeGlow);
  assert.ok(power.exhaustGlow > front.exhaustGlow);

  // Rain light reaches maximum at the rear celebratory view
  assert.equal(rear.rainLightIntensity, 1.0);
});

test('evaluateScrollPose is strictly deterministic and reversible', () => {
  const forward = evaluateScrollPose(0.5);
  const backward = evaluateScrollPose(0.5);
  assert.deepEqual(forward, backward);
  assert.ok(evaluateScrollPose(0.75).wheelAngle > evaluateScrollPose(0.25).wheelAngle);
});

test('reducedMotion eliminates wheel rotation and chassis pitch while keeping viewpoints', () => {
  const reduced = evaluateScrollPose(0.34, true);
  assert.equal(reduced.wheelAngle, 0);
  assert.equal(reduced.carPitch, 0);
  assert.ok(reduced.carYaw < -0.5);
});

test('getActiveChapterIndex maps progress evenly across 4 chapters', () => {
  assert.equal(getActiveChapterIndex(0.0), 0);
  assert.equal(getActiveChapterIndex(0.3), 1);
  assert.equal(getActiveChapterIndex(0.6), 2);
  assert.equal(getActiveChapterIndex(0.99), 3);
  assert.equal(getActiveChapterIndex(1.0), 3);
});

test('computeResponsiveCameraDistanceScale pulls back on narrower viewports', () => {
  assert.equal(computeResponsiveCameraDistanceScale(1.4), 1.04);
  assert.ok(computeResponsiveCameraDistanceScale(0.75) > 1.25);
});
