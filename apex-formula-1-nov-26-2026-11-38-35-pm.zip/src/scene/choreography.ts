export interface Vec3Tuple {
  x: number;
  y: number;
  z: number;
}

export interface ScrollPose {
  carYaw: number;
  carPitch: number;
  carPos: Vec3Tuple;
  cameraPos: Vec3Tuple;
  cameraTarget: Vec3Tuple;
  wheelAngle: number;
  brakeGlow: number;
  rainLightIntensity: number;
  exhaustGlow: number;
  drsOpen: number;
}

interface KeyframePose {
  at: number;
  carYaw: number;
  carPitch: number;
  carPos: Vec3Tuple;
  cameraPos: Vec3Tuple;
  cameraTarget: Vec3Tuple;
  brakeGlow: number;
  rainLightIntensity: number;
  exhaustGlow: number;
  drsOpen: number;
}

// Smooth progression from Front 3/4 -> Low Side/Aero -> Rear-Side Power/Brakes -> Dramatic Rear 3/4
const KEYFRAMES: KeyframePose[] = [
  {
    at: 0.0,
    carYaw: 0.16,
    carPitch: 0.0,
    carPos: {x: 0.0, y: 0.0, z: 0.0},
    cameraPos: {x: 4.5, y: 1.85, z: 6.45},
    cameraTarget: {x: 0.0, y: 0.44, z: 0.15},
    brakeGlow: 0.1,
    rainLightIntensity: 0.2,
    exhaustGlow: 0.15,
    drsOpen: 0.0,
  },
  {
    at: 0.34,
    carYaw: -0.92,
    carPitch: 0.012,
    carPos: {x: 0.0, y: 0.0, z: 0.0},
    cameraPos: {x: 5.5, y: 1.3, z: 6.2},
    cameraTarget: {x: 0.0, y: 0.4, z: 0.05},
    brakeGlow: 0.22,
    rainLightIntensity: 0.35,
    exhaustGlow: 0.25,
    drsOpen: 0.9,
  },
  {
    at: 0.68,
    carYaw: -1.92,
    carPitch: -0.01,
    carPos: {x: 0.0, y: 0.0, z: 0.0},
    cameraPos: {x: 4.85, y: 1.5, z: 5.6},
    cameraTarget: {x: 0.0, y: 0.44, z: -0.15},
    brakeGlow: 1.0,
    rainLightIntensity: 0.65,
    exhaustGlow: 1.0,
    drsOpen: 0.15,
  },
  {
    at: 1.0,
    carYaw: -2.62,
    carPitch: 0.0,
    carPos: {x: 0.0, y: 0.0, z: 0.0},
    cameraPos: {x: 4.4, y: 1.78, z: 6.1},
    cameraTarget: {x: 0.0, y: 0.46, z: -0.25},
    brakeGlow: 0.4,
    rainLightIntensity: 1.0,
    exhaustGlow: 0.6,
    drsOpen: 0.0,
  },
];

export function clamp01(value: number): number {
  if (!Number.isFinite(value)) return 0;
  return Math.max(0, Math.min(1, value));
}

export function smootherstep(t: number): number {
  const x = clamp01(t);
  return x * x * x * (x * (x * 6 - 15) + 10);
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpVec3(a: Vec3Tuple, b: Vec3Tuple, t: number): Vec3Tuple {
  return {
    x: lerp(a.x, b.x, t),
    y: lerp(a.y, b.y, t),
    z: lerp(a.z, b.z, t),
  };
}

export function evaluateScrollPose(
  rawProgress: number,
  reducedMotion = false,
): ScrollPose {
  const progress = clamp01(rawProgress);

  let start = KEYFRAMES[0];
  let end = KEYFRAMES[KEYFRAMES.length - 1];

  for (let i = 0; i < KEYFRAMES.length - 1; i++) {
    if (progress >= KEYFRAMES[i].at && progress <= KEYFRAMES[i + 1].at) {
      start = KEYFRAMES[i];
      end = KEYFRAMES[i + 1];
      break;
    }
  }

  const span = end.at - start.at;
  const localT = span > 0 ? (progress - start.at) / span : 0;
  const t = reducedMotion ? localT : smootherstep(localT);

  // Reversible wheel spin tied directly to scroll progress (~8 full rotations across page)
  const wheelAngle = reducedMotion ? 0 : progress * Math.PI * 16;

  return {
    carYaw: lerp(start.carYaw, end.carYaw, t),
    carPitch: reducedMotion ? 0 : lerp(start.carPitch, end.carPitch, t),
    carPos: lerpVec3(start.carPos, end.carPos, t),
    cameraPos: lerpVec3(start.cameraPos, end.cameraPos, t),
    cameraTarget: lerpVec3(start.cameraTarget, end.cameraTarget, t),
    wheelAngle,
    brakeGlow: lerp(start.brakeGlow, end.brakeGlow, t),
    rainLightIntensity: lerp(start.rainLightIntensity, end.rainLightIntensity, t),
    exhaustGlow: lerp(start.exhaustGlow, end.exhaustGlow, t),
    drsOpen: lerp(start.drsOpen, end.drsOpen, t),
  };
}

export function getActiveChapterIndex(
  rawProgress: number,
  chapterCount = 4,
): number {
  if (chapterCount <= 1) return 0;
  const p = clamp01(rawProgress);
  const idx = Math.floor(p * chapterCount * 0.9999);
  return Math.max(0, Math.min(chapterCount - 1, idx));
}

export function computeResponsiveCameraDistanceScale(aspect: number): number {
  if (!Number.isFinite(aspect) || aspect <= 0) return 1.04;
  // Pull back cleanly on square/narrow screens so the 5.6m F1 car fits with generous margins
  if (aspect < 0.85) return 1.38;
  if (aspect < 1.15) return 1.18;
  return 1.04;
}
