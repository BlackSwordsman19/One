import * as THREE from 'three';

export interface F1MaterialLibrary {
  redPaint: THREE.MeshPhysicalMaterial;
  redAccent: THREE.MeshPhysicalMaterial;
  whiteStripe: THREE.MeshStandardMaterial;
  matteCarbon: THREE.MeshStandardMaterial;
  glossCarbon: THREE.MeshPhysicalMaterial;
  titanium: THREE.MeshPhysicalMaterial;
  exhaustMetal: THREE.MeshStandardMaterial;
  tireRubber: THREE.MeshStandardMaterial;
  tireSidewall: THREE.MeshStandardMaterial;
  wheelRim: THREE.MeshPhysicalMaterial;
  brakeDisc: THREE.MeshStandardMaterial;
  brakeCaliper: THREE.MeshStandardMaterial;
  rainLight: THREE.MeshStandardMaterial;
  helmetShell: THREE.MeshPhysicalMaterial;
  visor: THREE.MeshPhysicalMaterial;
  cockpitAlcantara: THREE.MeshStandardMaterial;
  seatCarbon: THREE.MeshPhysicalMaterial;
  harnessRed: THREE.MeshStandardMaterial;
  steeringDisplay: THREE.MeshStandardMaterial;
  floorSurface: THREE.MeshStandardMaterial;
  contactShadow: THREE.MeshBasicMaterial;
  textures: THREE.Texture[];
  dispose: () => void;
}

function createCarbonTextures(maxAnisotropy: number): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const size = 128;
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = size;
  colorCanvas.height = size;
  const cctx = colorCanvas.getContext('2d')!;

  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = size;
  bumpCanvas.height = size;
  const bctx = bumpCanvas.getContext('2d')!;

  const step = 8;
  for (let y = 0; y < size; y += step) {
    for (let x = 0; x < size; x += step) {
      const diag = (((x / step + y / step) % 4) + 4) % 4;
      const isWarp = diag < 2;
      cctx.fillStyle = isWarp ? '#1c1e24' : '#111216';
      cctx.fillRect(x, y, step, step);
      cctx.fillStyle = isWarp ? '#252830' : '#16181d';
      cctx.fillRect(x + 1, y + 1, step - 2, step - 2);

      bctx.fillStyle = isWarp ? '#dcdcdc' : '#545454';
      bctx.fillRect(x, y, step, step);
    }
  }

  const map = new THREE.CanvasTexture(colorCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(16, 16);
  map.anisotropy = maxAnisotropy;

  const bumpMap = new THREE.CanvasTexture(bumpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.repeat.set(16, 16);
  bumpMap.anisotropy = maxAnisotropy;

  return {map, bumpMap};
}

function createTireTreadBumpTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, size, size);

  // Fine circumferential rubber grain & subtle slick tire center mold seam
  for (let y = 0; y < size; y += 2) {
    const shade = 118 + Math.sin(y * 0.7) * 14;
    ctx.fillStyle = `rgb(${shade},${shade},${shade})`;
    ctx.fillRect(0, y, size, 1);
  }
  // Faint wear grooves / heat-cycle banding
  ctx.fillStyle = 'rgba(40,40,40,0.45)';
  ctx.fillRect(0, size * 0.26, size, 3);
  ctx.fillRect(0, size * 0.74, size, 3);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(6, 1);
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createTireSidewallTexture(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  ctx.fillStyle = '#141518';
  ctx.fillRect(0, 0, size, size);

  // Concentric molded sidewall ribs
  for (let r = 138; r < 248; r += 3) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.strokeStyle = r % 6 === 0 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.28)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  // Dual crimson soft-compound sidewall arcs
  const segments = [
    [0.24, 1.38],
    [1.81, 2.95],
    [3.38, 4.52],
    [4.95, 6.09],
  ];
  ctx.strokeStyle = '#e10600';
  ctx.lineWidth = 13;
  ctx.lineCap = 'butt';
  for (const [start, end] of segments) {
    ctx.beginPath();
    ctx.arc(cx, cy, 198, start, end);
    ctx.stroke();
  }

  // Fine silver-white technical trim arcs
  ctx.strokeStyle = 'rgba(244,244,246,0.58)';
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.arc(cx, cy, 174, 0.38, 1.24);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(cx, cy, 174, 3.52, 4.38);
  ctx.stroke();

  // Outer shoulder chamfer ring
  ctx.strokeStyle = 'rgba(255,255,255,0.06)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(cx, cy, 232, 0, Math.PI * 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = maxAnisotropy;
  return texture;
}

function createStudioFloorTextures(maxAnisotropy: number): {
  map: THREE.CanvasTexture;
  alphaMap: THREE.CanvasTexture;
} {
  const size = 1024;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;

  const grad = ctx.createRadialGradient(cx, cy, 30, cx, cy, 460);
  grad.addColorStop(0, '#181920');
  grad.addColorStop(0.45, '#0e0f14');
  grad.addColorStop(0.85, '#08080a');
  grad.addColorStop(1, '#08080a');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Subtle calibration rings & pit-box grid lines
  ctx.strokeStyle = 'rgba(255,255,255,0.045)';
  ctx.lineWidth = 1.5;
  for (const r of [165, 255, 340]) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.strokeStyle = 'rgba(225, 6, 0, 0.3)';
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(cx - 175, cy - 290);
  ctx.lineTo(cx - 175, cy - 230);
  ctx.moveTo(cx + 175, cy - 290);
  ctx.lineTo(cx + 175, cy - 230);
  ctx.stroke();

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(cx - 175, cy + 230);
  ctx.lineTo(cx - 175, cy + 290);
  ctx.moveTo(cx + 175, cy + 230);
  ctx.lineTo(cx + 175, cy + 290);
  ctx.stroke();

  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;

  // Alpha falloff mask so floor melts 100% seamlessly into #08080A void with zero edge line
  const alphaCanvas = document.createElement('canvas');
  alphaCanvas.width = 512;
  alphaCanvas.height = 512;
  const actx = alphaCanvas.getContext('2d')!;
  const agrad = actx.createRadialGradient(256, 256, 40, 256, 256, 246);
  agrad.addColorStop(0, '#ffffff');
  agrad.addColorStop(0.55, '#b8b8b8');
  agrad.addColorStop(0.85, '#2a2a2a');
  agrad.addColorStop(1, '#000000');
  actx.fillStyle = agrad;
  actx.fillRect(0, 0, 512, 512);

  const alphaMap = new THREE.CanvasTexture(alphaCanvas);

  return {map, alphaMap};
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(
    size / 2,
    size / 2,
    size * 0.08,
    size / 2,
    size / 2,
    size * 0.48,
  );
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.92)');
  grad.addColorStop(0.52, 'rgba(0, 0, 0, 0.5)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');

  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  return new THREE.CanvasTexture(canvas);
}

function createSteeringDisplayTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#090b0f';
  ctx.fillRect(0, 0, 256, 128);

  // RPM LED shift bar along top
  const ledColors = [
    '#22c55e',
    '#22c55e',
    '#22c55e',
    '#ef4444',
    '#ef4444',
    '#ef4444',
    '#38bdf8',
    '#38bdf8',
  ];
  ledColors.forEach((c, idx) => {
    ctx.fillStyle = c;
    ctx.fillRect(18 + idx * 28, 10, 18, 10);
  });

  // Gear & Delta telemetry graphic
  ctx.fillStyle = '#f4f4f6';
  ctx.font = 'bold 54px sans-serif';
  ctx.textAlign = 'center';
  ctx.fillText('7', 128, 86);

  ctx.fillStyle = '#e10600';
  ctx.fillRect(28, 102, 200, 6);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createF1Materials(maxAnisotropy: number): F1MaterialLibrary {
  const {map: carbonMap, bumpMap: carbonBump} = createCarbonTextures(maxAnisotropy);
  const treadBump = createTireTreadBumpTexture(maxAnisotropy);
  const sidewallMap = createTireSidewallTexture(maxAnisotropy);
  const {map: floorMap, alphaMap: floorAlpha} = createStudioFloorTextures(maxAnisotropy);
  const contactMap = createContactShadowTexture();
  const steeringTex = createSteeringDisplayTexture();

  const redPaint = new THREE.MeshPhysicalMaterial({
    color: 0xc20906,
    metalness: 0.44,
    roughness: 0.21,
    clearcoat: 1.0,
    clearcoatRoughness: 0.06,
    envMapIntensity: 1.45,
  });

  const redAccent = new THREE.MeshPhysicalMaterial({
    color: 0xe10600,
    metalness: 0.32,
    roughness: 0.24,
    clearcoat: 0.92,
    clearcoatRoughness: 0.09,
    envMapIntensity: 1.3,
  });

  const whiteStripe = new THREE.MeshStandardMaterial({
    color: 0xf4f4f6,
    metalness: 0.14,
    roughness: 0.26,
  });

  const matteCarbon = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: carbonMap,
    bumpMap: carbonBump,
    bumpScale: 0.008,
    roughness: 0.72,
    metalness: 0.14,
  });

  const glossCarbon = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    map: carbonMap,
    bumpMap: carbonBump,
    bumpScale: 0.004,
    roughness: 0.26,
    metalness: 0.22,
    clearcoat: 0.75,
    clearcoatRoughness: 0.12,
  });

  const titanium = new THREE.MeshPhysicalMaterial({
    color: 0xc4c9d2,
    metalness: 0.92,
    roughness: 0.18,
    anisotropy: 0.8,
    envMapIntensity: 1.45,
  });

  const exhaustMetal = new THREE.MeshStandardMaterial({
    color: 0x9b8270,
    metalness: 0.88,
    roughness: 0.24,
    emissive: new THREE.Color(0xff4500),
    emissiveIntensity: 0.18,
  });

  const tireRubber = new THREE.MeshStandardMaterial({
    color: 0x17181c,
    bumpMap: treadBump,
    bumpScale: 0.003,
    roughness: 0.86,
    metalness: 0.04,
  });

  const tireSidewall = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: sidewallMap,
    roughness: 0.76,
    metalness: 0.06,
  });

  const wheelRim = new THREE.MeshPhysicalMaterial({
    color: 0x20232b,
    metalness: 0.85,
    roughness: 0.22,
    clearcoat: 0.45,
    envMapIntensity: 1.35,
  });

  const brakeDisc = new THREE.MeshStandardMaterial({
    color: 0x2c2d33,
    roughness: 0.45,
    metalness: 0.65,
    emissive: new THREE.Color(0xff3300),
    emissiveIntensity: 0.12,
  });

  const brakeCaliper = new THREE.MeshStandardMaterial({
    color: 0xd9100a,
    metalness: 0.55,
    roughness: 0.25,
    emissive: new THREE.Color(0xff2200),
    emissiveIntensity: 0.08,
  });

  const rainLight = new THREE.MeshStandardMaterial({
    color: 0xd10400,
    emissive: new THREE.Color(0xb80000),
    emissiveIntensity: 0.6,
    roughness: 0.25,
    metalness: 0.1,
  });

  const helmetShell = new THREE.MeshPhysicalMaterial({
    color: 0xf4f4f6,
    metalness: 0.22,
    roughness: 0.16,
    clearcoat: 1.0,
    clearcoatRoughness: 0.04,
  });

  const visor = new THREE.MeshPhysicalMaterial({
    color: 0x0b0e14,
    metalness: 0.92,
    roughness: 0.06,
    clearcoat: 1.0,
    iridescence: 0.9,
    iridescenceIOR: 1.42,
  });

  const cockpitAlcantara = new THREE.MeshStandardMaterial({
    color: 0x101114,
    roughness: 0.94,
    metalness: 0.02,
  });

  const seatCarbon = new THREE.MeshPhysicalMaterial({
    color: 0xffffff,
    map: carbonMap,
    bumpMap: carbonBump,
    bumpScale: 0.004,
    roughness: 0.34,
    metalness: 0.18,
    clearcoat: 0.5,
  });

  const harnessRed = new THREE.MeshStandardMaterial({
    color: 0xb90806,
    roughness: 0.82,
    metalness: 0.05,
  });

  const steeringDisplay = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: steeringTex,
    emissive: new THREE.Color(0xffffff),
    emissiveMap: steeringTex,
    emissiveIntensity: 0.85,
    roughness: 0.2,
  });

  const floorSurface = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    map: floorMap,
    alphaMap: floorAlpha,
    transparent: true,
    roughness: 0.86,
    metalness: 0.08,
  });

  const contactShadow = new THREE.MeshBasicMaterial({
    map: contactMap,
    transparent: true,
    opacity: 0.72,
    depthWrite: false,
  });

  const allMaterials: THREE.Material[] = [
    redPaint,
    redAccent,
    whiteStripe,
    matteCarbon,
    glossCarbon,
    titanium,
    exhaustMetal,
    tireRubber,
    tireSidewall,
    wheelRim,
    brakeDisc,
    brakeCaliper,
    rainLight,
    helmetShell,
    visor,
    cockpitAlcantara,
    seatCarbon,
    harnessRed,
    steeringDisplay,
    floorSurface,
    contactShadow,
  ];

  const textures: THREE.Texture[] = [
    carbonMap,
    carbonBump,
    treadBump,
    sidewallMap,
    floorMap,
    floorAlpha,
    contactMap,
    steeringTex,
  ];

  return {
    redPaint,
    redAccent,
    whiteStripe,
    matteCarbon,
    glossCarbon,
    titanium,
    exhaustMetal,
    tireRubber,
    tireSidewall,
    wheelRim,
    brakeDisc,
    brakeCaliper,
    rainLight,
    helmetShell,
    visor,
    cockpitAlcantara,
    seatCarbon,
    harnessRed,
    steeringDisplay,
    floorSurface,
    contactShadow,
    textures,
    dispose: () => {
      allMaterials.forEach((m) => m.dispose());
      textures.forEach((t) => t.dispose());
    },
  };
}
