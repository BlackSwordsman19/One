import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import {
  createCamberedWingBlade,
  createLoftedHull,
  sampleStationsSmooth,
} from './loftGeometry';

test('sampleStationsSmooth interpolates G2 smooth station progression', () => {
  const sampled = sampleStationsSmooth(
    [
      {z: 2, centerY: 0.2, rx: 0.1, ryTop: 0.05, ryBottom: 0.04},
      {z: 0, centerY: 0.4, rx: 0.3, ryTop: 0.2, ryBottom: 0.1},
      {z: -2, centerY: 0.3, rx: 0.15, ryTop: 0.12, ryBottom: 0.08},
    ],
    4,
  );
  assert.equal(sampled.length, 9);
  assert.equal(sampled[0].z, 2);
  assert.equal(sampled[sampled.length - 1].z, -2);
  assert.ok(sampled[4].rx > sampled[0].rx);
});

test('createLoftedHull produces finite vertices and outward-facing normals', () => {
  const geo = createLoftedHull(
    [
      {z: 1, centerY: 0.5, rx: 0.2, ryTop: 0.2, ryBottom: 0.2},
      {z: -1, centerY: 0.5, rx: 0.2, ryTop: 0.2, ryBottom: 0.2},
    ],
    16,
    2,
  );
  const pos = geo.getAttribute('position');
  const norm = geo.getAttribute('normal');
  assert.ok(pos.count > 0);
  assert.equal(pos.count, norm.count);

  // Check vertex normals near the middle ring point outward from axis (0, 0.5, z)
  let outwardDotSum = 0;
  for (let i = 0; i < pos.count - 2; i++) {
    const vx = pos.getX(i);
    const vy = pos.getY(i) - 0.5;
    const nx = norm.getX(i);
    const ny = norm.getY(i);
    outwardDotSum += vx * nx + vy * ny;
  }
  assert.ok(outwardDotSum > 0, 'Lofted hull normals must point outward');
  geo.dispose();
});

test('createCamberedWingBlade builds swept airfoil geometry with valid bounds', () => {
  const wing = createCamberedWingBlade({
    span: 1.9,
    centerChord: 0.22,
    tipChord: 0.14,
    thickness: 0.025,
    sweepBack: 0.2,
    centerArchY: -0.03,
    camber: 0.02,
    pitchRad: 0.1,
  });
  wing.computeBoundingBox();
  const size = new THREE.Vector3();
  wing.boundingBox!.getSize(size);
  assert.ok(Math.abs(size.x - 1.9) < 0.05);
  assert.ok(size.z > 0.2);
  wing.dispose();
});
