import * as THREE from 'three';
import {
  createCamberedWingBlade,
  createLoftedHull,
  LoftStation,
} from './loftGeometry';
import {F1MaterialLibrary} from './materials';

export interface F1CarRig {
  root: THREE.Group;
  wheels: THREE.Group[];
  drsFlapPivot: THREE.Group;
  brakeMaterials: {
    disc: THREE.MeshStandardMaterial;
    caliper: THREE.MeshStandardMaterial;
  };
  rainLightMaterial: THREE.MeshStandardMaterial;
  exhaustMaterial: THREE.MeshStandardMaterial;
  dispose: () => void;
}

function createExtrudedProfile(
  points: Array<[number, number]>,
  depth: number,
  bevelThickness = 0.012,
  bevelSize = 0.01,
): THREE.ExtrudeGeometry {
  const shape = new THREE.Shape();
  shape.moveTo(points[0][0], points[0][1]);
  for (let i = 1; i < points.length; i++) {
    shape.lineTo(points[i][0], points[i][1]);
  }
  shape.closePath();

  const geo = new THREE.ExtrudeGeometry(shape, {
    steps: 1,
    depth,
    bevelEnabled: true,
    bevelThickness,
    bevelSize,
    bevelSegments: 3,
  });
  geo.center();
  return geo;
}

function buildWheelAssembly(
  radius: number,
  width: number,
  isLeft: boolean,
  materials: F1MaterialLibrary,
  geometriesToDispose: THREE.BufferGeometry[],
): {assembly: THREE.Group; spinGroup: THREE.Group} {
  const assembly = new THREE.Group();
  const spinGroup = new THREE.Group();

  const halfW = width / 2;
  const rimR = radius * 0.62; // 18-inch modern F1 low-profile tire ratio

  // Curvy bulged tire cross-section via LatheGeometry (48 segments)
  const lathePoints = [
    new THREE.Vector2(rimR * 0.96, -halfW * 0.86),
    new THREE.Vector2(rimR * 1.12, -halfW * 0.96),
    new THREE.Vector2(radius * 0.85, -halfW * 1.02), // sidewall bulge
    new THREE.Vector2(radius * 0.96, -halfW * 0.94), // rounded shoulder
    new THREE.Vector2(radius * 0.995, -halfW * 0.72),
    new THREE.Vector2(radius, 0), // subtle contact crown
    new THREE.Vector2(radius * 0.995, halfW * 0.72),
    new THREE.Vector2(radius * 0.96, halfW * 0.94),
    new THREE.Vector2(radius * 0.85, halfW * 1.02),
    new THREE.Vector2(rimR * 1.12, halfW * 0.96),
    new THREE.Vector2(rimR * 0.96, halfW * 0.86),
  ];
  const tireGeo = new THREE.LatheGeometry(lathePoints, 48);
  tireGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(tireGeo);

  const tireMesh = new THREE.Mesh(tireGeo, materials.tireRubber);
  tireMesh.castShadow = true;
  tireMesh.receiveShadow = true;
  spinGroup.add(tireMesh);

  // Outer & Inner Sidewall graphics discs (tilted slightly to match sidewall curve)
  const sidewallGeo = new THREE.RingGeometry(rimR * 0.99, radius * 0.93, 48);
  geometriesToDispose.push(sidewallGeo);

  const outerSidewall = new THREE.Mesh(sidewallGeo, materials.tireSidewall);
  outerSidewall.rotation.y = isLeft ? Math.PI / 2 : -Math.PI / 2;
  outerSidewall.position.x = isLeft ? halfW * 0.99 : -halfW * 0.99;
  spinGroup.add(outerSidewall);

  const innerSidewall = new THREE.Mesh(sidewallGeo, materials.tireSidewall);
  innerSidewall.rotation.y = isLeft ? -Math.PI / 2 : Math.PI / 2;
  innerSidewall.position.x = isLeft ? -halfW * 0.99 : halfW * 0.99;
  spinGroup.add(innerSidewall);

  // Deep-dish sculpted magnesium wheel barrel
  const barrelGeo = new THREE.CylinderGeometry(rimR, rimR * 0.96, width * 0.84, 32, 1, true);
  barrelGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(barrelGeo);
  const barrelMesh = new THREE.Mesh(barrelGeo, materials.wheelRim);
  spinGroup.add(barrelMesh);

  // Rim outer lip flange
  const lipGeo = new THREE.TorusGeometry(rimR * 0.98, 0.014, 12, 36);
  lipGeo.rotateY(Math.PI / 2);
  geometriesToDispose.push(lipGeo);
  const rimLip = new THREE.Mesh(lipGeo, materials.titanium);
  rimLip.position.x = isLeft ? halfW * 0.82 : -halfW * 0.82;
  spinGroup.add(rimLip);

  // Sculpted 10-Spoke Racing Wheel Spider
  const spokeGeo = new THREE.BoxGeometry(0.022, rimR * 0.86, 0.022);
  geometriesToDispose.push(spokeGeo);
  const outerFaceX = isLeft ? halfW * 0.66 : -halfW * 0.66;
  for (let s = 0; s < 10; s++) {
    const angle = (s / 10) * Math.PI * 2;
    const spoke = new THREE.Mesh(spokeGeo, materials.wheelRim);
    spoke.position.set(
      outerFaceX,
      Math.cos(angle) * (rimR * 0.52),
      Math.sin(angle) * (rimR * 0.52),
    );
    spoke.rotation.x = angle;
    spinGroup.add(spoke);
  }

  // Crimson spoke accent tab so wheel rotation is crisp and unmistakable
  const accentSpokeGeo = new THREE.BoxGeometry(0.026, rimR * 0.72, 0.018);
  geometriesToDispose.push(accentSpokeGeo);
  const accentSpoke = new THREE.Mesh(accentSpokeGeo, materials.redAccent);
  accentSpoke.position.set(outerFaceX + (isLeft ? 0.006 : -0.006), rimR * 0.52, 0);
  spinGroup.add(accentSpoke);

  // Center-lock titanium wheel hub & anodized red lock ring
  const hubGeo = new THREE.CylinderGeometry(0.072, 0.088, 0.07, 24);
  hubGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(hubGeo);
  const hubMesh = new THREE.Mesh(hubGeo, materials.wheelRim);
  hubMesh.position.x = outerFaceX;
  spinGroup.add(hubMesh);

  const nutGeo = new THREE.CylinderGeometry(0.044, 0.052, 0.06, 6);
  nutGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(nutGeo);
  const nutMesh = new THREE.Mesh(nutGeo, materials.titanium);
  nutMesh.position.x = outerFaceX + (isLeft ? 0.032 : -0.032);
  spinGroup.add(nutMesh);

  const lockRingGeo = new THREE.TorusGeometry(0.056, 0.008, 10, 24);
  lockRingGeo.rotateY(Math.PI / 2);
  geometriesToDispose.push(lockRingGeo);
  const lockRing = new THREE.Mesh(lockRingGeo, materials.redAccent);
  lockRing.position.x = outerFaceX + (isLeft ? 0.028 : -0.028);
  spinGroup.add(lockRing);

  // Stationary Carbon-Ceramic Brake Rotor, Glowing Caliper & Carbon Brake Duct Scoop
  const discGeo = new THREE.CylinderGeometry(rimR * 0.76, rimR * 0.76, 0.032, 28);
  discGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(discGeo);
  const discMesh = new THREE.Mesh(discGeo, materials.brakeDisc);
  discMesh.position.x = isLeft ? -halfW * 0.16 : halfW * 0.16;
  assembly.add(discMesh);

  const caliperGeo = new THREE.BoxGeometry(0.085, 0.16, 0.13);
  geometriesToDispose.push(caliperGeo);
  const caliperMesh = new THREE.Mesh(caliperGeo, materials.brakeCaliper);
  caliperMesh.position.set(isLeft ? -halfW * 0.16 : halfW * 0.16, 0.04, -0.14);
  assembly.add(caliperMesh);

  // Inner carbon brake-duct shroud
  const ductGeo = new THREE.CylinderGeometry(rimR * 0.74, rimR * 0.84, 0.08, 20, 1, false, 0, Math.PI);
  ductGeo.rotateZ(Math.PI / 2);
  geometriesToDispose.push(ductGeo);
  const ductMesh = new THREE.Mesh(ductGeo, materials.matteCarbon);
  ductMesh.position.x = isLeft ? -halfW * 0.44 : halfW * 0.44;
  assembly.add(ductMesh);

  assembly.add(spinGroup);
  return {assembly, spinGroup};
}

function addAirfoilSuspensionLink(
  parent: THREE.Group,
  start: THREE.Vector3,
  end: THREE.Vector3,
  radius: number,
  material: THREE.Material,
  geometriesToDispose: THREE.BufferGeometry[],
) {
  const dir = new THREE.Vector3().subVectors(end, start);
  const len = dir.length();
  const geo = new THREE.CylinderGeometry(radius, radius * 0.9, len, 8);
  // Flatten into sleek carbon airfoil wishbone blade
  geo.scale(1.0, 1.0, 2.2);
  geometriesToDispose.push(geo);

  const mesh = new THREE.Mesh(geo, material);
  mesh.position.copy(start).addScaledVector(dir, 0.5);
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir.normalize());
  mesh.castShadow = true;
  parent.add(mesh);
}

export function buildF1Car(materials: F1MaterialLibrary): F1CarRig {
  const root = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const wheels: THREE.Group[] = [];

  // ---------------------------------------------------------------------------
  // 1. STREAMLINED LOFTED FUSELAGE (Nose -> Monocoque -> Airbox -> Coke-Bottle Tail)
  // ---------------------------------------------------------------------------
  const fuselageStations: LoftStation[] = [
    {z: 2.82, centerY: 0.175, rx: 0.048, ryTop: 0.025, ryBottom: 0.018, topPower: 2.2, bottomPower: 3.0},
    {z: 2.58, centerY: 0.215, rx: 0.115, ryTop: 0.045, ryBottom: 0.032, topPower: 2.2, bottomPower: 3.2},
    {z: 2.08, centerY: 0.285, rx: 0.155, ryTop: 0.075, ryBottom: 0.048, topPower: 2.1, bottomPower: 3.4},
    {z: 1.48, centerY: 0.365, rx: 0.21, ryTop: 0.125, ryBottom: 0.085, topPower: 2.0, bottomPower: 3.4},
    {z: 0.88, centerY: 0.415, rx: 0.265, ryTop: 0.165, ryBottom: 0.15, topPower: 2.2, bottomPower: 3.6},
    {z: 0.56, centerY: 0.42, rx: 0.285, ryTop: 0.155, ryBottom: 0.18, topPower: 2.4, bottomPower: 3.6},
    // Cockpit waist (slightly lower top so open cockpit tub sits cleanly inside)
    {z: 0.15, centerY: 0.36, rx: 0.28, ryTop: 0.145, ryBottom: 0.17, topPower: 2.6, bottomPower: 3.6},
    {z: -0.08, centerY: 0.44, rx: 0.275, ryTop: 0.22, ryBottom: 0.19, topPower: 2.2, bottomPower: 3.5},
    // Roll-hoop / Overhead Airbox peak
    {z: -0.28, centerY: 0.54, rx: 0.24, ryTop: 0.41, ryBottom: 0.26, topPower: 1.45, bottomPower: 3.2},
    // Sweeping Engine Cover Spine tapering into Coke-bottle tail
    {z: -0.82, centerY: 0.48, rx: 0.22, ryTop: 0.34, ryBottom: 0.23, topPower: 1.5, bottomPower: 3.0},
    {z: -1.48, centerY: 0.38, rx: 0.165, ryTop: 0.26, ryBottom: 0.19, topPower: 1.55, bottomPower: 2.8},
    {z: -2.02, centerY: 0.33, rx: 0.115, ryTop: 0.16, ryBottom: 0.14, topPower: 1.75, bottomPower: 2.4},
    {z: -2.3, centerY: 0.3, rx: 0.082, ryTop: 0.095, ryBottom: 0.11, topPower: 2.0, bottomPower: 2.2},
  ];

  const fuselageGeo = createLoftedHull(fuselageStations, 40, 4);
  geometries.push(fuselageGeo);
  const fuselageMesh = new THREE.Mesh(fuselageGeo, materials.redPaint);
  fuselageMesh.castShadow = true;
  fuselageMesh.receiveShadow = true;
  root.add(fuselageMesh);

  // White racing nose livery stripe following nose arch
  const stripeStations: LoftStation[] = [
    {z: 2.75, centerY: 0.215, rx: 0.025, ryTop: 0.008, ryBottom: 0.005},
    {z: 2.08, centerY: 0.362, rx: 0.038, ryTop: 0.008, ryBottom: 0.005},
    {z: 1.48, centerY: 0.492, rx: 0.044, ryTop: 0.008, ryBottom: 0.005},
    {z: 0.92, centerY: 0.582, rx: 0.048, ryTop: 0.008, ryBottom: 0.005},
  ];
  const stripeGeo = createLoftedHull(stripeStations, 16, 4);
  geometries.push(stripeGeo);
  const noseStripe = new THREE.Mesh(stripeGeo, materials.whiteStripe);
  root.add(noseStripe);

  // Overhead Roll-Hoop Airbox Intake Cowling (dark recessed scoop)
  const airboxGeo = new THREE.CylinderGeometry(0.088, 0.115, 0.22, 20);
  airboxGeo.rotateX(Math.PI / 2);
  airboxGeo.scale(1.0, 1.15, 1.0);
  geometries.push(airboxGeo);
  const airboxIntake = new THREE.Mesh(airboxGeo, materials.cockpitAlcantara);
  airboxIntake.position.set(0, 0.85, -0.2);
  root.add(airboxIntake);

  // Curved Dorsal Shark Fin
  const sharkFinShape = new THREE.Shape();
  sharkFinShape.moveTo(-0.38, 0.88);
  sharkFinShape.quadraticCurveTo(-0.95, 0.85, -1.55, 0.72);
  sharkFinShape.lineTo(-1.95, 0.52);
  sharkFinShape.lineTo(-1.95, 0.36);
  sharkFinShape.lineTo(-0.38, 0.62);
  sharkFinShape.closePath();

  const sharkFinGeo = new THREE.ExtrudeGeometry(sharkFinShape, {
    steps: 1,
    depth: 0.016,
    bevelEnabled: true,
    bevelThickness: 0.005,
    bevelSize: 0.005,
    bevelSegments: 2,
  });
  sharkFinGeo.center();
  sharkFinGeo.rotateY(-Math.PI / 2);
  geometries.push(sharkFinGeo);
  const sharkFin = new THREE.Mesh(sharkFinGeo, materials.matteCarbon);
  sharkFin.position.set(0, 0.66, -1.17);
  sharkFin.castShadow = true;
  root.add(sharkFin);

  // ---------------------------------------------------------------------------
  // 2. CURVY COANDA DOWNWASH SIDEPODS (Left & Right Smooth Lofted Pods)
  // ---------------------------------------------------------------------------
  for (const side of [-1, 1]) {
    const podStations: LoftStation[] = [
      // Overbite top cooling lip & sharp forward nose
      {z: 0.78, centerX: side * 0.44, centerY: 0.43, rx: 0.22, ryTop: 0.08, ryBottom: 0.06, topPower: 2.2, bottomPower: 2.4},
      {z: 0.6, centerX: side * 0.49, centerY: 0.38, rx: 0.28, ryTop: 0.145, ryBottom: 0.16, topPower: 2.3, bottomPower: 2.6, topTrough: 0.08},
      {z: 0.2, centerX: side * 0.51, centerY: 0.34, rx: 0.31, ryTop: 0.175, ryBottom: 0.18, topPower: 2.2, bottomPower: 2.8, topTrough: 0.24},
      {z: -0.35, centerX: side * 0.48, centerY: 0.29, rx: 0.285, ryTop: 0.16, ryBottom: 0.165, topPower: 2.1, bottomPower: 2.9, topTrough: 0.28},
      {z: -0.95, centerX: side * 0.39, centerY: 0.24, rx: 0.215, ryTop: 0.125, ryBottom: 0.135, topPower: 2.0, bottomPower: 2.8, topTrough: 0.18},
      {z: -1.48, centerX: side * 0.27, centerY: 0.2, rx: 0.135, ryTop: 0.085, ryBottom: 0.09, topPower: 2.0, bottomPower: 2.5, topTrough: 0.05},
      {z: -1.78, centerX: side * 0.19, centerY: 0.18, rx: 0.075, ryTop: 0.055, ryBottom: 0.055, topPower: 2.0, bottomPower: 2.2},
    ];

    const podGeo = createLoftedHull(podStations, 34, 4);
    geometries.push(podGeo);
    const podMesh = new THREE.Mesh(podGeo, materials.redPaint);
    podMesh.castShadow = true;
    podMesh.receiveShadow = true;
    root.add(podMesh);

    // Recessed Dark Carbon Shark-Mouth Radiator Inlet
    const inletGeo = createExtrudedProfile(
      [
        [-0.17, 0.06],
        [0.17, 0.05],
        [0.14, -0.055],
        [-0.14, -0.055],
      ],
      0.08,
      0.014,
      0.014,
    );
    geometries.push(inletGeo);
    const inlet = new THREE.Mesh(inletGeo, materials.cockpitAlcantara);
    inlet.position.set(side * 0.49, 0.39, 0.69);
    inlet.rotation.y = side * -0.14;
    root.add(inlet);

    // Curved Carbon Bargeboard / Sidepod Undercut Winglet
    const bargeGeo = createExtrudedProfile(
      [
        [0.18, -0.11],
        [-0.22, -0.11],
        [-0.24, 0.14],
        [0.06, 0.1],
      ],
      0.016,
      0.005,
      0.005,
    );
    bargeGeo.rotateY(-Math.PI / 2);
    geometries.push(bargeGeo);
    const barge = new THREE.Mesh(bargeGeo, materials.glossCarbon);
    barge.position.set(side * 0.78, 0.22, 0.85);
    barge.rotation.y = side * 0.14;
    root.add(barge);

    // Sculpted Rear-View Mirror with curved aero stay
    const mirrorPodGeo = createLoftedHull(
      [
        {z: 0.055, centerY: 0, rx: 0.06, ryTop: 0.022, ryBottom: 0.022},
        {z: -0.045, centerY: 0, rx: 0.048, ryTop: 0.018, ryBottom: 0.018},
      ],
      16,
      2,
    );
    geometries.push(mirrorPodGeo);
    const mirror = new THREE.Mesh(mirrorPodGeo, materials.redPaint);
    mirror.position.set(side * 0.45, 0.61, 0.48);
    root.add(mirror);

    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(side * 0.28, 0.56, 0.48),
      new THREE.Vector3(side * 0.44, 0.6, 0.48),
      0.008,
      materials.glossCarbon,
      geometries,
    );
  }

  // ---------------------------------------------------------------------------
  // 3. COCKPIT TUB, CARBON BUCKET SEAT, HARNESS, F1 STEERING WHEEL & HALO
  // ---------------------------------------------------------------------------
  // Recessed cockpit surround lip (curved carbon rim)
  const coamingCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.23, 0.54, 0.54),
    new THREE.Vector3(-0.25, 0.55, 0.2),
    new THREE.Vector3(-0.21, 0.59, -0.12),
    new THREE.Vector3(0, 0.62, -0.17),
    new THREE.Vector3(0.21, 0.59, -0.12),
    new THREE.Vector3(0.25, 0.55, 0.2),
    new THREE.Vector3(0.23, 0.54, 0.54),
  ]);
  const coamingGeo = new THREE.TubeGeometry(coamingCurve, 32, 0.028, 12, false);
  geometries.push(coamingGeo);
  const coaming = new THREE.Mesh(coamingGeo, materials.glossCarbon);
  root.add(coaming);

  // Dark cockpit interior floor tub
  const tubGeo = new THREE.BoxGeometry(0.4, 0.14, 0.78);
  geometries.push(tubGeo);
  const cockpitTub = new THREE.Mesh(tubGeo, materials.cockpitAlcantara);
  cockpitTub.position.set(0, 0.46, 0.2);
  root.add(cockpitTub);

  // Reclined Ergonomic Carbon Racing Bucket Seat (profile extruded & beveled)
  const seatBackShape = new THREE.Shape();
  seatBackShape.moveTo(0.46, 0.36); // thigh support front
  seatBackShape.quadraticCurveTo(0.26, 0.33, 0.12, 0.36); // seat pan
  seatBackShape.quadraticCurveTo(-0.04, 0.45, -0.09, 0.64); // reclined lumbar/shoulders
  seatBackShape.lineTo(-0.14, 0.64);
  seatBackShape.quadraticCurveTo(-0.08, 0.42, 0.11, 0.32);
  seatBackShape.quadraticCurveTo(0.28, 0.3, 0.47, 0.33);
  seatBackShape.closePath();

  const seatGeo = new THREE.ExtrudeGeometry(seatBackShape, {
    steps: 1,
    depth: 0.34,
    bevelEnabled: true,
    bevelThickness: 0.015,
    bevelSize: 0.012,
    bevelSegments: 3,
  });
  seatGeo.center();
  seatGeo.rotateY(-Math.PI / 2);
  geometries.push(seatGeo);
  const driverSeat = new THREE.Mesh(seatGeo, materials.seatCarbon);
  driverSeat.position.set(0, 0.46, 0.18);
  root.add(driverSeat);

  // Seat Side Shoulder Bolsters + U-Shaped FIA Headrest Padding
  const bolsterGeo = createExtrudedProfile(
    [
      [0.14, -0.08],
      [-0.12, -0.08],
      [-0.14, 0.12],
      [0.06, 0.08],
    ],
    0.04,
    0.012,
    0.012,
  );
  bolsterGeo.rotateY(-Math.PI / 2);
  geometries.push(bolsterGeo);
  for (const side of [-1, 1]) {
    const bolster = new THREE.Mesh(bolsterGeo, materials.cockpitAlcantara);
    bolster.position.set(side * 0.165, 0.54, 0.08);
    root.add(bolster);
  }

  // Crimson 6-Point Racing Harness Shoulder Straps
  const strapCurveLeft = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.09, 0.61, 0.01),
    new THREE.Vector3(-0.08, 0.51, 0.14),
    new THREE.Vector3(-0.05, 0.41, 0.24),
  ]);
  const strapCurveRight = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0.09, 0.61, 0.01),
    new THREE.Vector3(0.08, 0.51, 0.14),
    new THREE.Vector3(0.05, 0.41, 0.24),
  ]);
  for (const c of [strapCurveLeft, strapCurveRight]) {
    const strapGeo = new THREE.TubeGeometry(c, 12, 0.015, 8, false);
    geometries.push(strapGeo);
    const strap = new THREE.Mesh(strapGeo, materials.harnessRed);
    root.add(strap);
  }

  // F1 Butterfly Carbon Steering Wheel + Illuminated Telemetry Screen
  const steeringGroup = new THREE.Group();
  steeringGroup.position.set(0, 0.54, 0.42);
  steeringGroup.rotation.x = -0.35;

  const wheelPlateGeo = new THREE.BoxGeometry(0.24, 0.13, 0.022);
  geometries.push(wheelPlateGeo);
  const wheelPlate = new THREE.Mesh(wheelPlateGeo, materials.glossCarbon);
  steeringGroup.add(wheelPlate);

  const gripGeo = new THREE.CapsuleGeometry(0.022, 0.085, 6, 12);
  geometries.push(gripGeo);
  for (const side of [-1, 1]) {
    const grip = new THREE.Mesh(gripGeo, materials.cockpitAlcantara);
    grip.position.set(side * 0.115, 0, 0);
    steeringGroup.add(grip);
  }

  const screenGeo = new THREE.PlaneGeometry(0.11, 0.058);
  geometries.push(screenGeo);
  const screenMesh = new THREE.Mesh(screenGeo, materials.steeringDisplay);
  screenMesh.rotation.y = Math.PI;
  screenMesh.position.set(0, 0.012, -0.013);
  steeringGroup.add(screenMesh);

  const columnGeo = new THREE.CylinderGeometry(0.018, 0.022, 0.22, 12);
  columnGeo.rotateX(Math.PI / 2);
  geometries.push(columnGeo);
  const column = new THREE.Mesh(columnGeo, materials.titanium);
  column.position.set(0, 0, 0.11);
  steeringGroup.add(column);
  root.add(steeringGroup);

  // Sculpted Driver Helmet + Rear Aero Spoiler + Iridescent Visor
  const helmetGeo = new THREE.SphereGeometry(0.128, 28, 24);
  geometries.push(helmetGeo);
  const helmet = new THREE.Mesh(helmetGeo, materials.helmetShell);
  helmet.position.set(0, 0.64, 0.1);
  helmet.scale.set(0.92, 0.98, 1.16);
  helmet.castShadow = true;
  root.add(helmet);

  const visorGeo = new THREE.CylinderGeometry(
    0.126,
    0.126,
    0.068,
    24,
    1,
    true,
    -Math.PI * 0.36,
    Math.PI * 0.72,
  );
  geometries.push(visorGeo);
  const visor = new THREE.Mesh(visorGeo, materials.visor);
  visor.position.set(0, 0.655, 0.13);
  root.add(visor);

  // Helmet crimson crown stripe
  const hStripeGeo = new THREE.TorusGeometry(0.126, 0.012, 8, 24, Math.PI * 0.85);
  hStripeGeo.rotateY(Math.PI / 2);
  geometries.push(hStripeGeo);
  const hStripe = new THREE.Mesh(hStripeGeo, materials.redAccent);
  hStripe.position.set(0, 0.64, 0.1);
  hStripe.rotation.x = -0.3;
  root.add(hStripe);

  // Streamlined Titanium-Carbon Halo Safety Arch
  const haloCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(-0.22, 0.61, -0.07),
    new THREE.Vector3(-0.23, 0.735, 0.28),
    new THREE.Vector3(0, 0.755, 0.6),
    new THREE.Vector3(0.23, 0.735, 0.28),
    new THREE.Vector3(0.22, 0.61, -0.07),
  ]);
  const haloArchGeo = new THREE.TubeGeometry(haloCurve, 36, 0.023, 12, false);
  geometries.push(haloArchGeo);
  const haloArch = new THREE.Mesh(haloArchGeo, materials.glossCarbon);
  haloArch.castShadow = true;
  root.add(haloArch);

  const haloStemCurve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.56, 0.76),
    new THREE.Vector3(0, 0.66, 0.68),
    new THREE.Vector3(0, 0.75, 0.59),
  ]);
  const haloStemGeo = new THREE.TubeGeometry(haloStemCurve, 12, 0.022, 10, false);
  geometries.push(haloStemGeo);
  const haloStem = new THREE.Mesh(haloStemGeo, materials.glossCarbon);
  root.add(haloStem);

  // ---------------------------------------------------------------------------
  // 4. UNDERBODY VENTURI FLOOR, EDGE WINGS & MULTI-STRAKE DIFFUSER
  // ---------------------------------------------------------------------------
  const floorShape = new THREE.Shape();
  floorShape.moveTo(-0.42, 1.38);
  floorShape.lineTo(0.42, 1.38);
  floorShape.quadraticCurveTo(0.84, 1.08, 0.85, 0.72);
  floorShape.lineTo(0.84, -1.24);
  floorShape.quadraticCurveTo(0.74, -1.78, 0.58, -2.18);
  floorShape.lineTo(-0.58, -2.18);
  floorShape.quadraticCurveTo(-0.74, -1.78, -0.84, -1.24);
  floorShape.lineTo(-0.85, 0.72);
  floorShape.quadraticCurveTo(-0.84, 1.08, -0.42, 1.38);
  floorShape.closePath();

  const floorGeo = new THREE.ExtrudeGeometry(floorShape, {
    steps: 1,
    depth: 0.028,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.014,
    bevelSegments: 3,
  });
  floorGeo.rotateX(Math.PI / 2);
  geometries.push(floorGeo);

  const floorMesh = new THREE.Mesh(floorGeo, materials.matteCarbon);
  floorMesh.position.set(0, 0.068, 0);
  floorMesh.castShadow = true;
  floorMesh.receiveShadow = true;
  root.add(floorMesh);

  // Sculpted floor edge wings & red aero trim
  const floorEdgeGeo = new THREE.BoxGeometry(0.02, 0.024, 1.88);
  geometries.push(floorEdgeGeo);
  for (const side of [-1, 1]) {
    const trim = new THREE.Mesh(floorEdgeGeo, materials.redAccent);
    trim.position.set(side * 0.85, 0.078, -0.24);
    root.add(trim);
  }

  // Rear Venturi Diffuser Ramp & Strakes
  const diffuserRampGeo = new THREE.BoxGeometry(1.12, 0.032, 0.56);
  geometries.push(diffuserRampGeo);
  const diffuserRamp = new THREE.Mesh(diffuserRampGeo, materials.matteCarbon);
  diffuserRamp.position.set(0, 0.16, -2.18);
  diffuserRamp.rotation.x = 0.28;
  root.add(diffuserRamp);

  const strakeGeo = new THREE.BoxGeometry(0.016, 0.17, 0.46);
  geometries.push(strakeGeo);
  for (const sx of [-0.46, -0.24, 0, 0.24, 0.46]) {
    const strake = new THREE.Mesh(strakeGeo, materials.glossCarbon);
    strake.position.set(sx, 0.155, -2.22);
    root.add(strake);
  }

  // ---------------------------------------------------------------------------
  // 5. CAMBERED GULL-WING FRONT WING & S-CURVED ENDPLATES
  // ---------------------------------------------------------------------------
  const frontWingGroup = new THREE.Group();
  frontWingGroup.position.set(0, 0.12, 2.58);

  const fwConfigs = [
    {y: 0.0, z: 0.14, cCenter: 0.22, cTip: 0.15, sweep: 0.22, arch: -0.028, pitch: 0.04, mat: materials.glossCarbon},
    {y: 0.04, z: 0.0, cCenter: 0.16, cTip: 0.11, sweep: 0.2, arch: -0.018, pitch: 0.14, mat: materials.redPaint},
    {y: 0.082, z: -0.12, cCenter: 0.13, cTip: 0.09, sweep: 0.18, arch: -0.01, pitch: 0.23, mat: materials.redPaint},
    {y: 0.122, z: -0.23, cCenter: 0.105, cTip: 0.075, sweep: 0.16, arch: 0.0, pitch: 0.32, mat: materials.glossCarbon},
  ];
  for (const fc of fwConfigs) {
    const bladeGeo = createCamberedWingBlade({
      span: 1.94,
      centerChord: fc.cCenter,
      tipChord: fc.cTip,
      thickness: 0.02,
      sweepBack: fc.sweep,
      centerArchY: fc.arch,
      camber: 0.018,
      pitchRad: fc.pitch,
      spanSegments: 28,
      chordSegments: 12,
    });
    geometries.push(bladeGeo);
    const blade = new THREE.Mesh(bladeGeo, fc.mat);
    blade.position.set(0, fc.y, fc.z);
    blade.castShadow = true;
    frontWingGroup.add(blade);
  }

  // Rounded Swept Front Wing Endplates
  const fwEpShape = new THREE.Shape();
  fwEpShape.moveTo(0.14, -0.03);
  fwEpShape.lineTo(-0.34, -0.03);
  fwEpShape.quadraticCurveTo(-0.36, 0.22, -0.2, 0.22);
  fwEpShape.quadraticCurveTo(0.05, 0.16, 0.14, 0.03);
  fwEpShape.closePath();

  const fwEndplateGeo = new THREE.ExtrudeGeometry(fwEpShape, {
    steps: 1,
    depth: 0.02,
    bevelEnabled: true,
    bevelThickness: 0.008,
    bevelSize: 0.008,
    bevelSegments: 3,
  });
  fwEndplateGeo.center();
  fwEndplateGeo.rotateY(-Math.PI / 2);
  geometries.push(fwEndplateGeo);

  for (const side of [-1, 1]) {
    const ep = new THREE.Mesh(fwEndplateGeo, materials.redPaint);
    ep.position.set(side * 0.985, 0.095, -0.14);
    ep.rotation.z = side * -0.11;
    ep.castShadow = true;
    frontWingGroup.add(ep);
  }
  root.add(frontWingGroup);

  // ---------------------------------------------------------------------------
  // 6. SPOON-CURVED REAR WING, DRS FLAP, CURVED SWAN-NECK PYLONS & BEAM WING
  // ---------------------------------------------------------------------------
  const rearWingGroup = new THREE.Group();
  rearWingGroup.position.set(0, 0.88, -2.5);

  // Curved Swan-Neck Pylons arching smoothly over mainplane
  for (const side of [-1, 1]) {
    const swanCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.13, -0.45, 0.28),
      new THREE.Vector3(side * 0.13, -0.16, 0.16),
      new THREE.Vector3(side * 0.13, 0.04, 0.1),
      new THREE.Vector3(side * 0.13, 0.02, -0.02),
    ]);
    const swanGeo = new THREE.TubeGeometry(swanCurve, 18, 0.022, 10, false);
    geometries.push(swanGeo);
    const swan = new THREE.Mesh(swanGeo, materials.matteCarbon);
    rearWingGroup.add(swan);
  }

  // Cambered Spoon-Shaped Mainplane
  const rwMainGeo = createCamberedWingBlade({
    span: 1.04,
    centerChord: 0.28,
    tipChord: 0.21,
    thickness: 0.026,
    sweepBack: 0.06,
    centerArchY: -0.035,
    camber: 0.024,
    pitchRad: 0.16,
    spanSegments: 24,
    chordSegments: 12,
  });
  geometries.push(rwMainGeo);
  const rwMain = new THREE.Mesh(rwMainGeo, materials.glossCarbon);
  rwMain.position.set(0, 0.0, 0.04);
  rwMain.castShadow = true;
  rearWingGroup.add(rwMain);

  // Articulated Cambered DRS Upper Flap
  const drsFlapPivot = new THREE.Group();
  drsFlapPivot.position.set(0, 0.09, -0.1);
  const drsFlapGeo = createCamberedWingBlade({
    span: 1.02,
    centerChord: 0.18,
    tipChord: 0.14,
    thickness: 0.018,
    sweepBack: 0.04,
    centerArchY: -0.02,
    camber: 0.018,
    pitchRad: 0.48,
    spanSegments: 24,
    chordSegments: 10,
  });
  geometries.push(drsFlapGeo);
  const drsFlapMesh = new THREE.Mesh(drsFlapGeo, materials.redAccent);
  drsFlapMesh.position.set(0, 0.01, 0.02);
  drsFlapMesh.castShadow = true;
  drsFlapPivot.add(drsFlapMesh);
  rearWingGroup.add(drsFlapPivot);

  // Sculpted Rounded Rear Wing Endplates
  const rwEpShape = new THREE.Shape();
  rwEpShape.moveTo(0.2, -0.34);
  rwEpShape.lineTo(-0.2, -0.34);
  rwEpShape.quadraticCurveTo(-0.26, -0.08, -0.22, 0.18);
  rwEpShape.quadraticCurveTo(0.0, 0.2, 0.22, 0.15);
  rwEpShape.quadraticCurveTo(0.24, -0.08, 0.2, -0.34);
  rwEpShape.closePath();

  const rwEndplateGeo = new THREE.ExtrudeGeometry(rwEpShape, {
    steps: 1,
    depth: 0.018,
    bevelEnabled: true,
    bevelThickness: 0.007,
    bevelSize: 0.007,
    bevelSegments: 3,
  });
  rwEndplateGeo.center();
  rwEndplateGeo.rotateY(-Math.PI / 2);
  geometries.push(rwEndplateGeo);

  for (const side of [-1, 1]) {
    const rep = new THREE.Mesh(rwEndplateGeo, materials.redPaint);
    rep.position.set(side * 0.53, -0.07, -0.02);
    rep.castShadow = true;
    rearWingGroup.add(rep);
  }

  // Lower Beam Wing
  const beamWingGeo = createCamberedWingBlade({
    span: 0.92,
    centerChord: 0.18,
    tipChord: 0.14,
    thickness: 0.018,
    sweepBack: 0.03,
    centerArchY: 0.01,
    camber: 0.015,
    pitchRad: 0.22,
    spanSegments: 20,
    chordSegments: 10,
  });
  geometries.push(beamWingGeo);
  const beamWing = new THREE.Mesh(beamWingGeo, materials.matteCarbon);
  beamWing.position.set(0, -0.38, 0.04);
  rearWingGroup.add(beamWing);
  root.add(rearWingGroup);

  // ---------------------------------------------------------------------------
  // 7. EXHAUST SYSTEM & FIA REAR RAIN LIGHT
  // ---------------------------------------------------------------------------
  const exhaustGeo = new THREE.CylinderGeometry(0.052, 0.06, 0.32, 24, 1, true);
  exhaustGeo.rotateX(Math.PI / 2);
  geometries.push(exhaustGeo);
  const mainExhaust = new THREE.Mesh(exhaustGeo, materials.exhaustMetal);
  mainExhaust.position.set(0, 0.39, -2.28);
  root.add(mainExhaust);

  const exhaustCoreGeo = new THREE.CircleGeometry(0.044, 18);
  geometries.push(exhaustCoreGeo);
  const exhaustCore = new THREE.Mesh(exhaustCoreGeo, materials.exhaustMetal);
  exhaustCore.rotation.y = Math.PI;
  exhaustCore.position.set(0, 0.39, -2.41);
  root.add(exhaustCore);

  const wgGeo = new THREE.CylinderGeometry(0.02, 0.024, 0.24, 14);
  wgGeo.rotateX(Math.PI / 2);
  geometries.push(wgGeo);
  for (const side of [-1, 1]) {
    const wg = new THREE.Mesh(wgGeo, materials.titanium);
    wg.position.set(side * 0.082, 0.355, -2.26);
    root.add(wg);
  }

  // FIA Rear Crash Structure & Rain Light
  const crashStructGeo = createLoftedHull(
    [
      {z: -2.22, centerY: 0.23, rx: 0.072, ryTop: 0.06, ryBottom: 0.055},
      {z: -2.52, centerY: 0.23, rx: 0.056, ryTop: 0.055, ryBottom: 0.05},
    ],
    20,
    2,
  );
  geometries.push(crashStructGeo);
  const crashStruct = new THREE.Mesh(crashStructGeo, materials.matteCarbon);
  root.add(crashStruct);

  const rainLightGeo = new THREE.BoxGeometry(0.068, 0.088, 0.02);
  geometries.push(rainLightGeo);
  const rainLightMesh = new THREE.Mesh(rainLightGeo, materials.rainLight);
  rainLightMesh.position.set(0, 0.23, -2.535);
  root.add(rainLightMesh);

  // ---------------------------------------------------------------------------
  // 8. 4 CURVY TIRES, 10-SPOKE WHEELS, BROW WINGLETS & AIRFOIL SUSPENSION
  // ---------------------------------------------------------------------------
  const wheelPlacements = [
    {x: 0.81, y: 0.36, z: 1.78, radius: 0.36, width: 0.31, isLeft: true, isFront: true},
    {x: -0.81, y: 0.36, z: 1.78, radius: 0.36, width: 0.31, isLeft: false, isFront: true},
    {x: 0.82, y: 0.365, z: -1.78, radius: 0.365, width: 0.4, isLeft: true, isFront: false},
    {x: -0.82, y: 0.365, z: -1.78, radius: 0.365, width: 0.4, isLeft: false, isFront: false},
  ];

  for (const wp of wheelPlacements) {
    const {assembly, spinGroup} = buildWheelAssembly(
      wp.radius,
      wp.width,
      wp.isLeft,
      materials,
      geometries,
    );
    assembly.position.set(wp.x, wp.y, wp.z);
    root.add(assembly);
    wheels.push(spinGroup);

    const sign = wp.isLeft ? 1 : -1;
    const innerX = sign * (wp.isFront ? 0.16 : 0.14);
    const outerX = sign * (wp.isFront ? 0.67 : 0.65);

    // Front tire aero brow winglets curving over the inner tire shoulder
    if (wp.isFront) {
      const browCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(sign * 0.62, 0.42, wp.z + 0.34),
        new THREE.Vector3(sign * 0.62, 0.71, wp.z + 0.16),
        new THREE.Vector3(sign * 0.63, 0.74, wp.z - 0.14),
      ]);
      const browGeo = new THREE.TubeGeometry(browCurve, 18, 0.014, 8, false);
      geometries.push(browGeo);
      const brow = new THREE.Mesh(browGeo, materials.glossCarbon);
      root.add(brow);
    }

    // Airfoil carbon double wishbones + pushrod/pullrod
    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(innerX, wp.y + 0.08, wp.z + 0.19),
      new THREE.Vector3(outerX, wp.y + 0.06, wp.z),
      0.011,
      materials.glossCarbon,
      geometries,
    );
    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(innerX, wp.y + 0.08, wp.z - 0.19),
      new THREE.Vector3(outerX, wp.y + 0.06, wp.z),
      0.011,
      materials.glossCarbon,
      geometries,
    );
    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(innerX, wp.y - 0.1, wp.z + 0.15),
      new THREE.Vector3(outerX, wp.y - 0.09, wp.z),
      0.011,
      materials.glossCarbon,
      geometries,
    );
    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(innerX, wp.y - 0.1, wp.z - 0.15),
      new THREE.Vector3(outerX, wp.y - 0.09, wp.z),
      0.011,
      materials.glossCarbon,
      geometries,
    );
    addAirfoilSuspensionLink(
      root,
      new THREE.Vector3(innerX, wp.isFront ? wp.y + 0.11 : wp.y - 0.11, wp.z - 0.05),
      new THREE.Vector3(outerX, wp.isFront ? wp.y - 0.07 : wp.y + 0.08, wp.z),
      0.01,
      materials.titanium,
      geometries,
    );
  }

  return {
    root,
    wheels,
    drsFlapPivot,
    brakeMaterials: {
      disc: materials.brakeDisc,
      caliper: materials.brakeCaliper,
    },
    rainLightMaterial: materials.rainLight,
    exhaustMaterial: materials.exhaustMetal,
    dispose: () => {
      geometries.forEach((g) => g.dispose());
    },
  };
}
