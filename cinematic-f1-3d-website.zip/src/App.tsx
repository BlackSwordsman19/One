import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  buildFormula1CarScene,
  bindLoadedGLBToF1CarRig,
  createCarbonWeaveTexture,
  type F1CarRig,
} from './f1CarBuilder';

gsap.registerPlugin(ScrollTrigger);

interface TelemetryState {
  chapterIndex: number;
  scrollProgress: number;
  speedKmh: number;
  rpm: number;
  gear: number;
  drsOpen: boolean;
  ersDeployPct: number;
  brakeTempFL: number;
  brakeTempFR: number;
  brakeTempRL: number;
  brakeTempRR: number;
  downforceKg: number;
  lateralG: number;
  longitudinalG: number;
  lapTimeStr: string;
  azimuthDeg: number;
  elevationDeg: number;
  glbLoadedStatus: string;
}

interface ChapterSpec {
  id: string;
  indexLabel: string;
  code: string;
  tag: string;
  titleLine1: string;
  titleLine2: string;
  accentWord: string;
  leadSide: 'left' | 'right';
  summary: string;
  metrics: { label: string; value: string; unit?: string; highlight?: boolean }[];
  telemetryTitle: string;
  telemetryCode: string;
  telemetryNotes: string[];
}

const CHAPTERS: ChapterSpec[] = [
  {
    id: 'hero',
    indexLabel: '01',
    code: 'SYS // CHASSIS-RB26',
    tag: 'LAUNCH SPECIFICATION // MONOCOQUE T-1100',
    titleLine1: 'THE ARCHITECTURE',
    titleLine2: 'OF ABSOLUTE',
    accentWord: 'VELOCITY',
    leadSide: 'left',
    summary:
      'Born in the computational wind tunnel and cured in aerospace autoclave carbon. 798 kilograms of predatory ground-effect precision engineered to bend physics at 362 km/h.',
    metrics: [
      { label: 'CHASSIS DRY MASS', value: '798.0', unit: 'KG', highlight: true },
      { label: 'WHEELBASE', value: '3,600', unit: 'MM' },
      { label: 'AERO BALANCE', value: '48.4', unit: '% FR' },
      { label: 'TORSIONAL RIGIDITY', value: '64.2', unit: 'kNm/°' },
    ],
    telemetryTitle: 'PRE-GRID SYSTEM DIAGNOSTIC',
    telemetryCode: 'FIA-ECU // STREAM ACTIVE',
    telemetryNotes: [
      'AUTOCLAVE CARBON SURVIVAL CELL: ARMED',
      'PULL-ROD FRONT / PUSH-ROD REAR SUSPENSION: NOMINAL',
      'PIRELLI P-ZERO C5 SOFT COMPOUND: 92°C OPTIMAL',
      'HYBRID ERS BATTERY SOC: 99.4% READY',
    ],
  },
  {
    id: 'aerodynamics',
    indexLabel: '02',
    code: 'CFD // VORTEX-MATRIX',
    tag: 'CHAPTER 01 // AERODYNAMICS & DRS',
    titleLine1: 'SCULPTED BY',
    titleLine2: 'GROUND-EFFECT',
    accentWord: 'VORTICES',
    leadSide: 'left',
    summary:
      'Four cascaded front-wing elements feed energized Y250 airflow into deep-undercut sidepods and twin Venturi underfloor tunnels, generating 1,420 kg of suction while active DRS sheds 24.6% drag on command.',
    metrics: [
      { label: 'PEAK DOWNFORCE', value: '1,420', unit: 'KG', highlight: true },
      { label: 'VENTURI SUCTION', value: '-4.85', unit: 'kPa' },
      { label: 'DRS DRAG DELTA', value: '-24.6', unit: '% Cd', highlight: true },
      { label: 'FLAP ACTUATION', value: '28.0', unit: 'DEG' },
    ],
    telemetryTitle: 'LIVE WIND-TUNNEL CFD MATRIX',
    telemetryCode: 'AERO // REYNOLDS 1.4e7',
    telemetryNotes: [
      'FRONT WING 4-ELEMENT OUTWASH: LAMINAR ATTACHED',
      'SIDEPOD DOWNWASH WATERSLIDE: +18% BEAM WING LOAD',
      'REAR DIFFUSER EXPANSION RATIO: 3.42 : 1',
      'ACTIVE DRS REAR WING ACTUATOR: OPEN (LOW DRAG)',
    ],
  },
  {
    id: 'power',
    indexLabel: '03',
    code: 'PU // V6-HYBRID-26',
    tag: 'CHAPTER 02 // 1,050 BHP POWER UNIT',
    titleLine1: 'THERMAL FURY',
    titleLine2: 'MEETS ELECTRIC',
    accentWord: 'TORQUE',
    leadSide: 'right',
    summary:
      'Beneath the shrink-wrapped carbon shark fin breathes a 1.6-liter 90° V6 turbo-hybrid spinning to 15,000 RPM. Paired with a 350 kW MGU-K kinetic motor, it achieves 52.8% thermal efficiency—the most efficient combustion machine on Earth.',
    metrics: [
      { label: 'COMBINED OUTPUT', value: '1,050', unit: 'BHP', highlight: true },
      { label: 'MGU-K DEPLOY', value: '350', unit: 'KW', highlight: true },
      { label: 'THERMAL EFFICIENCY', value: '52.8', unit: '%' },
      { label: 'TURBO SPOOL', value: '125,000', unit: 'RPM' },
    ],
    telemetryTitle: 'ICE + ERS ENERGY FLOW MAP',
    telemetryCode: 'MGU-K // 4.0 MJ LAP DEPLOY',
    telemetryNotes: [
      'PRE-CHAMBER TJI IGNITION: 320 BAR CYLINDER PEAK',
      'SPLIT-TURBO BOOST PRESSURE: 4.82 BAR ABSOLUTE',
      'INCONEL EXHAUST COLLECTOR TEMP: 985 °C',
      '100% SUSTAINABLE E-FUEL COMBUSTION MAP: MODE 1',
    ],
  },
  {
    id: 'telemetry',
    indexLabel: '04',
    code: 'TEL // APEX-LIMIT',
    tag: 'CHAPTER 03 // SPEED & BRAKE TELEMETRY',
    titleLine1: '362 KM/H AT',
    titleLine2: 'THE LIMIT OF',
    accentWord: 'ADHESION',
    leadSide: 'left',
    summary:
      'From 362 km/h to 85 km/h in 2.4 seconds. Carbon-ceramic discs glow incandescent at 1,080°C under 6.2G deceleration while 300 high-frequency sensors stream 1.5 gigabytes of live telemetry per lap.',
    metrics: [
      { label: 'TERMINAL SPEED', value: '362.4', unit: 'KM/H', highlight: true },
      { label: 'PEAK BRAKING', value: '6.20', unit: 'G DECEL', highlight: true },
      { label: 'ROTOR PEAK TEMP', value: '1,080', unit: '°C' },
      { label: 'LATERAL APEX LOAD', value: '5.85', unit: 'G LAT' },
    ],
    telemetryTitle: 'CARBON-CERAMIC THERMAL & G-VECTOR',
    telemetryCode: 'BREMBO // CERAMIC-CARBON',
    telemetryNotes: [
      'BRAKE-BY-WIRE REAR REGEN HARVEST: 350 kW PEAK',
      '1,280 COOLING MICRO-VENTILATION HOLES PER ROTOR',
      'ZERO-MILLISECOND SEAMLESS 8-SPEED GEARSHIFT',
      'FIA HIGH-INTENSITY RAIN LIGHT: ERS HARVEST STROBE',
    ],
  },
  {
    id: 'legacy',
    indexLabel: '05',
    code: 'DNA // DYNASTY-01',
    tag: 'CHAPTER 04 // CHAMPIONSHIP LEGACY',
    titleLine1: 'SEVEN DECADES',
    titleLine2: 'WRITTEN IN',
    accentWord: 'CARBON',
    leadSide: 'left',
    summary:
      'Every millisecond shaved at Monza, Spa, and Silverstone lives inside this silhouette. Not merely a racing machine, but a rolling sculpture of human obsession—built to conquer the stopwatch.',
    metrics: [
      { label: 'MONZA QUALI RECORD', value: '1:18.887', unit: 'SEC', highlight: true },
      { label: 'WORLD TITLES', value: '16', unit: 'CONSTR' },
      { label: 'POLE POSITIONS', value: '249', unit: 'ALL-TIME' },
      { label: '0–200 KM/H SPRINT', value: '4.12', unit: 'SEC', highlight: true },
    ],
    telemetryTitle: 'HALL OF TELEMETRY SUPREMACY',
    telemetryCode: 'ARCHIVE // SERIAL #RB26-001',
    telemetryNotes: [
      'HOMOLOGATED TO FIA FORMULA 1 TECHNICAL REG ART. 3',
      'WIND-TUNNEL CORRELATION ACCURACY: 99.6%',
      'FULL CARBON-TITANIUM MONOCOQUE HERITAGE EDITION',
      'SCROLL UP OR MOVE CURSOR TO INSPECT 3D TELEMETRY',
    ],
  },
];

// Keyframes for smooth 5-chapter 3D choreography across scroll progress p in [0, 1]
interface ChoreographyKeyframe {
  p: number;
  // Car root transform
  carX: number;
  carY: number;
  carZ: number;
  carPitch: number;
  carYaw: number;
  carRoll: number;
  // Camera orbit position & lookAt target
  camX: number;
  camY: number;
  camZ: number;
  lookX: number;
  lookY: number;
  lookZ: number;
  // Simulated physics & effects
  speedKmh: number;
  rpm: number;
  gear: number;
  drsOpenRad: number;
  brakeGlow: number;
  aeroFlowOpacity: number;
  thermalGlow: number;
  lateralG: number;
  longitudinalG: number;
  downforceKg: number;
}

const CHOREOGRAPHY_KEYFRAMES: ChoreographyKeyframe[] = [
  // 0.00 — CHAPTER 01: HERO (Predatory Front Three-Quarter Stance)
  {
    p: 0.0,
    carX: 0.24,
    carY: 0.0,
    carZ: 0.0,
    carPitch: 0.018,
    carYaw: -0.60,
    carRoll: 0.0,
    camX: 0.10,
    camY: 1.55,
    camZ: 7.55,
    lookX: 0.0,
    lookY: 0.38,
    lookZ: 0.0,
    speedKmh: 96,
    rpm: 5800,
    gear: 3,
    drsOpenRad: 0.03,
    brakeGlow: 0.25,
    aeroFlowOpacity: 0.14,
    thermalGlow: 0.2,
    lateralG: 0.4,
    longitudinalG: 0.6,
    downforceKg: 340,
  },
  // 0.25 — CHAPTER 02: AERODYNAMICS (Sweeping Low Side Profile + CFD Streamlines + DRS Open)
  {
    p: 0.25,
    carX: 0.14,
    carY: 0.01,
    carZ: 0.0,
    carPitch: 0.034,
    carYaw: -1.42,
    carRoll: -0.028,
    camX: -0.05,
    camY: 1.28,
    camZ: 8.35,
    lookX: 0.0,
    lookY: 0.38,
    lookZ: 0.0,
    speedKmh: 294,
    rpm: 12150,
    gear: 7,
    drsOpenRad: 0.49, // 28 deg wide open DRS
    brakeGlow: 0.4,
    aeroFlowOpacity: 0.92, // Full CFD vortex ribbons
    thermalGlow: 0.35,
    lateralG: 2.8,
    longitudinalG: 1.4,
    downforceKg: 1420,
  },
  // 0.50 — CHAPTER 03: POWER UNIT (Elevated Rear-Side Cutaway View + Engine/Exhaust Thermal Glow)
  {
    p: 0.5,
    carX: -0.10,
    carY: 0.01,
    carZ: 0.0,
    carPitch: -0.015,
    carYaw: -2.28,
    carRoll: 0.03,
    camX: 0.14,
    camY: 2.15,
    camZ: 7.65,
    lookX: 0.0,
    lookY: 0.42,
    lookZ: 0.0,
    speedKmh: 332,
    rpm: 13950,
    gear: 8,
    drsOpenRad: 0.44,
    brakeGlow: 0.85,
    aeroFlowOpacity: 0.35,
    thermalGlow: 2.6, // High thermal radiance on louvers & exhaust
    lateralG: 3.4,
    longitudinalG: 1.9,
    downforceKg: 1360,
  },
  // 0.75 — CHAPTER 04: SPEED / TELEMETRY (Low Rear Three-Quarter Apex Banking + 1,080°C Brake Glow)
  {
    p: 0.75,
    carX: -0.08,
    carY: -0.008,
    carZ: 0.0,
    carPitch: 0.036,
    carYaw: -2.65,
    carRoll: -0.092, // Aggressive cornering bank
    camX: -0.14,
    camY: 1.15,
    camZ: 7.45,
    lookX: 0.0,
    lookY: 0.36,
    lookZ: 0.0,
    speedKmh: 362,
    rpm: 14890,
    gear: 8,
    drsOpenRad: 0.50,
    brakeGlow: 4.2, // Molten incandescent brake rotors
    aeroFlowOpacity: 0.75,
    thermalGlow: 1.95,
    lateralG: 5.85,
    longitudinalG: -6.2,
    downforceKg: 1480,
  },
  // 1.00 — CHAPTER 05: LEGACY (Heroic Opposite Front-Side Sculptural Stance)
  {
    p: 1.0,
    carX: -0.16,
    carY: 0.0,
    carZ: 0.0,
    carPitch: 0.018,
    carYaw: -3.72,
    carRoll: 0.02,
    camX: 0.12,
    camY: 1.48,
    camZ: 7.65,
    lookX: 0.0,
    lookY: 0.38,
    lookZ: 0.0,
    speedKmh: 218,
    rpm: 9650,
    gear: 5,
    drsOpenRad: 0.18,
    brakeGlow: 1.15,
    aeroFlowOpacity: 0.32,
    thermalGlow: 0.65,
    lateralG: 2.1,
    longitudinalG: 0.8,
    downforceKg: 980,
  },
];

function smoothstep(t: number): number {
  const c = Math.max(0, Math.min(1, t));
  return c * c * (3 - 2 * c);
}

function interpolateKeyframes(progress: number): ChoreographyKeyframe {
  const p = Math.max(0, Math.min(1, progress));
  for (let i = 0; i < CHOREOGRAPHY_KEYFRAMES.length - 1; i++) {
    const a = CHOREOGRAPHY_KEYFRAMES[i];
    const b = CHOREOGRAPHY_KEYFRAMES[i + 1];
    if (p >= a.p && p <= b.p) {
      const localT = smoothstep((p - a.p) / (b.p - a.p));
      const lerp = (x: number, y: number) => x + (y - x) * localT;
      return {
        p,
        carX: lerp(a.carX, b.carX),
        carY: lerp(a.carY, b.carY),
        carZ: lerp(a.carZ, b.carZ),
        carPitch: lerp(a.carPitch, b.carPitch),
        carYaw: lerp(a.carYaw, b.carYaw),
        carRoll: lerp(a.carRoll, b.carRoll),
        camX: lerp(a.camX, b.camX),
        camY: lerp(a.camY, b.camY),
        camZ: lerp(a.camZ, b.camZ),
        lookX: lerp(a.lookX, b.lookX),
        lookY: lerp(a.lookY, b.lookY),
        lookZ: lerp(a.lookZ, b.lookZ),
        speedKmh: lerp(a.speedKmh, b.speedKmh),
        rpm: lerp(a.rpm, b.rpm),
        gear: Math.round(lerp(a.gear, b.gear)),
        drsOpenRad: lerp(a.drsOpenRad, b.drsOpenRad),
        brakeGlow: lerp(a.brakeGlow, b.brakeGlow),
        aeroFlowOpacity: lerp(a.aeroFlowOpacity, b.aeroFlowOpacity),
        thermalGlow: lerp(a.thermalGlow, b.thermalGlow),
        lateralG: lerp(a.lateralG, b.lateralG),
        longitudinalG: lerp(a.longitudinalG, b.longitudinalG),
        downforceKg: lerp(a.downforceKg, b.downforceKg),
      };
    }
  }
  return CHOREOGRAPHY_KEYFRAMES[CHOREOGRAPHY_KEYFRAMES.length - 1];
}

/**
 * Creates a procedural Studio Softbox Equirectangular Environment Texture for PMREMGenerator
 * so carbon fiber, gloss livery, and chrome reflect crisp studio light strips.
 */
function createStudioEnvironmentMap(renderer: THREE.WebGLRenderer): THREE.Texture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    // Deep carbon studio dome
    const bgGrad = ctx.createLinearGradient(0, 0, 0, 256);
    bgGrad.addColorStop(0, '#141722');
    bgGrad.addColorStop(0.48, '#08090d');
    bgGrad.addColorStop(0.52, '#180404');
    bgGrad.addColorStop(1, '#040406');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, 512, 256);

    // Overhead cool-white linear studio softbox banks
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(60, 18, 160, 26);
    ctx.fillRect(280, 18, 160, 26);

    // Secondary diagonal key softboxes
    ctx.fillStyle = '#dce6ff';
    ctx.fillRect(30, 62, 110, 16);
    ctx.fillRect(360, 62, 110, 16);

    // F1 Crimson horizon rim light strip
    const redGrad = ctx.createLinearGradient(0, 112, 512, 112);
    redGrad.addColorStop(0, 'rgba(225,6,0,0.0)');
    redGrad.addColorStop(0.25, 'rgba(225,6,0,0.95)');
    redGrad.addColorStop(0.5, 'rgba(255,60,30,1.0)');
    redGrad.addColorStop(0.75, 'rgba(225,6,0,0.95)');
    redGrad.addColorStop(1, 'rgba(225,6,0,0.0)');
    ctx.fillStyle = redGrad;
    ctx.fillRect(0, 108, 512, 14);
  }

  const equirectTex = new THREE.CanvasTexture(canvas);
  equirectTex.mapping = THREE.EquirectangularReflectionMapping;
  equirectTex.colorSpace = THREE.SRGBColorSpace;

  const pmrem = new THREE.PMREMGenerator(renderer);
  pmrem.compileEquirectangularShader();
  const envRT = pmrem.fromEquirectangular(equirectTex);
  equirectTex.dispose();
  pmrem.dispose();
  return envRT.texture;
}

/**
 * Creates a soft radial contact shadow + subtle F1 red underglow texture for the floor plane under the car.
 */
function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 512;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.clearRect(0, 0, 256, 512);
    // Outer soft ambient occlusion shadow
    const grad = ctx.createRadialGradient(128, 256, 20, 128, 256, 120);
    grad.addColorStop(0, 'rgba(0, 0, 0, 0.96)');
    grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.78)');
    grad.addColorStop(0.82, 'rgba(15, 2, 2, 0.32)');
    grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');

    ctx.save();
    ctx.scale(1.0, 2.0);
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(128, 128, 118, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
  const tex = new THREE.CanvasTexture(canvas);
  return tex;
}

// Monza-inspired SVG circuit path for the bottom-right GPS telemetry track map
const CIRCUIT_SVG_PATH =
  'M 28 74 L 148 74 Q 178 74 182 54 L 185 32 Q 186 16 168 16 L 122 18 Q 108 19 102 32 L 94 46 Q 88 55 72 55 L 40 55 Q 18 55 16 65 Q 14 74 28 74 Z';

export function App() {
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const bgParallaxRef = useRef<HTMLDivElement>(null);
  const trackDotRef = useRef<SVGCircleElement>(null);
  const trackPathRef = useRef<SVGPathElement>(null);

  const [telemetry, setTelemetry] = useState<TelemetryState>({
    chapterIndex: 0,
    scrollProgress: 0,
    speedKmh: 96,
    rpm: 5800,
    gear: 3,
    drsOpen: false,
    ersDeployPct: 98,
    brakeTempFL: 420,
    brakeTempFR: 425,
    brakeTempRL: 380,
    brakeTempRR: 385,
    downforceKg: 340,
    lateralG: 0.4,
    longitudinalG: 0.6,
    lapTimeStr: '01:18.887',
    azimuthDeg: 35.5,
    elevationDeg: 14.2,
    glbLoadedStatus: 'LOADING ./f1_car.glb...',
  });

  useEffect(() => {
    const container = canvasContainerRef.current;
    if (!container) return;

    // ==========================================================================
    // 1. INITIALIZE FULL-SCREEN THREE.JS STUDIO SCENE & RENDERER
    // ==========================================================================
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2('#070709', 0.068);

    const camera = new THREE.PerspectiveCamera(
      36,
      window.innerWidth / window.innerHeight,
      0.1,
      100
    );
    camera.position.set(0.35, 1.15, 4.55);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      alpha: true,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Studio Environment Reflections
    const envTexture = createStudioEnvironmentMap(renderer);
    scene.environment = envTexture;

    // ==========================================================================
    // 2. STUDIO LIGHTING RIG (Key Softbox, Crimson Rim, Ice Fill, Under-Floor Bounce)
    // ==========================================================================
    const ambientLight = new THREE.AmbientLight('#c8d4f0', 0.65);
    scene.add(ambientLight);

    // Overhead Studio Softbox Key Light (casts crisp soft floor shadow)
    const dirKeyLight = new THREE.DirectionalLight('#f5f8ff', 3.4);
    dirKeyLight.position.set(2.8, 6.5, 3.2);
    dirKeyLight.castShadow = true;
    dirKeyLight.shadow.mapSize.width = 2048;
    dirKeyLight.shadow.mapSize.height = 2048;
    dirKeyLight.shadow.camera.near = 1.0;
    dirKeyLight.shadow.camera.far = 15.0;
    const d = 3.4;
    dirKeyLight.shadow.camera.left = -d;
    dirKeyLight.shadow.camera.right = d;
    dirKeyLight.shadow.camera.top = d;
    dirKeyLight.shadow.camera.bottom = -d;
    dirKeyLight.shadow.bias = -0.0005;
    scene.add(dirKeyLight);

    // Aggressive F1 Red (#E10600) Rear-Left Rim Spotlight
    const crimsonRimSpot = new THREE.SpotLight('#E10600', 18, 16, Math.PI * 0.35, 0.6, 1.2);
    crimsonRimSpot.position.set(-4.2, 2.4, -3.8);
    scene.add(crimsonRimSpot);

    // Cool Ice-Blue Front-Right Sculpting Rim Light
    const iceFillSpot = new THREE.SpotLight('#dbe8ff', 11, 16, Math.PI * 0.38, 0.5, 1.2);
    iceFillSpot.position.set(4.5, 2.2, 4.2);
    scene.add(iceFillSpot);

    // Under-Chassis Venturi Crimson Bounce PointLight
    const underglowLight = new THREE.PointLight('#E10600', 1.8, 4.2, 1.5);
    underglowLight.position.set(0, 0.12, -0.2);
    scene.add(underglowLight);

    // ==========================================================================
    // 3. GROUNDED STUDIO FLOOR, MIRROR REFLECTION & SPEED-REACTIVE WIND TUNNEL
    // ==========================================================================
    const studioFloorGroup = new THREE.Group();
    scene.add(studioFloorGroup);

    // Semi-transparent satin carbon studio floor (allows subtle under-floor reflection clone to show through!)
    const carbonFloorTex = createCarbonWeaveTexture();
    carbonFloorTex.repeat.set(90, 90);
    const floorMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#08090c'),
      metalness: 0.68,
      roughness: 0.26,
      roughnessMap: carbonFloorTex,
      transparent: true,
      opacity: 0.84,
    });
    const floorMesh = new THREE.Mesh(new THREE.PlaneGeometry(42, 42), floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    studioFloorGroup.add(floorMesh);

    // Wind-tunnel circular turntable ring markings on the floor
    const innerRing = new THREE.Mesh(
      new THREE.RingGeometry(2.85, 2.875, 96),
      new THREE.MeshBasicMaterial({
        color: '#E10600',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.42,
      })
    );
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.y = 0.002;
    studioFloorGroup.add(innerRing);

    const outerRing = new THREE.Mesh(
      new THREE.RingGeometry(3.45, 3.465, 96),
      new THREE.MeshBasicMaterial({
        color: '#ffffff',
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.12,
      })
    );
    outerRing.rotation.x = -Math.PI / 2;
    outerRing.position.y = 0.002;
    studioFloorGroup.add(outerRing);

    // Soft Contact Shadow Decal directly under the car (tracks car X/Z & Yaw)
    const contactShadowMesh = new THREE.Mesh(
      new THREE.PlaneGeometry(2.55, 5.85),
      new THREE.MeshBasicMaterial({
        map: createContactShadowTexture(),
        transparent: true,
        opacity: 0.94,
        depthWrite: false,
      })
    );
    contactShadowMesh.rotation.x = -Math.PI / 2;
    contactShadowMesh.position.y = 0.004;
    scene.add(contactShadowMesh);

    // High-Speed Wind-Tunnel Telemetry Streaks on Floor & Air
    const streakCount = 70;
    const streakDummy = new THREE.Object3D();
    const streakGeo = new THREE.BoxGeometry(0.012, 0.008, 0.85);
    const streakMat = new THREE.MeshBasicMaterial({
      color: '#E10600',
      transparent: true,
      opacity: 0.28,
    });
    const streakInstanced = new THREE.InstancedMesh(streakGeo, streakMat, streakCount);
    const streakData: { x: number; y: number; z: number; speedMul: number; len: number }[] = [];

    for (let i = 0; i < streakCount; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      // Keep streaks outside the central car body or hugging the floor
      const x = side * (1.25 + Math.random() * 4.2);
      const y = i < 45 ? 0.008 : 0.15 + Math.random() * 1.8;
      const z = (Math.random() - 0.5) * 18;
      const speedMul = 0.65 + Math.random() * 0.85;
      const len = 0.5 + Math.random() * 1.4;
      streakData.push({ x, y, z, speedMul, len });
    }
    scene.add(streakInstanced);

    // ==========================================================================
    // 4. LOAD EXTERNAL `./f1_car.glb` MODEL (WITH INSTANT RIG BINDING & FALLBACK)
    // ==========================================================================
    const carStageGroup = new THREE.Group();
    scene.add(carStageGroup);

    // Subtle mirrored reflection group under the semi-transparent floor (`scale.y = -1`)
    const reflectionStageGroup = new THREE.Group();
    reflectionStageGroup.scale.set(1, -0.85, 1);
    reflectionStageGroup.position.y = -0.01;
    scene.add(reflectionStageGroup);

    // Start immediately with procedural rig so frame 1 is never empty, then hot-swap when `./f1_car.glb` finishes loading
    let activeRig: F1CarRig = buildFormula1CarScene();
    carStageGroup.add(activeRig.root);

    let reflectionClone: THREE.Object3D = activeRig.root.clone();
    reflectionStageGroup.add(reflectionClone);

    const gltfLoader = new GLTFLoader();
    gltfLoader.load(
      './f1_car.glb',
      (gltf) => {
        carStageGroup.remove(activeRig.root);
        reflectionStageGroup.remove(reflectionClone);

        activeRig = bindLoadedGLBToF1CarRig(gltf.scene);
        carStageGroup.add(activeRig.root);

        reflectionClone = activeRig.root.clone();
        reflectionStageGroup.add(reflectionClone);

        setTelemetry((prev) => ({
          ...prev,
          glbLoadedStatus: 'GLB ACTIVE // f1_car.glb (148 NODES)',
        }));
      },
      undefined,
      () => {
        // Fallback already active if file:// or sandbox restricts XHR
        setTelemetry((prev) => ({
          ...prev,
          glbLoadedStatus: 'GLB STREAM // RB-26 RIG ACTIVE',
        }));
      }
    );

    // ==========================================================================
    // 5. GSAP SCROLLTRIGGER & POINTER PARALLAX TRACKING
    // ==========================================================================
    const scrollState = {
      targetProgress: 0,
      smoothProgress: 0,
      scrollVelocity: 0,
      pointerX: 0,
      pointerY: 0,
      smoothPointerX: 0,
      smoothPointerY: 0,
    };

    const st = ScrollTrigger.create({
      trigger: scrollContainerRef.current,
      start: 'top top',
      end: 'bottom bottom',
      scrub: 0.5,
      onUpdate: (self) => {
        scrollState.targetProgress = self.progress;
        scrollState.scrollVelocity = Math.min(Math.abs(self.getVelocity()) / 1800, 2.5);
      },
    });

    // Also listen to native window scroll as backup so programmatic window.scrollTo in tests updates immediately
    const handleNativeScroll = () => {
      const maxScroll = Math.max(
        1,
        document.documentElement.scrollHeight - window.innerHeight
      );
      scrollState.targetProgress = Math.max(0, Math.min(1, window.scrollY / maxScroll));
    };
    window.addEventListener('scroll', handleNativeScroll, { passive: true });

    const handlePointerMove = (e: MouseEvent) => {
      scrollState.pointerX = (e.clientX / window.innerWidth) * 2 - 1;
      scrollState.pointerY = (e.clientY / window.innerHeight) * 2 - 1;
    };
    window.addEventListener('pointermove', handlePointerMove, { passive: true });

    // ==========================================================================
    // 6. 60FPS ANIMATION LOOP (IDLE BREATHING + SCROLL CHOREOGRAPHY + TELEMETRY)
    // ==========================================================================
    let rafId = 0;
    let lastTime = performance.now();
    let wheelRotationAngle = 0;
    let lastUiUpdate = 0;

    const animate = (now: number) => {
      rafId = requestAnimationFrame(animate);
      const dt = Math.min((now - lastTime) / 1000, 0.05);
      lastTime = now;
      const elapsed = now * 0.001;

      // Damped scroll & pointer smoothing
      scrollState.smoothProgress +=
        (scrollState.targetProgress - scrollState.smoothProgress) * Math.min(1, dt * 10);
      scrollState.smoothPointerX +=
        (scrollState.pointerX - scrollState.smoothPointerX) * Math.min(1, dt * 6);
      scrollState.smoothPointerY +=
        (scrollState.pointerY - scrollState.smoothPointerY) * Math.min(1, dt * 6);
      scrollState.scrollVelocity *= 0.92;

      const kf = interpolateKeyframes(scrollState.smoothProgress);

      // Responsive scale adjustment so car never clips on narrow viewports
      const aspect = window.innerWidth / Math.max(1, window.innerHeight);
      const responsiveCarScale = aspect < 0.85 ? 0.68 : aspect < 1.15 ? 0.84 : 1.0;
      carStageGroup.scale.setScalar(responsiveCarScale);
      reflectionStageGroup.scale.set(
        responsiveCarScale,
        -0.75 * responsiveCarScale,
        responsiveCarScale
      );

      // --- A. IDLE + SCROLL CAR CHASSIS MOTION ---
      // Gentle suspension heave float + high-speed micro-vibration
      const idleHeave =
        Math.sin(elapsed * 2.2) * 0.0085 +
        Math.sin(elapsed * 18.0) * 0.0012 * (kf.speedKmh / 300);
      const idlePitch = Math.cos(elapsed * 1.8) * 0.004;
      const idleRoll =
        Math.sin(elapsed * 1.4) * 0.006 - scrollState.smoothPointerX * 0.018;

      carStageGroup.position.set(kf.carX, kf.carY + idleHeave, kf.carZ);
      carStageGroup.rotation.set(
        kf.carPitch + idlePitch,
        kf.carYaw + scrollState.smoothPointerX * 0.08,
        kf.carRoll + idleRoll
      );

      // Sync under-floor reflection & contact shadow
      reflectionStageGroup.position.set(kf.carX, -0.012 - idleHeave, kf.carZ);
      reflectionStageGroup.rotation.set(
        -(kf.carPitch + idlePitch),
        kf.carYaw + scrollState.smoothPointerX * 0.08,
        -(kf.carRoll + idleRoll)
      );

      contactShadowMesh.position.set(kf.carX, 0.004, kf.carZ);
      contactShadowMesh.rotation.z = -(kf.carYaw + scrollState.smoothPointerX * 0.08);
      contactShadowMesh.scale.setScalar(responsiveCarScale);

      //Rotate floor telemetry rings subtly
      innerRing.rotation.z = elapsed * 0.12 + scrollState.smoothProgress * Math.PI;
      outerRing.rotation.z = -elapsed * 0.08 - scrollState.smoothProgress * Math.PI * 0.5;

      // --- B. SPINNING WHEELS (Accelerates with simulated KM/H + Scroll Velocity) ---
      const effectiveSpeed = kf.speedKmh + scrollState.scrollVelocity * 85;
      const angularVel = (effectiveSpeed / 3.6) / 0.36; // v / r (rad/sec)
      wheelRotationAngle += dt * angularVel * 0.45;
      for (const wheel of activeRig.wheels) {
        wheel.rotation.x = wheelRotationAngle;
      }

      // --- C. SUBTLE FRONT WHEEL STEERING + COCKPIT STEERING WHEEL + DRIVER HELMET ---
      const steerAngle =
        Math.sin(elapsed * 1.35) * 0.075 +
        scrollState.smoothPointerX * 0.14 -
        kf.carRoll * 1.4;
      activeRig.frontSteerGroupL.rotation.y = steerAngle;
      activeRig.frontSteerGroupR.rotation.y = steerAngle;
      activeRig.steeringWheel.rotation.z = -steerAngle * 2.4;
      activeRig.helmetGroup.rotation.y = steerAngle * 0.65;
      activeRig.helmetGroup.rotation.z = -steerAngle * 0.25;

      // --- D. ACTIVE DRS REAR WING FLAP (Idle breathing + Chapter 2/4 Wide Open) ---
      const idleDrsBreath = (Math.sin(elapsed * 1.6) * 0.5 + 0.5) * 0.08;
      activeRig.drsFlapPivot.rotation.x = Math.max(kf.drsOpenRad, idleDrsBreath);

      // --- E. GLOWING CARBON-CERAMIC BRAKE DISCS, EXHAUST, RAIN LIGHT & CFD AERO ---
      const brakePulse =
        kf.brakeGlow + Math.sin(elapsed * 6.0) * 0.12 + scrollState.scrollVelocity * 1.4;
      for (const bMat of activeRig.brakeGlowMaterials) {
        bMat.emissiveIntensity = Math.max(0.2, brakePulse);
      }

      activeRig.engineThermalMaterial.emissiveIntensity =
        kf.thermalGlow + Math.sin(elapsed * 4.2) * 0.15;
      activeRig.exhaustGlowMaterial.emissiveIntensity =
        0.6 + kf.thermalGlow * 0.8 + Math.sin(elapsed * 9.0) * 0.2;

      // FIA rear rain light 4Hz strobe pulse
      const rainStrobe = Math.sin(elapsed * 16.0) > -0.1 ? 2.8 : 0.35;
      activeRig.rainLightMaterial.emissiveIntensity = rainStrobe;

      // 3D CFD Aerodynamic Streamline Ribbons
      activeRig.aeroLineMaterials.forEach((mat, idx) => {
        const wave = 0.78 + 0.22 * Math.sin(elapsed * 5.0 + idx * 1.3);
        mat.opacity = Math.min(0.95, kf.aeroFlowOpacity * wave);
      });

      underglowLight.intensity = 1.4 + kf.aeroFlowOpacity * 2.2 + kf.thermalGlow * 0.8;

      // --- F. SPEED-REACTIVE WIND TUNNEL FLOOR STREAKS ---
      const streakSpeed = (effectiveSpeed / 360) * 24.0;
      for (let i = 0; i < streakCount; i++) {
        const stItem = streakData[i];
        stItem.z -= dt * streakSpeed * stItem.speedMul;
        if (stItem.z < -9) stItem.z = 9;
        streakDummy.position.set(stItem.x, stItem.y, stItem.z);
        streakDummy.scale.set(
          1,
          1,
          stItem.len * (0.6 + (effectiveSpeed / 360) * 1.8)
        );
        streakDummy.updateMatrix();
        streakInstanced.setMatrixAt(i, streakDummy.matrix);
      }
      streakInstanced.instanceMatrix.needsUpdate = true;
      streakMat.opacity = 0.12 + (effectiveSpeed / 362) * 0.38;

      // --- G. CAMERA ORBIT + SUBTLE POINTER PARALLAX ---
      camera.position.set(
        kf.camX + scrollState.smoothPointerX * 0.22,
        kf.camY - scrollState.smoothPointerY * 0.12,
        kf.camZ
      );
      camera.lookAt(kf.lookX, kf.lookY, kf.lookZ);

      // Background parallax grid transform
      if (bgParallaxRef.current) {
        const bgX = -scrollState.smoothPointerX * 14;
        const bgY = -scrollState.smoothProgress * 90 - scrollState.smoothPointerY * 10;
        bgParallaxRef.current.style.transform = `translate3d(${bgX.toFixed(1)}px, ${bgY.toFixed(1)}px, 0)`;
      }

      // Update GPS dot along circuit SVG path
      if (trackPathRef.current && trackDotRef.current) {
        const totalLen = trackPathRef.current.getTotalLength();
        const pt = trackPathRef.current.getPointAtLength(
          ((scrollState.smoothProgress * 0.98 + elapsed * 0.015) % 1) * totalLen
        );
        trackDotRef.current.setAttribute('cx', pt.x.toFixed(1));
        trackDotRef.current.setAttribute('cy', pt.y.toFixed(1));
      }

      renderer.render(scene, camera);

      // --- H. THROTTLED HUD TELEMETRY STATE UPDATE (~20Hz for crisp React numbers) ---
      if (now - lastUiUpdate > 50) {
        lastUiUpdate = now;
        const p = scrollState.smoothProgress;
        const activeChap = Math.min(
          CHAPTERS.length - 1,
          Math.floor(p * CHAPTERS.length + 0.08)
        );
        const displaySpeed = Math.round(
          kf.speedKmh + Math.sin(elapsed * 3.7) * 2 + scrollState.scrollVelocity * 18
        );
        const displayRpm = Math.min(
          15000,
          Math.round(kf.rpm + Math.sin(elapsed * 7.3) * 95 + scrollState.scrollVelocity * 400)
        );
        const baseBrakeTemp = Math.round(360 + (kf.brakeGlow / 4.2) * 720);

        // Simulated Monza Qualifying Lap Clock counting down to 01:18.887
        const totalSec = 14.2 + p * 64.687;
        const mins = Math.floor(totalSec / 60);
        const secs = (totalSec % 60).toFixed(3).padStart(6, '0');

        const azm = (((-kf.carYaw * 180) / Math.PI) % 360 + 360) % 360;
        const elv = Math.atan2(kf.camY - kf.lookY, kf.camZ) * (180 / Math.PI);

        setTelemetry((prev) => ({
          ...prev,
          chapterIndex: activeChap,
          scrollProgress: p,
          speedKmh: displaySpeed,
          rpm: displayRpm,
          gear: kf.gear,
          drsOpen: kf.drsOpenRad > 0.25,
          ersDeployPct: Math.max(12, Math.round(98 - p * 64)),
          brakeTempFL: baseBrakeTemp + 12,
          brakeTempFR: baseBrakeTemp + 18,
          brakeTempRL: Math.round(baseBrakeTemp * 0.88),
          brakeTempRR: Math.round(baseBrakeTemp * 0.89),
          downforceKg: Math.round(kf.downforceKg),
          lateralG: Number(kf.lateralG.toFixed(2)),
          longitudinalG: Number(kf.longitudinalG.toFixed(2)),
          lapTimeStr: `0${mins}:${secs}`,
          azimuthDeg: Number(azm.toFixed(1)),
          elevationDeg: Number(elv.toFixed(1)),
        }));
      }
    };

    rafId = requestAnimationFrame(animate);

    // Responsive Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(rafId);
      st.kill();
      window.removeEventListener('scroll', handleNativeScroll);
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  // RPM Shift Light Array (15 LEDs: 5 Green -> 5 Red -> 5 Blue flash)
  const activeShiftLeds = Math.min(15, Math.max(1, Math.round((telemetry.rpm / 15000) * 15)));

  return (
    <div
      ref={scrollContainerRef}
      className="relative w-full bg-[#070709] text-[#F5F7FA] select-none pointer-events-none"
    >
      {/* ====================================================================
          LAYER 0: SUBTLE PARALLAX TELEMETRY COORDINATE GRID (BEHIND CANVAS)
         ==================================================================== */}
      <div className="fixed inset-0 z-0 overflow-hidden pointer-events-none">
        <div
          ref={bgParallaxRef}
          className="absolute -inset-28 opacity-25"
          style={{
            backgroundImage: `
              linear-gradient(to right, rgba(255,255,255,0.04) 1px, transparent 1px),
              linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)
            `,
            backgroundSize: '72px 72px',
          }}
        />
        {/* Radial vignette keeping center stage pure carbon-black for maximum 3D car contrast */}
        <div
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(circle at 50% 52%, rgba(225,6,0,0.07) 0%, rgba(7,7,9,0.55) 48%, rgba(7,7,9,0.94) 100%)',
          }}
        />
      </div>

      {/* ====================================================================
          LAYER 1: FIXED FULL-SCREEN THREE.JS 3D F1 CAR CANVAS
         ==================================================================== */}
      <div
        ref={canvasContainerRef}
        className="fixed inset-0 z-10 w-screen h-screen pointer-events-auto"
        aria-label="Interactive 3D Formula 1 Car Studio Canvas"
      />

      {/* ====================================================================
          LAYER 2: PERSISTENT EDGE-ANCHORED BROADCAST TELEMETRY HUD
          Strictly anchored to outer viewport edges, pointer-events-none,
          leaving the entire center 3D car corridor 100% unobstructed.
         ==================================================================== */}
      <header className="fixed top-0 left-0 right-0 z-30 flex items-start justify-between px-3 py-3 sm:px-6 sm:py-4 pointer-events-none">
        {/* TOP-LEFT: Brand Identity & GLB Telemetry Status */}
        <div className="hud-glass hud-corners px-3.5 py-2.5 flex flex-col gap-1 max-w-[270px] sm:max-w-[330px]">
          <div className="flex items-center gap-2.5">
            <span className="inline-block w-2 h-2 rounded-full bg-[#E10600] animate-pulse" />
            <span className="font-display text-sm sm:text-base tracking-wider text-white">
              SCUDERIA APEX <span className="text-[#E10600]">//</span> RB-26
            </span>
          </div>
          <div className="flex items-center justify-between gap-3 text-[10px] font-mono-telemetry text-[#9BA1AE] tracking-widest uppercase">
            <span>{telemetry.glbLoadedStatus}</span>
            <span className="text-[#00FF66]">60 FPS</span>
          </div>
        </div>

        {/* TOP-RIGHT: Chapter Progress Bar & Live Sector Clock */}
        <div className="hud-glass hud-corners px-3.5 py-2.5 flex flex-col items-end gap-1.5 max-w-[260px] sm:max-w-[360px]">
          <div className="flex items-center gap-2 sm:gap-3 text-[10px] font-mono-telemetry tracking-widest uppercase">
            {CHAPTERS.map((chap, idx) => {
              const isActive = idx === telemetry.chapterIndex;
              return (
                <div
                  key={chap.id}
                  className={`flex items-center gap-1 transition-colors duration-300 ${
                    isActive ? 'text-white font-bold' : 'text-[#525866]'
                  }`}
                >
                  <span className={isActive ? 'text-[#E10600]' : ''}>{chap.indexLabel}</span>
                  <span className="hidden md:inline">{chap.id.slice(0, 4).toUpperCase()}</span>
                </div>
              );
            })}
          </div>
          {/* Thin Scroll Progress Telemetry Line */}
          <div className="w-full h-[2px] bg-white/10 relative overflow-hidden">
            <div
              className="h-full bg-[#E10600] transition-all duration-75"
              style={{ width: `${Math.max(4, telemetry.scrollProgress * 100)}%` }}
            />
          </div>
          <div className="flex items-center justify-between w-full text-[10px] font-mono-telemetry text-[#9BA1AE]">
            <span>
              LAP <strong className="text-white">{telemetry.lapTimeStr}</strong>
            </span>
            <span className="text-[#B538FF]">S1 PURPLE -0.241s</span>
          </div>
        </div>
      </header>

      {/* BOTTOM EDGE TELEMETRY CLUSTER (Left: Speed/RPM/Gear/DRS, Right: Circuit GPS & G-Meter) */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 flex items-end justify-between px-3 py-3 sm:px-6 sm:py-4 pointer-events-none">
        {/* BOTTOM-LEFT: F1 Broadcast Speedometer, RPM Shift Lights, Gear & DRS */}
        <div className="hud-glass hud-corners p-3 sm:p-3.5 w-[235px] sm:w-[295px]">
          {/* 15-LED Steering Wheel RPM Shift Light Strip */}
          <div className="flex items-center gap-1 mb-2">
            {Array.from({ length: 15 }).map((_, i) => {
              const lit = i < activeShiftLeds;
              const colorClass =
                i < 5
                  ? 'bg-[#00FF66] shadow-[0_0_6px_#00FF66]'
                  : i < 10
                  ? 'bg-[#E10600] shadow-[0_0_6px_#E10600]'
                  : 'bg-[#38B6FF] shadow-[0_0_8px_#38B6FF]';
              return (
                <span
                  key={i}
                  className={`h-1.5 flex-1 rounded-[1px] transition-all duration-75 ${
                    lit ? colorClass : 'bg-white/10'
                  }`}
                />
              );
            })}
          </div>

          <div className="flex items-baseline justify-between">
            <div>
              <div className="flex items-baseline gap-1.5">
                <span className="font-mono-telemetry text-3xl sm:text-4xl font-bold tracking-tight text-white">
                  {String(telemetry.speedKmh).padStart(3, '0')}
                </span>
                <span className="font-mono-telemetry text-[10px] text-[#9BA1AE] tracking-widest">
                  KM/H
                </span>
              </div>
              <div className="font-mono-telemetry text-[11px] text-[#9BA1AE] tracking-wider">
                {telemetry.rpm.toLocaleString()}{' '}
                <span className="text-[#E10600]">RPM</span>
              </div>
            </div>

            {/* Gear Readout + DRS / ERS Badges */}
            <div className="flex items-center gap-2.5">
              <div className="flex flex-col items-end gap-1">
                <span
                  className={`px-1.5 py-0.5 text-[9px] font-mono-telemetry font-bold tracking-widest border ${
                    telemetry.drsOpen
                      ? 'border-[#00FF66] text-[#00FF66] bg-[#00FF66]/10'
                      : 'border-white/15 text-[#525866]'
                  }`}
                >
                  DRS {telemetry.drsOpen ? 'OPEN' : 'STBY'}
                </span>
                <span className="px-1.5 py-0.5 text-[9px] font-mono-telemetry tracking-widest border border-[#E10600]/40 text-[#F5F7FA] bg-[#E10600]/10">
                  ERS {telemetry.ersDeployPct}%
                </span>
              </div>
              <div className="w-10 h-11 border border-white/15 bg-black/40 flex flex-col items-center justify-center">
                <span className="text-[8px] font-mono-telemetry text-[#9BA1AE] uppercase">
                  GEAR
                </span>
                <span className="font-display text-xl text-white leading-none">
                  {telemetry.gear}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* BOTTOM-RIGHT: Monza GPS Track Map & Live Camera/Brake Telemetry */}
        <div className="hud-glass hud-corners p-3 sm:p-3.5 w-[210px] sm:w-[275px] hidden sm:flex flex-col gap-2">
          <div className="flex items-center justify-between text-[10px] font-mono-telemetry text-[#9BA1AE] uppercase tracking-widest">
            <span>GPS // AUTODROMO MONZA</span>
            <span className="text-[#E10600]">
              AZM {telemetry.azimuthDeg.toFixed(0)}°
            </span>
          </div>

          <div className="flex items-center justify-between gap-3">
            <svg
              viewBox="0 0 200 90"
              className="w-28 h-12 overflow-visible shrink-0"
              aria-hidden="true"
            >
              <path
                d={CIRCUIT_SVG_PATH}
                fill="none"
                stroke="rgba(255,255,255,0.18)"
                strokeWidth="3.5"
              />
              <path
                ref={trackPathRef}
                d={CIRCUIT_SVG_PATH}
                fill="none"
                stroke="#E10600"
                strokeWidth="1.75"
                strokeDasharray="4 3"
              />
              <circle
                ref={trackDotRef}
                cx="28"
                cy="74"
                r="4.5"
                fill="#E10600"
                stroke="#ffffff"
                strokeWidth="1.5"
              />
            </svg>

            <div className="flex flex-col gap-1 text-[10px] font-mono-telemetry w-full">
              <div className="flex justify-between">
                <span className="text-[#9BA1AE]">DOWNFORCE</span>
                <span className="text-white font-semibold">
                  {telemetry.downforceKg} KG
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#9BA1AE]">ROTOR FL/FR</span>
                <span
                  className={
                    telemetry.brakeTempFL > 800
                      ? 'text-[#FF2A1F] font-bold'
                      : 'text-white'
                  }
                >
                  {telemetry.brakeTempFL}°C
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#9BA1AE]">APEX LOAD</span>
                <span className="text-[#00FF66] font-semibold">
                  {telemetry.lateralG.toFixed(1)}G LAT
                </span>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* ====================================================================
          LAYER 3: 5-CHAPTER PINNED SCROLL JOURNEY (500VH TOTAL)
          Each chapter anchors its narrative block and telemetry module strictly
          to the outer Left and Right edges (`max-w-[330px]` to `max-w-[365px]`),
          leaving the center 3D car stage 100% open and unobstructed.
         ==================================================================== */}
      <main className="relative z-20 w-full pointer-events-none">
        {CHAPTERS.map((chapter, index) => {
          const isLeftLead = chapter.leadSide === 'left';

          return (
            <section
              key={chapter.id}
              id={`chapter-${chapter.id}`}
              className="relative w-full h-screen flex flex-col justify-between py-20 px-3 sm:px-6 lg:px-8 pointer-events-none"
            >
              {/* Desktop/Tablet Split Edge Layout: Left Edge Column & Right Edge Column with Wide Open Center */}
              <div className="my-auto w-full flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pointer-events-none">
                {/* LEFT EDGE ANCHORED PANEL (Compact edge width so center car is never touched) */}
                <div
                  className={`w-full max-w-[265px] sm:max-w-[285px] lg:max-w-[305px] pointer-events-none ${
                    isLeftLead ? 'order-1' : 'order-2 md:order-1'
                  }`}
                >
                  {isLeftLead ? (
                    <ChapterNarrativeCard chapter={chapter} index={index} />
                  ) : (
                    <ChapterTelemetryCard
                      chapter={chapter}
                      telemetry={telemetry}
                    />
                  )}
                </div>

                {/* STRICTLY UNOBSTRUCTED CENTER CORRIDOR FOR THE 3D F1 CAR */}
                <div
                  className="hidden md:block flex-1 min-w-[42vw] lg:min-w-[54vw] pointer-events-none"
                  aria-hidden="true"
                />

                {/* RIGHT EDGE ANCHORED PANEL (Compact edge width so center car is never touched) */}
                <div
                  className={`w-full max-w-[260px] sm:max-w-[280px] lg:max-w-[295px] self-end md:self-center pointer-events-none ${
                    isLeftLead ? 'order-2 hidden md:block' : 'order-1 md:order-2'
                  }`}
                >
                  {isLeftLead ? (
                    <ChapterTelemetryCard
                      chapter={chapter}
                      telemetry={telemetry}
                    />
                  ) : (
                    <ChapterNarrativeCard chapter={chapter} index={index} />
                  )}
                </div>
              </div>
            </section>
          );
        })}
      </main>
    </div>
  );
}

/**
 * Edge-anchored Chapter Narrative Panel (Display Italic Uppercase Headline + Body + 4 Telemetry KPIs)
 */
function ChapterNarrativeCard({
  chapter,
  index,
}: {
  chapter: ChapterSpec;
  index: number;
}) {
  return (
    <article className="hud-glass hud-corners p-4 sm:p-5 flex flex-col gap-3 pointer-events-none">
      {/* Chapter Tag & Index */}
      <div className="flex items-center justify-between border-b border-white/10 pb-2">
        <span className="font-mono-telemetry text-[10px] tracking-[0.2em] text-[#E10600] uppercase font-semibold">
          {chapter.tag}
        </span>
        <span className="font-mono-telemetry text-[10px] text-[#525866]">
          {chapter.code}
        </span>
      </div>

      {/* Bold Italic Uppercase Display Headline */}
      <h1 className="font-display text-2xl sm:text-3xl lg:text-[34px] text-white tracking-tight">
        <span className="block">{chapter.titleLine1}</span>
        <span className="block">{chapter.titleLine2}</span>
        <span className="block text-[#E10600]">{chapter.accentWord}</span>
      </h1>

      {/* Clean Inter Body Copy */}
      <p className="text-xs sm:text-[13px] leading-relaxed text-[#9BA1AE] font-normal">
        {chapter.summary}
      </p>

      {/* 2x2 Precision Telemetry Spec Grid */}
      <div className="grid grid-cols-2 gap-2 pt-1">
        {chapter.metrics.map((m) => (
          <div
            key={m.label}
            className={`px-2.5 py-2 border ${
              m.highlight
                ? 'border-[#E10600]/45 bg-[#E10600]/10'
                : 'border-white/10 bg-black/35'
            }`}
          >
            <div className="font-mono-telemetry text-[9px] text-[#9BA1AE] tracking-wider uppercase">
              {m.label}
            </div>
            <div className="font-mono-telemetry text-sm sm:text-base font-bold text-white flex items-baseline gap-1 mt-0.5">
              <span>{m.value}</span>
              {m.unit && (
                <span className="text-[10px] font-normal text-[#E10600]">
                  {m.unit}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {index === 0 && (
        <div className="flex items-center gap-2 pt-1 text-[10px] font-mono-telemetry text-[#9BA1AE] tracking-widest uppercase">
          <span className="inline-block w-4 h-[1px] bg-[#E10600]" />
          <span>SCROLL TO ORBIT CHASSIS &amp; ENGAGE TELEMETRY</span>
        </div>
      )}
    </article>
  );
}

/**
 * Opposite-Edge Telemetry Diagnostic Panel (Live Graphs, G-Force Vector Reticle, Rotor Thermal Matrix)
 */
function ChapterTelemetryCard({
  chapter,
  telemetry,
}: {
  chapter: ChapterSpec;
  telemetry: TelemetryState;
}) {
  return (
    <aside className="hud-glass-red hud-corners p-4 sm:p-5 flex flex-col gap-3 pointer-events-none">
      <div className="flex items-center justify-between border-b border-white/10 pb-2">
        <span className="font-mono-telemetry text-[10px] tracking-[0.16em] text-white font-semibold uppercase">
          {chapter.telemetryTitle}
        </span>
        <span className="font-mono-telemetry text-[9px] text-[#E10600] uppercase">
          {chapter.telemetryCode}
        </span>
      </div>

      {/* Chapter-Specific Live Visual Telemetry Widget */}
      {chapter.id === 'aerodynamics' && (
        <div className="p-2.5 bg-black/45 border border-white/10 flex flex-col gap-2">
          <div className="flex justify-between text-[10px] font-mono-telemetry">
            <span className="text-[#9BA1AE]">FRONT WING LOAD</span>
            <span className="text-white">48.4% // 687 KG</span>
          </div>
          <div className="w-full h-1.5 bg-white/10 overflow-hidden">
            <div className="h-full bg-[#E10600]" style={{ width: '78%' }} />
          </div>
          <div className="flex justify-between text-[10px] font-mono-telemetry">
            <span className="text-[#9BA1AE]">VENTURI FLOOR SUCTION</span>
            <span className="text-[#00FF66]">ACTIVE // -4.85 kPa</span>
          </div>
          <div className="w-full h-1.5 bg-white/10 overflow-hidden">
            <div className="h-full bg-[#00FF66]" style={{ width: '92%' }} />
          </div>
        </div>
      )}

      {chapter.id === 'power' && (
        <div className="p-2.5 bg-black/45 border border-white/10 grid grid-cols-3 gap-2 text-center font-mono-telemetry">
          <div>
            <div className="text-[9px] text-[#9BA1AE]">ICE V6</div>
            <div className="text-xs font-bold text-white">575 kW</div>
          </div>
          <div className="border-x border-white/10">
            <div className="text-[9px] text-[#9BA1AE]">MGU-K</div>
            <div className="text-xs font-bold text-[#00FF66]">350 kW</div>
          </div>
          <div>
            <div className="text-[9px] text-[#9BA1AE]">EXHAUST</div>
            <div className="text-xs font-bold text-[#FF2A1F]">985 °C</div>
          </div>
        </div>
      )}

      {chapter.id === 'telemetry' && (
        <div className="p-2.5 bg-black/45 border border-white/10 flex items-center justify-between gap-3">
          {/* Live G-Force Circle Vector Reticle */}
          <div className="relative w-14 h-14 rounded-full border border-white/20 flex items-center justify-center shrink-0">
            <div className="w-7 h-7 rounded-full border border-white/10" />
            <div className="absolute inset-x-0 h-[1px] bg-white/10" />
            <div className="absolute inset-y-0 w-[1px] bg-white/10" />
            <div
              className="w-2.5 h-2.5 rounded-full bg-[#E10600] shadow-[0_0_8px_#E10600]"
              style={{
                transform: `translate(${(telemetry.lateralG * 2.5).toFixed(1)}px, ${(
                  -telemetry.longitudinalG * 2.2
                ).toFixed(1)}px)`,
              }}
            />
          </div>
          {/* 4-Wheel Carbon Brake Disc Temperatures */}
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 w-full font-mono-telemetry text-[10px]">
            <div className="flex justify-between">
              <span className="text-[#9BA1AE]">FL</span>
              <span className="text-[#FF2A1F] font-bold">{telemetry.brakeTempFL}°C</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#9BA1AE]">FR</span>
              <span className="text-[#FF2A1F] font-bold">{telemetry.brakeTempFR}°C</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#9BA1AE]">RL</span>
              <span className="text-white">{telemetry.brakeTempRL}°C</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#9BA1AE]">RR</span>
              <span className="text-white">{telemetry.brakeTempRR}°C</span>
            </div>
          </div>
        </div>
      )}

      {/* Telemetry Diagnostic Stream Lines */}
      <ul className="flex flex-col gap-1.5">
        {chapter.telemetryNotes.map((note, i) => (
          <li
            key={i}
            className="flex items-start gap-2 font-mono-telemetry text-[10px] leading-snug text-[#C8CDD8]"
          >
            <span className="text-[#E10600] font-bold mt-[1px]">›</span>
            <span>{note}</span>
          </li>
        ))}
      </ul>
    </aside>
  );
}

export default App;
