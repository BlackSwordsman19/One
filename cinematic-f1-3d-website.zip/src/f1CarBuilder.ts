import * as THREE from 'three';

export interface F1CarRig {
  root: THREE.Group;
  wheels: THREE.Object3D[];
  frontSteerGroupL: THREE.Object3D;
  frontSteerGroupR: THREE.Object3D;
  drsFlapPivot: THREE.Object3D;
  steeringWheel: THREE.Object3D;
  helmetGroup: THREE.Object3D;
  brakeGlowMaterials: THREE.MeshStandardMaterial[];
  exhaustGlowMaterial: THREE.MeshStandardMaterial;
  rainLightMaterial: THREE.MeshStandardMaterial;
  engineThermalMaterial: THREE.MeshStandardMaterial;
  aeroLinesGroup: THREE.Group;
  aeroLineMaterials: THREE.MeshBasicMaterial[];
  chassisBodyMaterials: THREE.MeshStandardMaterial[];
}

/**
 * Helper: Creates a smooth lofted BufferGeometry from an array of cross-section rings.
 * Each station in `stations` has `z` and a list of `[x, y]` points (identical vertex count per ring).
 */
function createLoftedGeometry(
  stations: { z: number; pts: [number, number][] }[],
  closeCaps = true
): THREE.BufferGeometry {
  const numStations = stations.length;
  const ringSize = stations[0].pts.length;
  const positions: number[] = [];
  const indices: number[] = [];

  for (let s = 0; s < numStations; s++) {
    const { z, pts } = stations[s];
    for (let p = 0; p < ringSize; p++) {
      positions.push(pts[p][0], pts[p][1], z);
    }
  }

  for (let s = 0; s < numStations - 1; s++) {
    const rowA = s * ringSize;
    const rowB = (s + 1) * ringSize;
    for (let p = 0; p < ringSize; p++) {
      const nextP = (p + 1) % ringSize;
      const a = rowA + p;
      const b = rowA + nextP;
      const c = rowB + nextP;
      const d = rowB + p;
      indices.push(a, d, b);
      indices.push(b, d, c);
    }
  }

  if (closeCaps) {
    // Front cap (first station)
    const frontCenterIdx = positions.length / 3;
    let cx0 = 0,
      cy0 = 0;
    for (const [x, y] of stations[0].pts) {
      cx0 += x;
      cy0 += y;
    }
    cx0 /= ringSize;
    cy0 /= ringSize;
    positions.push(cx0, cy0, stations[0].z);
    for (let p = 0; p < ringSize; p++) {
      const nextP = (p + 1) % ringSize;
      indices.push(frontCenterIdx, p, nextP);
    }

    // Rear cap (last station)
    const rearCenterIdx = positions.length / 3;
    const lastS = numStations - 1;
    const baseIdx = lastS * ringSize;
    let cx1 = 0,
      cy1 = 0;
    for (const [x, y] of stations[lastS].pts) {
      cx1 += x;
      cy1 += y;
    }
    cx1 /= ringSize;
    cy1 /= ringSize;
    positions.push(cx1, cy1, stations[lastS].z);
    for (let p = 0; p < ringSize; p++) {
      const nextP = (p + 1) % ringSize;
      indices.push(rearCenterIdx, baseIdx + nextP, baseIdx + p);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Generates a smooth 24-point parametric super-ellipse / trapezoidal F1 chassis cross-section ring.
 */
function makeSectionRing(
  halfWBot: number,
  halfWTop: number,
  yBot: number,
  yTop: number,
  midWScale = 1.08,
  crownArch = 0.03
): [number, number][] {
  const pts: [number, number][] = [];
  const N = 24;
  const yCenter = (yBot + yTop) * 0.5;
  const halfH = Math.max(0.01, (yTop - yBot) * 0.5);

  for (let i = 0; i < N; i++) {
    const theta = (i / N) * Math.PI * 2;
    const rawX = Math.sin(theta);
    const rawY = -Math.cos(theta); // -1 at bottom, +1 at top
    const v = rawY * 0.5 + 0.5; // 0 at bottom, 1 at top

    // Squarish super-ellipse shaping for authentic F1 monocoque cross-section
    const shapedX = Math.sign(rawX) * Math.pow(Math.abs(rawX), 0.72);
    const shapedY = Math.sign(rawY) * Math.pow(Math.abs(rawY), 0.78);

    const wAtHeight =
      THREE.MathUtils.lerp(halfWBot, halfWTop, v) *
      (1 + (midWScale - 1) * Math.sin(v * Math.PI));
    const archOffset = v > 0.5 ? Math.cos(rawX * Math.PI * 0.5) * crownArch * (v - 0.5) * 2 : 0;

    const x = shapedX * wAtHeight;
    const y = yCenter + shapedY * halfH + archOffset;
    pts.push([x, y]);
  }
  return pts;
}

/**
 * Creates a swept 3D airfoil wing element across X from -halfSpan to +halfSpan.
 */
function createSweptWingElement(
  halfSpan: number,
  chordRoot: number,
  chordTip: number,
  thickness: number,
  sweepZ: number,
  dihedralY: number,
  camberAngleRad: number,
  spanSegments = 28
): THREE.BufferGeometry {
  // Cross section of airfoil (10 points around chord)
  const airfoilProfile: [number, number][] = [
    [0.0, 0.0], // leading edge
    [0.15, thickness * 0.72],
    [0.42, thickness * 0.95],
    [0.75, thickness * 0.62],
    [1.0, thickness * 0.12], // trailing edge top
    [1.0, -thickness * 0.05], // trailing edge bottom
    [0.72, -thickness * 0.22],
    [0.4, -thickness * 0.3],
    [0.14, -thickness * 0.25],
    [0.02, -thickness * 0.08],
  ];

  const numPts = airfoilProfile.length;
  const positions: number[] = [];
  const indices: number[] = [];

  for (let i = 0; i <= spanSegments; i++) {
    const u = (i / spanSegments) * 2 - 1; // -1 to +1
    const absU = Math.abs(u);
    const x = u * halfSpan;
    // Smooth spoon curve in Y and sweep in Z
    const spoonCurve = Math.sin(absU * Math.PI * 0.5);
    const yOffset = spoonCurve * dihedralY;
    const zOffset = Math.pow(absU, 1.45) * sweepZ;
    const chord = THREE.MathUtils.lerp(chordRoot, chordTip, absU);
    const localPitch = camberAngleRad * (1 + 0.25 * absU);
    const cosP = Math.cos(localPitch);
    const sinP = Math.sin(localPitch);

    for (let p = 0; p < numPts; p++) {
      const [cu, cv] = airfoilProfile[p];
      // Leading edge at +z, trailing edge towards -z
      const localZ = (0.5 - cu) * chord;
      const localY = cv;
      const rotY = localY * cosP - localZ * sinP;
      const rotZ = localY * sinP + localZ * cosP;
      positions.push(x, yOffset + rotY, zOffset + rotZ);
    }
  }

  for (let i = 0; i < spanSegments; i++) {
    const rowA = i * numPts;
    const rowB = (i + 1) * numPts;
    for (let p = 0; p < numPts; p++) {
      const nextP = (p + 1) % numPts;
      const a = rowA + p;
      const b = rowA + nextP;
      const c = rowB + nextP;
      const d = rowB + p;
      indices.push(a, b, d);
      indices.push(b, c, d);
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}

/**
 * Builds the complete, high-detail 2026 Formula 1 car hierarchy.
 * Front of car faces +Z (`z = +2.75`), Rear faces -Z (`z = -2.65`), wheels touch ground at `y = 0`.
 */
export function buildFormula1CarScene(): F1CarRig {
  const root = new THREE.Group();
  root.name = 'SCUDERIA_APEX_F1_26';

  // --- PBR Materials (Tuned for high-contrast studio lighting against #070709 carbon void) ---
  const matCarbonBody = new THREE.MeshStandardMaterial({
    name: 'Mat_Carbon_Gloss',
    color: new THREE.Color('#2c313f'),
    metalness: 0.56,
    roughness: 0.20,
    emissive: new THREE.Color('#090b12'),
    emissiveIntensity: 0.35,
  });

  const matCarbonWeave = new THREE.MeshStandardMaterial({
    name: 'Mat_Carbon_FloorWeave',
    color: new THREE.Color('#1f232e'),
    metalness: 0.45,
    roughness: 0.32,
  });

  const matF1Red = new THREE.MeshStandardMaterial({
    name: 'Mat_F1_Crimson_Livery',
    color: new THREE.Color('#E10600'),
    metalness: 0.30,
    roughness: 0.16,
    emissive: new THREE.Color('#4a0200'),
    emissiveIntensity: 0.45,
  });

  const matF1RedGlow = new THREE.MeshStandardMaterial({
    name: 'Mat_F1_Red_AccentGlow',
    color: new THREE.Color('#ff2214'),
    metalness: 0.2,
    roughness: 0.18,
    emissive: new THREE.Color('#E10600'),
    emissiveIntensity: 0.95,
  });

  const matWhiteAccent = new THREE.MeshStandardMaterial({
    name: 'Mat_Aero_WhiteStripe',
    color: new THREE.Color('#F5F7FA'),
    metalness: 0.25,
    roughness: 0.18,
    emissive: new THREE.Color('#222630'),
    emissiveIntensity: 0.3,
  });

  const matTitanium = new THREE.MeshStandardMaterial({
    name: 'Mat_Titanium_Alloy',
    color: new THREE.Color('#5a6275'),
    metalness: 0.82,
    roughness: 0.22,
  });

  const matChrome = new THREE.MeshStandardMaterial({
    name: 'Mat_Exhaust_Inconel',
    color: new THREE.Color('#9ea6b8'),
    metalness: 0.92,
    roughness: 0.14,
  });

  const matTireRubber = new THREE.MeshStandardMaterial({
    name: 'Mat_Pirelli_Slick_Rubber',
    color: new THREE.Color('#22252e'),
    metalness: 0.14,
    roughness: 0.52,
  });

  const matWheelCover = new THREE.MeshStandardMaterial({
    name: 'Mat_Wheel_Aero_Cover',
    color: new THREE.Color('#262a36'),
    metalness: 0.62,
    roughness: 0.24,
  });

  const matHelmetVisor = new THREE.MeshStandardMaterial({
    name: 'Mat_Helmet_Iridescent_Visor',
    color: new THREE.Color('#ff3300'),
    metalness: 0.95,
    roughness: 0.06,
    emissive: new THREE.Color('#330500'),
    emissiveIntensity: 0.3,
  });

  const matEngineThermal = new THREE.MeshStandardMaterial({
    name: 'Mat_Engine_Thermal_Core',
    color: new THREE.Color('#220500'),
    metalness: 0.5,
    roughness: 0.35,
    emissive: new THREE.Color('#ff2a00'),
    emissiveIntensity: 0.15,
  });

  const matExhaustGlow = new THREE.MeshStandardMaterial({
    name: 'Mat_Exhaust_Plume_Glow',
    color: new THREE.Color('#ff3b00'),
    metalness: 0.2,
    roughness: 0.2,
    emissive: new THREE.Color('#ff3300'),
    emissiveIntensity: 0.7,
  });

  const matRainLight = new THREE.MeshStandardMaterial({
    name: 'Mat_FIA_Rain_Light',
    color: new THREE.Color('#ff1100'),
    metalness: 0.1,
    roughness: 0.15,
    emissive: new THREE.Color('#ff0a00'),
    emissiveIntensity: 2.2,
  });

  // ============================================================================
  // 1. LOFTED MONOCOQUE, NEEDLE NOSE CONE & COKE-BOTTLE ENGINE COVER
  // ============================================================================
  const chassisStations = [
    // Tip of front nose cone
    { z: 2.66, pts: makeSectionRing(0.055, 0.045, 0.17, 0.23, 1.02, 0.008) },
    { z: 2.42, pts: makeSectionRing(0.095, 0.082, 0.19, 0.29, 1.04, 0.012) },
    { z: 2.08, pts: makeSectionRing(0.135, 0.118, 0.22, 0.37, 1.05, 0.016) },
    // Front suspension bulkhead
    { z: 1.72, pts: makeSectionRing(0.175, 0.155, 0.23, 0.48, 1.06, 0.022) },
    { z: 1.32, pts: makeSectionRing(0.215, 0.195, 0.21, 0.56, 1.07, 0.025) },
    { z: 0.92, pts: makeSectionRing(0.255, 0.235, 0.16, 0.61, 1.08, 0.025) },
    // Cockpit front cowl & survival cell entry
    { z: 0.56, pts: makeSectionRing(0.295, 0.265, 0.12, 0.63, 1.08, 0.02) },
    // Around cockpit tub (slightly lower center crown because cockpit recessed tub sits inside)
    { z: 0.18, pts: makeSectionRing(0.32, 0.29, 0.10, 0.62, 1.08, 0.01) },
    { z: -0.22, pts: makeSectionRing(0.32, 0.28, 0.10, 0.65, 1.07, 0.02) },
    // Roll hoop / Airbox tower transition
    { z: -0.45, pts: makeSectionRing(0.30, 0.19, 0.11, 0.95, 1.12, 0.04) },
    { z: -0.78, pts: makeSectionRing(0.28, 0.15, 0.11, 0.91, 1.12, 0.035) },
    // Engine cover tapering spine
    { z: -1.18, pts: makeSectionRing(0.25, 0.11, 0.12, 0.81, 1.1, 0.025) },
    { z: -1.58, pts: makeSectionRing(0.19, 0.075, 0.14, 0.68, 1.08, 0.02) },
    { z: -1.98, pts: makeSectionRing(0.13, 0.055, 0.18, 0.55, 1.05, 0.01) },
    // Rear gearbox & crash structure tail
    { z: -2.38, pts: makeSectionRing(0.08, 0.045, 0.21, 0.45, 1.02, 0.005) },
    { z: -2.54, pts: makeSectionRing(0.05, 0.038, 0.22, 0.36, 1.0, 0.0) },
  ];

  const monocoqueGeo = createLoftedGeometry(chassisStations, true);
  const monocoqueMesh = new THREE.Mesh(monocoqueGeo, matCarbonBody);
  monocoqueMesh.name = 'Chassis_Monocoque';
  monocoqueMesh.castShadow = true;
  monocoqueMesh.receiveShadow = true;
  root.add(monocoqueMesh);

  // Nose-to-cockpit F1 Red Center Racing Stripe
  const stripeStations = [
    { z: 2.65, pts: makeSectionRing(0.032, 0.032, 0.225, 0.238, 1.0, 0.004) },
    { z: 2.08, pts: makeSectionRing(0.068, 0.068, 0.365, 0.388, 1.0, 0.005) },
    { z: 1.32, pts: makeSectionRing(0.095, 0.095, 0.555, 0.588, 1.0, 0.006) },
    { z: 0.58, pts: makeSectionRing(0.12, 0.12, 0.625, 0.654, 1.0, 0.006) },
  ];
  const noseStripeMesh = new THREE.Mesh(
    createLoftedGeometry(stripeStations, true),
    matF1Red
  );
  noseStripeMesh.name = 'Livery_Nose_Stripe';
  root.add(noseStripeMesh);

  // ============================================================================
  // 2. SCULPTED GROUND-EFFECT SIDEPODS WITH HIGH UNDERCUT & LOUVERS (L & R)
  // ============================================================================
  for (const side of [-1, 1] as const) {
    const makeSidepodRing = (
      xInner: number,
      xOuter: number,
      yBotInner: number,
      yBotOuter: number,
      yTopInner: number,
      yTopOuter: number,
      undercutPinch: number
    ): [number, number][] => {
      const N = 20;
      const pts: [number, number][] = [];
      const cx = side * (xInner + xOuter) * 0.5;
      const halfW = (xOuter - xInner) * 0.5;
      const cy = (Math.min(yBotInner, yBotOuter) + Math.max(yTopInner, yTopOuter)) * 0.5;
      const halfH = Math.max(0.02, (Math.max(yTopInner, yTopOuter) - Math.min(yBotInner, yBotOuter)) * 0.5);

      for (let i = 0; i < N; i++) {
        const theta = (i / N) * Math.PI * 2;
        const sx = Math.sin(theta);
        const sy = -Math.cos(theta); // -1 bottom, +1 top
        const v = sy * 0.5 + 0.5;

        const pinch = v < 0.45 ? undercutPinch * (0.45 - v) * 1.4 : 0;
        const shapedX = Math.sign(sx) * Math.pow(Math.abs(sx), 0.75) * (1 - pinch);
        const shapedY = Math.sign(sy) * Math.pow(Math.abs(sy), 0.75);

        const x = cx + shapedX * halfW;
        const slopeY = sx * side > 0 ? (yTopOuter - yTopInner) * 0.35 : 0;
        const y = cy + shapedY * halfH + slopeY * v;
        pts.push([x, y]);
      }
      return pts;
    };

    const sidepodStations = [
      // Aggressive overbite front radiator inlet lip
      { z: 0.52, pts: makeSidepodRing(0.27, 0.72, 0.26, 0.31, 0.58, 0.55, 0.35) },
      { z: 0.35, pts: makeSidepodRing(0.28, 0.82, 0.14, 0.24, 0.60, 0.57, 0.42) },
      { z: 0.05, pts: makeSidepodRing(0.28, 0.85, 0.11, 0.21, 0.60, 0.56, 0.48) },
      { z: -0.35, pts: makeSidepodRing(0.26, 0.82, 0.11, 0.19, 0.58, 0.52, 0.45) },
      // Downwash waterslide ramp & coke-bottle waist
      { z: -0.78, pts: makeSidepodRing(0.23, 0.72, 0.11, 0.16, 0.53, 0.44, 0.38) },
      { z: -1.22, pts: makeSidepodRing(0.19, 0.55, 0.11, 0.14, 0.46, 0.35, 0.28) },
      { z: -1.62, pts: makeSidepodRing(0.14, 0.36, 0.12, 0.14, 0.38, 0.27, 0.18) },
      { z: -1.96, pts: makeSidepodRing(0.10, 0.20, 0.15, 0.16, 0.32, 0.23, 0.10) },
    ];

    const sidepodGeo = createLoftedGeometry(sidepodStations, true);
    const sidepodMesh = new THREE.Mesh(sidepodGeo, matCarbonBody);
    sidepodMesh.name = side === -1 ? 'Sidepod_L' : 'Sidepod_R';
    sidepodMesh.castShadow = true;
    sidepodMesh.receiveShadow = true;
    root.add(sidepodMesh);

    // Sidepod F1 Red Sweeping Shoulder Slash
    const slashStations = [
      { z: 0.53, pts: makeSidepodRing(0.32, 0.73, 0.53, 0.51, 0.59, 0.56, 0.05) },
      { z: 0.10, pts: makeSidepodRing(0.55, 0.855, 0.48, 0.46, 0.58, 0.565, 0.05) },
      { z: -0.55, pts: makeSidepodRing(0.48, 0.77, 0.43, 0.41, 0.52, 0.48, 0.05) },
      { z: -1.25, pts: makeSidepodRing(0.32, 0.53, 0.33, 0.31, 0.41, 0.36, 0.05) },
    ];
    const slashMesh = new THREE.Mesh(
      createLoftedGeometry(slashStations, true),
      matF1Red
    );
    slashMesh.name = side === -1 ? 'Sidepod_Livery_L' : 'Sidepod_Livery_R';
    root.add(slashMesh);

    // Recessed Thermal Radiator Core inside front sidepod inlet + cooling gills
    const radMesh = new THREE.Mesh(
      new THREE.BoxGeometry(0.38, 0.20, 0.08),
      matEngineThermal
    );
    radMesh.position.set(side * 0.53, 0.43, 0.48);
    radMesh.rotation.y = side * -0.18;
    radMesh.name = side === -1 ? 'Radiator_Core_L' : 'Radiator_Core_R';
    root.add(radMesh);

    // Cooling gill louvers on upper sidepod shoulder (glow subtly when thermal mode active)
    for (let g = 0; g < 6; g++) {
      const gill = new THREE.Mesh(
        new THREE.BoxGeometry(0.16, 0.012, 0.035),
        matEngineThermal
      );
      gill.position.set(side * (0.44 - g * 0.025), 0.54 - g * 0.024, -0.25 - g * 0.14);
      gill.rotation.set(0.18, side * 0.2, side * -0.22);
      root.add(gill);
    }
  }

  // ============================================================================
  // 3. SHARK FIN ENGINE COVER & ROLL-HOOP AIRBOX INTAKE
  // ============================================================================
  const sharkFinShape = new THREE.Shape();
  sharkFinShape.moveTo(-0.48, 0.93);
  sharkFinShape.lineTo(-1.82, 0.76);
  sharkFinShape.lineTo(-1.95, 0.52);
  sharkFinShape.lineTo(-0.48, 0.62);
  sharkFinShape.closePath();

  const sharkFinGeo = new THREE.ExtrudeGeometry(sharkFinShape, {
    depth: 0.018,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.004,
    bevelThickness: 0.004,
  });
  // Rotate by -PI/2 so x_shape maps directly to +Z (-0.48 to -1.95 on rear engine cover)
  sharkFinGeo.rotateY(-Math.PI / 2);
  sharkFinGeo.translate(0.009, 0, 0);
  const sharkFinMesh = new THREE.Mesh(sharkFinGeo, matCarbonBody);
  sharkFinMesh.name = 'Engine_Shark_Fin';
  sharkFinMesh.castShadow = true;
  root.add(sharkFinMesh);

  // Red Top Trim on Shark Fin (slopes down from y=0.93 at z=-0.48 to y=0.76 at z=-1.82)
  const finTrimGeo = new THREE.BoxGeometry(0.024, 0.035, 1.35);
  const finTrimMesh = new THREE.Mesh(finTrimGeo, matF1Red);
  finTrimMesh.position.set(0, 0.845, -1.15);
  finTrimMesh.rotation.x = -0.126;
  finTrimMesh.name = 'Shark_Fin_Red_Trim';
  root.add(finTrimMesh);

  // Airbox Intake Scoop Ring at Roll Hoop
  const airboxRim = new THREE.Mesh(
    new THREE.TorusGeometry(0.085, 0.022, 12, 24),
    matF1Red
  );
  airboxRim.scale.set(0.85, 1.15, 1.0);
  airboxRim.position.set(0, 0.84, -0.38);
  airboxRim.name = 'Airbox_Intake_Bezel';
  root.add(airboxRim);

  // ============================================================================
  // 4. VENTURI UNDERFLOOR, FLOOR EDGE WINGS & REAR DIFFUSER STRAKES
  // ============================================================================
  const floorGroup = new THREE.Group();
  floorGroup.name = 'Floor_Venturi_Diffuser';

  // Main Carbon Underfloor Plank
  const floorShape = new THREE.Shape();
  floorShape.moveTo(-0.32, 1.15);
  floorShape.lineTo(-0.78, 0.68);
  floorShape.lineTo(-0.91, 0.35);
  floorShape.lineTo(-0.89, -1.35);
  floorShape.lineTo(-0.68, -1.78);
  floorShape.lineTo(-0.52, -2.38);
  floorShape.lineTo(0.52, -2.38);
  floorShape.lineTo(0.68, -1.78);
  floorShape.lineTo(0.89, -1.35);
  floorShape.lineTo(0.91, 0.35);
  floorShape.lineTo(0.78, 0.68);
  floorShape.lineTo(0.32, 1.15);
  floorShape.closePath();

  const floorGeo = new THREE.ExtrudeGeometry(floorShape, {
    depth: 0.025,
    bevelEnabled: true,
    bevelSegments: 2,
    steps: 1,
    bevelSize: 0.008,
    bevelThickness: 0.006,
  });
  floorGeo.rotateX(Math.PI / 2);
  floorGeo.translate(0, 0.075, 0);
  const floorMesh = new THREE.Mesh(floorGeo, matCarbonWeave);
  floorMesh.receiveShadow = true;
  floorMesh.castShadow = true;
  floorGroup.add(floorMesh);

  // Floor Edge Vortex Scroll Wings + Red Pinstripe (Left & Right)
  for (const side of [-1, 1] as const) {
    const edgeBeam = new THREE.Mesh(
      new THREE.BoxGeometry(0.032, 0.022, 1.75),
      matF1Red
    );
    edgeBeam.position.set(side * 0.905, 0.076, -0.48);
    floorGroup.add(edgeBeam);

    // Front Floor Fences (3 vertical curved strakes per side)
    for (let f = 0; f < 3; f++) {
      const fence = new THREE.Mesh(
        new THREE.BoxGeometry(0.008, 0.09, 0.42),
        matCarbonWeave
      );
      fence.position.set(side * (0.48 + f * 0.14), 0.10, 0.56 - f * 0.05);
      fence.rotation.y = side * -0.16;
      floorGroup.add(fence);
    }
  }

  // Rear Upswept Venturi Diffuser Roof & 6 Vertical Diffuser Strakes
  const diffuserRoof = new THREE.Mesh(
    new THREE.BoxGeometry(1.04, 0.018, 0.62),
    matCarbonWeave
  );
  diffuserRoof.position.set(0, 0.16, -2.18);
  diffuserRoof.rotation.x = 0.24;
  floorGroup.add(diffuserRoof);

  for (const sx of [-0.46, -0.31, -0.16, 0.16, 0.31, 0.46]) {
    const strake = new THREE.Mesh(
      new THREE.BoxGeometry(0.01, 0.13, 0.56),
      matCarbonBody
    );
    strake.position.set(sx, 0.13, -2.20);
    strake.rotation.x = 0.2;
    floorGroup.add(strake);
  }
  root.add(floorGroup);

  // ============================================================================
  // 5. MULTI-ELEMENT FRONT WING (4 CASCADED FLAPS + ENDPLATES + NOSE PYLONS)
  // ============================================================================
  const frontWingGroup = new THREE.Group();
  frontWingGroup.name = 'Front_Wing_Assembly';

  // 4 Cascaded Swept Airfoil Flaps
  const flapConfigs = [
    { z: 2.58, y: 0.075, chordRoot: 0.22, chordTip: 0.17, pitch: -0.06, mat: matCarbonBody },
    { z: 2.46, y: 0.102, chordRoot: 0.17, chordTip: 0.14, pitch: -0.16, mat: matCarbonBody },
    { z: 2.35, y: 0.136, chordRoot: 0.14, chordTip: 0.12, pitch: -0.26, mat: matCarbonBody },
    { z: 2.26, y: 0.172, chordRoot: 0.11, chordTip: 0.095, pitch: -0.36, mat: matF1Red },
  ];

  flapConfigs.forEach((cfg, idx) => {
    const wingGeo = createSweptWingElement(
      0.94,
      cfg.chordRoot,
      cfg.chordTip,
      0.018,
      -0.22,
      0.032,
      cfg.pitch,
      32
    );
    const wingMesh = new THREE.Mesh(wingGeo, cfg.mat);
    wingMesh.position.set(0, cfg.y, cfg.z);
    wingMesh.castShadow = true;
    wingMesh.receiveShadow = true;
    wingMesh.name = `Front_Wing_Element_${idx + 1}`;
    frontWingGroup.add(wingMesh);
  });

  // Twin Swan-Neck Nose Pylons
  for (const side of [-1, 1] as const) {
    const pylon = new THREE.Mesh(
      new THREE.BoxGeometry(0.014, 0.13, 0.22),
      matCarbonBody
    );
    pylon.position.set(side * 0.068, 0.145, 2.46);
    pylon.rotation.x = 0.22;
    frontWingGroup.add(pylon);

    // Sculpted Curved Front Wing Endplate
    const epShape = new THREE.Shape();
    epShape.moveTo(0, 0.06);
    epShape.lineTo(0.54, 0.06);
    epShape.lineTo(0.46, 0.31);
    epShape.quadraticCurveTo(0.22, 0.34, 0.0, 0.22);
    epShape.closePath();

    const epGeo = new THREE.ExtrudeGeometry(epShape, {
      depth: 0.014,
      bevelEnabled: true,
      bevelSegments: 2,
      steps: 1,
      bevelSize: 0.004,
      bevelThickness: 0.004,
    });
    epGeo.rotateY(-Math.PI / 2);
    const epMesh = new THREE.Mesh(epGeo, matCarbonBody);
    epMesh.position.set(side * 0.945 + 0.007, 0.02, 2.12);
    epMesh.rotation.z = side * -0.06;
    epMesh.castShadow = true;
    frontWingGroup.add(epMesh);

    // Endplate Red Diveplane Canard & Top Flash
    const canard = new THREE.Mesh(
      new THREE.BoxGeometry(0.055, 0.01, 0.28),
      matF1Red
    );
    canard.position.set(side * 0.975, 0.21, 2.26);
    canard.rotation.set(-0.22, 0, side * 0.15);
    frontWingGroup.add(canard);

    const epWhiteTip = new THREE.Mesh(
      new THREE.BoxGeometry(0.018, 0.032, 0.44),
      matWhiteAccent
    );
    epWhiteTip.position.set(side * 0.95, 0.32, 2.24);
    epWhiteTip.rotation.x = -0.18;
    frontWingGroup.add(epWhiteTip);
  }
  root.add(frontWingGroup);

  // ============================================================================
  // 6. COCKPIT TUB, STEERING WHEEL, DRIVER HELMET & TITANIUM HALO
  // ============================================================================
  const cockpitGroup = new THREE.Group();
  cockpitGroup.name = 'Cockpit_Halo_Assembly';

  // Dark recessed cockpit opening
  const cockpitRecess = new THREE.Mesh(
    new THREE.BoxGeometry(0.42, 0.14, 0.72),
    new THREE.MeshStandardMaterial({ color: '#050507', roughness: 0.85, metalness: 0.1 })
  );
  cockpitRecess.position.set(0, 0.58, 0.16);
  cockpitGroup.add(cockpitRecess);

  // F1 Carbon Butterfly Steering Wheel with RPM LED Strip
  const steeringWheel = new THREE.Group();
  steeringWheel.name = 'Steering_Wheel';
  steeringWheel.position.set(0, 0.62, 0.36);
  steeringWheel.rotation.x = -0.35;

  const wheelPlate = new THREE.Mesh(
    new THREE.BoxGeometry(0.24, 0.13, 0.022),
    matCarbonBody
  );
  steeringWheel.add(wheelPlate);

  const telemetryScreen = new THREE.Mesh(
    new THREE.BoxGeometry(0.11, 0.06, 0.026),
    matF1RedGlow
  );
  telemetryScreen.position.set(0, 0.01, 0);
  steeringWheel.add(telemetryScreen);
  cockpitGroup.add(steeringWheel);

  // Sculpted Aerodynamic Driver Helmet
  const helmetGroup = new THREE.Group();
  helmetGroup.name = 'Driver_Helmet';
  helmetGroup.position.set(0, 0.67, 0.02);

  const helmetShell = new THREE.Mesh(
    new THREE.SphereGeometry(0.145, 24, 20),
    matCarbonBody
  );
  helmetShell.scale.set(0.92, 0.96, 1.14);
  helmetGroup.add(helmetShell);

  const helmetCrownStripe = new THREE.Mesh(
    new THREE.SphereGeometry(0.147, 20, 16, -0.35, 0.7, 0.2, 1.2),
    matF1Red
  );
  helmetCrownStripe.scale.set(0.92, 0.96, 1.14);
  helmetGroup.add(helmetCrownStripe);

  // Iridescent Red-Gold Chrome Visor
  const visorMesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.138, 0.138, 0.082, 24, 1, false, -Math.PI * 0.38, Math.PI * 0.76),
    matHelmetVisor
  );
  visorMesh.rotation.y = Math.PI;
  visorMesh.position.set(0, 0.015, 0.03);
  helmetGroup.add(visorMesh);
  cockpitGroup.add(helmetGroup);

  // Titanium Halo Protection Hoop (3D Catmull-Rom Curved Tubes)
  const haloCenterPillar = new THREE.CatmullRomCurve3([
    new THREE.Vector3(0, 0.60, 0.50),
    new THREE.Vector3(0, 0.72, 0.44),
    new THREE.Vector3(0, 0.79, 0.36),
  ]);
  cockpitGroup.add(
    new THREE.Mesh(
      new THREE.TubeGeometry(haloCenterPillar, 16, 0.02, 12, false),
      matTitanium
    )
  );

  for (const side of [-1, 1] as const) {
    const haloHoopCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0.785, 0.37),
      new THREE.Vector3(side * 0.16, 0.79, 0.28),
      new THREE.Vector3(side * 0.26, 0.77, 0.05),
      new THREE.Vector3(side * 0.24, 0.72, -0.22),
      new THREE.Vector3(side * 0.19, 0.66, -0.32),
    ]);
    const haloArm = new THREE.Mesh(
      new THREE.TubeGeometry(haloHoopCurve, 28, 0.024, 12, false),
      matTitanium
    );
    haloArm.castShadow = true;
    cockpitGroup.add(haloArm);

    // Red Aero Fairing Lip along top of Halo
    const haloFairingCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, 0.812, 0.36),
      new THREE.Vector3(side * 0.16, 0.815, 0.27),
      new THREE.Vector3(side * 0.255, 0.795, 0.05),
      new THREE.Vector3(side * 0.23, 0.745, -0.20),
    ]);
    cockpitGroup.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(haloFairingCurve, 22, 0.009, 8, false),
        matF1Red
      )
    );
  }
  root.add(cockpitGroup);

  // ============================================================================
  // 7. REAR WING ASSEMBLY, SWAN-NECK PYLONS, BEAM WING & ACTIVE DRS FLAP
  // ============================================================================
  const rearWingGroup = new THREE.Group();
  rearWingGroup.name = 'Rear_Wing_Assembly';

  // Lower Double-Element Beam Wing above Diffuser
  const beamWingGeo = createSweptWingElement(0.50, 0.18, 0.15, 0.018, -0.05, 0.02, -0.24, 20);
  const beamWing = new THREE.Mesh(beamWingGeo, matCarbonBody);
  beamWing.position.set(0, 0.37, -2.35);
  rearWingGroup.add(beamWing);

  // Upper Rear Wing Mainplane (Fixed Lower Element)
  const rwMainGeo = createSweptWingElement(0.52, 0.24, 0.22, 0.024, -0.04, 0.025, -0.18, 24);
  const rwMainMesh = new THREE.Mesh(rwMainGeo, matCarbonBody);
  rwMainMesh.position.set(0, 0.79, -2.38);
  rwMainMesh.castShadow = true;
  rearWingGroup.add(rwMainMesh);

  // Active Movable DRS Flap (Pivots around its rear/lower hinge axis!)
  const drsFlapPivot = new THREE.Group();
  drsFlapPivot.name = 'DRS_Flap_Pivot';
  drsFlapPivot.position.set(0, 0.885, -2.47);

  const drsFlapGeo = createSweptWingElement(0.515, 0.17, 0.16, 0.018, -0.02, 0.01, -0.42, 24);
  const drsFlapMesh = new THREE.Mesh(drsFlapGeo, matF1Red);
  drsFlapMesh.position.set(0, 0.01, 0.06);
  drsFlapMesh.castShadow = true;
  drsFlapMesh.name = 'DRS_Flap';
  drsFlapPivot.add(drsFlapMesh);

  // White Leading-Edge Livery Strip on DRS Flap
  const drsStrip = new THREE.Mesh(
    new THREE.BoxGeometry(1.01, 0.012, 0.028),
    matWhiteAccent
  );
  drsStrip.position.set(0, 0.042, 0.12);
  drsFlapPivot.add(drsStrip);
  rearWingGroup.add(drsFlapPivot);

  // Central DRS Actuator Pod
  const drsPod = new THREE.Mesh(
    new THREE.BoxGeometry(0.036, 0.14, 0.22),
    matCarbonBody
  );
  drsPod.position.set(0, 0.86, -2.36);
  rearWingGroup.add(drsPod);

  // Twin Swan-Neck Rear Wing Pylons & Endplates
  for (const side of [-1, 1] as const) {
    const pylonCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(side * 0.055, 0.45, -2.14),
      new THREE.Vector3(side * 0.055, 0.68, -2.26),
      new THREE.Vector3(side * 0.055, 0.83, -2.32),
      new THREE.Vector3(side * 0.055, 0.79, -2.37),
    ]);
    rearWingGroup.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(pylonCurve, 18, 0.013, 8, false),
        matCarbonBody
      )
    );

    // Sculpted Rear Wing Endplate
    const rwEpShape = new THREE.Shape();
    rwEpShape.moveTo(0, 0.32);
    rwEpShape.lineTo(0.42, 0.34);
    rwEpShape.lineTo(0.36, 0.96);
    rwEpShape.lineTo(-0.04, 0.96);
    rwEpShape.quadraticCurveTo(-0.08, 0.65, 0, 0.32);
    rwEpShape.closePath();

    const rwEpGeo = new THREE.ExtrudeGeometry(rwEpShape, {
      depth: 0.014,
      bevelEnabled: true,
      bevelSegments: 2,
      steps: 1,
      bevelSize: 0.003,
      bevelThickness: 0.003,
    });
    rwEpGeo.rotateY(-Math.PI / 2);
    const rwEpMesh = new THREE.Mesh(rwEpGeo, matCarbonBody);
    rwEpMesh.position.set(side * 0.525 + 0.007, 0, -2.62);
    rwEpMesh.castShadow = true;
    rearWingGroup.add(rwEpMesh);

    // Red Endplate Trailing Edge Accent
    const rwAccent = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.58, 0.032),
      matF1Red
    );
    rwAccent.position.set(side * 0.53, 0.65, -2.56);
    rwAccent.rotation.x = -0.08;
    rearWingGroup.add(rwAccent);
  }

  // Central Inconel Exhaust Pipe + Wastegates + FIA Pulsing Rain Light
  const exhaustOuter = new THREE.Mesh(
    new THREE.CylinderGeometry(0.058, 0.066, 0.28, 24, 1, true),
    matChrome
  );
  exhaustOuter.rotation.x = Math.PI / 2 - 0.08;
  exhaustOuter.position.set(0, 0.46, -2.42);
  rearWingGroup.add(exhaustOuter);

  const exhaustCore = new THREE.Mesh(
    new THREE.CylinderGeometry(0.052, 0.052, 0.12, 20),
    matExhaustGlow
  );
  exhaustCore.rotation.x = Math.PI / 2 - 0.08;
  exhaustCore.position.set(0, 0.46, -2.48);
  exhaustCore.name = 'Exhaust_Thermal_Core';
  rearWingGroup.add(exhaustCore);

  // FIA Rear Crash Structure & Pulsing LED Rain Light
  const rainLightHousing = new THREE.Mesh(
    new THREE.BoxGeometry(0.065, 0.14, 0.16),
    matCarbonBody
  );
  rainLightHousing.position.set(0, 0.25, -2.50);
  rearWingGroup.add(rainLightHousing);

  const rainLightLED = new THREE.Mesh(
    new THREE.BoxGeometry(0.028, 0.105, 0.02),
    matRainLight
  );
  rainLightLED.position.set(0, 0.25, -2.582);
  rainLightLED.name = 'FIA_Rain_Light_LED';
  rearWingGroup.add(rainLightLED);

  root.add(rearWingGroup);

  // ============================================================================
  // 8. DOUBLE-WISHBONE CARBON SUSPENSION ARMS (FRONT & REAR)
  // ============================================================================
  const suspensionGroup = new THREE.Group();
  suspensionGroup.name = 'Suspension_Wishbones';

  const addWishboneStrut = (p1: THREE.Vector3, p2: THREE.Vector3, radius = 0.012) => {
    const curve = new THREE.LineCurve3(p1, p2);
    const mesh = new THREE.Mesh(
      new THREE.TubeGeometry(curve, 4, radius, 8, false),
      matCarbonWeave
    );
    mesh.castShadow = true;
    suspensionGroup.add(mesh);
  };

  for (const side of [-1, 1] as const) {
    // Front Double Wishbones + Pushrod + Steering Tie-Rod (around z = +1.72)
    const fHubTop = new THREE.Vector3(side * 0.72, 0.43, 1.72);
    const fHubBot = new THREE.Vector3(side * 0.72, 0.24, 1.72);
    addWishboneStrut(new THREE.Vector3(side * 0.16, 0.44, 1.92), fHubTop);
    addWishboneStrut(new THREE.Vector3(side * 0.18, 0.42, 1.50), fHubTop);
    addWishboneStrut(new THREE.Vector3(side * 0.15, 0.25, 1.90), fHubBot);
    addWishboneStrut(new THREE.Vector3(side * 0.17, 0.24, 1.48), fHubBot);
    // Front Pushrod
    addWishboneStrut(new THREE.Vector3(side * 0.16, 0.48, 1.76), fHubBot, 0.01);

    // Rear Double Wishbones + Pullrod + Driveshaft (around z = -1.85)
    const rHubTop = new THREE.Vector3(side * 0.70, 0.44, -1.85);
    const rHubBot = new THREE.Vector3(side * 0.70, 0.23, -1.85);
    addWishboneStrut(new THREE.Vector3(side * 0.14, 0.43, -1.62), rHubTop);
    addWishboneStrut(new THREE.Vector3(side * 0.10, 0.41, -2.08), rHubTop);
    addWishboneStrut(new THREE.Vector3(side * 0.13, 0.23, -1.60), rHubBot);
    addWishboneStrut(new THREE.Vector3(side * 0.09, 0.22, -2.06), rHubBot);
    // Rear Driveshaft
    addWishboneStrut(
      new THREE.Vector3(side * 0.11, 0.34, -1.85),
      new THREE.Vector3(side * 0.74, 0.36, -1.85),
      0.018
    );
  }
  root.add(suspensionGroup);

  // ============================================================================
  // 9. 4 PIRELLI P-ZERO SLICK WHEELS, AERO COVERS, BRAKE GLOW ROTORS & WINGLETS
  // ============================================================================
  const wheels: THREE.Object3D[] = [];
  const brakeGlowMaterials: THREE.MeshStandardMaterial[] = [];
  let frontSteerGroupL = new THREE.Object3D();
  let frontSteerGroupR = new THREE.Object3D();

  const wheelConfigs = [
    { name: 'FL', x: 0.84, z: 1.72, width: 0.34, isFront: true, side: 1 },
    { name: 'FR', x: -0.84, z: 1.72, width: 0.34, isFront: true, side: -1 },
    { name: 'RL', x: 0.85, z: -1.85, width: 0.42, isFront: false, side: 1 },
    { name: 'RR', x: -0.85, z: -1.85, width: 0.42, isFront: false, side: -1 },
  ];

  for (const wc of wheelConfigs) {
    const tireRadius = 0.36;
    const rimRadius = 0.235;
    const halfW = wc.width * 0.5;

    // Upright / Steering Pivot Group (stationary vertically, pivots Y for steering on front wheels)
    const uprightGroup = new THREE.Group();
    uprightGroup.name = `Upright_${wc.name}`;
    uprightGroup.position.set(wc.x, tireRadius, wc.z);
    if (wc.name === 'FL') frontSteerGroupL = uprightGroup;
    if (wc.name === 'FR') frontSteerGroupR = uprightGroup;

    // Non-spinning Glowing Carbon-Ceramic Brake Disc & Caliper inside the wheel hub
    const brakeGlowMat = new THREE.MeshStandardMaterial({
      name: `Mat_BrakeGlow_${wc.name}`,
      color: new THREE.Color('#2a120c'),
      metalness: 0.65,
      roughness: 0.32,
      emissive: new THREE.Color('#ff2f00'),
      emissiveIntensity: 0.25,
    });
    brakeGlowMaterials.push(brakeGlowMat);

    const brakeRotor = new THREE.Mesh(
      new THREE.CylinderGeometry(0.185, 0.185, 0.036, 28),
      brakeGlowMat
    );
    brakeRotor.rotation.z = Math.PI / 2;
    brakeRotor.position.set(-wc.side * 0.04, 0, 0);
    brakeRotor.name = `BrakeDisc_${wc.name}`;
    uprightGroup.add(brakeRotor);

    // F1 Red Brembo Brake Caliper
    const caliper = new THREE.Mesh(
      new THREE.BoxGeometry(0.065, 0.14, 0.095),
      matF1Red
    );
    caliper.position.set(-wc.side * 0.04, 0.02, -0.13);
    uprightGroup.add(caliper);

    // Front Over-Wheel Aero Deflector Winglet (FIA 2022-2026 signature wheel wake brow)
    if (wc.isFront) {
      const browCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-wc.side * (halfW + 0.02), 0.12, 0.24),
        new THREE.Vector3(-wc.side * (halfW * 0.45), 0.37, 0.18),
        new THREE.Vector3(-wc.side * 0.02, 0.415, 0.02),
        new THREE.Vector3(wc.side * 0.06, 0.39, -0.16),
      ]);
      const browMesh = new THREE.Mesh(
        new THREE.TubeGeometry(browCurve, 18, 0.022, 8, false),
        matCarbonBody
      );
      browMesh.scale.set(1, 0.35, 1.8);
      uprightGroup.add(browMesh);
    }

    // Spinning Wheel Group (rotates around X axis as the car drives)
    const wheelSpinGroup = new THREE.Group();
    wheelSpinGroup.name = `Wheel_${wc.name}`;

    // LatheGeometry for authentic rounded-shoulder Pirelli P-Zero Slick Tire
    const shoulder = 0.048;
    const lathePts: THREE.Vector2[] = [
      new THREE.Vector2(rimRadius, -halfW + 0.015),
      new THREE.Vector2(tireRadius - 0.03, -halfW),
      new THREE.Vector2(tireRadius - 0.006, -halfW + shoulder * 0.6),
      new THREE.Vector2(tireRadius, -halfW + shoulder),
      new THREE.Vector2(tireRadius, halfW - shoulder),
      new THREE.Vector2(tireRadius - 0.006, halfW - shoulder * 0.6),
      new THREE.Vector2(tireRadius - 0.03, halfW),
      new THREE.Vector2(rimRadius, halfW - 0.015),
      new THREE.Vector2(rimRadius, -halfW + 0.015),
    ];
    const tireGeo = new THREE.LatheGeometry(lathePts, 40);
    tireGeo.rotateZ(-Math.PI / 2);
    const tireMesh = new THREE.Mesh(tireGeo, matTireRubber);
    tireMesh.castShadow = true;
    tireMesh.receiveShadow = true;
    wheelSpinGroup.add(tireMesh);

    // Pirelli P-Zero Red Soft Compound Sidewall Ring (Outer & Inner face)
    const ringTrack = new THREE.Mesh(
      new THREE.RingGeometry(rimRadius + 0.034, rimRadius + 0.056, 40),
      matF1RedGlow
    );
    ringTrack.rotation.y = (wc.side * Math.PI) / 2;
    ringTrack.position.x = wc.side * (halfW - 0.002);
    wheelSpinGroup.add(ringTrack);

    // 18-Inch Carbon Aero Wheel Cover + Rotational Telemetry Fin
    const aeroCover = new THREE.Mesh(
      new THREE.CylinderGeometry(rimRadius + 0.005, rimRadius - 0.02, 0.025, 36),
      matWheelCover
    );
    aeroCover.rotation.z = Math.PI / 2;
    aeroCover.position.x = wc.side * (halfW - 0.022);
    wheelSpinGroup.add(aeroCover);

    // High-contrast Red & White Aero Cover Rotational Fin (makes wheel spin visually unmistakable!)
    const spinStripeRed = new THREE.Mesh(
      new THREE.BoxGeometry(0.032, rimRadius * 1.65, 0.032),
      matF1Red
    );
    spinStripeRed.position.x = wc.side * (halfW - 0.012);
    wheelSpinGroup.add(spinStripeRed);

    const spinStripeWhite = new THREE.Mesh(
      new THREE.BoxGeometry(0.032, 0.024, rimRadius * 1.55),
      matWhiteAccent
    );
    spinStripeWhite.position.x = wc.side * (halfW - 0.012);
    wheelSpinGroup.add(spinStripeWhite);

    // Center Wheel Lock Nut (Anodized F1 Red)
    const centerLock = new THREE.Mesh(
      new THREE.CylinderGeometry(0.042, 0.048, 0.045, 16),
      matF1Red
    );
    centerLock.rotation.z = Math.PI / 2;
    centerLock.position.x = wc.side * (halfW - 0.006);
    wheelSpinGroup.add(centerLock);

    wheels.push(wheelSpinGroup);
    uprightGroup.add(wheelSpinGroup);
    root.add(uprightGroup);
  }

  // ============================================================================
  // 10. 3D AERODYNAMIC CFD STREAMLINE VORTEX RIBBONS (Activated during Aero/Speed)
  // ============================================================================
  const aeroLinesGroup = new THREE.Group();
  aeroLinesGroup.name = 'Aero_CFD_Streamlines';
  const aeroLineMaterials: THREE.MeshBasicMaterial[] = [];

  for (const side of [-1, 1] as const) {
    const streamPaths = [
      // Streamline 1: Front wing tip vortex -> over front wheel -> sidepod undercut -> rear diffuser
      [
        new THREE.Vector3(side * 0.72, 0.14, 2.75),
        new THREE.Vector3(side * 0.88, 0.28, 2.15),
        new THREE.Vector3(side * 0.96, 0.56, 1.55),
        new THREE.Vector3(side * 0.88, 0.34, 0.55),
        new THREE.Vector3(side * 0.84, 0.22, -0.45),
        new THREE.Vector3(side * 0.62, 0.24, -1.55),
        new THREE.Vector3(side * 0.52, 0.44, -2.75),
      ],
      // Streamline 2: Nose cone -> Halo -> Sidepod downwash waterslide -> Beam wing
      [
        new THREE.Vector3(side * 0.14, 0.24, 2.70),
        new THREE.Vector3(side * 0.25, 0.58, 1.35),
        new THREE.Vector3(side * 0.45, 0.72, 0.35),
        new THREE.Vector3(side * 0.58, 0.62, -0.55),
        new THREE.Vector3(side * 0.38, 0.48, -1.65),
        new THREE.Vector3(side * 0.34, 0.88, -2.75),
      ],
      // Streamline 3: Centerline cockpit / airbox -> Shark fin -> DRS Rear Wing wake
      [
        new THREE.Vector3(side * 0.05, 0.26, 2.72),
        new THREE.Vector3(side * 0.10, 0.68, 0.95),
        new THREE.Vector3(side * 0.14, 0.98, -0.35),
        new THREE.Vector3(side * 0.12, 0.92, -1.55),
        new THREE.Vector3(side * 0.22, 1.04, -2.85),
      ],
    ];

    streamPaths.forEach((pts, idx) => {
      const curve = new THREE.CatmullRomCurve3(pts);
      const mat = new THREE.MeshBasicMaterial({
        color: idx === 1 ? new THREE.Color('#ffffff') : new THREE.Color('#E10600'),
        transparent: true,
        opacity: 0.0,
        depthWrite: false,
      });
      aeroLineMaterials.push(mat);
      const ribbon = new THREE.Mesh(
        new THREE.TubeGeometry(curve, 52, idx === 1 ? 0.005 : 0.007, 6, false),
        mat
      );
      aeroLinesGroup.add(ribbon);
    });
  }
  root.add(aeroLinesGroup);

  return {
    root,
    wheels,
    frontSteerGroupL,
    frontSteerGroupR,
    drsFlapPivot,
    steeringWheel,
    helmetGroup,
    brakeGlowMaterials,
    exhaustGlowMaterial: matExhaustGlow,
    rainLightMaterial: matRainLight,
    engineThermalMaterial: matEngineThermal,
    aeroLinesGroup,
    aeroLineMaterials,
    chassisBodyMaterials: [matCarbonBody, matCarbonWeave, matF1Red],
  };
}

/**
 * Generates a subtle procedural carbon-fiber weave bump/roughness CanvasTexture
 * to give the chassis and wings realistic clear-coat carbon sheen under studio lights.
 */
export function createCarbonWeaveTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 64;
  canvas.height = 64;
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#18191e';
    ctx.fillRect(0, 0, 64, 64);
    for (let y = 0; y < 64; y += 4) {
      for (let x = 0; x < 64; x += 4) {
        const diag = ((x + y) / 4) % 2 === 0;
        ctx.fillStyle = diag ? '#262830' : '#101115';
        ctx.fillRect(x, y, 3, 3);
      }
    }
  }
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(48, 48);
  return tex;
}

/**
 * Binds a loaded GLTF scene (from `./f1_car.glb`) into the interactive F1CarRig structure,
 * restoring dynamic emissive materials, shadows, carbon weave textures, and 3D CFD aero ribbons.
 */
export function bindLoadedGLBToF1CarRig(gltfRoot: THREE.Group): F1CarRig {
  const fallback = buildFormula1CarScene();
  const carbonTex = createCarbonWeaveTexture();

  const wheels: THREE.Object3D[] = [];
  const brakeGlowMaterials: THREE.MeshStandardMaterial[] = [];
  const chassisBodyMaterials: THREE.MeshStandardMaterial[] = [];

  let frontSteerGroupL: THREE.Object3D | null = null;
  let frontSteerGroupR: THREE.Object3D | null = null;
  let drsFlapPivot: THREE.Object3D | null = null;
  let steeringWheel: THREE.Object3D | null = null;
  let helmetGroup: THREE.Object3D | null = null;
  let exhaustGlowMaterial: THREE.MeshStandardMaterial | null = null;
  let rainLightMaterial: THREE.MeshStandardMaterial | null = null;
  let engineThermalMaterial: THREE.MeshStandardMaterial | null = null;

  gltfRoot.traverse((obj) => {
    if (obj.name === 'Upright_FL') frontSteerGroupL = obj;
    if (obj.name === 'Upright_FR') frontSteerGroupR = obj;
    if (obj.name === 'DRS_Flap_Pivot') drsFlapPivot = obj;
    if (obj.name === 'Steering_Wheel') steeringWheel = obj;
    if (obj.name === 'Driver_Helmet') helmetGroup = obj;
    if (
      obj.name === 'Wheel_FL' ||
      obj.name === 'Wheel_FR' ||
      obj.name === 'Wheel_RL' ||
      obj.name === 'Wheel_RR'
    ) {
      wheels.push(obj);
    }

    if ((obj as THREE.Mesh).isMesh) {
      const mesh = obj as THREE.Mesh;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mat) {
        if (mat.name?.includes('Carbon')) {
          mat.roughnessMap = carbonTex;
          mat.bumpMap = carbonTex;
          mat.bumpScale = 0.0025;
          mat.needsUpdate = true;
          chassisBodyMaterials.push(mat);
        }
        if (mat.name?.includes('Crimson')) {
          chassisBodyMaterials.push(mat);
        }
        if (mesh.name.startsWith('BrakeDisc_') || mat.name?.startsWith('Mat_BrakeGlow')) {
          const cloneMat = mat.clone();
          cloneMat.emissive = new THREE.Color('#ff2f00');
          cloneMat.emissiveIntensity = 0.25;
          mesh.material = cloneMat;
          brakeGlowMaterials.push(cloneMat);
        }
        if (mesh.name === 'Exhaust_Thermal_Core' || mat.name === 'Mat_Exhaust_Plume_Glow') {
          mat.emissive = new THREE.Color('#ff3300');
          mat.emissiveIntensity = 0.7;
          exhaustGlowMaterial = mat;
        }
        if (mesh.name === 'FIA_Rain_Light_LED' || mat.name === 'Mat_FIA_Rain_Light') {
          mat.emissive = new THREE.Color('#ff0a00');
          mat.emissiveIntensity = 2.2;
          rainLightMaterial = mat;
        }
        if (mat.name === 'Mat_Engine_Thermal_Core') {
          mat.emissive = new THREE.Color('#ff2a00');
          mat.emissiveIntensity = 0.15;
          engineThermalMaterial = mat;
        }
      }
    }
  });

  // Attach the 3D CFD Aero Streamlines group to the loaded GLB root
  gltfRoot.add(fallback.aeroLinesGroup);

  return {
    root: gltfRoot,
    wheels: wheels.length === 4 ? wheels : fallback.wheels,
    frontSteerGroupL: frontSteerGroupL || fallback.frontSteerGroupL,
    frontSteerGroupR: frontSteerGroupR || fallback.frontSteerGroupR,
    drsFlapPivot: drsFlapPivot || fallback.drsFlapPivot,
    steeringWheel: steeringWheel || fallback.steeringWheel,
    helmetGroup: helmetGroup || fallback.helmetGroup,
    brakeGlowMaterials:
      brakeGlowMaterials.length > 0 ? brakeGlowMaterials : fallback.brakeGlowMaterials,
    exhaustGlowMaterial: exhaustGlowMaterial || fallback.exhaustGlowMaterial,
    rainLightMaterial: rainLightMaterial || fallback.rainLightMaterial,
    engineThermalMaterial: engineThermalMaterial || fallback.engineThermalMaterial,
    aeroLinesGroup: fallback.aeroLinesGroup,
    aeroLineMaterials: fallback.aeroLineMaterials,
    chassisBodyMaterials:
      chassisBodyMaterials.length > 0 ? chassisBodyMaterials : fallback.chassisBodyMaterials,
  };
}

