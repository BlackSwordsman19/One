// Procedural F1 car -> optimized GLB (named nodes for runtime animation)
// Car faces +Z, up is +Y, units = metres, origin on the ground at mid-wheelbase.
// Usage: node tools/build-car.mjs public/models
import * as THREE from 'three';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { mergeGeometries, mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import fs from 'fs';

globalThis.FileReader = class {
  readAsArrayBuffer(blob) { blob.arrayBuffer().then((b) => { this.result = b; this.onloadend && this.onloadend(); }); }
  readAsDataURL(blob) {
    blob.arrayBuffer().then((b) => {
      this.result = 'data:' + (blob.type || 'application/octet-stream') + ';base64,' + Buffer.from(b).toString('base64');
      this.onloadend && this.onloadend();
    });
  }
};

const { Vector3: V3, Color, Group, Mesh, Shape, ExtrudeGeometry, BufferGeometry, Float32BufferAttribute } = THREE;
const PI = Math.PI;

/* ---------------------------------------------------------------- materials */
const mat = (o) => new THREE.MeshPhysicalMaterial(o);
const M = {
  livery: mat({ name: 'PaintLivery', color: 0xffffff, roughness: 0.3, metalness: 0.3, clearcoat: 1, clearcoatRoughness: 0.035, vertexColors: true }),
  red: mat({ name: 'PaintRed', color: 0xe10600, roughness: 0.3, metalness: 0.3, clearcoat: 1, clearcoatRoughness: 0.035 }),
  white: mat({ name: 'PaintWhite', color: 0xf2f2f2, roughness: 0.28, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.05 }),
  carbon: mat({ name: 'Carbon', color: 0x0d0d0e, roughness: 0.38, metalness: 0.55, clearcoat: 0.6, clearcoatRoughness: 0.2 }),
  matte: mat({ name: 'BlackMatte', color: 0x050505, roughness: 0.7, metalness: 0.2, side: THREE.DoubleSide }),
  tyre: mat({ name: 'Tyre', color: 0x0b0b0b, roughness: 0.88, metalness: 0 }),
  band: mat({ name: 'TyreBand', color: 0xf2f2f2, roughness: 0.6, metalness: 0, side: THREE.DoubleSide }),
  rim: mat({ name: 'RimMetal', color: 0x4a4d52, roughness: 0.28, metalness: 1, side: THREE.DoubleSide }),
  hub: mat({ name: 'HubGold', color: 0xc9a24a, roughness: 0.25, metalness: 1 }),
  brake: mat({ name: 'BrakeGlow', color: 0x2a2a2c, roughness: 0.5, metalness: 0.9, emissive: 0xff4a12, emissiveIntensity: 1, side: THREE.DoubleSide }),
  blur: mat({ name: 'WheelBlur', color: 0x0a0a0b, roughness: 0.9, metalness: 0, transparent: true, opacity: 0.0 }),
  helmet: mat({ name: 'Helmet', color: 0xf5f5f5, roughness: 0.2, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.03 }),
  visor: mat({ name: 'Visor', color: 0x020204, roughness: 0.03, metalness: 1, clearcoat: 1, clearcoatRoughness: 0 }),
  tail: mat({ name: 'TailLight', color: 0x300000, roughness: 0.4, metalness: 0, emissive: 0xff0a00, emissiveIntensity: 1 }),
  exhaust: mat({ name: 'Exhaust', color: 0x15110e, roughness: 0.35, metalness: 1, side: THREE.DoubleSide }),
  exglow: mat({ name: 'ExhaustGlow', color: 0x180800, roughness: 0.5, metalness: 0, emissive: 0xff5a14, emissiveIntensity: 1, side: THREE.DoubleSide }),
};

/* ----------------------------------------------------------------- builder */
const buckets = new Map();
function add(group, geo, material) {
  const key = group.uuid + '|' + material.uuid;
  if (!buckets.has(key)) buckets.set(key, { group, material, list: [] });
  const g = geo.index ? geo.toNonIndexed() : geo.clone();
  g.deleteAttribute('uv');
  if (g.attributes.uv1) g.deleteAttribute('uv1');
  if (!g.attributes.normal) g.computeVertexNormals();
  buckets.get(key).list.push(g);
}
function flush() {
  for (const { group, material, list } of buckets.values()) {
    let g = mergeGeometries(list, false);
    g = mergeVertices(g, 1e-4);
    const m = new Mesh(g, material);
    m.name = group.name + '_' + material.name;
    group.add(m);
  }
  buckets.clear();
}

/* ----------------------------------------------------------- geometry kit */
function mirrorGeo(src) {
  const g = src.index ? src.toNonIndexed() : src.clone();
  g.scale(-1, 1, 1);
  for (const name of Object.keys(g.attributes)) {
    const a = g.attributes[name];
    const s = a.itemSize;
    for (let i = 0; i < a.count; i += 3) {
      for (let k = 0; k < s; k++) {
        const t = a.array[(i + 1) * s + k];
        a.array[(i + 1) * s + k] = a.array[(i + 2) * s + k];
        a.array[(i + 2) * s + k] = t;
      }
    }
  }
  return g;
}
const both = (group, geo, material) => { add(group, geo, material); add(group, mirrorGeo(geo), material); };

function catmull(p0, p1, p2, p3, t) {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * (2 * p1 + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3);
}
// sections: {z, yb, yt, w, x?, n?}; ordered front (+z) to rear (-z)
function loft(sections, { rings = 70, seg = 40, color = null } = {}) {
  const keys = ['z', 'x', 'yb', 'yt', 'w', 'n'];
  const S = sections.map((s) => ({ z: s.z, x: s.x ?? 0, yb: s.yb, yt: s.yt, w: s.w, n: s.n ?? 2.6 }));
  const N = S.length;
  const samples = [];
  for (let r = 0; r < rings; r++) {
    const f = (r / (rings - 1)) * (N - 1);
    const i = Math.min(N - 2, Math.floor(f));
    const t = f - i;
    const o = {};
    for (const k of keys) {
      const p0 = S[Math.max(0, i - 1)][k], p1 = S[i][k], p2 = S[i + 1][k], p3 = S[Math.min(N - 1, i + 2)][k];
      o[k] = catmull(p0, p1, p2, p3, t);
    }
    o.w = Math.max(o.w, 0.004);
    o.yt = Math.max(o.yt, o.yb + 0.008);
    samples.push(o);
  }
  const pos = [], col = [];
  for (const s of samples) {
    const h = (s.yt - s.yb) / 2, yc = (s.yt + s.yb) / 2;
    for (let k = 0; k < seg; k++) {
      const th = (k / seg) * PI * 2;
      const c = Math.cos(th), sn = Math.sin(th);
      const e = 2 / s.n;
      const x = s.x + s.w * Math.sign(c) * Math.pow(Math.abs(c), e);
      const y = yc + h * Math.sign(sn) * Math.pow(Math.abs(sn), e);
      pos.push(x, y, s.z);
      if (color) { const cc = color(x, y, s.z, (y - s.yb) / (s.yt - s.yb)); col.push(cc.r, cc.g, cc.b); }
    }
  }
  const idx = [];
  for (let r = 0; r < rings - 1; r++) {
    for (let k = 0; k < seg; k++) {
      const k2 = (k + 1) % seg;
      const a = r * seg + k, b = r * seg + k2, c = (r + 1) * seg + k, d = (r + 1) * seg + k2;
      idx.push(a, c, b, b, c, d);
    }
  }
  const capVertex = (ring) => {
    const s = samples[ring];
    const ci = pos.length / 3;
    pos.push(s.x, (s.yt + s.yb) / 2, s.z);
    if (color) { const cc = color(s.x, (s.yt + s.yb) / 2, s.z, 0.5); col.push(cc.r, cc.g, cc.b); }
    return ci;
  };
  const cf = capVertex(0), cr = capVertex(rings - 1);
  for (let k = 0; k < seg; k++) {
    const k2 = (k + 1) % seg;
    idx.push(cf, k, k2);
    idx.push(cr, (rings - 1) * seg + k2, (rings - 1) * seg + k);
  }
  const g = new BufferGeometry();
  g.setAttribute('position', new Float32BufferAttribute(pos, 3));
  if (color) g.setAttribute('color', new Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  return g;
}

// Extruded outline in the Z/Y plane (pts = [z,y]), thickness along X, centred on x
function plate(pts, thick, x = 0) {
  const sh = new Shape();
  pts.forEach(([z, y], i) => (i ? sh.lineTo(z, y) : sh.moveTo(z, y)));
  const g = new ExtrudeGeometry(sh, { depth: thick, bevelEnabled: false, curveSegments: 1 });
  g.rotateY(-PI / 2);
  g.translate(x + thick / 2, 0, 0);
  return g;
}
// Inverted aerofoil element, span along X, LE toward +Z
function airfoil({ span, chord, t = 0.12, camber = 0.07, seg = 22, flip = -1 }) {
  const up = [], lo = [];
  for (let i = 0; i <= seg; i++) {
    const u = (1 - Math.cos((PI * i) / seg)) / 2;
    const yt = 5 * t * (0.2969 * Math.sqrt(u) - 0.126 * u - 0.3516 * u * u + 0.2843 * u ** 3 - 0.1036 * u ** 4) * chord;
    const yc = flip * camber * chord * 4 * u * (1 - u);
    up.push([(0.5 - u) * chord, yc + yt]);
    lo.push([(0.5 - u) * chord, yc - yt]);
  }
  const sh = new Shape();
  up.forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  for (let i = seg - 1; i >= 1; i--) sh.lineTo(lo[i][0], lo[i][1]);
  const g = new ExtrudeGeometry(sh, { depth: span, bevelEnabled: false, curveSegments: 1 });
  g.rotateY(-PI / 2);
  g.translate(span / 2, 0, 0);
  return g;
}
function rod(p1, p2, r = 0.012, seg = 8) {
  const a = new V3(...p1), b = new V3(...p2);
  const len = a.distanceTo(b);
  const g = new THREE.CylinderGeometry(r, r, len, seg, 1);
  g.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new V3(0, 1, 0), b.clone().sub(a).normalize()));
  const m = a.clone().add(b).multiplyScalar(0.5);
  g.translate(m.x, m.y, m.z);
  return g;
}
function tube(points, r, segs = 40) {
  const curve = new THREE.CatmullRomCurve3(points.map((p) => new V3(...p)));
  return new THREE.TubeGeometry(curve, segs, r, 8, false);
}
const C = (hex) => new Color(hex);
const RED = C(0xe10600), CARB = C(0x0c0c0d), WHITE = C(0xf0f0f0);

/* ------------------------------------------------------------------- build */
const root = new Group(); root.name = 'F1Car';
const chassis = new Group(); chassis.name = 'chassis'; root.add(chassis);

// ---- main body / monocoque / engine cover
const bodyColor = (x, y, z, fy) => {
  if (z > 1.93) return WHITE;
  if (fy < 0.17) return CARB;
  if (fy > 0.9 && Math.abs(x) < 0.03 && z < 1.9 && z > -2.3) return WHITE;
  return RED;
};
add(chassis, loft([
  { z: 2.38, yb: 0.17, yt: 0.265, w: 0.045, n: 2.4 },
  { z: 2.1, yb: 0.15, yt: 0.285, w: 0.085, n: 2.5 },
  { z: 1.6, yb: 0.12, yt: 0.33, w: 0.15, n: 2.6 },
  { z: 1.0, yb: 0.1, yt: 0.41, w: 0.235, n: 2.8 },
  { z: 0.45, yb: 0.075, yt: 0.52, w: 0.3, n: 3.0 },
  { z: 0.0, yb: 0.06, yt: 0.58, w: 0.325, n: 3.1 },
  { z: -0.5, yb: 0.06, yt: 0.64, w: 0.31, n: 3.0 },
  { z: -1.0, yb: 0.07, yt: 0.72, w: 0.26, n: 2.8 },
  { z: -1.55, yb: 0.09, yt: 0.62, w: 0.17, n: 2.6 },
  { z: -2.05, yb: 0.12, yt: 0.5, w: 0.1, n: 2.4 },
  { z: -2.5, yb: 0.2, yt: 0.4, w: 0.065, n: 2.2 },
], { rings: 90, seg: 44, color: bodyColor }), M.livery);

// ---- sidepods
const podColor = (x, y, z, fy) => {
  if (fy < 0.24) return CARB;
  if (z > 0.55) return C(0x1a1a1a);
  if (z < 0.22 && z > 0.1 && fy > 0.4) return WHITE;
  return RED;
};
const pod = loft([
  { z: 0.78, x: 0.46, yb: 0.12, yt: 0.31, w: 0.1, n: 2.6 },
  { z: 0.45, x: 0.47, yb: 0.1, yt: 0.4, w: 0.18, n: 3.0 },
  { z: -0.15, x: 0.46, yb: 0.09, yt: 0.45, w: 0.245, n: 3.0 },
  { z: -0.85, x: 0.42, yb: 0.09, yt: 0.4, w: 0.23, n: 2.8 },
  { z: -1.45, x: 0.33, yb: 0.1, yt: 0.31, w: 0.16, n: 2.6 },
  { z: -2.0, x: 0.2, yb: 0.12, yt: 0.24, w: 0.08, n: 2.3 },
], { rings: 70, seg: 36, color: podColor });
both(chassis, pod, M.livery);
// sidepod inlets (dark mouths)
{
  const g = new THREE.CircleGeometry(1, 28); g.scale(0.085, 0.085, 1); g.translate(0.46, 0.215, 0.785);
  both(chassis, g, M.matte);
}
// ---- cockpit tub, headrest & helmet
add(chassis, loft([
  { z: 0.5, yb: 0.52, yt: 0.585, w: 0.1, n: 3.2 },
  { z: 0.15, yb: 0.52, yt: 0.62, w: 0.19, n: 3.2 },
  { z: -0.3, yb: 0.52, yt: 0.64, w: 0.18, n: 3.2 },
  { z: -0.55, yb: 0.52, yt: 0.61, w: 0.1, n: 3.0 },
], { rings: 24, seg: 24 }), M.carbon);
{
  const h = new THREE.SphereGeometry(0.135, 32, 22); h.scale(1, 1.06, 1.18); h.translate(0, 0.66, -0.08);
  add(chassis, h, M.helmet);
  const v = new THREE.SphereGeometry(0.139, 28, 14, PI / 2 - 0.95, 1.9, PI / 2 - 0.42, 0.62); v.scale(1, 1.06, 1.18); v.translate(0, 0.66, -0.08);
  add(chassis, v, M.visor);
  const stripe = new THREE.TorusGeometry(0.1, 0.012, 6, 28, PI); stripe.rotateY(PI / 2); stripe.scale(1, 1.2, 1.2); stripe.translate(0, 0.7, -0.08);
  add(chassis, stripe, M.red);
}
// ---- airbox + shark fin
const airboxColor = (x, y, z, fy) => (z < -0.7 && fy > 0.2 ? RED : fy < 0.3 ? CARB : RED);
add(chassis, loft([
  { z: -0.2, yb: 0.56, yt: 0.86, w: 0.115, n: 2.5 },
  { z: -0.5, yb: 0.58, yt: 0.99, w: 0.14, n: 2.5 },
  { z: -0.95, yb: 0.62, yt: 0.9, w: 0.115, n: 2.6 },
  { z: -1.6, yb: 0.6, yt: 0.72, w: 0.02, n: 2.2 },
  { z: -2.2, yb: 0.5, yt: 0.56, w: 0.012, n: 2.0 },
], { rings: 40, seg: 28, color: airboxColor }), M.livery);
{
  const g = new THREE.CircleGeometry(1, 24); g.scale(0.095, 0.115, 1); g.translate(0, 0.92, -0.196);
  add(chassis, g, M.matte);
}
// ---- halo
{
  const arcL = tube([[-0.2, 0.6, -0.28], [-0.235, 0.74, -0.04], [-0.16, 0.82, 0.3], [0, 0.82, 0.5]], 0.019, 40);
  add(chassis, arcL, M.carbon); add(chassis, mirrorGeo(arcL), M.carbon);
  add(chassis, tube([[0, 0.82, 0.5], [0, 0.68, 0.56], [0, 0.56, 0.6]], 0.024, 16), M.carbon);
}
// ---- mirrors
for (const s of [1, -1]) {
  add(chassis, rod([s * 0.3, 0.6, 0.44], [s * 0.42, 0.67, 0.44], 0.008), M.carbon);
  const m = new THREE.BoxGeometry(0.1, 0.055, 0.045); m.translate(s * 0.47, 0.675, 0.44);
  add(chassis, m, M.carbon);
  const r = new THREE.BoxGeometry(0.1, 0.012, 0.047); r.translate(s * 0.47, 0.705, 0.44); add(chassis, r, M.red);
}

// ---- floor + diffuser + bargeboards
{
  const poly = [[0, 1.5], [0.42, 1.46], [0.6, 1.15], [0.75, 0.6], [0.8, 0.0], [0.79, -0.7], [0.62, -1.3], [0.52, -1.7], [0.44, -2.1]];
  const pts = [...poly.map(([x, z]) => [x, -z]), ...poly.slice().reverse().map(([x, z]) => [-x, -z])];
  const sh = new Shape(); pts.forEach(([x, y], i) => (i ? sh.lineTo(x, y) : sh.moveTo(x, y)));
  const fl = new ExtrudeGeometry(sh, { depth: 0.03, bevelEnabled: false, curveSegments: 1 });
  fl.rotateX(-PI / 2); fl.translate(0, 0.045, 0);
  add(chassis, fl, M.carbon);
  for (const s of [1, -1]) {
    const e = new THREE.BoxGeometry(0.012, 0.022, 1.6); e.translate(s * 0.795, 0.095, -0.15); add(chassis, e, M.red);
  }
  // diffuser ramp: pivot at z=-1.55
  const dsh = new Shape();
  dsh.moveTo(-0.5, 0); dsh.lineTo(0.5, 0); dsh.lineTo(0.4, 0.95); dsh.lineTo(-0.4, 0.95);
  const dg = new ExtrudeGeometry(dsh, { depth: 0.02, bevelEnabled: false, curveSegments: 1 });
  dg.rotateX(-PI / 2); // shape y -> -z, extrude -> +y
  dg.rotateX(0.2);
  dg.translate(0, 0.05, -1.55);
  add(chassis, dg, M.carbon);
  for (const x of [-0.3, -0.12, 0.12, 0.3]) {
    const f = plate([[-1.55, 0.04], [-2.45, 0.2], [-2.45, 0.05]], 0.012, x);
    add(chassis, f, M.matte);
  }
  // bargeboards
  for (const x of [0.36, 0.5, 0.64]) {
    const k = (x - 0.36) * 0.4;
    const bb = plate([[1.05, 0.08], [0.85, 0.36 - k], [0.5, 0.38 - k], [0.42, 0.08]], 0.012, x);
    both(chassis, bb, x === 0.5 ? M.white : M.carbon);
  }
}

// ---- front wing
{
  const zc = 2.62;
  const main = airfoil({ span: 1.86, chord: 0.38, t: 0.1, camber: 0.08 });
  main.rotateX(0.08); main.translate(0, 0.085, zc); add(chassis, main, M.carbon);
  const f1 = airfoil({ span: 1.78, chord: 0.27, t: 0.09, camber: 0.09 }); f1.rotateX(0.2); f1.translate(0, 0.165, zc - 0.07); add(chassis, f1, M.white);
  const f2 = airfoil({ span: 1.66, chord: 0.23, t: 0.09, camber: 0.09 }); f2.rotateX(0.3); f2.translate(0, 0.235, zc - 0.1); add(chassis, f2, M.carbon);
  const f3 = airfoil({ span: 1.5, chord: 0.2, t: 0.09, camber: 0.08 }); f3.rotateX(0.4); f3.translate(0, 0.295, zc - 0.13); add(chassis, f3, M.red);
  const ep = plate([[2.95, 0.045], [2.95, 0.2], [2.74, 0.36], [2.3, 0.36], [2.3, 0.13], [2.45, 0.045]], 0.022, 0.935);
  both(chassis, ep, M.red);
  const foot = plate([[2.9, 0.04], [2.9, 0.07], [2.35, 0.07], [2.35, 0.04]], 0.1, 0.9);
  both(chassis, foot, M.carbon);
  for (const s of [1, -1]) {
    const py = plate([[2.38, 0.17], [2.7, 0.1], [2.5, 0.1], [2.15, 0.15]], 0.016, s * 0.065 - 0.008);
    add(chassis, py, M.carbon);
  }
}

// ---- rear wing (DRS flap is its own animated group)
{
  const zr = -2.38;
  const mainP = airfoil({ span: 0.96, chord: 0.3, t: 0.1, camber: 0.1 }); mainP.rotateX(0.32); mainP.translate(0, 0.8, zr); add(chassis, mainP, M.carbon);
  const beam = airfoil({ span: 0.74, chord: 0.2, t: 0.1, camber: 0.09 }); beam.rotateX(0.18); beam.translate(0, 0.36, zr - 0.04); add(chassis, beam, M.carbon);
  const ep = plate([[-2.14, 0.5], [-2.64, 0.5], [-2.66, 1.13], [-2.3, 1.15], [-2.16, 0.98]], 0.02, 0.485);
  both(chassis, ep, M.red);
  const stripe = plate([[-2.3, 1.03], [-2.62, 1.03], [-2.63, 1.09], [-2.3, 1.1]], 0.024, 0.485);
  both(chassis, stripe, M.white);
  add(chassis, plate([[-2.1, 0.45], [-2.28, 0.45], [-2.45, 0.8], [-2.33, 0.8]], 0.03, -0.015), M.carbon);
  const drs = new Group(); drs.name = 'drsFlap'; drs.position.set(0, 1.0, zr + 0.02); chassis.add(drs);
  const flap = airfoil({ span: 0.95, chord: 0.24, t: 0.085, camber: 0.1 }); flap.translate(0, 0, -0.12); flap.rotateX(0.3);
  add(drs, flap, M.red);
  const flapStripe = airfoil({ span: 0.2, chord: 0.243, t: 0.088, camber: 0.1 }); flapStripe.translate(0, 0, -0.12); flapStripe.rotateX(0.3);
  add(drs, flapStripe, M.white);
  const tl = new THREE.BoxGeometry(0.09, 0.12, 0.02); tl.translate(0, 0.42, -2.52);
  add(chassis, tl, M.tail);
  const ex = new THREE.CylinderGeometry(0.04, 0.045, 0.18, 20, 1, true); ex.rotateX(PI / 2); ex.translate(0, 0.54, -2.5);
  add(chassis, ex, M.exhaust);
  const exg = new THREE.CircleGeometry(0.036, 20); exg.rotateY(PI); exg.translate(0, 0.54, -2.595);
  add(chassis, exg, M.exglow);
}

// ---- wheels + suspension
const WHEELS = [
  { id: 'FL', x: 0.79, z: 1.75, front: true, side: 1 },
  { id: 'FR', x: -0.79, z: 1.75, front: true, side: -1 },
  { id: 'RL', x: 0.8, z: -1.85, front: false, side: 1 },
  { id: 'RR', x: -0.8, z: -1.85, front: false, side: -1 },
];
for (const w of WHEELS) {
  const R = w.front ? 0.36 : 0.365, W = w.front ? 0.305 : 0.405, hw = W / 2;
  const steer = new Group(); steer.name = 'steer_' + w.id; steer.position.set(w.x, R, w.z); root.add(steer);
  const spin = new Group(); spin.name = 'spin_' + w.id; steer.add(spin);
  const inner = new Group(); inner.name = 'wheel_' + w.id; inner.rotation.y = w.side > 0 ? 0 : PI; spin.add(inner);

  const V = (r, y) => new THREE.Vector2(r, y);
  const tp = [V(0.215, -hw * 0.88), V(0.235, -hw * 0.97), V(0.27, -hw), V(R - 0.05, -hw * 0.99), V(R - 0.022, -hw * 0.93), V(R - 0.006, -hw * 0.75), V(R, -hw * 0.5),
    V(R, hw * 0.5), V(R - 0.006, hw * 0.75), V(R - 0.022, hw * 0.93), V(R - 0.05, hw * 0.99), V(0.27, hw), V(0.235, hw * 0.97), V(0.215, hw * 0.88)];
  const tyre = new THREE.LatheGeometry(tp, 64); tyre.rotateZ(-PI / 2);
  add(inner, tyre, M.tyre);
  const band = new THREE.LatheGeometry([V(0.31, hw + 0.0008), V(0.285, hw + 0.0008)], 64); band.rotateZ(-PI / 2); add(inner, band, M.band);
  const band2 = new THREE.LatheGeometry([V(0.325, hw * 0.995), V(0.322, hw * 0.995)], 64); band2.rotateZ(-PI / 2); add(inner, band2, M.band);
  const barrel = new THREE.LatheGeometry([V(0.238, hw * 0.92), V(0.2286, hw * 0.88), V(0.2286, -hw * 0.88), V(0.238, -hw * 0.92)], 48); barrel.rotateZ(-PI / 2);
  add(inner, barrel, M.rim);
  const lip = new THREE.LatheGeometry([V(0.238, hw * 0.92), V(0.185, hw * 0.92)], 48); lip.rotateZ(-PI / 2); add(inner, lip, M.rim);
  const sx = hw * 0.78;
  for (let i = 0; i < 10; i++) {
    const sp = new THREE.BoxGeometry(0.03, 0.2, 0.034); sp.translate(0, 0.125, 0); sp.rotateX((i / 10) * PI * 2); sp.translate(sx, 0, 0);
    add(inner, sp, M.rim);
  }
  const hubG = new THREE.CylinderGeometry(0.06, 0.07, 0.04, 28); hubG.rotateZ(-PI / 2); hubG.translate(sx, 0, 0); add(inner, hubG, M.rim);
  const nut = new THREE.CylinderGeometry(0.028, 0.028, 0.05, 6); nut.rotateZ(-PI / 2); nut.translate(sx + 0.01, 0, 0); add(inner, nut, M.hub);
  const bx = hw * 0.5;
  const disc = new THREE.LatheGeometry([V(0.1, bx - 0.014), V(0.172, bx - 0.014), V(0.172, bx + 0.014), V(0.1, bx + 0.014), V(0.1, bx - 0.014)], 48); disc.rotateZ(-PI / 2);
  add(inner, disc, M.brake);
  const discBack = new THREE.CylinderGeometry(0.11, 0.11, 0.02, 24); discBack.rotateZ(-PI / 2); discBack.translate(bx - 0.02, 0, 0); add(inner, discBack, M.carbon);
  const blur = new THREE.CircleGeometry(0.232, 40); blur.rotateY(PI / 2); blur.translate(hw * 0.9, 0, 0); add(inner, blur, M.blur);

  const sgn = w.side;
  const cal = new THREE.BoxGeometry(0.055, 0.08, 0.13); cal.translate(sgn * bx, 0.13, -0.06); add(steer, cal, M.red);
  const calB = new THREE.BoxGeometry(0.03, 0.03, 0.16); calB.translate(sgn * (bx - 0.02), 0.095, -0.06); add(steer, calB, M.carbon);
  add(steer, rod([-sgn * (hw + 0.06), 0, 0], [-sgn * 0.02, 0, 0], 0.045, 12), M.carbon);
  const upright = new THREE.BoxGeometry(0.05, 0.3, 0.1); upright.translate(-sgn * (hw + 0.04), 0.0, 0); add(steer, upright, M.carbon);

  const hx = w.x - sgn * (hw + 0.045);
  const bodyW = w.front ? 0.13 : 0.15;
  const zf = w.z;
  const ax = sgn * bodyW;
  const upY = w.front ? 0.45 : 0.5, loY = 0.2;
  const cUp = w.front ? 0.34 : 0.36, cLo = 0.15;
  add(chassis, rod([hx, upY, zf], [ax, cUp, zf + 0.3], 0.011), M.carbon);
  add(chassis, rod([hx, upY, zf], [ax, cUp, zf - 0.3], 0.011), M.carbon);
  add(chassis, rod([hx, loY, zf], [ax, cLo, zf + 0.32], 0.012), M.carbon);
  add(chassis, rod([hx, loY, zf], [ax, cLo, zf - 0.32], 0.012), M.carbon);
  add(chassis, rod([hx, upY - 0.03, zf + 0.02], [sgn * 0.07, w.front ? 0.5 : 0.56, zf + (w.front ? 0.12 : -0.12)], 0.013), M.carbon);
  if (w.front) add(chassis, rod([hx, 0.26, zf - 0.06], [sgn * 0.1, 0.24, zf - 0.28], 0.009), M.carbon);
  else add(chassis, rod([hx, 0.3, zf - 0.08], [sgn * 0.12, 0.3, zf - 0.28], 0.009), M.carbon);
}

flush();

/* ------------------------------------------------------------------ export */
const scene = new THREE.Scene(); scene.add(root);
const exporter = new GLTFExporter();
const glb = await exporter.parseAsync(scene, { binary: true, onlyVisible: false });
const dir = process.argv[2] || '.';
fs.mkdirSync(dir, { recursive: true });
const out = dir + '/f1-car.glb';
fs.writeFileSync(out, Buffer.from(glb));
let tris = 0, verts = 0;
root.traverse((o) => { if (o.isMesh) { verts += o.geometry.attributes.position.count; tris += (o.geometry.index ? o.geometry.index.count : o.geometry.attributes.position.count) / 3; } });
console.log('wrote', out, (glb.byteLength / 1024).toFixed(0) + ' KB', 'tris', tris, 'verts', verts);
