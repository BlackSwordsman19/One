import bpy
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath='Kamishs_Wrath.glb')
print('objects',[(o.name,o.type) for o in bpy.data.objects])
print('cameras',len(bpy.data.cameras),'lights',len(bpy.data.lights))
print('images',[(i.name,i.size[:],i.has_data) for i in bpy.data.images])
print('materials',[m.name for m in bpy.data.materials])
tv=sum(len(o.data.vertices) for o in bpy.data.objects if o.type=='MESH'); tt=sum(len(p.vertices)==3 for o in bpy.data.objects if o.type=='MESH' for p in o.data.polygons)
print('verts',tv,'tris',tt, 'uv layers', all(len(o.data.uv_layers)>=1 for o in bpy.data.objects if o.type=='MESH'))
