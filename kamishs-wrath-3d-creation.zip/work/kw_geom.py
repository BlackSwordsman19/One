"""Procedural geometry kit for Kamish's Wrath.
Authoring frame = artwork pixels: x right, y DOWN, z toward viewer (px units).
All builders return (tris[N,3,3], tones[N]) with outward winding (authoring frame).
"""
import numpy as np, math

EPS_AREA = 0.05


def _finish(T, TN, C):
    T = np.asarray(T, float).reshape(-1, 3, 3)
    TN = np.asarray(TN, int)
    C = np.asarray(C, float).reshape(-1, 3)
    n = np.cross(T[:, 1] - T[:, 0], T[:, 2] - T[:, 0])
    keep = np.linalg.norm(n, axis=1) * 0.5 > EPS_AREA
    T, TN, C, n = T[keep], TN[keep], C[keep], n[keep]
    flip = (n * (T.mean(1) - C)).sum(1) < 0
    T[flip] = T[flip][:, [0, 2, 1]]
    return T, TN


def cat(*prims):
    prims = [p for p in prims if p is not None and len(p[0])]
    return (np.concatenate([p[0] for p in prims]), np.concatenate([p[1] for p in prims]))


def loft(rings, tones, cap_start=False, cap_end=False, captone=0):
    R = np.asarray(rings, float)
    m, k, _ = R.shape
    T, TN, C = [], [], []
    for i in range(m - 1):
        cen = (R[i].mean(0) + R[i + 1].mean(0)) / 2
        for j in range(k):
            j2 = (j + 1) % k
            a, b, c, d = R[i][j], R[i][j2], R[i + 1][j2], R[i + 1][j]
            T += [[a, b, c], [a, c, d]]
            TN += [tones[j % len(tones)]] * 2
            C += [cen, cen]
    for flag, idx, nb in ((cap_start, 0, 1), (cap_end, m - 1, m - 2)):
        if flag:
            ring = R[idx]
            c0 = ring.mean(0)
            cn = R[nb].mean(0)
            for j in range(k):
                T.append([c0, ring[j], ring[(j + 1) % k]])
                TN.append(captone)
                C.append(cn)
    return _finish(T, TN, C)


def _bez(p0, p1, p2, n):
    s = np.linspace(0, 1, n)[:, None]
    return (1 - s) ** 2 * p0 + 2 * (1 - s) * s * p1 + s ** 2 * p2


def _bez3(pts, n):
    pts = [np.asarray(p, float) for p in pts]
    s = np.linspace(0, 1, n)[:, None]
    if len(pts) == 3:
        return _bez(pts[0], pts[1], pts[2], n)
    p0, p1, p2, p3 = pts
    return ((1 - s) ** 3 * p0 + 3 * (1 - s) ** 2 * s * p1 + 3 * (1 - s) * s ** 2 * p2 + s ** 3 * p3)


def stroke(path, hw, t, tones=(0, 1, 1, 0), z0=0.0, cap_start=False, cap_end=False, hwr=None):
    path = np.asarray(path, float)
    n = len(path)
    hw = np.broadcast_to(np.asarray(hw, float), (n,))
    hwr = hw if hwr is None else np.broadcast_to(np.asarray(hwr, float), (n,))
    t = np.broadcast_to(np.asarray(t, float), (n,))
    tg = np.gradient(path, axis=0)
    tg /= np.linalg.norm(tg, axis=1)[:, None] + 1e-9
    nm = np.stack([-tg[:, 1], tg[:, 0]], 1)
    rings = []
    for i in range(n):
        c = path[i]
        rings.append([np.r_[c + nm[i] * hw[i], z0], np.r_[c, z0 + t[i]],
                      np.r_[c - nm[i] * hwr[i], z0], np.r_[c, z0 - t[i]]])
    return loft(rings, tones, cap_start, cap_end)


def shard(base, tip, w, t, bend=0.0, n=5, z0=0.0, p=0.9, tones=(0, 1, 1, 0), cap_start=False):
    b = np.array(base, float)
    e = np.array(tip, float)
    d = e - b
    L = np.linalg.norm(d)
    perp = np.array([-d[1], d[0]]) / (L + 1e-9)
    path = _bez(b, (b + e) / 2 + perp * bend, e, n)
    s = np.linspace(0, 1, n)
    return stroke(path, w * (1 - s) ** p, t * (1 - s) ** p, tones, z0, cap_start=cap_start)


def curve_stroke(ctrl, hw, t, n=8, **kw):
    path = _bez3(ctrl, n)
    s = np.linspace(0, 1, len(ctrl))
    si = np.linspace(0, 1, n)
    hw = np.interp(si, s, hw)
    t = np.interp(si, s, t)
    return stroke(path, hw, t, **kw)


# ------------------------------------------------------------------ blade
def blade(edge, spine, tfun, section, tones, zoff=0.0, cap_end=True):
    edge = np.asarray(edge, float)
    spine = np.asarray(spine, float)
    ys = np.unique(np.r_[edge[:, 1], spine[:, 1]])
    xe = np.interp(ys, edge[:, 1], edge[:, 0])
    xs = np.interp(ys, spine[:, 1], spine[:, 0])
    rings = []
    for y, a, b in zip(ys, xe, xs):
        t = tfun(y)
        rings.append([[a + u * (b - a), y, zoff + zf * t] for (u, zf) in section])
    return loft(rings, tones, cap_start=False, cap_end=cap_end, captone=2)


# ------------------------------------------------------------------ plates
def _sorted(poly, pivot):
    P = np.asarray(poly, float)
    c = np.asarray(pivot, float)
    ang = np.arctan2(P[:, 1] - c[1], P[:, 0] - c[0])
    return P[np.argsort(ang)]


def plate(poly, pivot, t, k=0.6, z0=0.0, dome=1.0, hole=None, tones=(1, 0), both=True, sides=(1, -1)):
    """Bevelled plate: outline at z0 (razor edge), flat/domed cap at z0 +/- t.
    hole=(radius, depth) carves a crater on the +z face. Returns (main, crater)."""
    P = _sorted(poly, pivot)
    c = np.asarray(pivot, float)
    Q = c + (P - c) * k
    n = len(P)
    T, TN, C = [], [], []
    CT, CTN, CC = [], [], []
    for sg in sides:
        zt = z0 + sg * t
        cen = np.r_[c, z0]
        for i in range(n):
            j = (i + 1) % n
            p0, p1 = np.r_[P[i], z0], np.r_[P[j], z0]
            q0, q1 = np.r_[Q[i], zt], np.r_[Q[j], zt]
            T += [[p0, p1, q1], [p0, q1, q0]]
            TN += [tones[0]] * 2
            C += [cen] * 2
            if hole and sg > 0:
                rh, depth = hole
                def ring(pt):
                    v = pt - c
                    return c + v / (np.linalg.norm(v) + 1e-9) * rh
                r0, r1 = np.r_[ring(Q[i]), zt], np.r_[ring(Q[j]), zt]
                T += [[q0, q1, r1], [q0, r1, r0]]
                TN += [tones[1]] * 2
                C += [cen] * 2
                apex = np.r_[c, zt - depth]
                CT.append([r0, r1, apex])
                CTN.append(0)
                CC.append(np.r_[c, zt - depth * 4])
            else:
                apex = np.r_[c, z0 + sg * t * dome]
                T.append([apex, q0, q1])
                TN.append(tones[1])
                C.append(cen)
    main = _finish(T, TN, C)
    crater = _finish(CT, CTN, CC) if CT else None
    return main, crater


def plate_z(poly, pivot, t, k, x, y, z0=0.0, dome=1.0):
    """Surface height of +z face of plate at (x,y) (for ribbon conforming)."""
    P = _sorted(poly, pivot)
    c = np.asarray(pivot, float)
    v = np.array([x, y], float) - c
    r = np.linalg.norm(v)
    if r < 1e-6:
        return z0 + t * dome
    d = v / r
    best = None
    for i in range(len(P)):
        a, b = P[i] - c, P[(i + 1) % len(P)] - c
        e = b - a
        den = d[0] * (-e[1]) - d[1] * (-e[0])
        if abs(den) < 1e-9:
            continue
        # solve s*d = a + u*e
        M = np.array([[d[0], -e[0]], [d[1], -e[1]]])
        try:
            s, u = np.linalg.solve(M, a)
        except np.linalg.LinAlgError:
            continue
        if s > 0 and -1e-6 <= u <= 1 + 1e-6:
            best = s if best is None else min(best, s)
    if best is None:
        return z0
    q = r / best
    if q <= k:
        return z0 + t * (dome - (dome - 1) * q / k) if dome != 1 else z0 + t
    return z0 + t * max(0.0, 1 - (q - k) / (1 - k))


def ribbon(pts, width, zfun, tone=0, taper=True, step=7.0):
    """Flat ribbon following polyline, z from zfun(x,y)."""
    pts = np.asarray(pts, float)
    dense = [pts[0]]
    for a, b in zip(pts[:-1], pts[1:]):
        L = np.linalg.norm(b - a)
        m = max(1, int(L / step))
        for i in range(1, m + 1):
            dense.append(a + (b - a) * i / m)
    D = np.array(dense)
    n = len(D)
    tg = np.gradient(D, axis=0)
    tg /= np.linalg.norm(tg, axis=1)[:, None] + 1e-9
    nm = np.stack([-tg[:, 1], tg[:, 0]], 1)
    s = np.linspace(0, 1, n)
    w = np.full(n, width / 2.0)
    if taper:
        w *= np.clip(np.minimum(s, 1 - s) * 6, 0.25, 1.0)
    L_ = D + nm * w[:, None]
    R_ = D - nm * w[:, None]
    def z(p):
        return zfun(p[0], p[1])
    T, TN, C = [], [], []
    for i in range(n - 1):
        a = np.r_[L_[i], z(L_[i])]
        b = np.r_[R_[i], z(R_[i])]
        c = np.r_[R_[i + 1], z(R_[i + 1])]
        d = np.r_[L_[i + 1], z(L_[i + 1])]
        for tri in ([a, b, c], [a, c, d]):
            T.append(tri)
            TN.append(tone)
            C.append(np.r_[D[i], z(D[i]) - 10.0])
    return _finish(T, TN, C)


# ------------------------------------------------------------------ grip
def grip(a0, a1, r0, r1, rows, N, lift, twist=0.0):
    a0, a1 = np.asarray(a0, float), np.asarray(a1, float)
    ax = a1 - a0
    Ln = np.linalg.norm(ax)
    d = ax / Ln
    n2 = np.array([-d[1], d[0]])

    def pos(sx, phi, dr=0.0):
        r = r0 + (r1 - r0) * sx + dr
        c = a0 + ax * sx
        return np.r_[c + n2 * (r * math.cos(phi)), r * math.sin(phi)], np.r_[c, 0.0]

    # core (dark) cylinder
    Nc = 10
    rings = []
    for sx in np.linspace(-0.02, 1.02, 4):
        r = (r0 + (r1 - r0) * sx) * 0.93
        c = a0 + ax * sx
        rings.append([np.r_[c + n2 * (r * math.cos(2 * math.pi * j / Nc)), r * math.sin(2 * math.pi * j / Nc)] for j in range(Nc)])
    core = loft(rings, (2,), cap_start=True, cap_end=True, captone=2)

    T, TN, C = [], [], []
    pitch = 1.0 / rows
    for k in range(rows):
        sx = (k + 0.65) * pitch * 0.985
        for j in range(N):
            phi0 = (j + 0.5 * (k % 2) + twist * k) * 2 * math.pi / N
            dphi = 2 * math.pi / N * 0.56
            dsx = pitch * 0.95
            outline = [(-1, 0.55), (1, 0.55), (0.92, -0.05), (0, -1.0), (-0.92, -0.05)]
            ring = []
            for (u, v) in outline:
                p, ax_c = pos(sx + v * dsx * 0.78, phi0 + u * dphi, 0.5 + (0.9 if v > 0.4 else 0.0))
                ring.append((p, ax_c))
            cp, cc = pos(sx + 0.05 * dsx, phi0, lift)
            for i in range(5):
                i2 = (i + 1) % 5
                T.append([cp, ring[i][0], ring[i2][0]])
                TN.append(0 if i in (0, 4) else 1 if i in (1, 2) else 0 if i == 3 and False else 1)
                C.append(cc)
            # tone: left half lighter, right half darker (value steps)
            TN[-5:] = [0, 1, 1, 0, 0]
    sc = _finish(T, TN, C)
    return core, sc


def mirror_pts(pts, xc):
    return [(2 * xc - x, y) for x, y in pts]
