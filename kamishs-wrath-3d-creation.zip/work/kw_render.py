import bpy, sys, math, os
from mathutils import Vector

glb = sys.argv[sys.argv.index("--") + 1]
mode = sys.argv[sys.argv.index("--") + 2]
outprefix = sys.argv[sys.argv.index("--") + 3]
S = 0.61 / 1382.0

bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=glb)
sc = bpy.context.scene
sc.render.engine = "CYCLES"
sc.cycles.device = "CPU"
sc.cycles.samples = int(os.environ.get("SAMPLES", 20))
sc.cycles.use_denoising = False
sc.view_settings.view_transform = "Standard"
sc.render.film_transparent = False
w = bpy.data.worlds.new("w")
w.use_nodes = True
w.node_tree.nodes["Background"].inputs[0].default_value = (0.42, 0.42, 0.42, 1)
w.node_tree.nodes["Background"].inputs[1].default_value = 1.0
sc.world = w


def sun(rot, energy):
    d = bpy.data.lights.new("s", "SUN")
    d.energy = energy
    d.color = (1, 1, 1)
    o = bpy.data.objects.new("s", d)
    o.rotation_euler = [math.radians(a) for a in rot]
    sc.collection.objects.link(o)


sun((50, 0, -30), 3.2)   # key, from front-top-left (neutral white)
sun((70, 0, 140), 1.2)   # fill, neutral white
cam_d = bpy.data.cameras.new("c")
cam = bpy.data.objects.new("c", cam_d)
sc.collection.objects.link(cam)
sc.camera = cam


def shoot(name, loc, rot=None, ortho=None, res=(600, 1000), look=None):
    cam.location = loc
    if look is not None:
        cam.rotation_euler = (Vector(look) - Vector(loc)).to_track_quat("-Z", "Y").to_euler()
    else:
        cam.rotation_euler = [math.radians(a) for a in rot]
    if ortho:
        cam_d.type = "ORTHO"
        cam_d.ortho_scale = ortho
    else:
        cam_d.type = "PERSP"
        cam_d.lens = 50
    sc.render.resolution_x, sc.render.resolution_y = res
    sc.render.filepath = name
    bpy.ops.render.render(write_still=True)


if mode == "flat":
    shoot(outprefix + "_flat.png", (0, -5, 0), (90, 0, 0), ortho=1499 * S, res=(720, 1499))
else:
    for o in bpy.data.objects:
        pass
    shoot(outprefix + "_front.png", (0, -3.2, 0), (90, 0, 0), ortho=0.78, res=(640, 640))
    shoot(outprefix + "_back.png", (0, 3.2, 0), (90, 0, 180), ortho=0.78, res=(640, 640))
    shoot(outprefix + "_side.png", (3.2, 0, 0), (90, 0, 90), ortho=0.78, res=(640, 640))
    shoot(outprefix + "_q.png", (0.9, -1.5, 0.35), look=(0, 0, 0), res=(640, 640))
