"""Convert authored daggers -> local metres, pack UVs, bake procedural textures, write GLB."""
import numpy as np, json, struct, math, io, sys
from PIL import Image
from kw_models import *

S = 0.61 / 1382.0
TEX = 2048
CELL = 16
LEG = 12
PER_ROW = TEX // CELL

MATS = {
    # name: (base hex, metallic, roughness, tone colours)
    M_BLADE: ("F98A7A", 0.85, 0.30, ["F98A7A", "E4645A", "BC4A40", "F98A7A"]),
    M_BLACK: ("100609", 0.70, 0.45, ["100609", "0D0508", "0A0306", "100609"]),
    M_EMIS: ("FF695E", 0.0, 0.60, ["FF695E", "FF695E", "FF695E", "FF695E"]),
    M_IVORY: ("E8DDB4", 0.80, 0.40, ["E8DDB4", "D6C79E", "997158", "9D664B"]),
    M_GBLUE: ("5D576F", 0.80, 0.50, ["5D576F", "535468", "2E2F3C", "5D576F"]),
    M_GPURP: ("7B5D6E", 0.80, 0.50, ["7B5D6E", "543347", "3A2333", "7B5D6E"]),
    M_POMMEL: ("F28A87", 0.60, 0.55, ["F28A87", "A24D55", "7A3640", "F28A87"]),
}
MAT_ORDER = [M_BLADE, M_BLACK, M_EMIS, M_IVORY, M_GBLUE, M_GPURP, M_POMMEL]


def hex2rgb(h):
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], float) / 255.0


def s2l(c):
    c = np.asarray(c, float)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def l2s(c):
    c = np.clip(np.asarray(c, float), 0, 1)
    return np.where(c <= 0.0031308, c * 12.92, 1.055 * c ** (1 / 2.4) - 0.055)


def to_local(prim, which):
    T, TN = prim
    T = T.copy()
    if which == "A":
        x0, y0 = ORIGIN_A
        L = np.stack([(T[..., 0] - x0) * S, -T[..., 2] * S, -(T[..., 1] - y0) * S], -1)
    else:
        x0, y0 = ORIGIN_B
        L = np.stack([-(T[..., 0] - x0) * S, -T[..., 2] * S, (T[..., 1] - y0) * S], -1)
    L = L[:, [0, 2, 1]]  # reflection in mapping -> swap winding
    return L, TN


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def mat2quat(R):
    t = np.trace(R)
    if t > 0:
        s = math.sqrt(t + 1) * 2
        return [(R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s, 0.25 * s]
    i = int(np.argmax(np.diag(R)))
    j, k = (i + 1) % 3, (i + 2) % 3
    s = math.sqrt(R[i, i] - R[j, j] - R[k, k] + 1) * 2
    q = [0, 0, 0, 0]
    q[i] = 0.25 * s
    q[j] = (R[j, i] + R[i, j]) / s
    q[k] = (R[k, i] + R[i, k]) / s
    q[3] = (R[k, j] - R[j, k]) / s
    return q


def noise3(P, f=1.0, ph=0.0):
    x, y, z = P[..., 0] * f, P[..., 1] * f, P[..., 2] * f
    return (np.sin(x * 0.9 + ph) * np.sin(y * 1.1 + 2 * ph + 1) + np.sin(z * 1.3 + y * 0.7 + ph) * np.cos(x * 0.6 + 3)) * 0.5


def build_scene(placement="final", tilt=(14.0, -6.0), centers=(-0.135, 0.135)):
    rng = np.random.default_rng(11)
    daggers = []
    for which, parts in (("A", build_A()), ("B", build_B())):
        d = {"name": "KW_Dagger_A_BlackGuard" if which == "A" else "KW_Dagger_B_GoldGuard", "parts": {}}
        for pname in ("Blade", "Guard", "Grip", "Pommel"):
            prims = []
            for mat, prim in parts[pname]:
                T, TN = to_local(prim, which)
                if mat == M_IVORY:  # tan shading steps on some facets
                    r = rng.random(len(TN))
                    TN = np.where((TN == 1) & (r < 0.18), 2, TN)
                    TN = np.where((TN == 1) & (r > 0.93), 3, TN)
                prims.append((mat, T, TN))
            d["parts"][pname] = prims
        # placement
        if placement == "flat":
            x0, y0 = ORIGIN_A if which == "A" else ORIGIN_B
            R = rot_x(-math.pi / 2)
            if which == "B":
                R = rot_z(math.pi) @ R
            d["t"] = [(x0 - 360) * S, -(y0 - 750) * S, 0.0]
        else:
            ang = math.radians(tilt[0] if which == "A" else tilt[1])
            R = rot_x(-math.pi / 2)
            R = rot_z(ang) @ (R if which == "A" else rot_z(math.pi) @ R)
            allv = np.concatenate([p[1].reshape(-1, 3) for pr in d["parts"].values() for p in pr])
            W = allv @ R.T
            c = (W.min(0) + W.max(0)) / 2
            d["t"] = [centers[0 if which == "A" else 1] - c[0], -c[1], -c[2]]
        d["R"] = R
        daggers.append(d)
    return daggers


# ---------------------------------------------------------------- texture bake
def bake(daggers):
    # gather all triangles
    items = []
    for d in daggers:
        for pname, prims in d["parts"].items():
            for (mat, T, TN) in prims:
                items.append((d, pname, mat, T, TN))
    n_total = sum(len(i[3]) for i in items)
    assert n_total <= PER_ROW * PER_ROW, n_total
    base = np.zeros((TEX, TEX, 3), np.float32)
    nrm = np.zeros((TEX, TEX, 3), np.float32)
    orm = np.zeros((TEX, TEX, 3), np.float32)
    base[:] = 1.0
    nrm[:] = (0.5, 0.5, 1.0)
    orm[:] = 1.0
    # texel barycentrics for a 16x16 cell
    tx, ty = np.meshgrid(np.arange(CELL) + 0.5, np.arange(CELL) + 0.5)
    a = (tx - 2) / LEG
    b = (ty - 2) / LEG
    l2_, l1_ = a, b
    l0_ = 1 - a - b
    bc = np.stack([l0_, l1_, l2_], -1).clip(0, None)
    bc /= bc.sum(-1, keepdims=True)
    bc = bc.reshape(-1, 3)  # (256,3)
    idx = 0
    prim_out = []
    rng = np.random.default_rng(5)
    for (d, pname, mat, T, TN) in items:
        n = len(T)
        ids = np.arange(idx, idx + n)
        cx, cy = ids % PER_ROW, ids // PER_ROW
        ox = cx * CELL + 2
        oy = cy * CELL + 2
        # UVs (glTF: v down). non-mirrored assignment: uv1=(0,L), uv2=(L,0)
        uv = np.zeros((n, 3, 2))
        uv[:, 0] = np.stack([ox, oy], -1)
        uv[:, 1] = np.stack([ox, oy + LEG], -1)
        uv[:, 2] = np.stack([ox + LEG, oy], -1)
        uv /= TEX
        # normals / tangents
        e1, e2 = T[:, 1] - T[:, 0], T[:, 2] - T[:, 0]
        N = np.cross(e1, e2)
        N /= np.linalg.norm(N, axis=1)[:, None]
        du1, dv1 = uv[:, 1, 0] - uv[:, 0, 0], uv[:, 1, 1] - uv[:, 0, 1]
        du2, dv2 = uv[:, 2, 0] - uv[:, 0, 0], uv[:, 2, 1] - uv[:, 0, 1]
        det = du1 * dv2 - du2 * dv1
        Tg = (e1 * dv2[:, None] - e2 * dv1[:, None]) / det[:, None]
        Bg = (e2 * du1[:, None] - e1 * du2[:, None]) / det[:, None]
        Tg /= np.linalg.norm(Tg, axis=1)[:, None]
        w = np.sign((np.cross(N, Tg) * (-Bg)).sum(1))
        w[w == 0] = 1
        tan = np.concatenate([Tg, w[:, None]], 1)
        # bake texels
        P = np.einsum("tk,nkc->ntc", bc, T)  # (n,256,3)
        bh, bm, br, tones = MATS[mat][0], MATS[mat][1], MATS[mat][2], MATS[mat][3]
        bl = s2l(hex2rgb(bh))
        tone_lin = np.array([s2l(hex2rgb(h)) for h in tones])
        mod = np.clip(tone_lin / np.maximum(bl, 1e-5), 0, 1)  # (4,3)
        col = mod[TN][:, None, :] * np.ones((1, CELL * CELL, 1))
        nz = 1 + 0.035 * noise3(P * 900, 0.05) + 0.02 * rng.standard_normal((n, 1)).clip(-2, 2)
        col = np.clip(col * nz[..., None], 0, 1)
        colS = l2s(col)
        # write
        yy = (cy[:, None] * CELL + np.arange(CELL)[None, :])
        xx = (cx[:, None] * CELL + np.arange(CELL)[None, :])
        def put(img, vals):
            v = vals.reshape(n, CELL, CELL, -1)
            for k in range(n):
                img[yy[k][:, None], xx[k][None, :]] = v[k]
        put(base, colS)
        nt = np.stack([0.5 + 0.045 * noise3(P * 700, 0.07, 1.0), 0.5 + 0.045 * noise3(P * 700, 0.07, 4.0), np.ones((n, CELL * CELL))], -1)
        nv = np.clip(nt[..., :2] * 2 - 1, -1, 1)
        nzv = np.sqrt(np.clip(1 - (nv ** 2).sum(-1), 0, 1))
        nt = np.stack([nv[..., 0] * 0.5 + 0.5, nv[..., 1] * 0.5 + 0.5, nzv * 0.5 + 0.5], -1)
        put(nrm, nt)
        ao = np.where(TN >= 2, 0.88, 1.0)[:, None] * (1 + 0.02 * noise3(P * 500, 0.1, 2.0))
        o = np.stack([np.clip(ao, 0, 1), np.clip(0.97 + 0.03 * noise3(P * 300, 0.12, 5.0), 0, 1), np.ones((n, CELL * CELL))], -1)
        put(orm, o)
        # per-vertex streams: 3 verts per tri
        pos = T.reshape(-1, 3).astype(np.float32)
        nor = np.repeat(N, 3, axis=0).astype(np.float32)
        tg = np.repeat(tan, 3, axis=0).astype(np.float32)
        uvs = uv.reshape(-1, 2).astype(np.float32)
        prim_out.append((d, pname, mat, pos, nor, tg, uvs))
        idx += n
    q = lambda im: Image.fromarray((np.clip(im, 0, 1) * 255 + 0.5).astype(np.uint8), "RGB")
    return q(base), q(nrm), q(orm), prim_out, n_total


# ---------------------------------------------------------------- glb writer
def write_glb(path, daggers, images, prim_out, emissive_strength=0.6):
    buf = bytearray()
    views, accs = [], []

    def add_view(data, target=None):
        while len(buf) % 4:
            buf.append(0)
        off = len(buf)
        buf.extend(data)
        v = {"buffer": 0, "byteOffset": off, "byteLength": len(data)}
        if target:
            v["target"] = target
        views.append(v)
        return len(views) - 1

    def add_acc(arr, ctype, atype, target=34962, minmax=False):
        vi = add_view(arr.tobytes(), target)
        a = {"bufferView": vi, "componentType": ctype, "count": int(len(arr)), "type": atype}
        if minmax:
            a["min"] = [float(x) for x in arr.min(0)]
            a["max"] = [float(x) for x in arr.max(0)]
        accs.append(a)
        return len(accs) - 1

    img_idx = []
    for im in images:
        b = io.BytesIO()
        im.save(b, "PNG", optimize=True)
        img_idx.append(add_view(b.getvalue()))
    gimages = [{"bufferView": v, "mimeType": "image/png"} for v in img_idx]
    gimages[0]["name"] = "KW_BaseColor"
    gimages[1]["name"] = "KW_Normal"
    gimages[2]["name"] = "KW_ORM"
    textures = [{"source": i, "sampler": 0} for i in range(3)]
    samplers = [{"magFilter": 9729, "minFilter": 9987, "wrapS": 33071, "wrapT": 33071}]
    materials = []
    for name in MAT_ORDER:
        bh, met, rough, _ = MATS[name]
        m = {"name": name,
             "pbrMetallicRoughness": {"baseColorFactor": list(map(float, s2l(hex2rgb(bh)))) + [1.0],
                                      "baseColorTexture": {"index": 0},
                                      "metallicFactor": met, "roughnessFactor": rough,
                                      "metallicRoughnessTexture": {"index": 2}},
             "normalTexture": {"index": 1, "scale": 1.0},
             "occlusionTexture": {"index": 2, "strength": 1.0}}
        if name == M_EMIS:
            m["emissiveFactor"] = list(map(float, s2l(hex2rgb(bh))))
            m["extensions"] = {"KHR_materials_emissive_strength": {"emissiveStrength": emissive_strength}}
        materials.append(m)

    meshes, nodes = [], []
    nodes.append({"name": "KamishsWrath", "children": [1, 2]})
    stats = {}
    for di, d in enumerate(daggers):
        q = mat2quat(d["R"])
        nodes.append({"name": d["name"], "translation": [float(x) for x in d["t"]], "rotation": [float(x) for x in q], "children": []})
    for di, d in enumerate(daggers):
        node_i = 1 + di
        for pname in ("Blade", "Guard", "Grip", "Pommel"):
            prims = []
            vt = 0
            tt = 0
            for (dd, pn, mat, pos, nor, tg, uvs) in prim_out:
                if dd is not d or pn != pname:
                    continue
                pa = add_acc(pos, 5126, "VEC3", minmax=True)
                na = add_acc(nor, 5126, "VEC3")
                ta = add_acc(tg, 5126, "VEC4")
                ua = add_acc(uvs, 5126, "VEC2")
                ia = add_acc(np.arange(len(pos), dtype=np.uint32), 5125, "SCALAR", target=34963)
                prims.append({"attributes": {"POSITION": pa, "NORMAL": na, "TANGENT": ta, "TEXCOORD_0": ua},
                              "indices": ia, "material": MAT_ORDER.index(mat), "mode": 4})
                vt += len(pos)
                tt += len(pos) // 3
            meshes.append({"name": f"{d['name']}_{pname}" if False else pname, "primitives": prims})
            nodes.append({"name": pname, "mesh": len(meshes) - 1})
            nodes[node_i]["children"].append(len(nodes) - 1)
            stats[(d["name"], pname)] = (vt, tt)
    gltf = {"asset": {"version": "2.0", "generator": "KamishsWrath procedural builder (numpy) / validated with Blender 4.2"},
            "extensionsUsed": ["KHR_materials_emissive_strength"],
            "scene": 0, "scenes": [{"name": "KamishsWrath", "nodes": [0]}],
            "nodes": nodes, "meshes": meshes, "materials": materials, "textures": textures,
            "images": gimages, "samplers": samplers, "accessors": accs, "bufferViews": views,
            "buffers": [{"byteLength": len(buf)}]}
    js = json.dumps(gltf, separators=(",", ":")).encode()
    while len(js) % 4:
        js += b" "
    while len(buf) % 4:
        buf.append(0)
    total = 12 + 8 + len(js) + 8 + len(buf)
    with open(path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total))
        f.write(struct.pack("<II", len(js), 0x4E4F534A))
        f.write(js)
        f.write(struct.pack("<II", len(buf), 0x004E4942))
        f.write(buf)
    return stats


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "final"
    out = sys.argv[2] if len(sys.argv) > 2 else "Kamishs_Wrath.glb"
    sc = build_scene(mode)
    base, nrm, orm, prim_out, n = bake(sc)
    st = write_glb(out, sc, (base, nrm, orm), prim_out)
    tv = sum(len(p[3]) for p in prim_out)
    print("tris", n, "verts", tv)
    for k, v in st.items():
        print(k, "verts/tris", v)
    import os
    print(out, os.path.getsize(out))
