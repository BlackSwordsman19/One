import sys
from PIL import Image
p=sys.argv[1]
ims=[Image.open(f'{p}_{n}.png') for n in ('front','back','side','q')]
sh=Image.new('RGB',(1280,1280))
for k,i in enumerate(ims): sh.paste(i,((k%2)*640,(k//2)*640))
sh.save(f'{p}_sheet.png')
