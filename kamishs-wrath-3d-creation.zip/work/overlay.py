import sys
from PIL import Image, ImageDraw
sys.path.insert(0,'.')
from kw_models import LANDMARKS
im=Image.open(sys.argv[1]).convert('RGB'); d=ImageDraw.Draw(im)
cols={'A_spine':(0,255,0),'A_edge':(0,200,255),'B_spine':(0,255,0),'B_edge':(0,200,255),'A_len':(255,255,0),'B_len':(255,255,0)}
for k,p in LANDMARKS.items():
    d.line(p,fill=cols[k],width=2)
    for x,y in p: d.ellipse([x-4,y-4,x+4,y+4],outline=cols[k])
im.save(sys.argv[2])
