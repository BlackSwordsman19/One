"""Dagger A (slim, black guard) and Dagger B (thick, ivory 'gold' guard) authored in artwork pixels."""
import numpy as np
from kw_geom import *

M_BLADE = "M_Blade_Coral"
M_BLACK = "M_Guard_Black"
M_EMIS = "M_Guard_BlackEmissive"
M_IVORY = "M_Guard_Ivory"
M_GBLUE = "M_Grip_BlueGrey"
M_GPURP = "M_Grip_PurpleGrey"
M_POMMEL = "M_Pommel_Coral"

ORIGIN_A = (201.0, 1195.0)   # grip centre, px
ORIGIN_B = (480.0, 321.0)

# landmark polylines used for overlay verification (artwork px)
LANDMARKS = {
    "A_spine": [(338, 88), (352, 140), (300, 230), (250, 330), (215, 430), (195, 520), (185, 590)],
    "A_edge": [(338, 88), (300, 120), (255, 190), (215, 270), (185, 360), (170, 430), (160, 490)],
    "B_spine": [(410, 470), (375, 560), (370, 650), (390, 720), (400, 800), (395, 900), (390, 1000), (380, 1100), (385, 1200)],
    "B_edge": [(560, 900), (555, 1000), (520, 1100), (490, 1200), (470, 1345)],
    "A_len": [(338, 88), (200, 1470)],
    "B_len": [(500, 195), (470, 1345)],
}


def build_A():
    parts = {"Blade": [], "Guard": [], "Grip": [], "Pommel": []}
    # ---------------- blade (coral): left = zero-thickness cutting edge, right = spine ridge
    edge = [(338, 88), (318, 106), (300, 125), (262, 190), (228, 270), (205, 360), (190, 425), (158, 452),
            (183, 480), (174, 520), (178, 556), (166, 600), (160, 700), (158, 800), (160, 900), (170, 1000), (190, 1065)]
    spine = [(338, 88), (346, 114), (351, 140), (335, 185), (320, 220), (300, 265), (285, 310), (270, 355), (262, 400),
             (270, 424), (256, 446), (262, 474), (250, 492), (254, 520), (244, 552), (248, 590), (242, 640), (240, 700),
             (238, 800), (240, 900), (238, 1000), (232, 1065)]
    tf = lambda y: float(np.clip((y - 88) / 130.0, 0, 1)) * 7.5 + 1.5 * float(np.clip((y - 88) / 130.0, 0, 1))
    sec = [(0, 0), (0.3, 0.5), (0.65, 1.0), (1.0, 0.9), (1.0, -0.9), (0.65, -1.0), (0.3, -0.5)]
    # tones per face: bevel(1) lit(0) lit(0) spine(2) spine-back(2) back(0) back-bevel(1)
    parts["Blade"].append((M_BLADE, blade(edge, spine, tf, sec, (1, 0, 0, 2, 0, 0, 1))))

    # ---------------- black guard
    pivot = (195, 965)
    body_poly = [(150, 885), (120, 905), (142, 940), (100, 978), (120, 1015), (104, 1050), (150, 1082), (188, 1058),
                 (236, 1042), (268, 1070), (262, 1010), (292, 985), (268, 950), (284, 915), (252, 895), (215, 880)]
    tb, kb = 30.0, 0.8
    body, _ = plate(body_poly, pivot, tb, k=kb, dome=1.0, tones=(0, 0))
    g = [body]
    sh = lambda *a, **k: g.append(shard(*a, **k))
    # wings hugging the blade
    sh((152, 900), (160, 610), 48, 18, bend=-18, n=7)
    sh((125, 940), (112, 760), 40, 15, bend=-12, n=6)
    sh((112, 985), (86, 860), 32, 13, bend=8, n=5)
    sh((140, 800), (108, 742), 13, 7, bend=-3)
    sh((150, 700), (124, 652), 11, 6, bend=-3)
    sh((128, 880), (96, 830), 12, 7)
    sh((250, 905), (255, 640), 40, 16, bend=14, n=7)
    sh((272, 950), (278, 800), 34, 14, bend=10, n=6)
    sh((285, 985), (302, 895), 26, 11, bend=6)
    sh((262, 820), (288, 783), 11, 6)
    sh((258, 720), (280, 688), 10, 5)
    sh((270, 870), (296, 840), 11, 6)
    # talons
    sh((135, 1040), (80, 1172), 50, 18, bend=-16, n=7)
    sh((165, 1070), (128, 1135), 19, 9, bend=6)
    sh((255, 1020), (262, 1148), 40, 16, bend=16, n=7)
    sh((228, 1058), (236, 1115), 14, 8, bend=4)
    sh((110, 1010), (70, 1060), 14, 8, bend=-4)
    sh((290, 1000), (310, 1052), 12, 7, bend=4)
    parts["Guard"].append((M_BLACK, cat(*g)))

    zf = lambda x, y: plate_z(body_poly, pivot, tb, kb, x, y) + 3.0
    cx = 195.0
    half = [
        [(128, 938), (160, 952), (186, 984)],                      # brow
        [(150, 975), (170, 966), (183, 982), (160, 990), (150, 975)],  # eye
        [(140, 1012), (120, 1030), (104, 1046)],                  # whisker
        [(150, 1024), (130, 1050), (120, 1072)],                  # whisker 2
        [(152, 905), (170, 922), (188, 940)],                      # forehead stripe
        [(130, 970), (118, 992), (126, 1008)],                    # cheek curl
    ]
    lines = []
    for h in half:
        lines.append(h)
        lines.append(mirror_pts(h, cx))
    lines.append([(195, 896), (195, 952), (195, 1008)])           # nose bridge
    lines.append([(180, 1020), (195, 1034), (210, 1020)])         # nostrils
    lines.append([(175, 925), (195, 940), (215, 925)])           # brow chevron
    rib = [ribbon(l, 4.0, zf) for l in lines]
    parts["Guard"].append((M_EMIS, cat(*rib)))

    # ---------------- grip (blue-grey)
    core, scales = grip((213, 1035), (190, 1355), 34, 24, rows=17, N=9, lift=3.0)
    parts["Grip"].append((M_GBLUE, cat(core, scales)))

    # ---------------- pommel: coral flame
    pc = curve_stroke([(198, 1345), (192, 1400), (190, 1440), (222, 1478)], [36, 42, 26, 0], [26, 30, 20, 0], n=9)
    f1 = shard((196, 1395), (165, 1440), 17, 10, bend=-6)
    f2 = shard((205, 1405), (240, 1440), 15, 9, bend=6)
    parts["Pommel"].append((M_POMMEL, cat(pc, f1, f2)))
    return parts


def build_B():
    parts = {"Blade": [], "Guard": [], "Grip": [], "Pommel": []}
    # ---------------- blade
    spine = [(474, 470), (442, 515), (402, 565), (370, 610), (370, 650), (380, 690), (390, 720), (398, 760), (400, 800),
             (397, 850), (395, 900), (384, 925), (393, 945), (386, 975), (390, 1000), (383, 1050), (380, 1100),
             (381, 1150), (385, 1200), (410, 1275), (440, 1318), (470, 1345)]
    edge = [(504, 470), (512, 520), (528, 580), (545, 640), (560, 700), (566, 760), (566, 830), (560, 900),
            (548, 935), (558, 950), (546, 985), (556, 1002), (540, 1050), (520, 1100), (505, 1150), (490, 1200),
            (481, 1270), (474, 1320), (470, 1345)]
    tf = lambda y: 17.0 * float(np.clip((1345 - y) / 220.0, 0, 1)) ** 0.8 + 1.0 * float(y < 1330)
    sec = [(0, 0), (0.35, 0.5), (0.75, 1.0), (1.0, 0.8), (1.0, -0.8), (0.75, -1.0), (0.35, -0.5)]
    b = [blade(edge, spine, tf, sec, (1, 0, 0, 2, 0, 0, 1))]
    # red fin (big, sweeping up-right) as a bevelled plate
    fin_poly = [(520, 650), (505, 590), (540, 560), (575, 520), (612, 470), (640, 405), (655, 470), (654, 550),
                (640, 620), (612, 690), (570, 702), (540, 692)]
    fp, _ = plate(fin_poly, (575, 610), 15, k=0.5, tones=(1, 0))
    b.append(fp)
    b.append(shard((495, 600), (558, 505), 30, 11, bend=-14, n=6))          # mid hook
    b.append(shard((422, 645), (395, 466), 28, 12, bend=-14, n=7))          # left horn
    b.append(shard((388, 700), (366, 588), 21, 9, bend=-8, n=6))            # 2nd horn
    # row of spine spikes
    b.append(shard((380, 600), (340, 560), 15, 8))
    b.append(shard((376, 650), (338, 628), 15, 8))
    b.append(shard((388, 715), (362, 698), 10, 6))
    b.append(shard((398, 770), (372, 758), 9, 5))
    parts["Blade"].append((M_BLADE, cat(*b)))

    # ---------------- ivory guard
    pivot = (452, 708)
    poly = [(392, 690), (400, 650), (440, 640), (478, 652), (520, 672), (560, 662), (596, 676), (590, 720), (606, 760),
            (578, 790), (570, 830), (540, 860), (520, 880), (480, 870), (445, 890), (430, 850), (405, 830), (392, 780),
            (380, 740)]
    tS = 34.0
    skull, crater = plate(poly, pivot, tS, k=0.62, dome=1.1, hole=(22, 22), tones=(0, 1))
    g = [skull]
    fangs = [((560, 690), (612, 640), 27, 20, -8), ((572, 742), (622, 716), 26, 20, 6), ((560, 792), (612, 782), 24, 18, 4),
             ((540, 832), (594, 838), 24, 18, 6), ((520, 862), (558, 912), 24, 18, 8), ((490, 876), (500, 950), 24, 18, -4),
             ((455, 880), (436, 930), 22, 16, 4), ((420, 850), (424, 905), 20, 14, -4), ((410, 810), (370, 846), 22, 16, -6),
             ((396, 770), (360, 730), 22, 16, 6), ((396, 700), (366, 672), 20, 15, -4), ((410, 665), (386, 580), 26, 20, -14),
             ((470, 650), (440, 612), 18, 14, 4), ((520, 672), (548, 628), 18, 14, -4)]
    for (bs, tp, w, t, bd) in fangs:
        g.append(shard(bs, tp, w, t, bend=bd, n=4, tones=(0, 1, 1, 0)))
    # overlapping scutes on both faces
    scutes = [((505, 692), 44, 0.3), ((548, 738), 46, -0.2), ((505, 786), 44, 0.4), ((468, 832), 40, 0.1),
              ((418, 776), 40, -0.3), ((430, 730), 30, 0.2), ((556, 690), 34, 0.0)]
    for sgn in (1, -1):
        for (cc, sz, rot) in scutes:
            ca, sa = np.cos(rot), np.sin(rot)
            kite = [(0, -sz * 0.7), (sz * 0.62, -sz * 0.1), (sz * 0.35, sz * 0.8), (-sz * 0.35, sz * 0.8), (-sz * 0.62, -sz * 0.1)]
            kp = [(cc[0] + x * ca - y * sa, cc[1] + x * sa + y * ca) for x, y in kite]
            sp, _ = plate(kp, cc, 13, k=0.55, z0=sgn * 36.0, tones=(1, 0), sides=(1, -1))
            g.append(sp)
    # collar plate along grip into guard
    g.append(curve_stroke([(488, 392), (503, 455), (522, 522)], [24, 27, 8], [14, 17, 6], n=6))
    parts["Guard"].append((M_IVORY, cat(*g)))
    if crater is not None:
        parts["Guard"].append((M_BLACK, crater))

    # ---------------- grip (purple-grey)
    core, scales = grip((467, 236), (494, 404), 33, 27, rows=10, N=8, lift=3.0)
    parts["Grip"].append((M_GPURP, cat(core, scales)))

    # ---------------- pommel: crescent tail claw + sideways hook
    pc = curve_stroke([(452, 232), (440, 130), (470, 62), (540, 16)], [27, 30, 20, 0], [17, 19, 12, 0], n=11)
    hook = shard((452, 205), (512, 246), 13, 8, bend=10)
    parts["Pommel"].append((M_POMMEL, cat(pc, hook)))
    return parts
